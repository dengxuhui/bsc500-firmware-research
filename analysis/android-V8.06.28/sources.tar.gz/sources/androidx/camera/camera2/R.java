package androidx.camera.camera2;

/* JADX INFO: loaded from: classes.dex */
public final class R {
    private R() {
    }
}
