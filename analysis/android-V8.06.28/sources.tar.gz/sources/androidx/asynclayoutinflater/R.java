package androidx.asynclayoutinflater;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static final int alpha = 0x7f04003a;
        public static final int font = 0x7f0402cb;
        public static final int fontProviderAuthority = 0x7f0402cd;
        public static final int fontProviderCerts = 0x7f0402ce;
        public static final int fontProviderFetchStrategy = 0x7f0402cf;
        public static final int fontProviderFetchTimeout = 0x7f0402d0;
        public static final int fontProviderPackage = 0x7f0402d1;
        public static final int fontProviderQuery = 0x7f0402d2;
        public static final int fontStyle = 0x7f0402d4;
        public static final int fontVariationSettings = 0x7f0402d5;
        public static final int fontWeight = 0x7f0402d6;
        public static final int ttcIndex = 0x7f0407d4;

        private attr() {
        }
    }

    public static final class color {
        public static final int notification_action_color_filter = 0x7f0603f9;
        public static final int notification_icon_bg_color = 0x7f0603fa;
        public static final int ripple_material_light = 0x7f060442;
        public static final int secondary_text_default_material_light = 0x7f060444;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7f0700b1;
        public static final int compat_button_inset_vertical_material = 0x7f0700b2;
        public static final int compat_button_padding_horizontal_material = 0x7f0700b3;
        public static final int compat_button_padding_vertical_material = 0x7f0700b4;
        public static final int compat_control_corner_material = 0x7f0700b5;
        public static final int compat_notification_large_icon_max_height = 0x7f0700b6;
        public static final int compat_notification_large_icon_max_width = 0x7f0700b7;
        public static final int notification_action_icon_size = 0x7f070413;
        public static final int notification_action_text_size = 0x7f070414;
        public static final int notification_big_circle_margin = 0x7f070415;
        public static final int notification_content_margin_start = 0x7f070416;
        public static final int notification_large_icon_height = 0x7f070417;
        public static final int notification_large_icon_width = 0x7f070418;
        public static final int notification_main_column_padding_top = 0x7f070419;
        public static final int notification_media_narrow_margin = 0x7f07041a;
        public static final int notification_right_icon_size = 0x7f07041b;
        public static final int notification_right_side_padding_top = 0x7f07041c;
        public static final int notification_small_icon_background_padding = 0x7f07041d;
        public static final int notification_small_icon_size_as_large = 0x7f07041e;
        public static final int notification_subtext_size = 0x7f07041f;
        public static final int notification_top_pad = 0x7f070420;
        public static final int notification_top_pad_large_text = 0x7f070421;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int notification_action_background = 0x7f080653;
        public static final int notification_bg = 0x7f080654;
        public static final int notification_bg_low = 0x7f080655;
        public static final int notification_bg_low_normal = 0x7f080656;
        public static final int notification_bg_low_pressed = 0x7f080657;
        public static final int notification_bg_normal = 0x7f080658;
        public static final int notification_bg_normal_pressed = 0x7f080659;
        public static final int notification_icon_background = 0x7f08065a;
        public static final int notification_template_icon_bg = 0x7f08065c;
        public static final int notification_template_icon_low_bg = 0x7f08065d;
        public static final int notification_tile_bg = 0x7f08065e;
        public static final int notify_panel_notification_icon_bg = 0x7f08065f;

        private drawable() {
        }
    }

    public static final class id {
        public static final int action_container = 0x7f0a0053;
        public static final int action_divider = 0x7f0a0055;
        public static final int action_image = 0x7f0a0056;
        public static final int action_text = 0x7f0a005c;
        public static final int actions = 0x7f0a005d;
        public static final int async = 0x7f0a0091;
        public static final int blocking = 0x7f0a00af;
        public static final int chronometer = 0x7f0a0156;
        public static final int forever = 0x7f0a02b5;
        public static final int icon = 0x7f0a0307;
        public static final int icon_group = 0x7f0a030a;
        public static final int info = 0x7f0a0336;
        public static final int italic = 0x7f0a0342;
        public static final int line1 = 0x7f0a048b;
        public static final int line3 = 0x7f0a048c;
        public static final int normal = 0x7f0a0690;
        public static final int notification_background = 0x7f0a0698;
        public static final int notification_main_column = 0x7f0a0699;
        public static final int notification_main_column_container = 0x7f0a069a;
        public static final int right_icon = 0x7f0a075c;
        public static final int right_side = 0x7f0a075e;
        public static final int tag_transition_group = 0x7f0a0927;
        public static final int tag_unhandled_key_event_manager = 0x7f0a0928;
        public static final int tag_unhandled_key_listeners = 0x7f0a0929;
        public static final int text = 0x7f0a092c;
        public static final int text2 = 0x7f0a092d;
        public static final int time = 0x7f0a094b;
        public static final int title = 0x7f0a0954;

        private id() {
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7f0b004c;

        private integer() {
        }
    }

    public static final class layout {
        public static final int notification_action = 0x7f0d02be;
        public static final int notification_action_tombstone = 0x7f0d02bf;
        public static final int notification_template_custom_big = 0x7f0d02c6;
        public static final int notification_template_icon_group = 0x7f0d02c7;
        public static final int notification_template_part_chronometer = 0x7f0d02cb;
        public static final int notification_template_part_time = 0x7f0d02cc;

        private layout() {
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7f130c3b;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7f14028d;
        public static final int TextAppearance_Compat_Notification_Info = 0x7f14028e;
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f140290;
        public static final int TextAppearance_Compat_Notification_Time = 0x7f140293;
        public static final int TextAppearance_Compat_Notification_Title = 0x7f140295;
        public static final int Widget_Compat_NotificationActionContainer = 0x7f140402;
        public static final int Widget_Compat_NotificationActionText = 0x7f140403;

        private style() {
        }
    }

    public static final class styleable {
        public static final int ColorStateListItem_alpha = 0x00000003;
        public static final int ColorStateListItem_android_alpha = 0x00000001;
        public static final int ColorStateListItem_android_color = 0x00000000;
        public static final int ColorStateListItem_android_lStar = 0x00000002;
        public static final int ColorStateListItem_lStar = 0x00000004;
        public static final int FontFamilyFont_android_font = 0x00000000;
        public static final int FontFamilyFont_android_fontStyle = 0x00000002;
        public static final int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static final int FontFamilyFont_android_fontWeight = 0x00000001;
        public static final int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static final int FontFamilyFont_font = 0x00000005;
        public static final int FontFamilyFont_fontStyle = 0x00000006;
        public static final int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static final int FontFamilyFont_fontWeight = 0x00000008;
        public static final int FontFamilyFont_ttcIndex = 0x00000009;
        public static final int FontFamily_fontProviderAuthority = 0x00000000;
        public static final int FontFamily_fontProviderCerts = 0x00000001;
        public static final int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static final int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static final int FontFamily_fontProviderPackage = 0x00000004;
        public static final int FontFamily_fontProviderQuery = 0x00000005;
        public static final int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static final int GradientColorItem_android_color = 0x00000000;
        public static final int GradientColorItem_android_offset = 0x00000001;
        public static final int GradientColor_android_centerColor = 0x00000007;
        public static final int GradientColor_android_centerX = 0x00000003;
        public static final int GradientColor_android_centerY = 0x00000004;
        public static final int GradientColor_android_endColor = 0x00000001;
        public static final int GradientColor_android_endX = 0x0000000a;
        public static final int GradientColor_android_endY = 0x0000000b;
        public static final int GradientColor_android_gradientRadius = 0x00000005;
        public static final int GradientColor_android_startColor = 0x00000000;
        public static final int GradientColor_android_startX = 0x00000008;
        public static final int GradientColor_android_startY = 0x00000009;
        public static final int GradientColor_android_tileMode = 0x00000006;
        public static final int GradientColor_android_type = 0x00000002;
        public static final int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, android.R.attr.lStar, com.qiwu.worldwide.ride.R.attr.alpha, com.qiwu.worldwide.ride.R.attr.lStar};
        public static final int[] FontFamily = {com.qiwu.worldwide.ride.R.attr.fontProviderAuthority, com.qiwu.worldwide.ride.R.attr.fontProviderCerts, com.qiwu.worldwide.ride.R.attr.fontProviderFetchStrategy, com.qiwu.worldwide.ride.R.attr.fontProviderFetchTimeout, com.qiwu.worldwide.ride.R.attr.fontProviderPackage, com.qiwu.worldwide.ride.R.attr.fontProviderQuery, com.qiwu.worldwide.ride.R.attr.fontProviderSystemFontFamily};
        public static final int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, com.qiwu.worldwide.ride.R.attr.font, com.qiwu.worldwide.ride.R.attr.fontStyle, com.qiwu.worldwide.ride.R.attr.fontVariationSettings, com.qiwu.worldwide.ride.R.attr.fontWeight, com.qiwu.worldwide.ride.R.attr.ttcIndex};
        public static final int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static final int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}
