
void FUN_60003100(undefined4 param_1,int param_2,int param_3,uint param_4,int param_5)

{
  longlong lVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  bool bVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  byte bVar15;
  uint uVar16;
  uint uVar17;
  ulonglong in_d0;
  uint uVar18;
  ulonglong uVar19;
  longlong lVar20;
  undefined8 uVar21;
  ulonglong uVar22;
  ulonglong uVar23;
  longlong lVar24;
  longlong lVar25;
  uint local_30;
  
  uVar2 = param_2 + 1;
  if (param_2 == 0) {
    uVar2 = 7;
  }
  iVar3 = FUN_60167bb6();
  if ((iVar3 == 0) && (iVar3 = FUN_60167ba8(), iVar3 == 0)) {
    uVar19 = FUN_601682c8();
    bVar10 = true;
  }
  else {
    iVar3 = FUN_60167b9a();
    iVar4 = FUN_60167bc4();
    bVar10 = iVar3 != 0 && iVar4 != 0;
    uVar19 = FUN_601682c8();
    if (iVar3 == 0 || iVar4 == 0) {
      uVar19 = in_d0;
    }
  }
  uVar18 = (uint)(uVar19 >> 0x20);
  uVar11 = (uint)uVar19;
  uVar5 = (uVar18 & 0x7fffffff) >> 0x14;
  if (uVar5 == 0x7ff) {
    if ((param_3 != 0) && ((param_4 & 1) == 0)) {
      FUN_600ff010(param_1,param_3 + ((int)(param_4 << 0x1d | uVar18) >> 0x1f) + 0xfdU & 0xff,0);
    }
    if ((longlong)uVar19 < 0) {
      uVar6 = 0x2d;
    }
    else {
      if (-1 < (int)(param_4 << 0x1d)) goto LAB_6000336e;
      uVar6 = 0x2b;
    }
    FUN_60116830(param_1,uVar6);
LAB_6000336e:
    if (uVar11 == 0 && (uVar19 & 0xfffff00000000) == 0) {
      if (param_5 == 0) {
        FUN_60116830(param_1,0x69);
        FUN_60116830(param_1,0x6e);
        uVar6 = 0x66;
      }
      else {
        FUN_60116830(param_1,0x49);
        FUN_60116830(param_1,0x4e);
        uVar6 = 0x46;
      }
    }
    else if (param_5 == 0) {
      FUN_60116830(param_1,0x6e);
      FUN_60116830(param_1,0x61);
      uVar6 = 0x6e;
    }
    else {
      FUN_60116830(param_1,0x4e);
      FUN_60116830(param_1,0x41);
      uVar6 = 0x4e;
    }
    FUN_60116830(param_1,uVar6);
    return;
  }
  uVar17 = 0x33 - (uVar18 >> 0x14);
  uVar13 = 0;
  uVar7 = 0;
  if ((uVar11 != 0 || (uVar19 & 0xfffff00000000) != 0) || uVar5 != 0) {
    uVar13 = (uVar18 & 0xfffff) + 0x100000;
    uVar7 = uVar11;
  }
  uVar5 = uVar17 & 0xff;
  if (0x40 < uVar5) {
    return;
  }
  lVar20 = FUN_60158804(uVar7,uVar13,uVar5);
  uVar21 = FUN_60158128((int)lVar20,(int)((ulonglong)lVar20 >> 0x20),uVar5);
  uVar13 = uVar13 & ~(uint)((ulonglong)uVar21 >> 0x20);
  iVar3 = 0;
  for (uVar7 = uVar7 & ~(uint)uVar21; (uVar7 != 0 || uVar13 != 0 && ((uVar7 & 1) == 0));
      uVar7 = (uint)(uVar5 != 0) << 0x1f | uVar7 >> 1) {
    uVar5 = uVar13 & 1;
    uVar13 = uVar13 >> 1;
    iVar3 = iVar3 + 1;
  }
  uVar11 = 0;
  uVar5 = 1;
  for (bVar15 = 0; (uint)bVar15 < (uVar2 & 0xff); bVar15 = bVar15 + 1) {
    uVar22 = (ulonglong)uVar5;
    uVar5 = (uint)(uVar22 * 10);
    uVar11 = (int)(uVar22 * 10 >> 0x20) + uVar11 * 10;
  }
  uVar14 = (uint)((ulonglong)uVar11 * (ulonglong)uVar13);
  uVar16 = (uint)((ulonglong)uVar5 * (ulonglong)uVar7 >> 0x20);
  lVar25 = CONCAT44(uVar14,uVar16);
  lVar1 = (ulonglong)uVar5 * (ulonglong)uVar13;
  uVar8 = (uint)((ulonglong)lVar1 >> 0x20);
  lVar24 = lVar1 + lVar25;
  uVar9 = (uint)((ulonglong)lVar24 >> 0x20);
  lVar25 = (ulonglong)uVar11 * (ulonglong)uVar7 + lVar1 + lVar25;
  uVar12 = (uint)((ulonglong)uVar11 * (ulonglong)uVar7 >> 0x20);
  uVar17 = uVar17 - iVar3 & 0xff;
  uVar22 = FUN_60158128((int)((ulonglong)lVar25 >> 0x20),
                        (int)((ulonglong)uVar11 * (ulonglong)uVar13 >> 0x20) +
                        (uint)(CARRY4(uVar8,uVar14) ||
                              CARRY4(uVar8 + uVar14,(uint)CARRY4(uVar16,(uint)lVar1))) +
                        (uint)(CARRY4(uVar9,uVar12) ||
                              CARRY4(uVar9 + uVar12,
                                     (uint)CARRY4((uint)((ulonglong)uVar11 * (ulonglong)uVar7),
                                                  (uint)lVar24))),0x40 - uVar17);
  uVar23 = FUN_60158804((int)((ulonglong)uVar5 * (ulonglong)uVar7),(int)lVar25,uVar17);
  uVar22 = uVar22 | uVar23;
  lVar24 = FUN_60162a88((int)uVar22,(int)(uVar22 >> 0x20),10,0);
  lVar25 = lVar24 + 1;
  lVar1 = uVar22 + lVar24 * -10;
  if ((uint)-(int)((ulonglong)lVar1 >> 0x20) < (uint)((uint)lVar1 < 5)) {
    lVar25 = lVar24;
  }
  if ((bool)(lVar20 == 1 & bVar10)) {
    lVar20 = 0;
  }
  uVar22 = (ulonglong)lVar20 >> 0x20;
  iVar3 = (int)lVar20;
  local_30 = uVar2 - 1;
  if (10 < (local_30 & 0xff)) {
    uVar2 = uVar2 - 0xb;
    while( true ) {
      if ((uVar2 & 0xff) == 0) break;
      lVar25 = FUN_60162a88((int)lVar25,(int)((ulonglong)lVar25 >> 0x20),10,0);
      uVar2 = uVar2 - 1;
    }
    local_30 = 10;
  }
  bVar15 = 0;
  while( true ) {
    if (lVar20 == 0) break;
    lVar20 = FUN_60162a88((int)lVar20,(int)((ulonglong)lVar20 >> 0x20),10,0);
    bVar15 = bVar15 + 1;
  }
  if (((int)lVar25 == 0 && iVar3 == 0) &&
      ((int)((ulonglong)lVar25 >> 0x20) == 0 && (int)uVar22 == 0)) {
    bVar15 = 1;
  }
  if (bVar15 == 0) {
    bVar15 = 1;
  }
  if (((param_3 != 0) && ((param_4 & 1) == 0)) &&
     (uVar2 = ((~((param_4 << 0x1d | uVar18) >> 0x1f) + param_3) - (local_30 & 0xff)) - (uint)bVar15
     , 0 < (int)uVar2)) {
    FUN_600ff010(param_1,uVar2 & 0xff,(param_4 & 3) >> 1);
  }
  if ((longlong)uVar19 < 0) {
    uVar6 = 0x2d;
  }
  else {
    if (-1 < (int)(param_4 << 0x1d)) goto LAB_60003468;
    uVar6 = 0x2b;
  }
  FUN_60116830(param_1,uVar6);
LAB_60003468:
  FUN_6011140c(param_1,iVar3,0,0,0);
  FUN_60116830(param_1,0x2e);
  FUN_6011140c(param_1,(int)lVar25,local_30 & 0xff,0,0);
  if ((((param_4 & 1) != 0) && (param_3 != 0)) &&
     (uVar2 = ((~((param_4 << 0x1d | uVar18) >> 0x1f) + param_3) - (local_30 & 0xff)) - (uint)bVar15
     , 0 < (int)uVar2)) {
    FUN_600ff010(param_1,uVar2 & 0xff,0);
    return;
  }
  return;
}
