
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x600347a4 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

int FUN_600341d0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                undefined4 param_5,undefined4 param_6,undefined4 param_7,int param_8,int param_9,
                undefined4 param_10,int param_11,int param_12,int param_13)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int *piVar11;
  undefined4 uVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  bool bVar16;
  int iVar17;
  int iVar18;
  float *pfVar19;
  int iVar20;
  bool bVar21;
  uint in_fpscr;
  float fVar22;
  float fVar23;
  float fVar24;
  float fVar25;
  float fVar26;
  undefined8 uVar27;
  undefined8 uVar28;
  uint local_b8;
  int *local_b4;
  int *local_b0;
  undefined8 local_80;
  undefined1 local_78 [8];
  undefined1 local_70 [8];
  undefined1 local_68 [8];
  undefined1 local_60 [8];
  undefined1 local_58 [8];
  
  if (iRam2000af54 == 0) {
    FUN_6011fff0("Finding Middle Route: Super-Nodes checked = 0");
  }
  iVar17 = *(int *)(param_12 + 0x20);
  if (iVar17 + 0x10000U < 0xffff) {
    FUN_60133d58(iVar17,local_58,local_60);
  }
  else {
    FUN_60136908(param_7,iVar17,0,local_58);
  }
  iVar17 = *(int *)(param_13 + 0x28);
  if (iVar17 + 0x10000U < 0xffff) {
    FUN_60133d58(iVar17,local_68,local_70);
  }
  else {
    FUN_60136908(param_7,iVar17,0,local_68);
  }
  iVar17 = FUN_60125e9c(0x14);
  if (iVar17 == 0) {
    return 0;
  }
  iVar2 = FUN_60125de2(0xc);
  if (iVar2 == 0) goto LAB_600343ee;
  iVar3 = FUN_60125de2(0xc);
  if (iVar3 != 0) {
    if (*(int *)(param_12 + 8) == 1) {
      if (*(int *)(param_12 + 0x24) == -1) {
        iVar4 = -1;
      }
      else {
        iVar4 = FUN_6011f7a4(param_7,param_8,param_9);
      }
      local_b0 = (int *)FUN_60125f94(iVar17,*(undefined4 *)(param_12 + 0x20),iVar4);
      if ((local_b0 == (int *)0x0) || (FUN_60125f04(0,iVar2), *(int *)(iVar2 + 0xc) == 0)) {
        FUN_60125a74(iVar3);
        goto LAB_600343e8;
      }
      fVar24 = 1e+30;
      if (iVar4 != -1) {
        iVar4 = FUN_60125d50(param_7,*(undefined4 *)(param_12 + 0x20),1);
        bVar21 = (*(ushort *)(iVar4 + 8) & *(ushort *)(param_11 + 0x78)) != 0;
        local_b4 = (int *)0x0;
        goto LAB_600344bc;
      }
    }
    else {
      piVar5 = (int *)FUN_600f8dc0(param_12);
      fVar24 = 1e+30;
      local_b4 = (int *)0x0;
LAB_600342ba:
      piVar5 = (int *)FUN_600f9e80(param_12,piVar5);
      if (piVar5 != (int *)0x0) {
        if ((0xfffe < *piVar5 + 0x10000U) &&
           (iVar4 = FUN_60125d50(param_7,*piVar5,3), 0x7fffffff < (uint)(int)*(short *)(iVar4 + 10))
           ) {
          iVar4 = FUN_6011f7a4(param_7,param_8,param_9,param_11);
          if (iVar4 != piVar5[1]) {
            iVar20 = FUN_60125f94(iVar17,*piVar5);
            if (iVar20 != 0) {
              *(int *)(iVar20 + 0x10) = piVar5[4];
              goto LAB_6003431a;
            }
LAB_60034402:
            FUN_60125a74(iVar3);
            goto LAB_600343e8;
          }
          iVar20 = -1;
LAB_6003431a:
          piVar7 = (int *)FUN_6012726c(iVar17,*piVar5,iVar4);
          if (piVar7 == (int *)0x0) {
            piVar7 = (int *)FUN_60125f94(iVar17,*piVar5,iVar4);
            if (piVar7 == (int *)0x0) goto LAB_60034402;
            piVar7[2] = iVar20;
            piVar7[4] = piVar5[4];
          }
          else {
            fVar26 = (float)piVar5[4];
            uVar10 = in_fpscr & 0xfffffff | (uint)(fVar26 < (float)piVar7[4]) << 0x1f;
            in_fpscr = uVar10 | (uint)(NAN(fVar26) || NAN((float)piVar7[4])) << 0x1c;
            if ((byte)(uVar10 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1)) goto LAB_600342ba;
            piVar7[4] = (int)fVar26;
            piVar7[2] = iVar20;
          }
          iVar4 = FUN_6012726c(param_13,*piVar7,piVar7[1]);
          if (iVar4 != 0) {
            fVar26 = (float)piVar7[4] + *(float *)(iVar4 + 0x10);
            uVar10 = in_fpscr & 0xfffffff | (uint)(fVar26 < fVar24) << 0x1f;
            in_fpscr = uVar10 | (uint)(NAN(fVar26) || NAN(fVar24)) << 0x1c;
            if ((byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) {
              fVar24 = fVar26;
              local_b4 = piVar7;
            }
          }
        }
        goto LAB_600342ba;
      }
      local_b0 = local_b4;
      if (local_b4 != (int *)0x0) {
        bVar21 = true;
        goto LAB_600344bc;
      }
      for (iVar4 = FUN_600f8dc0(iVar17); iVar4 != 0; iVar4 = FUN_600f9e80(iVar17,iVar4)) {
        if ((*(int *)(iVar4 + 8) != 0) &&
           (FUN_60125f04(*(undefined4 *)(iVar4 + 0x10),iVar2,iVar4), *(int *)(iVar2 + 0xc) == 0))
        goto LAB_600344a4;
      }
      for (piVar5 = (int *)FUN_600f8dc0(param_13); piVar5 != (int *)0x0;
          piVar5 = (int *)FUN_600f9e80(param_13,piVar5)) {
        if ((0xfffe < *piVar5 + 0x10000U) &&
           (iVar4 = FUN_60125d50(param_7,*piVar5,3), 0x7fffffff < (uint)(int)*(short *)(iVar4 + 10))
           ) {
          iVar4 = FUN_60125f94(iVar17,*piVar5,piVar5[1]);
          if (iVar4 == 0) goto LAB_600344a4;
          *(undefined4 *)(iVar4 + 0xc) = 0xffffffff;
          *(int *)(iVar4 + 0x10) = piVar5[4];
          FUN_60125f04(0,iVar3);
          if (*(int *)(iVar3 + 0xc) == 0) goto LAB_600344a4;
        }
      }
    }
    local_b4 = (int *)0x0;
    bVar21 = true;
LAB_600344bc:
    local_b8 = 0;
LAB_600344d2:
    do {
      if (iRam2000af50 != 0) goto LAB_60034c4e;
      piVar5 = (int *)FUN_60125c90(iVar2);
      if (piVar5 == (int *)0x0) {
        bVar16 = true;
      }
      else {
        uVar10 = in_fpscr & 0xfffffff | (uint)((float)piVar5[4] < fVar24) << 0x1f;
        in_fpscr = uVar10 | (uint)(NAN((float)piVar5[4]) || NAN(fVar24)) << 0x1c;
        if ((byte)(uVar10 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1)) goto LAB_600344d2;
        iVar20 = *piVar5;
        iVar4 = piVar5[1];
        puVar6 = (undefined4 *)FUN_60125d50(param_7,iVar20,1);
        if ((*(int *)(param_11 + 0x70) == 0) ||
           (-1 < (int)((uint)*(ushort *)((int)puVar6 + 10) << 0x13))) {
          iVar18 = -1;
        }
        else {
          iVar18 = FUN_6011fe5c(param_10,iVar20,iVar4);
        }
        for (piVar7 = (int *)FUN_601264ba(param_8,*puVar6,1); fVar26 = fVar24, piVar7 != (int *)0x0;
            piVar7 = (int *)FUN_60125c46(param_8,piVar7,iVar20)) {
          iVar8 = piVar7[4];
          if (iVar8 << 3 < 0) {
            if (*(int *)(param_11 + 0x6c) != 0) {
              if (*piVar7 == iVar20) {
                iVar8 = iVar8 << 2;
              }
              else {
                iVar8 = iVar8 << 1;
              }
              if ((iVar8 < 0) &&
                 ((*(short *)(param_11 + 0x78) != 8 ||
                  (iVar8 = FUN_60125bc4(param_9,piVar7[3],1),
                  -1 < (int)((uint)*(byte *)(iVar8 + 6) << 0x1b))))) goto LAB_60034696;
            }
            iVar8 = *(int *)(param_8 + (((int)piVar7 - (param_8 + 0x10)) / 0x14) * 4 + 0x60);
            if ((bVar21) || (iVar20 != *(int *)(param_12 + 0x20))) {
              if (iVar4 != iVar8) goto LAB_600345c6;
            }
            else if (iVar8 == piVar5[1]) {
LAB_600345c6:
              if ((((((iVar18 == -1) ||
                     (iVar9 = FUN_6011ff10(param_10,iVar18,iVar20,iVar4), iVar9 != 0)) &&
                    (iVar9 = FUN_60125bc4(param_9,piVar7[3],1),
                    (*(ushort *)(param_11 + 0x78) & *(ushort *)(iVar9 + 4)) != 0)) &&
                   ((*(byte *)(iVar9 + 9) == 0 ||
                    (*(byte *)(param_11 + 0x74) <= *(byte *)(iVar9 + 9))))) &&
                  ((*(byte *)(iVar9 + 10) == 0 ||
                   (*(byte *)(param_11 + 0x75) <= *(byte *)(iVar9 + 10))))) &&
                 (((*(byte *)(iVar9 + 0xb) == 0 ||
                   (*(byte *)(param_11 + 0x76) <= *(byte *)(iVar9 + 0xb))) &&
                  ((*(byte *)(iVar9 + 0xc) == 0 ||
                   (*(byte *)(param_11 + 0x77) <= *(byte *)(iVar9 + 0xc))))))) {
                fVar26 = *(float *)(param_11 + (*(byte *)(iVar9 + 6) & 0xf) * 4 + 8);
                uVar10 = in_fpscr & 0xfffffff;
                in_fpscr = uVar10 | (uint)(fVar26 == 0.0) << 0x1e;
                if ((byte)(in_fpscr >> 0x1e) == 0) {
                  iVar13 = 1;
                  for (iVar14 = -0x18; iVar14 != 0; iVar14 = iVar14 + 4) {
                    uVar15 = 1 << (iVar13 - 1U & 0xff);
                    if ((uVar15 & *(byte *)(param_9 + 8)) != 0) {
                      pfVar19 = (float *)(param_11 + iVar14 + 0x98);
                      if ((uVar15 & *(byte *)(iVar9 + 7)) == 0) {
                        pfVar19 = (float *)(param_11 + iVar14 + 0xb4);
                      }
                      fVar26 = fVar26 * *pfVar19;
                    }
                    iVar13 = iVar13 + 1;
                  }
                  in_fpscr = uVar10 | (uint)(fVar26 == 0.0) << 0x1e;
                  if ((byte)(in_fpscr >> 0x1e) == 0) {
                    iVar13 = *piVar7;
                    if (iVar13 == iVar20) {
                      iVar13 = piVar7[1];
                    }
                    iVar14 = FUN_60125d50(param_7,iVar13,2);
                    if ((iVar13 == *(int *)(param_13 + 0x28)) ||
                       ((*(ushort *)(param_11 + 0x78) & *(ushort *)(iVar14 + 8)) != 0)) {
                      if (iRam2007d268 == 0) {
                        uVar10 = piVar7[4] & 0x7ffffff;
                      }
                      else {
                        uVar10 = FUN_60120128(piVar7,iVar9,param_11);
                      }
                      fVar22 = (float)VectorUnsignedToFloat(uVar10,(byte)(in_fpscr >> 0x16) & 3);
                      fVar26 = (float)piVar5[4] + fVar22 / fVar26;
                      uVar10 = in_fpscr & 0xfffffff | (uint)(fVar26 < fVar24) << 0x1f;
                      in_fpscr = uVar10 | (uint)(NAN(fVar26) || NAN(fVar24)) << 0x1c;
                      if ((byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) {
                        piVar11 = (int *)FUN_6012726c(iVar17,iVar13,iVar8);
                        if (piVar11 == (int *)0x0) {
                          piVar11 = (int *)FUN_60125f94(iVar17,iVar13,iVar8);
                          if (piVar11 != (int *)0x0) {
LAB_6003477e:
                            piVar11[2] = (int)piVar5;
                            piVar11[4] = (int)fVar26;
                            FUN_60136908(param_7,iVar13,iVar14,local_78);
                            uVar15 = FUN_601335f0(local_78._0_4_,param_2,(int)local_80,param_4,
                                                  local_68._0_4_,param_6,local_70._0_4_);
                            uVar10 = uVar15;
                            if (((local_b8 != 0) && (uVar10 = local_b8, uVar15 <= local_b8)) &&
                               (local_b8 = ((local_b8 - uVar15) * 100) / local_b8,
                               (uint)bRam2000af4c < (local_b8 & 0xff))) {
                              bRam2000af4c = (byte)local_b8;
                            }
                            fVar26 = (float)piVar11[4];
                            if (iRam2007d268 != 0) {
                              uVar27 = FUN_601673c4();
                              uVar28 = FUN_601673c4(*(undefined1 *)(param_11 + 0xb8));
                              uVar27 = FUN_601675d8((int)uVar27,(int)((ulonglong)uVar27 >> 0x20),
                                                    (int)uVar28,(int)((ulonglong)uVar28 >> 0x20));
                              FUN_601678fc((int)uVar27,(int)((ulonglong)uVar27 >> 0x20),0,0x40420000
                                          );
                              uVar15 = FUN_6015e530();
                            }
                            fVar22 = (float)VectorUnsignedToFloat
                                                      (uVar15,(byte)(in_fpscr >> 0x16) & 3);
                            fVar26 = fVar26 + fVar22 / *(float *)(param_11 + 0xb4);
                            uVar15 = in_fpscr & 0xfffffff | (uint)(fVar26 < fVar24) << 0x1f;
                            in_fpscr = uVar15 | (uint)(NAN(fVar26) || NAN(fVar24)) << 0x1c;
                            local_b8 = uVar10;
                            if (((byte)(uVar15 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1)) ||
                               (FUN_60125f04(iVar2,piVar11), *(int *)(iVar2 + 0xc) != 0))
                            goto LAB_60034696;
                          }
                          FUN_60125a74(iVar3);
                          goto LAB_60034cf6;
                        }
                        fVar22 = (float)piVar11[4];
                        if (piVar11[3] == 0) {
                          uVar10 = in_fpscr & 0xfffffff | (uint)(fVar26 < fVar22) << 0x1f;
                          in_fpscr = uVar10 | (uint)(NAN(fVar26) || NAN(fVar22)) << 0x1c;
                          if ((byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1))
                          goto LAB_6003477e;
                        }
                        else {
                          fVar26 = fVar26 + fVar22;
                          uVar10 = in_fpscr & 0xfffffff | (uint)(fVar26 < fVar24) << 0x1f;
                          in_fpscr = uVar10 | (uint)(NAN(fVar26) || NAN(fVar24)) << 0x1c;
                          if (((byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) &&
                             (local_b4 = piVar11, local_b0 = piVar5, fVar24 = fVar26,
                             iRam20007dc4 != 0)) break;
                        }
                      }
                    }
                  }
                }
              }
            }
          }
LAB_60034696:
        }
        bVar16 = false;
        fVar24 = fVar26;
      }
      uVar10 = in_fpscr & 0xfffffff | (uint)(fVar24 < 5e+29) << 0x1f;
      in_fpscr = uVar10 | (uint)NAN(fVar24) << 0x1c;
      if (((byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) && (iRam20007dc4 != 0))
      goto LAB_60034c4e;
      piVar5 = (int *)FUN_60125c90(iVar3);
      if (piVar5 == (int *)0x0) {
        bVar1 = true;
      }
      else {
        uVar10 = in_fpscr & 0xfffffff | (uint)((float)piVar5[4] < fVar24) << 0x1f;
        in_fpscr = uVar10 | (uint)(NAN((float)piVar5[4]) || NAN(fVar24)) << 0x1c;
        if ((byte)(uVar10 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1)) goto LAB_600344d2;
        iVar4 = piVar5[1];
        iVar20 = *piVar5;
        piVar7 = (int *)FUN_601264ba(param_8,iVar4,1);
        iVar18 = *piVar7;
        if (iVar18 == iVar20) {
          iVar18 = piVar7[1];
        }
        puVar6 = (undefined4 *)FUN_60125d50(param_7,iVar18,1);
        if ((*(ushort *)(param_11 + 0x78) & *(ushort *)(puVar6 + 2)) == 0) goto LAB_600344d2;
        iVar9 = 1;
        iVar20 = FUN_60125bc4(param_9,piVar7[3],1);
        fVar26 = *(float *)(param_11 + (*(byte *)(iVar20 + 6) & 0xf) * 4 + 8);
        for (iVar8 = -0x18; iVar8 != 0; iVar8 = iVar8 + 4) {
          uVar10 = 1 << (iVar9 - 1U & 0xff);
          if ((uVar10 & *(byte *)(param_9 + 8)) != 0) {
            pfVar19 = (float *)(param_11 + iVar8 + 0x98);
            if ((uVar10 & *(byte *)(iVar20 + 7)) == 0) {
              pfVar19 = (float *)(param_11 + iVar8 + 0xb4);
            }
            fVar26 = fVar26 * *pfVar19;
          }
          iVar9 = iVar9 + 1;
        }
        if (iRam2007d268 == 0) {
          uVar10 = piVar7[4] & 0x7ffffff;
        }
        else {
          uVar10 = FUN_60120128(piVar7,iVar20,param_11);
        }
        piVar7 = (int *)FUN_601264ba(param_8,*puVar6,1);
        fVar23 = (float)VectorUnsignedToFloat(uVar10,(byte)(in_fpscr >> 0x16) & 3);
        fVar22 = fVar24;
        for (; fVar24 = fVar22, piVar7 != (int *)0x0;
            piVar7 = (int *)FUN_60125c46(param_8,piVar7,iVar18)) {
          iVar20 = *(int *)(param_8 + (((int)piVar7 - (param_8 + 0x10)) / 0x14) * 4 + 0x60);
          if (((iVar4 != iVar20) &&
              ((piVar11 = (int *)FUN_6012726c(iVar17,iVar18,iVar20),
               (int)((uint)*(byte *)((int)piVar7 + 0x13) << 0x1b) < 0 ||
               ((piVar11 != (int *)0x0 && (piVar11[2] != 0)))))) &&
             ((*(int *)(param_11 + 0x70) == 0 ||
              (((-1 < (int)((uint)*(ushort *)((int)puVar6 + 10) << 0x13) ||
                (iVar8 = FUN_6011fe5c(param_10,iVar18,iVar20), iVar8 == -1)) ||
               (iVar8 = FUN_6011ff10(param_10,iVar8,iVar18,iVar20), iVar8 != 0)))))) {
            if (*(int *)(param_11 + 0x6c) != 0) {
              if (piVar7[1] == iVar18) {
                iVar8 = piVar7[4] << 2;
              }
              else {
                iVar8 = piVar7[4] << 1;
              }
              if ((iVar8 < 0) &&
                 ((*(short *)(param_11 + 0x78) != 8 ||
                  (iVar8 = FUN_60125bc4(param_9,piVar7[3],1),
                  -1 < (int)((uint)*(byte *)(iVar8 + 6) << 0x1b))))) goto LAB_60034972;
            }
            iVar8 = FUN_60125bc4(param_9,piVar7[3],1);
            if ((((*(ushort *)(param_11 + 0x78) & *(ushort *)(iVar8 + 4)) != 0) &&
                ((((*(byte *)(iVar8 + 9) == 0 ||
                   (*(byte *)(param_11 + 0x74) <= *(byte *)(iVar8 + 9))) &&
                  ((*(byte *)(iVar8 + 10) == 0 ||
                   (*(byte *)(param_11 + 0x75) <= *(byte *)(iVar8 + 10))))) &&
                 ((*(byte *)(iVar8 + 0xb) == 0 ||
                  (*(byte *)(param_11 + 0x76) <= *(byte *)(iVar8 + 0xb))))))) &&
               ((*(byte *)(iVar8 + 0xc) == 0 ||
                (*(byte *)(param_11 + 0x77) <= *(byte *)(iVar8 + 0xc))))) {
              fVar24 = *(float *)(param_11 + (*(byte *)(iVar8 + 6) & 0xf) * 4 + 8);
              uVar10 = in_fpscr & 0xfffffff;
              in_fpscr = uVar10 | (uint)(fVar24 == 0.0) << 0x1e;
              if ((byte)(in_fpscr >> 0x1e) == 0) {
                iVar9 = 1;
                for (iVar13 = -0x18; iVar13 != 0; iVar13 = iVar13 + 4) {
                  uVar15 = 1 << (iVar9 - 1U & 0xff);
                  if ((uVar15 & *(byte *)(param_9 + 8)) != 0) {
                    pfVar19 = (float *)(param_11 + iVar13 + 0x98);
                    if ((uVar15 & *(byte *)(iVar8 + 7)) == 0) {
                      pfVar19 = (float *)(param_11 + iVar13 + 0xb4);
                    }
                    fVar24 = fVar24 * *pfVar19;
                  }
                  iVar9 = iVar9 + 1;
                }
                in_fpscr = uVar10 | (uint)(fVar24 == 0.0) << 0x1e;
                if ((byte)(in_fpscr >> 0x1e) == 0) {
                  iVar8 = *piVar7;
                  if (iVar8 == iVar18) {
                    iVar8 = piVar7[1];
                  }
                  fVar24 = fVar23 / fVar26 + (float)piVar5[4];
                  uVar15 = uVar10 | (uint)(fVar24 < fVar22) << 0x1f;
                  in_fpscr = uVar15 | (uint)(NAN(fVar24) || NAN(fVar22)) << 0x1c;
                  if ((byte)(uVar15 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) {
                    if (piVar11 == (int *)0x0) {
                      piVar11 = (int *)FUN_60125f94(iVar17,iVar18,iVar20);
                      if (piVar11 != (int *)0x0) {
                        piVar11[3] = (int)piVar5;
LAB_60034b34:
                        piVar11[4] = (int)fVar24;
                        uVar12 = FUN_60125d50(param_7,iVar8,2);
                        FUN_60136908(param_7,iVar8,uVar12,local_78);
                        uVar15 = FUN_601335f0(local_78._0_4_,param_2,(int)local_80,param_4,
                                              local_58._0_4_,param_6,local_60._0_4_);
                        uVar10 = uVar15;
                        if (((local_b8 != 0) && (uVar10 = local_b8, uVar15 <= local_b8)) &&
                           (local_b8 = ((local_b8 - uVar15) * 100) / local_b8,
                           (uint)bRam2000af4c < (local_b8 & 0xff))) {
                          bRam2000af4c = (byte)local_b8;
                        }
                        fVar24 = (float)piVar11[4];
                        if (iRam2007d268 != 0) {
                          uVar27 = FUN_601673c4();
                          uVar28 = FUN_601673c4(*(undefined1 *)(param_11 + 0xb8));
                          uVar27 = FUN_601675d8((int)uVar27,(int)((ulonglong)uVar27 >> 0x20),
                                                (int)uVar28,(int)((ulonglong)uVar28 >> 0x20));
                          FUN_601678fc((int)uVar27,(int)((ulonglong)uVar27 >> 0x20),0,0x40420000);
                          uVar15 = FUN_6015e530();
                        }
                        fVar25 = (float)VectorUnsignedToFloat(uVar15,(byte)(in_fpscr >> 0x16) & 3);
                        fVar24 = fVar24 + fVar25 / *(float *)(param_11 + 0xb4);
                        uVar15 = in_fpscr & 0xfffffff | (uint)(fVar24 < fVar22) << 0x1f;
                        in_fpscr = uVar15 | (uint)(NAN(fVar24) || NAN(fVar22)) << 0x1c;
                        local_b8 = uVar10;
                        if (((byte)(uVar15 >> 0x1f) == ((byte)(in_fpscr >> 0x1c) & 1)) ||
                           (FUN_60125f04(iVar3,piVar11), *(int *)(iVar3 + 0xc) != 0))
                        goto LAB_60034972;
                      }
                      FUN_60125a74(iVar3);
LAB_60034cf6:
                      FUN_60125a74(iVar2);
                      goto LAB_600343ee;
                    }
                    fVar25 = (float)piVar11[4];
                    if (piVar11[2] == 0) {
                      uVar10 = uVar10 | (uint)(fVar24 < fVar25) << 0x1f;
                      in_fpscr = uVar10 | (uint)(NAN(fVar24) || NAN(fVar25)) << 0x1c;
                      if ((byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) {
                        piVar11[3] = (int)piVar5;
                        goto LAB_60034b34;
                      }
                    }
                    else {
                      fVar24 = fVar24 + fVar25;
                      uVar10 = uVar10 | (uint)(fVar24 < fVar22) << 0x1f;
                      in_fpscr = uVar10 | (uint)(NAN(fVar24) || NAN(fVar22)) << 0x1c;
                      if (((byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) &&
                         (local_b4 = piVar5, local_b0 = piVar11, fVar22 = fVar24, iRam20007dc4 != 0)
                         ) break;
                    }
                  }
                }
              }
            }
          }
LAB_60034972:
        }
        bVar1 = false;
      }
      uVar10 = in_fpscr & 0xfffffff | (uint)(fVar24 < 5e+29) << 0x1f;
      in_fpscr = uVar10 | (uint)NAN(fVar24) << 0x1c;
      if ((bVar1 || bVar16) ||
         (iRam20007dc4 != 0 && (byte)(uVar10 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)))
      goto LAB_60034c4e;
    } while( true );
  }
LAB_600343e8:
  FUN_60125a74(iVar2);
LAB_600343ee:
  FUN_60127138(iVar17);
  return 0;
LAB_600344a4:
  FUN_60125a74(iVar3);
  goto LAB_600343e8;
LAB_60034c4e:
  FUN_60125a74(iVar2);
  FUN_60125a74(iVar3);
  if (iRam2000af50 == 0) {
    if (local_b4 != (int *)0x0) {
      piVar5 = local_b0;
      if (local_b0 != local_b4) {
        local_b4[2] = (int)local_b0;
        local_b0[3] = (int)local_b4;
        do {
          piVar5 = local_b0;
          local_b0 = (int *)piVar5[2];
        } while (1 < piVar5[2] + 1U);
        FUN_6011ffe0(local_b4);
        local_b0 = piVar5;
        if ((piVar5[2] == 0) && (local_b0 = (int *)piVar5[3], (int *)piVar5[3] == (int *)0x0)) {
          local_b0 = piVar5;
        }
        do {
          piVar7 = local_b4 + 3;
          piVar5 = local_b4;
          local_b4 = (int *)*piVar7;
        } while (1 < *piVar7 + 1U);
      }
      iVar2 = local_b0[1];
      *(int *)(iVar17 + 0x20) = *local_b0;
      *(int *)(iVar17 + 0x24) = iVar2;
      iVar2 = piVar5[1];
      *(int *)(iVar17 + 0x28) = *piVar5;
      *(int *)(iVar17 + 0x2c) = iVar2;
      if (iRam2000af54 == 0) {
        FUN_60120034("Found Middle Route: Super-Nodes checked = %d",*(undefined4 *)(iVar17 + 8));
        return iVar17;
      }
      return iVar17;
    }
    if (iRam2000af54 == 0) {
      FUN_60120034("Found Middle Route: Super-Nodes checked = %d - Fail",*(undefined4 *)(iVar17 + 8)
                  );
    }
  }
  else {
    FUN_60149068("    Aborted.");
  }
  goto LAB_600343ee;
}
