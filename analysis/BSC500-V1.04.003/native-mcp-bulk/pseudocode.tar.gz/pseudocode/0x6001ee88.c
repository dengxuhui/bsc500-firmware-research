
/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_6001ee88(int param_1,int param_2,int param_3,int param_4)

{
  byte bVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int *piVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  uint uVar15;
  int iVar16;
  int iVar17;
  uint uVar18;
  uint uVar19;
  uint uVar20;
  bool bVar21;
  int local_e8;
  int local_e0;
  undefined4 local_d8;
  int local_cc;
  uint local_b4;
  undefined4 local_a8;
  undefined4 uStack_a4;
  undefined4 local_a0;
  undefined4 uStack_9c;
  undefined4 local_98;
  undefined4 uStack_94;
  undefined4 local_90;
  undefined4 uStack_8c;
  int local_88;
  int local_84 [4];
  int local_74;
  uint local_70;
  uint local_6c;
  uint local_68;
  uint local_64;
  int local_60;
  uint local_5c;
  uint uStack_58;
  undefined1 auStack_54 [32];
  int local_34;
  undefined2 local_30;
  byte local_2e;
  byte local_2d;
  byte local_2c;
  uint local_28;
  
  iVar16 = iRam20085890;
  local_e0 = iRam2008588c;
  iVar17 = *(int *)(param_4 + 0x160);
  local_70 = 0x20;
  local_5c = 0;
  uStack_58 = 0;
  local_84[1] = 0;
  local_84[2] = 0;
  local_88 = 0;
  local_84[0] = 0;
  local_90 = 0;
  uStack_8c = 0;
  local_98 = 0;
  uStack_94 = 0;
  local_a0 = 0;
  uStack_9c = 0;
  local_a8 = 0;
  uStack_a4 = 0;
  local_d8 = 0xffffffff;
  if ((param_1 != 0) && (iVar17 != 0)) {
    uVar3 = FUN_601668a4(0xffffffff);
    iVar4 = FUN_6015cbf2(iVar17);
    FUN_60161ef4(iVar17,0x60c7e740,0x1fa0,local_84 + 1);
    iVar13 = 0;
    iVar5 = param_4 + (uint)((uVar3 | 2) != 2) * 0x18;
    local_b4 = 0;
    for (uVar3 = 0; uVar3 < ((uint)*(byte *)(iVar5 + 0x12a) - (uint)*(byte *)(iVar5 + 0x129)) + 1;
        uVar3 = uVar3 + 1) {
      iVar6 = FUN_6015a168(&uStack_58,iVar13 + 0x60c7e740);
      iVar7 = FUN_6015a168(&local_5c,iVar13 + iVar6 + 0x60c7e740);
      iVar13 = iVar13 + iVar6 + iVar7;
      local_b4 = local_b4 + local_5c;
    }
    bVar21 = 9999 < uStack_58;
    if (uStack_58 < 0x2711) {
      bVar21 = 10000 < local_5c;
    }
    if (bVar21) {
      if (iRam2004970c == 0) {
        FUN_60168578("map:[poi %d][ways %d]\n");
        iRam2004970c = 1;
      }
LAB_6001f51a:
      local_d8 = 0xffffffff;
    }
    else {
      iVar5 = FUN_6015a168(&local_60,iVar13 + 0x60c7e740);
      FUN_60163c98(iVar17,local_60 + iVar5 + iVar13 + iVar4);
      local_cc = FUN_6015cbf2(iVar17);
      ZeroBytes(0x60c7e740,0x1fa0);
      local_d8 = FUN_60161ef4(iVar17,0x60c7e740,0x1fa0,local_84 + 1);
      iVar13 = 5;
      iVar4 = 5;
      iVar5 = 0;
      if (param_2 < 0) {
        iVar13 = -5;
      }
      if (param_3 < 0) {
        iVar4 = -5;
      }
      for (uVar3 = 0; uVar3 != local_b4; uVar3 = uVar3 + 1) {
        if (*(char *)(param_4 + 0x8a) < '\0') {
          iVar5 = iVar5 + 0x20;
        }
        iVar6 = FUN_6015a168(&local_34,iVar5 + 0x60c7e740);
        if (uRam20008304 < (uint)(local_34 + iVar16)) break;
        iVar6 = iVar5 + iVar6;
        iVar7 = iVar6 + local_34;
        if (local_34 + 2U < 0x1fa0) {
          if (0x1f9f < iVar7 + 2U) {
            local_cc = local_cc + iVar5;
            FUN_60163c98(iVar17,local_cc);
            ZeroBytes(0x60c7e740,0x1fa0);
            local_d8 = FUN_60161ef4(iVar17,0x60c7e740,0x1fa0,local_84 + 1);
            uVar14 = *(byte *)(param_4 + 0x8a) >> 2 & 0x20;
            iVar6 = FUN_6015a168(&local_34,uVar14 + 0x60c7e740);
            iVar6 = iVar6 + uVar14;
            iVar7 = iVar6 + local_34;
            if (0x1f9f < local_34 + 2U) {
              local_cc = local_cc + iVar6 + local_34;
              FUN_60163c98(iVar17,local_cc);
              ZeroBytes(0x60c7e740,0x1fa0);
              local_d8 = FUN_60161ef4(iVar17,0x60c7e740,0x1fa0,local_84 + 1);
              iVar5 = 0;
              goto LAB_6001f1ce;
            }
          }
          iVar5 = iVar7;
          local_30 = FUN_6015bd50(iVar6 + 0x60c7e740);
          local_2e = *(byte *)(iVar6 + 0x60c7e742);
          uVar14 = 0xff;
          iVar6 = iVar6 + 3;
          local_2d = 0xff;
          for (uVar15 = 0; uVar15 < (local_2e & 0xf); uVar15 = uVar15 + 1) {
            iVar7 = FUN_6015a168(&local_64,iVar6 + 0x60c7e740);
            iVar6 = iVar6 + iVar7;
            uVar14 = (uint)local_2d;
            if ((uVar14 == 0xff) && (local_64 < 0x85)) {
              if (*(char *)(param_4 + local_64 + 0x9e) == -1) {
                uVar14 = 0xff;
              }
              else {
                uVar14 = local_64 & 0xff;
                local_2d = (byte)local_64;
              }
            }
          }
          if (uVar14 < 0x85) {
            uVar14 = FUN_60032f14(*(undefined1 *)(uVar14 + param_4 + 0x9e));
            if (((uVar14 < 0xe) && (uVar14 < 7 || local_b4 < 0x7d1)) &&
               (iVar7 = uVar14 * 4, *(uint *)(iVar7 + 0x200858d4) < 3000)) {
              local_2c = *(byte *)(iVar6 + 0x60c7e740);
              uVar15 = (local_2c & 7) >> 2;
              if (((uVar14 - 3 < 3) && ((char)local_2c < '\0')) ||
                 (((int)((uint)local_2c << 0x1a) < 0 && (uVar14 - 3 < 3)))) {
                FUN_6015a168(&local_70,iVar6 + 0x60c7e741);
                if (0x1f < local_70) {
                  local_70 = 0x1f;
                }
                uVar19 = local_70;
                FUN_60167214(auStack_54 + local_70,0x20 - local_70);
                CopyBytes(auStack_54,iVar6 + 0x60c7e742,uVar19);
                CopyBytes(0x60ca2742,auStack_54,uVar19);
              }
              else {
                uVar19 = 0;
                local_70 = 0;
              }
              iVar12 = uVar19 + 2;
              bVar1 = (byte)uVar14 | (byte)(uVar15 << 7);
              uRam60ca2741 = (undefined1)uVar19;
              *(byte *)(uVar19 + 0x60ca2742) = bVar1;
              iVar5 = FUN_60032fb0(iVar6 + 0x60c7e741,local_2c);
              iVar5 = iVar5 + iVar6 + 1;
              if ((int)((uint)local_2c << 0x1c) < 0) {
                iVar6 = FUN_6015a168(&local_28,iVar5 + 0x60c7e740);
                if (100 < local_28) {
                  if (iRam2004970c == 0) {
                    FUN_60168578("map:[way_data_blocks %d]\n");
                    iRam2004970c = 1;
                  }
                  iRam2008588c = local_e0;
                  iRam20085890 = iVar16;
                  goto LAB_6001f51a;
                }
                iVar5 = iVar5 + iVar6;
              }
              else {
                local_28 = 1;
              }
              piVar8 = (int *)(iVar7 + 0x200858d4);
              local_e8 = 0;
              for (uVar14 = 0; uVar19 = local_70, uVar14 < local_28; uVar14 = uVar14 + 1) {
                if (uVar14 != 0) {
                  if (local_70 != 0) {
                    CopyBytes(local_e8 + 0x60ca2742,auStack_54,local_70);
                  }
                  iVar12 = uVar19 + 2;
                  *(char *)(local_e8 + 0x60ca2741) = (char)uVar19;
                  *(byte *)(iVar12 + local_e8 + 0x60ca2740) = bVar1;
                }
                iVar6 = FUN_6015a168(&local_6c,iVar5 + 0x60c7e740);
                if (100 < local_6c) {
                  if (iRam2004970c == 0) {
                    FUN_60168578("map:[way_coordinate_blocks %d]\n");
                    iRam2004970c = 1;
                  }
                  iRam2008588c = local_e0;
                  iRam20085890 = iVar16;
                  goto LAB_6001f51a;
                }
                iVar5 = iVar5 + iVar6;
                iVar6 = local_e8 + 0x60ca2740;
                iVar9 = local_e8 + 0x60ca2741;
                for (uVar19 = 0; uVar19 < local_6c; uVar19 = uVar19 + 1) {
                  iVar10 = FUN_6015a168(&local_68,iVar5 + 0x60c7e740);
                  if (local_68 == 0) {
                    FUN_60168578("ERROR: way_nodes = 0!!!\r\n");
                  }
                  uVar18 = local_68;
                  if (1000 < local_68) {
                    if (iRam2004970c == 0) {
                      FUN_60168578("map:[way_nodes %d]\n",local_68);
                      iRam2004970c = 1;
                    }
                    iRam2008588c = local_e0;
                    iRam20085890 = iVar16;
                    goto LAB_6001f51a;
                  }
                  if (uVar19 == 0) {
                    CopyBytes(iVar9 + iVar12,iVar5 + 0x60c7e740,iVar10);
                    iVar12 = iVar12 + iVar10;
                  }
                  iVar5 = iVar5 + iVar10;
                  for (uVar20 = 0; uVar20 < uVar18; uVar20 = uVar20 + 1) {
                    iVar10 = FUN_60158ee8(&local_74,iVar5 + 0x60c7e740);
                    iVar11 = FUN_60158ee8(local_84 + 3,iVar10 + iVar5 + 0x60c7e740);
                    iVar5 = iVar10 + iVar5 + iVar11;
                    if (uVar19 == 0) {
                      if (uVar20 == 0) {
                        if (*(char *)(param_4 + 0x15d) == '\0') {
                          local_74 = param_3 + local_74;
                          local_84[3] = local_84[3] + param_2;
                          goto LAB_6001f3ba;
                        }
                        local_74 = (iVar4 + param_3) / 10 + local_74;
                        local_84[3] = local_84[3] + (iVar13 + param_2) / 10;
                      }
                      else if (*(char *)(param_4 + 0x15d) == '\0') {
LAB_6001f3ba:
                        bVar21 = uVar20 == 0;
                        FUN_601564c6(local_84,&uStack_8c,&uStack_94,local_74,uVar15,bVar21);
                        FUN_601564c6(&local_88,&local_90,&local_98,local_84[3],uVar15,bVar21);
                        iVar10 = 5;
                        if (local_84[0] < 0) {
                          iVar10 = -5;
                        }
                        local_84[0] = (local_84[0] + iVar10) / 10;
                        iVar10 = 5;
                        if (local_88 < 0) {
                          iVar10 = -5;
                        }
                        local_88 = (local_88 + iVar10) / 10;
                        FUN_600301a6(&local_74,&uStack_9c,&uStack_a4,local_84[0],uVar15,bVar21);
                        FUN_600301a6(local_84 + 3,&local_a0,&local_a8,local_88,uVar15,bVar21);
                      }
                      piVar2 = local_84 + 2;
                      iVar10 = FUN_60028fe4(piVar2,local_74);
                      CopyBytes(iVar9 + iVar12,piVar2,iVar10);
                      iVar11 = FUN_60028fe4(piVar2,local_84[3]);
                      CopyBytes(iVar9 + iVar12 + iVar10,piVar2,iVar11);
                      iVar12 = iVar11 + iVar12 + iVar10;
                    }
                    uVar18 = local_68;
                  }
                }
                uVar19 = FUN_60039bf8(local_84 + 2,iVar12);
                if (1 < uVar19) {
                  FUN_6015dda0(iVar6 + uVar19,iVar9,iVar12);
                }
                CopyBytes(iVar6,local_84 + 2,uVar19);
                iVar9 = uVar19 + iVar12;
                *(int *)(*(int *)(iVar7 + 0x20085974) + *piVar8 * 4) = iVar16;
                *(short *)(*(int *)(iVar7 + 0x200859ac) + *piVar8 * 2) = (short)iVar9;
                CopyBytes(param_1 + iVar16,iVar6,iVar9);
                iVar16 = iVar16 + iVar9;
                *(int *)(iVar7 + 0x2008589c) = *(int *)(iVar7 + 0x2008589c) + iVar9;
                *piVar8 = *piVar8 + 1;
                local_e8 = local_e8 + iVar9;
                local_e0 = local_e0 + 1;
              }
            }
          }
        }
        else {
          local_cc = local_cc + iVar7;
          FUN_60163c98(iVar17);
          ZeroBytes(0x60c7e740,0x1fa0);
          local_d8 = FUN_60161ef4(iVar17,0x60c7e740,0x1fa0,local_84 + 1);
          iVar5 = 0;
        }
LAB_6001f1ce:
      }
      iRam2008588c = local_e0;
      iRam20085890 = iVar16;
    }
  }
  return local_d8;
}
