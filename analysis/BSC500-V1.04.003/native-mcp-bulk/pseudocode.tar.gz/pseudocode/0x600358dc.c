
undefined8 FUN_600358dc(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = 0;
  uVar2 = 0;
  FUN_60164f44(0x1e,2,1,0xff,0,0,0,0);
  return CONCAT44(uVar2,uVar1);
}
