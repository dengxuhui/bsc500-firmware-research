
void FUN_6000b224(void)

{
  if (DAT_2007e908 == '\x01') {
    FUN_6015df1c(0x86,0);
    FUN_6015df1c(0x83,0);
    FUN_601649b8(0);
    thunk_EXT_FUN_00020440(2);
    FUN_6015df1c(0x74,0);
    thunk_EXT_FUN_00020440(3);
    FUN_601559cc();
    DAT_2007e908 = '\0';
  }
  return;
}
