
void FUN_600247a8(void)

{
  int iVar1;
  uint uVar2;
  undefined8 in_d0;
  undefined1 local_20 [16];
  int local_10;
  uint uStack_c;
  
  uStack_c = (uint)((ulonglong)in_d0 >> 0x20);
  uStack_c = uStack_c & 0x7fffffff;
  if (uStack_c < 0x3fe921fc) {
    iVar1 = 1;
LAB_6002480c:
    FUN_600330d8(iVar1);
    return;
  }
  local_10 = (int)in_d0;
  if (uStack_c == 0x7ff00000) {
    if (local_10 == 0) {
      FUN_60163236(1);
      FUN_60138608();
      return;
    }
  }
  else if (uStack_c < 0x7ff00000) {
    uVar2 = FUN_60136250(local_10,local_20);
    iVar1 = (uVar2 & 1) * -2 + 1;
    goto LAB_6002480c;
  }
  FUN_60138584(local_10);
  return;
}
