
void FUN_60018a74(void)

{
  FUN_6001da48(0x200829c8);
  ZeroBytes(0x2000c36c,0x1c);
  uRam2000c368 = 0;
  return;
}
