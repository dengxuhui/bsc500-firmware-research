
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000f40(int param_1)

{
  bool bVar1;
  
  bVar1 = param_1 - 1U >> 0x18 != 0;
  if (bVar1) {
    return;
  }
  _DAT_e000e014 = param_1 - 1U;
  DAT_e000ed23 = 0xe0;
  _DAT_e000e018 = (uint)bVar1;
  _DAT_e000e010 = 7;
  return;
}
