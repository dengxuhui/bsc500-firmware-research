
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60010d38(void)

{
  return _DAT_20049b40;
}
