
void FUN_60023c8c(void)

{
  int iVar1;
  undefined4 *puVar2;
  
  ZeroBytes(0x60d61890,0x2718);
  ZeroBytes(0x60d63fa8,0x4fc4);
  ZeroBytes(0x60d68f6c,0x8b0);
  iVar1 = FUN_60164e24();
  if ((iVar1 != 0) && (cRam2008bc08 != '\0')) {
    puVar2 = (undefined4 *)FUN_60122a50();
    if (puVar2 != (undefined4 *)0x0) {
      *puVar2 = 0x1e;
      puVar2[1] = 100;
      puVar2[2] = 10;
    }
    return;
  }
  return;
}
