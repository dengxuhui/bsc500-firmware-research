
void FUN_60026260(uint *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar2 = *param_1;
  uStack_20 = param_3;
  uStack_1c = param_4;
  FUN_60034df4(&uStack_20,param_1,8);
  uVar2 = (uVar2 & 0x1ff) >> 3;
  iVar1 = 0x78;
  if (uVar2 < 0x38) {
    iVar1 = 0x38;
  }
  FUN_6015723c(param_1,0x20005a90,iVar1 - uVar2);
  FUN_6015723c(param_1,&uStack_20,8);
  FUN_60034df4(param_2,param_1 + 2,0x10);
  return;
}
