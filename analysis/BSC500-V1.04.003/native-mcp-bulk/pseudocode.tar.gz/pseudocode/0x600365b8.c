
int FUN_600365b8(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  int local_24;
  undefined4 uStack_20;
  int local_1c;
  
  local_1c = 0;
  if (param_1 == 0) {
    return 0xe;
  }
  if (param_4 == (uint *)0x0) {
    return 0xe;
  }
  if (0xb < *param_4) {
    *param_4 = *param_4 - 0xc;
    *param_3 = 0x18;
    local_24 = param_2;
    uStack_20 = param_3;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 2,param_1);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60100b98(param_3[2],&local_24);
    if (iVar1 != 0) {
      return iVar1;
    }
    *(undefined4 *)(param_3 + 4) = *(undefined4 *)(local_24 * 0x24 + 0x2007923c);
    iVar1 = FUN_601544a4(param_1,param_2,&local_1c,param_3 + 4,&UNK_6004a5e9);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fbe(param_1,param_2,&local_1c,(int)&uStack_20 + 3);
    if (iVar1 != 0) {
      return iVar1;
    }
    *(byte *)(param_3 + 6) = (uStack_20._3_1_ & 1) + (*(byte *)(param_3 + 6) & 0xfe);
    if (local_1c == param_2) {
      *param_4 = 0xc;
      return 0;
    }
  }
  return 9;
}
