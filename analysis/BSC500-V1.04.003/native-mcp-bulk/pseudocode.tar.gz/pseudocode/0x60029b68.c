
int FUN_60029b68(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uStack_94;
  undefined2 auStack_90 [54];
  
  iVar5 = 0x20085bf8;
  iVar6 = 0;
  if (param_1 != 0) {
    iVar5 = 0x20085cba;
  }
  iVar4 = iVar5 + 1;
  do {
    if (iVar6 == 2) {
      iVar6 = 0;
LAB_60029c64:
      return iVar6 * 0x61 + iVar5 + 1;
    }
    if (*(char *)(iVar4 + -1) == '\0') {
      *(undefined1 *)(iVar4 + -1) = 1;
      *(undefined1 *)(iVar5 + (uint)(iVar6 == 0) * 0x61) = 0;
      FUN_60167214(iVar4,0x60);
      if (param_1 == 0) {
        ZeroBytes(0x20085d7c,0x60);
        uVar3 = 0x20005d2a;
        uVar1 = 0x20005d02;
        param_1 = 0;
      }
      else {
        ZeroBytes(0x20085b48,0x60);
        uVar3 = 0x20005af8;
        uVar1 = 0x20005ad0;
      }
      if (iVar6 == 0) {
        uVar3 = uVar1;
      }
      FUN_601681f4(iVar4,&UNK_603f9dc7,param_1,uVar3);
      ZeroBytes(&uStack_94,0x6e);
      FUN_601681f4(&uStack_94,"%s/%s",0x20005712,iVar4);
      FUN_6015c57c(&uStack_94);
      iVar4 = FUN_60168220(&uStack_94);
      iVar2 = FUN_60168220(&uStack_94);
      *(undefined4 *)((int)&uStack_94 + iVar2) = 0x6e63742e;
      *(undefined2 *)((int)auStack_90 + iVar2) = 0x78;
      FUN_6015c57c(&uStack_94);
      *(undefined1 *)((int)&uStack_94 + iVar4) = 0;
      iVar2 = FUN_60168220(&uStack_94);
      *(undefined4 *)((int)&uStack_94 + iVar2) = 0x616e742e;
      *(undefined2 *)((int)auStack_90 + iVar2) = 0x76;
      FUN_6015c57c(&uStack_94);
      *(undefined1 *)((int)&uStack_94 + iVar4) = 0;
      iVar2 = FUN_60168220(&uStack_94);
      *(undefined4 *)((int)&uStack_94 + iVar2) = 0x6c63742e;
      *(undefined2 *)((int)auStack_90 + iVar2) = 0x6d;
      FUN_6015c57c(&uStack_94);
      *(undefined1 *)((int)&uStack_94 + iVar4) = 0;
      iVar4 = FUN_60168220(&uStack_94);
      *(undefined4 *)((int)&uStack_94 + iVar4) = 0x6773742e;
      *(undefined2 *)((int)auStack_90 + iVar4) = 0x6e;
      FUN_6015c57c(&uStack_94);
      goto LAB_60029c64;
    }
    iVar4 = iVar4 + 0x61;
    iVar6 = iVar6 + 1;
  } while( true );
}
