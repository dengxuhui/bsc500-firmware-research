
undefined1 FUN_600182f0(void)

{
  return uRam2007ce5f;
}
