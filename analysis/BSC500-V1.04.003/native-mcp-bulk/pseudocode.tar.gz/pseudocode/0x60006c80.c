
void FUN_60006c80(undefined4 *param_1)

{
  uRam40070100 = *param_1;
  uRam40070104 = param_1[1];
  return;
}
