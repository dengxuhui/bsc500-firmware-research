
undefined4 FUN_6002001a(int param_1,undefined2 *param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  undefined2 uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined4 uStack_28;
  
  if (param_1 == 0 || param_2 == (undefined2 *)0x0) {
    return 0xffffffff;
  }
  uStack_28 = param_4;
  FUN_60030266(param_1,*param_2);
  iVar5 = 0;
  iVar7 = (int)&uStack_28 + 2;
  do {
    if (iVar5 == 0xb0) {
      return 0;
    }
    iVar4 = param_1 + iVar5;
    uVar1 = *(uint *)(param_1 + 8);
    uVar6 = *(uint *)(iVar4 + 0x10);
    *(undefined2 *)(iVar4 + 0x1c) = 0xffff;
    if ((uVar6 < uVar1) && (uVar1 = *(uint *)(param_1 + 4), uVar1 != 0)) {
      uStack_28 = CONCAT22(0xffff,(undefined2)uStack_28);
      if (uVar6 < uVar1) {
        FUN_6003db58(param_1,uVar6 + 1,iVar7);
        if (uStack_28 >> 0x10 != 0xffff) {
          *(uint *)(iVar4 + 0x14) = *(int *)(iVar4 + 0x14) - (uStack_28 >> 0x10);
          *(int *)(iVar4 + 0x18) = *(int *)(iVar4 + 0x18) + -1;
        }
        FUN_60030296(param_1,iVar7);
        uVar3 = uStack_28 >> 0x10;
LAB_600200aa:
        if (uVar3 == 0xffff) {
          uVar1 = *(uint *)(iVar4 + 0x18);
        }
        else {
          uVar1 = *(int *)(iVar4 + 0x18) + 1;
          *(uint *)(iVar4 + 0x14) = *(int *)(iVar4 + 0x14) + uVar3;
          *(uint *)(iVar4 + 0x18) = uVar1;
        }
        if (uVar1 <= (uint)(*(int *)(iVar4 + 0x10) << 1) / 3) goto LAB_600200e6;
        uVar1 = *(uint *)(iVar4 + 0x14) / uVar1;
        *(short *)(iVar4 + 0x1c) = (short)uVar1;
        uVar1 = uVar1 & 0xffff;
      }
      else {
        FUN_60030296(param_1,iVar7);
        uVar3 = uStack_28 >> 0x10;
        if (uVar1 == uVar6) goto LAB_600200aa;
        if (uVar3 != 0xffff) {
          *(uint *)(iVar4 + 0x14) = uVar3 + *(int *)(iVar4 + 0x14);
          *(int *)(iVar4 + 0x18) = *(int *)(iVar4 + 0x18) + 1;
        }
LAB_600200e6:
        uVar1 = (uint)*(ushort *)(iVar4 + 0x1c);
      }
      if ((uVar1 != 0xffff) &&
         ((uVar3 = (uint)*(ushort *)(iVar4 + 0x1e), uVar6 = uVar1, uVar3 == 0xffff ||
          (uVar6 = uVar3, uVar3 < uVar1)))) {
        uVar2 = (short)uVar6;
        if (uVar6 < uVar1) {
          uVar2 = (short)uVar1;
        }
        *(undefined2 *)(iVar4 + 0x1e) = uVar2;
      }
    }
    iVar5 = iVar5 + 0x10;
  } while( true );
}
