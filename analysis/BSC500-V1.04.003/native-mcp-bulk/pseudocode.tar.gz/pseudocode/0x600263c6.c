
void FUN_600263c6(void)

{
  FUN_6015df1c(0x24,0);
  return;
}
