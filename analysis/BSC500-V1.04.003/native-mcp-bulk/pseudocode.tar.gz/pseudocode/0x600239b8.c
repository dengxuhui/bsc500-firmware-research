
int FUN_600239b8(int param_1)

{
  return param_1 + 0xd78;
}
