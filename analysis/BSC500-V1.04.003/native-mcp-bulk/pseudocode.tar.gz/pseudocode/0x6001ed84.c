
int FUN_6001ed84(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  
  uVar2 = param_3;
  uVar7 = param_4;
  iVar1 = FUN_6015f71c(0x154);
  if (iVar1 != 0) {
    FUN_601608ac(iVar1,0x154);
    param_2 = param_2 & 0xfffff000;
    uVar3 = param_1 + 0xfffU & 0xfffff000;
    *(uint *)(iVar1 + 0x138) = uVar3;
    *(uint *)(iVar1 + 0x13c) = param_2;
    if (uVar3 < param_2) {
      *(undefined4 *)(iVar1 + 0x144) = param_3;
      *(undefined4 *)(iVar1 + 0x148) = param_4;
      if (uVar3 == 0) {
        FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_slab.c",0x103,
                     "lv_page_init","Asserted at expression: %s","addr != NULL");
                    /* WARNING: Subroutine does not return */
        FUN_6016804c(&DAT_60434315,"lv_page_init",0x103);
      }
      param_2 = param_2 - uVar3;
      if (param_2 == 0) {
        FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_slab.c",0x104,
                     "lv_page_init","Asserted at expression: %s","npages != 0");
                    /* WARNING: Subroutine does not return */
        FUN_6016804c(&DAT_60434315,"lv_page_init",0x104);
      }
      *(undefined4 *)(iVar1 + 0x140) = 0;
      FUN_6002ebb0(iVar1,uVar3,param_2 >> 0xc);
      uVar3 = 0x8000;
      do {
        uVar4 = uVar3;
        if (0x1ffff < (int)uVar4) break;
        uVar3 = uVar4 << 1;
      } while (uVar4 << 1 < param_2 >> 10);
      iVar5 = (int)uVar4 / 4;
      if (0x10003 < (int)uVar4) {
        iVar5 = 0x4000;
      }
      iVar6 = (int)(uVar4 + ((uint)((int)uVar4 >> 0x1f) >> 0x14)) >> 0xc;
      *(uint *)(iVar1 + 0x128) = uVar4;
      *(int *)(iVar1 + 300) = iVar5;
      *(int *)(iVar1 + 0x130) = iVar6;
      uVar2 = FUN_6012037c(iVar1,(param_2 >> 10) + 0xfff >> 0xc,iVar5,iVar6,uVar2,uVar7);
      *(undefined4 *)(iVar1 + 0x134) = uVar2;
      return iVar1;
    }
  }
  return 0;
}
