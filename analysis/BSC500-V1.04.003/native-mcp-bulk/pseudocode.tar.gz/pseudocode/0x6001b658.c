
void FUN_6001b658(void)

{
  undefined4 uVar1;
  undefined8 uVar2;
  
  uVar2 = FUN_60166bb4();
  uVar2 = FUN_601678fc((int)uVar2,(int)((ulonglong)uVar2 >> 0x20),0x50c753f8,0x3fef8a6c);
  FUN_601682c8((int)uVar2,(int)((ulonglong)uVar2 >> 0x20),0x31f8a090,0x408997e6);
  uVar1 = FUN_601672d4();
  FUN_60127be0(uVar1);
  return;
}
