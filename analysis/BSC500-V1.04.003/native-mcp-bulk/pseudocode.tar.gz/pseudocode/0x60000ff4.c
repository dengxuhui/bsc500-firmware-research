
undefined4 FUN_60000ff4(int param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  char *pcVar2;
  
  param_3 = param_3 + 1;
  pcVar2 = (char *)(param_1 + 0x11c);
  do {
    param_3 = param_3 + -1;
    if (param_3 == 0) {
      return 0;
    }
    iVar1 = 0x703;
    *(undefined ***)(pcVar2 + 0x5c) = &PTR_FUN_60119c9c_1_603e4d8c;
    *(undefined4 *)(pcVar2 + 0x60) = param_4;
    pcVar2[100] = '\b';
    pcVar2[0x65] = '\0';
    pcVar2[0x66] = '\x10';
    pcVar2[0x67] = '\0';
    *(undefined4 **)(pcVar2 + -0xa4) = param_2;
    if (*pcVar2 == '\0') {
      iVar1 = 0x503;
    }
    if (pcVar2[1] != '\0') {
      iVar1 = iVar1 + 0x800;
    }
    iVar1 = FUN_6000194c(pcVar2 + 4,*param_2,iVar1,pcVar2 + -0x11c);
    param_2 = param_2 + 5;
    pcVar2 = pcVar2 + 0x18c;
  } while (iVar1 == 0);
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("result == RT_EOK","rt_hw_usart_init2",0x363);
}
