
void FUN_60000a5c(void)

{
  FUN_6016305c(0x200574c4,"tidle",&DAT_60000df9,0,0x231c8,0x800,0x37,0x20);
  FUN_60167f8c(0x200574c4);
  return;
}
