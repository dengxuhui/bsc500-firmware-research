
void FUN_60031bc0(undefined1 param_1)

{
  uRam2008b549 = param_1;
  return;
}
