
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_6002e560(undefined4 param_1,short *param_2,int param_3,int param_4,int param_5,int param_6,
                 short *param_7,int param_8,int param_9,int param_10)

{
  short sVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  short sVar5;
  ushort uVar6;
  short sVar7;
  bool bVar8;
  undefined2 uVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int *piVar14;
  uint uVar15;
  uint uVar16;
  int iVar17;
  ushort *puVar18;
  int iVar19;
  int iVar20;
  ushort *puVar21;
  undefined1 uVar22;
  ushort *puVar23;
  int iVar24;
  int iVar25;
  uint uVar26;
  uint uVar27;
  int iVar28;
  int iVar29;
  uint uVar30;
  ushort *puVar31;
  int iVar32;
  int iVar33;
  ushort *puVar34;
  int iVar35;
  ushort *puVar36;
  uint uStack_cc;
  uint uStack_c8;
  uint uStack_c4;
  uint uStack_c0;
  uint uStack_bc;
  uint uStack_b8;
  int iStack_84;
  int local_78;
  int iStack_68;
  int local_64;
  int iStack_60;
  int iStack_5c;
  int iStack_58;
  int iStack_54;
  undefined1 auStack_50 [16];
  int local_40;
  int local_3c;
  uint local_38;
  int local_34;
  int local_30;
  int local_2c;
  int local_28;
  
  iVar24 = (int)*param_7;
  iVar28 = *(int *)(param_7 + 2);
  local_34 = -iVar24;
  local_38 = 0x10000 / (ushort)param_7[1];
  sVar7 = (short)(iVar24 / -10);
  local_28 = iVar28;
  iVar10 = FUN_6012536c((int)sVar7);
  iVar11 = FUN_6012536c((int)(short)(sVar7 + 1));
  iVar12 = FUN_6012536c((int)(short)(sVar7 + 0x5a));
  iVar13 = FUN_6012536c((int)(short)(sVar7 + 0x5b));
  local_2c = (iVar28 >> 0x10) << 8;
  local_30 = (iVar28 << 0x10) >> 8;
  iVar28 = 0;
  iVar24 = (iVar24 / -10) * -10 - iVar24;
  local_3c = (iVar24 * iVar13 + (10 - iVar24) * iVar12) / 10 >> 5;
  local_40 = (iVar24 * iVar11 + (10 - iVar24) * iVar10) / 10 >> 5;
  iVar10 = param_3 + param_5 * param_6 * 2;
  sVar7 = param_2[3];
  sVar5 = param_2[1];
  iVar11 = (int)(short)((param_2[2] - *param_2) + 1);
  local_64 = param_10;
  local_78 = param_9;
  do {
    if ((short)((sVar7 - sVar5) + 1) <= iVar28) {
      return;
    }
    FUN_60040d10(auStack_50,(int)*param_2,iVar28 + param_2[1],&iStack_54);
    FUN_60040d10(auStack_50,(int)param_2[2],iVar28 + param_2[1],&iStack_5c);
    if (iVar11 < 2) {
      iStack_84 = 0;
      iStack_68 = 0;
    }
    else {
      iStack_68 = ((iStack_60 - iStack_58) * 0x100) / (iVar11 + -1);
      iStack_84 = ((iStack_5c - iStack_54) * 0x100) / (iVar11 + -1);
    }
    iVar12 = iStack_58 + 0x80;
    iVar13 = iStack_54 + 0x80;
    if ((*(byte *)(param_7 + 10) & 1) == 0) {
      if (param_8 == 4) {
LAB_6002e766:
        piVar14 = (int *)FUN_6015bb78();
        sVar1 = *(short *)(*piVar14 + 0x38);
        FUN_60129756(local_64,iVar11);
        iVar24 = 0;
        iVar19 = 0;
        for (iVar20 = 0; iVar20 < iVar11; iVar20 = iVar20 + 1) {
          iVar29 = iVar13 + (iVar19 >> 8);
          if (iVar29 < 0) {
LAB_6002e7c0:
            *(undefined1 *)(local_64 + iVar20) = 0;
          }
          else {
            iVar32 = iVar12 + (iVar24 >> 8);
            iVar25 = iVar32 >> 8;
            if (((param_5 <= iVar25) || (iVar32 < 0)) || (iVar29 = iVar29 >> 8, param_4 <= iVar29))
            goto LAB_6002e7c0;
            *(undefined2 *)(local_78 + iVar20 * 2) =
                 *(undefined2 *)(param_3 + (iVar25 * param_6 + iVar29) * 2);
          }
          if ((param_8 == 6) && (*(short *)(local_78 + iVar20 * 2) == sVar1)) {
            *(undefined1 *)(local_64 + iVar20) = 0;
          }
          iVar19 = iVar19 + iStack_84;
          iVar24 = iVar24 + iStack_68;
        }
      }
      else if (param_8 == 5) {
        iVar24 = 0;
        iVar19 = 0;
        for (iVar20 = 0; iVar20 < iVar11; iVar20 = iVar20 + 1) {
          iVar29 = iVar13 + (iVar19 >> 8);
          if (iVar29 < 0) {
            uVar22 = 0;
          }
          else {
            iVar32 = iVar12 + (iVar24 >> 8);
            uVar22 = 0;
            iVar25 = iVar32 >> 8;
            if (((iVar25 < param_5) && (-1 < iVar32)) && (iVar29 = iVar29 >> 8, iVar29 < param_4)) {
              iVar29 = (iVar25 * param_6 + iVar29) * 3;
              *(undefined2 *)(local_78 + iVar20 * 2) = *(undefined2 *)(param_3 + iVar29);
              uVar22 = *(undefined1 *)(iVar29 + param_3 + 2);
            }
          }
          iVar19 = iVar19 + iStack_84;
          *(undefined1 *)(local_64 + iVar20) = uVar22;
          iVar24 = iVar24 + iStack_68;
        }
      }
      else {
        if (param_8 == 6) goto LAB_6002e766;
        if (param_8 == 0x14) {
          iVar24 = 0;
          iVar19 = 0;
          for (iVar20 = 0; iVar20 < iVar11; iVar20 = iVar20 + 1) {
            iVar29 = iVar13 + (iVar19 >> 8);
            if (iVar29 < 0) {
              uVar22 = 0;
            }
            else {
              iVar32 = iVar12 + (iVar24 >> 8);
              uVar22 = 0;
              iVar25 = iVar32 >> 8;
              if (((iVar25 < param_5) && (-1 < iVar32)) && (iVar29 = iVar29 >> 8, iVar29 < param_4))
              {
                iVar29 = iVar25 * param_6 + iVar29;
                *(undefined2 *)(local_78 + iVar20 * 2) = *(undefined2 *)(param_3 + iVar29 * 2);
                uVar22 = *(undefined1 *)(iVar10 + iVar29);
              }
            }
            iVar19 = iVar19 + iStack_84;
            *(undefined1 *)(local_64 + iVar20) = uVar22;
            iVar24 = iVar24 + iStack_68;
          }
        }
      }
    }
    else {
      if (param_8 == 4) {
        uVar2 = 0;
        bVar8 = false;
LAB_6002e872:
        iVar24 = 2;
      }
      else {
        if (param_8 == 0x14) {
          bVar8 = true;
          uVar2 = 0;
          goto LAB_6002e872;
        }
        if (param_8 == 6) {
          piVar14 = (int *)FUN_6015bb78();
          uVar2 = *(ushort *)(*piVar14 + 0x38);
          bVar8 = true;
          goto LAB_6002e872;
        }
        if (param_8 != 5) goto LAB_6002eb04;
        iVar24 = 3;
        bVar8 = true;
        uVar2 = 0;
      }
      iVar20 = 0;
      iVar29 = 0;
      for (iVar19 = 0; iVar19 < iVar11; iVar19 = iVar19 + 1) {
        uVar15 = iVar13 + (iVar29 >> 8);
        if ((int)uVar15 < 0) {
LAB_6002e946:
          *(undefined1 *)(local_64 + iVar19) = 0;
        }
        else {
          uVar26 = iVar12 + (iVar20 >> 8);
          iVar25 = (int)uVar26 >> 8;
          if (((param_5 <= iVar25) || ((int)uVar26 < 0)) ||
             (iVar32 = (int)uVar15 >> 8, param_4 <= iVar32)) goto LAB_6002e946;
          uVar26 = uVar26 & 0xff;
          iVar33 = 1;
          puVar36 = (ushort *)((iVar25 * param_6 + iVar32) * iVar24 + param_3);
          uVar30 = uVar26 * 2 - 0x100;
          if (uVar26 < 0x80) {
            uVar30 = uVar26 * -2 + 0xfe;
          }
          uVar15 = uVar15 & 0xff;
          uVar16 = uVar15 * 2 - 0x100;
          if (uVar15 < 0x80) {
            uVar16 = uVar15 * -2 + 0xfe;
          }
          if (uVar26 < 0x80) {
            iVar33 = -1;
          }
          iVar17 = 1;
          if (uVar15 < 0x80) {
            iVar17 = -1;
          }
          if (((iVar17 + iVar32 < 0) || (param_4 <= iVar17 + iVar32)) ||
             ((iVar35 = iVar33 + iVar25, iVar35 < 0 || (param_5 <= iVar35)))) {
            uVar4 = *puVar36;
            *(ushort *)(local_78 + iVar19 * 2) = uVar4;
            if (param_8 == 0x14) {
              uVar27 = (uint)*(byte *)(iVar10 + iVar25 * param_6 + iVar32);
            }
            else if (param_8 == 6) {
              uVar27 = 0;
              if (uVar2 != uVar4) {
                uVar27 = 0xffffffff;
              }
            }
            else if (param_8 == 5) {
              uVar27 = (uint)(byte)puVar36[1];
            }
            else {
              uVar27 = 0xff;
            }
            if ((((iVar32 == 0) && (uVar15 < 0x80)) ||
                (((iVar32 == param_4 + -1 && (0x7f < uVar15)) ||
                 ((uVar16 = uVar30, iVar25 == 0 && (uVar26 < 0x80)))))) ||
               ((iVar25 == param_5 + -1 && (0x7f < uVar26)))) {
              *(char *)(local_64 + iVar19) = (char)((0xff - uVar16) * (uVar27 & 0xff) >> 8);
            }
            else {
              *(undefined1 *)(local_64 + iVar19) = 0;
            }
          }
          else {
            puVar21 = (ushort *)(iVar24 * param_6 * iVar33 + (int)puVar36);
            puVar34 = (ushort *)(iVar17 * iVar24 + (int)puVar36);
            if (bVar8) {
              if (param_8 == 0x14) {
                puVar31 = (ushort *)(iVar35 * param_6 + iVar10 + iVar32);
                puVar23 = (ushort *)(iVar32 + iVar10 + iVar25 * param_6);
                puVar18 = (ushort *)(iVar17 + (int)puVar23);
LAB_6002e9fe:
                uVar27 = (uint)(byte)*puVar23;
                uVar26 = (uint)(byte)*puVar31;
                uVar15 = (uint)(byte)*puVar18;
                if (uVar26 != uVar27) {
                  uVar26 = ((0x100 - uVar30) * uVar27 + uVar30 * uVar26 & 0xffff) >> 8;
                }
                if (uVar15 != uVar27) {
                  uVar15 = ((0x100 - uVar16) * uVar27 + uVar16 * uVar15 & 0xffff) >> 8;
                }
              }
              else {
                if (param_8 == 6) {
                  if (((uVar2 == *puVar36) || (uVar2 == *puVar21)) || (uVar2 == *puVar34)) {
                    *(undefined1 *)(local_64 + iVar19) = 0;
                    goto LAB_6002eaf8;
                  }
                }
                else if (param_8 == 5) {
                  puVar18 = puVar34 + 1;
                  puVar31 = puVar21 + 1;
                  puVar23 = puVar36 + 1;
                  goto LAB_6002e9fe;
                }
                uVar26 = 0xff;
                uVar15 = 0xff;
              }
              *(char *)(local_64 + iVar19) = (char)(uVar15 + uVar26 >> 1);
              if (uVar15 + uVar26 >> 1 == 0) goto LAB_6002eaf8;
              uVar3 = *puVar34;
              uVar4 = *puVar21;
              uVar6 = *puVar36;
            }
            else {
              uVar4 = *puVar21;
              uVar3 = *puVar34;
              uVar6 = *puVar36;
              *(undefined1 *)(local_64 + iVar19) = 0xff;
            }
            uVar15 = (uint)uVar6;
            if (uVar15 == uVar4 && uVar15 == uVar3) {
              *(ushort *)(local_78 + iVar19 * 2) = uVar6;
            }
            else {
              uStack_b8 = (uint)uVar4 + (uStack_b8 & 0xffff0000);
              uStack_bc = (uStack_bc & 0xffff0000) + uVar15;
              uVar26 = (*(code *)&UNK_6003b225)(uStack_b8,uStack_bc,uVar30 & 0xff);
              uStack_c0 = (uStack_c0 & 0xffff0000) + (uint)uVar3;
              uStack_c4 = (uStack_c4 & 0xffff0000) + uVar15;
              uVar15 = (*(code *)&UNK_6003b225)(uStack_c0,uStack_c4,uVar16 & 0xff);
              uStack_cc = uVar26 & 0xffff | uStack_cc & 0xffff0000;
              uStack_c8 = uVar15 & 0xffff | uStack_c8 & 0xffff0000;
              uVar9 = (*(code *)&UNK_6003b225)(uStack_c8,uStack_cc,0x7f);
              *(undefined2 *)(local_78 + iVar19 * 2) = uVar9;
            }
          }
        }
LAB_6002eaf8:
        iVar29 = iVar29 + iStack_84;
        iVar20 = iVar20 + iStack_68;
      }
    }
LAB_6002eb04:
    local_78 = local_78 + iVar11 * 2;
    iVar28 = iVar28 + 1;
    local_64 = local_64 + iVar11;
  } while( true );
}
