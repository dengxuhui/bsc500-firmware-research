
void FUN_6002709e(int param_1,undefined4 param_2)

{
  int iVar1;
  undefined1 local_64 [4];
  undefined4 local_60;
  undefined1 local_14;
  
  if (((param_1 != 0) && (iVar1 = FUN_6015cda8(param_1,0xc), iVar1 != 0)) &&
     (iVar1 = FUN_6015ccf4(param_1), iVar1 == 1)) {
    local_14 = 1;
    local_64[0] = 0xb;
    local_60 = param_2;
    FUN_6015cd04(param_1,local_64);
  }
  return;
}
