
undefined4 FUN_60021f00(int param_1)

{
  uint uVar1;
  int iVar2;
  
  if ((param_1 != 0) && (uVar1 = FUN_60168220(), uVar1 < 0x5f)) {
    FUN_601681f4(0x2008ae28,&UNK_60021fd8,param_1);
    iVar2 = FUN_60166758(0x2000b030,0x2008ae28,10);
    if (iVar2 == 0) {
      uRam2000b044 = 100;
      uRam2000b03c = 300;
      uRam2000bddc = 0;
      iVar2 = FUN_60135720(0x2000b030);
      if ((((iVar2 == 0) && (iVar2 = FUN_60135acc(0x2000b030,0x2000be00), iVar2 == 0)) &&
          (iVar2 = FUN_60135b7e(0x2000b030,0x2000b038), iVar2 == 0)) &&
         ((iVar2 = FUN_60135bf2(0x2000b030,0x2000b040), iVar2 == 0 &&
          (iVar2 = FUN_60135b38(0x2000b030,0), iVar2 == 0)))) {
        FUN_6013a69a(0x200895a0);
        FUN_6013a692(0x2000b060);
        FUN_6013a67e(0x2000b070);
        FUN_6013a662(0x2000b090);
        FUN_6013a652(0x2000bdc8);
        FUN_6013a642(0x2000b080);
        FUN_6013a64a(0x2000bde0);
        if (iRam2000b034 == 0) {
          return 0;
        }
        FUN_601667bc();
        iRam2000b034 = 0;
        return 0;
      }
      FUN_601667bc(uRam2000b030);
      uRam2000b030 = 0;
      FUN_60163bbe(0x2008ae28);
    }
    else {
      uRam2000b030 = 0;
    }
  }
  return 0xffffffff;
}
