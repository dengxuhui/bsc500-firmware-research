
void FUN_60003ba8(void)

{
  FUN_60004de2();
  FUN_60004dd4();
  FUN_6015c57c("0:/iGPSPORT/Maps/CN0000C.map");
  return;
}
