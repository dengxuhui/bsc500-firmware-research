
byte * FUN_60027f50(undefined4 param_1,uint param_2,uint *param_3,undefined4 *param_4,byte *param_5,
                   int param_6)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  byte bVar5;
  uint uVar6;
  uint uVar7;
  byte *pbVar8;
  byte *pbVar9;
  undefined4 uVar10;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined8 in_d6;
  undefined8 in_d7;
  undefined8 uVar11;
  undefined8 unaff_d9;
  undefined8 uVar12;
  undefined8 local_50;
  undefined8 local_48;
  
  param_2 = param_2 & ~((int)param_2 >> 0x1f);
  *param_4 = 0;
  if (0x4d < (int)param_2) {
    param_2 = 0x4e;
  }
  local_50 = in_d6;
  local_48 = in_d7;
  iVar2 = FUN_60167ba8();
  if (iVar2 == 0) {
    *param_4 = 1;
    param_1 = FUN_60165558(0,0x80000000);
  }
  uVar10 = FUN_600f8228(param_1,&local_48);
  uVar12 = local_48;
  uVar11 = CONCAT44(extraout_s1,uVar10);
  iVar2 = FUN_60167b7e((int)local_48,(int)((ulonglong)local_48 >> 0x20),0,0);
  if (iVar2 == 0) {
    iVar2 = 0;
    while( true ) {
      uVar10 = (undefined4)((ulonglong)uVar12 >> 0x20);
      iVar3 = FUN_60167b7e((int)uVar12,uVar10,0,0);
      if (iVar3 != 0) break;
      uVar10 = FUN_601675d8((int)uVar12,uVar10,0,0x40240000);
      uVar10 = FUN_600f8228(uVar10,&local_48);
      unaff_d9 = CONCAT44(extraout_s1_00,uVar10);
      uVar12 = FUN_601682c8(uVar10,extraout_s1_00,0xeb851eb8,0x3f9eb851);
      FUN_601678fc((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),0,0x40240000);
      cVar1 = FUN_60167a50();
      param_5[iVar2 + 0x4f] = cVar1 + 0x30;
      if (iVar2 == -0x4e) {
                    /* WARNING: Subroutine does not return */
        FUN_6016804c("r2 < CVTBUFSIZE - 1",&UNK_600281e4,0x3b7);
      }
      iVar2 = iVar2 + -1;
      uVar12 = local_48;
    }
    uVar6 = -iVar2;
    for (uVar4 = 0; uVar7 = uVar6, local_50 = unaff_d9, uVar6 != uVar4; uVar4 = uVar4 + 1) {
      param_5[uVar4] = param_5[iVar2 + uVar4 + 0x50];
    }
  }
  else {
    iVar2 = FUN_60167bb6(uVar10,extraout_s1,0,0);
    if (iVar2 == 0) {
      uVar6 = 1;
      uVar12 = uVar11;
      do {
        uVar11 = uVar12;
        uVar12 = FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),0,0x40240000);
        iVar2 = FUN_60167bc4((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),0,0x3ff00000);
        uVar6 = uVar6 - 1;
        local_50 = uVar12;
      } while (iVar2 != 0);
    }
    else {
      uVar6 = 0;
    }
    uVar7 = 0;
  }
  *param_3 = uVar6;
  if (param_6 == 0) {
    param_2 = param_2 + uVar6;
  }
  pbVar9 = param_5;
  if (-1 < (int)param_2) {
    pbVar8 = param_5 + param_2;
    for (; ((int)uVar7 <= (int)param_2 && (uVar7 < 0x50)); uVar7 = uVar7 + 1) {
      uVar10 = FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),0,0x40240000);
      uVar10 = FUN_600f8228(uVar10,&local_50);
      uVar11 = CONCAT44(extraout_s1_01,uVar10);
      cVar1 = FUN_60167a50((int)local_50,(int)((ulonglong)local_50 >> 0x20));
      param_5[uVar7] = cVar1 + 0x30;
    }
    if ((int)param_2 < 0x50) {
      bVar5 = *pbVar8 + 5;
      *pbVar8 = bVar5;
      pbVar9 = pbVar8;
      while (0x39 < bVar5) {
        *pbVar8 = 0x30;
        if (param_5 < pbVar8) {
          pbVar8 = pbVar8 + -1;
          *pbVar8 = *pbVar8 + 1;
        }
        else {
          *pbVar8 = 0x31;
          *param_3 = *param_3 + 1;
          if (param_6 == 0) {
            if (param_5 < pbVar9) {
              *pbVar9 = 0x30;
            }
            pbVar9 = pbVar9 + 1;
          }
        }
        bVar5 = *pbVar8;
      }
    }
    else {
      pbVar9 = param_5 + 0x4f;
    }
  }
  *pbVar9 = 0;
  return param_5;
}
