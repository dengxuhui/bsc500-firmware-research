
void FUN_600302ce(undefined4 param_1,undefined4 param_2)

{
  FUN_6003db8a(param_1,1,param_2);
  return;
}
