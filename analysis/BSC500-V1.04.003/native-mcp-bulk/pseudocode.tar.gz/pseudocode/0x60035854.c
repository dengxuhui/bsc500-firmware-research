
int FUN_60035854(int param_1,undefined4 param_2,int *param_3,int param_4)

{
  int iVar1;
  
  iVar1 = 0xe;
  if (((param_1 != 0) && (param_3 != (int *)0x0)) && (param_4 != 0)) {
    CopyBytes(param_4,param_1 + *param_3,0x29,param_4,param_4);
    *param_3 = *param_3 + 0x29;
    iVar1 = FUN_60152fbe(param_1,param_2,param_3,param_4 + 0x2d);
    if (iVar1 == 0) {
      iVar1 = FUN_60152fbe(param_1,param_2,param_3,param_4 + 0x2c);
      return iVar1;
    }
  }
  return iVar1;
}
