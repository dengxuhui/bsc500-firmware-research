
void FUN_60009110(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  uRam20009d34 = param_1;
  if (iRam20009d38 == 0) {
    iRam20009d38 = FUN_60165194(1,1,0,param_4,param_3,param_4);
  }
  if (iRam20009d3c == 0) {
    iRam20009d3c = FUN_60165194(1,1,0);
  }
  if (iRam20009d40 == 0) {
    iRam20009d40 = FUN_60165194(1,0,0);
  }
  FUN_60167f3c(7,0x603f8fab,1,&UNK_60009180,"ble_device_interconnect_init");
  return;
}
