
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000d18(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 *puVar3;
  uint uVar4;
  
  uVar1 = FUN_60167d0c();
  iVar2 = FUN_60163aac();
  if (iVar2 != 0) {
    FUN_60168578("Function[%s] shall not be used in ISR\n","rt_system_heap_init");
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&DAT_60434315,"rt_system_heap_init",0x116);
  }
  uVar4 = param_2 & 0xfffffffc;
  FUN_60167d14(uVar1);
  if ((0x30 < uVar4) &&
     (puVar3 = (undefined4 *)(param_1 + 3U & 0xfffffffc), puVar3 <= (undefined4 *)(uVar4 - 0x30))) {
    _DAT_2000953c = (uVar4 - (int)puVar3) + -0x30;
    _DAT_20009540 = puVar3;
    puVar3[2] = 0;
    puVar3[1] = (uVar4 - (int)puVar3) + -0x18;
    *puVar3 = 0x1ea0;
    _DAT_20009544 = uVar4 - 0x18;
    FUN_60162cd4();
    FUN_60167ef4(0x20009560,&DAT_60000db4,1,0);
    _DAT_20009548 = _DAT_20009540;
    _DAT_2000954c = 0;
    return;
  }
  FUN_60168578("mem init, error begin address 0x%x, and end address 0x%x\n",param_1,param_2,param_4)
  ;
  return;
}
