
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600008cc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 local_10;
  undefined4 uStack_c;
  
  if ((DAT_200042c8 == '\0') &&
     (local_10 = param_3, uStack_c = param_4, iVar1 = FUN_60000abc((int)&uStack_c + 3,&local_10),
     iVar1 == 0)) {
    if ((byte)(uStack_c._3_1_ - 1U) < 3) {
      DAT_200042c8 = uStack_c._3_1_ + '\x01';
    }
    _DAT_200042cc = local_10;
    return;
  }
  return;
}
