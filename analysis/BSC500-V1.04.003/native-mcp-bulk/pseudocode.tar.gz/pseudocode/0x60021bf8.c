
undefined4 FUN_60021bf8(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  
  if ((param_1 != 0) && (uVar1 = FUN_60168220(), uVar1 < 0x5f)) {
    FUN_601681f4(0x2008ad60,&UNK_60021db4,param_1);
    FUN_601681f4(0x2008af54,&UNK_60021dc4,param_1);
    FUN_601681f4(0x2008b01c,&UNK_60021dd0,param_1);
    iVar2 = FUN_60166758(0x2000b00c,0x2008ad60,10);
    if (iVar2 == 0) {
      uRam2000b010 = 0;
      uRam2000b014 = 0;
      iVar2 = FUN_60166758(0x2000afc0,0x2008af54,10);
      if (iVar2 == 0) {
        uRam2000afc4 = 0;
        iVar2 = FUN_60166758(0x2000afd0,0x2008b01c,10);
        if (iVar2 == 0) {
          uRam2000afd4 = 0;
          iVar2 = FUN_60135294(0x2000b00c);
          if (((iVar2 == 0) && (iVar2 = FUN_6013588c(0x2000b00c,0x2000c558), iVar2 == 0)) &&
             (iVar2 = FUN_60135820(0x2000b00c,0x2000c570), iVar2 == 0)) {
            uRam2000afdc = 300;
            iVar2 = FUN_601358f8(0x2000b00c,0x2000afd8);
            if (iVar2 == 0) {
              uRam2000afe4 = 100;
              iVar2 = FUN_60135968(0x2000b00c,0x2000afe0);
              if (iVar2 == 0) {
                uRam2000afec = 0x14;
                iVar2 = FUN_601359da(0x2000b00c,0x2000afe8);
                if (iVar2 == 0) {
                  uRam2000aff4 = 0x14;
                  iVar2 = FUN_60135a4c(0x2000b00c,0x2000aff0);
                  if (((iVar2 == 0) && (iVar2 = FUN_601352fc(0x2000afc0), iVar2 == 0)) &&
                     (iVar2 = FUN_60135364(0x2000afd0), iVar2 == 0)) {
                    FUN_6013a776(0x2000c57c);
                    FUN_6013a76e(0x2000c768);
                    FUN_6013a760(0x2000c58c);
                    FUN_6013a752(0x2007f8cc);
                    FUN_6013a744(0x2000c5a4);
                    FUN_6013a744(0x2000c720);
                    FUN_6013a6e6(0x2000c818);
                    FUN_6013a6f4(0x2000b018);
                    FUN_6013a6f4(0x2000b024);
                    FUN_6013a6de(0x2000c738);
                    FUN_6013a6d6(0x2000c750);
                    FUN_6013a6ba(0x2000c564);
                    FUN_6013a6c4(0x2000c840);
                    if (iRam2000b000 != 0) {
                      FUN_601667bc();
                      iRam2000b000 = 0;
                      return 0;
                    }
                    return 0;
                  }
                }
              }
            }
          }
          FUN_601667bc(uRam2000b00c);
          FUN_601667bc(uRam2000afc0);
          FUN_601667bc(uRam2000afd0);
          FUN_60163bbe(0x2008ad60);
          FUN_60163bbe(0x2008af54);
          FUN_60163bbe(0x2008b01c);
          return 0xffffffff;
        }
        uRam2000afd0 = 0;
        FUN_601667bc(uRam2000b00c);
        FUN_60163bbe(0x2008ad60);
        FUN_601667bc(uRam2000afc0);
        uVar3 = 0x2008af54;
      }
      else {
        uRam2000afc0 = 0;
        FUN_601667bc(uRam2000b00c);
        uVar3 = 0x2008ad60;
      }
      FUN_60163bbe(uVar3);
    }
    else {
      uRam2000b00c = 0;
    }
  }
  return 0xffffffff;
}
