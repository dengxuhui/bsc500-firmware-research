
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000904(void)

{
  undefined **ppuVar1;
  
  FUN_60000cdc();
  FUN_6014157c();
  FUN_60000b30();
  FUN_601415d0();
  FUN_60000d18(0x2008e104,0x200bf800);
  FUN_60000cc8();
  FUN_60000ce0();
  FUN_60160620("uart1");
  FUN_60168578("Serial:%x,Chip:%x,Package:%x,Rev:%x",_DAT_4000b004 >> 0x18,
               (_DAT_4000b004 & 0xffffff) >> 0x10,(_DAT_4000b004 & 0xffff) >> 8);
  for (ppuVar1 = &PTR_FUN_60250904_1_6043dd68; ppuVar1 < &PTR_LAB_60250900_1_6043dd90;
      ppuVar1 = ppuVar1 + 1) {
    (*(code *)*ppuVar1)();
  }
  return;
}
