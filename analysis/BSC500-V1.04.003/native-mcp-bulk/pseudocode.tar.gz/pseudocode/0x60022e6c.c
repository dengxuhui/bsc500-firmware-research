
undefined4 FUN_60022e6c(int param_1,int param_2,int param_3)

{
  byte *pbVar1;
  byte bVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  float *pfVar6;
  byte bVar7;
  uint uVar8;
  uint uVar9;
  byte bVar10;
  float *pfVar11;
  undefined4 in_cr2;
  undefined4 in_cr3;
  float fVar12;
  float fVar13;
  byte local_100 [4];
  float local_fc [54];
  
  uVar3 = 0xffffffff;
  if ((param_2 != 0) && (param_3 != 0)) {
    iVar4 = FUN_60166dd0(param_2);
    if (iVar4 != 1) {
      iVar4 = FUN_60166dd0(param_2 + 8);
      if (iVar4 != 1) {
        pfVar11 = local_fc + 4;
        *(undefined1 *)(param_3 + 4) = 0;
        ZeroBytes(pfVar11,200);
        iVar4 = param_1 + 0x50;
        pfVar6 = pfVar11;
        for (uVar8 = 0; bVar7 = *(byte *)(param_1 + 1), uVar8 < bVar7; uVar8 = uVar8 + 1) {
          FUN_6015ce30(pfVar6,param_2,param_2 + 8,iVar4 + -8,iVar4);
          iVar4 = iVar4 + 0x1ec;
          pfVar6 = pfVar6 + 1;
        }
        bVar10 = 0;
        local_fc[3] = 0.0;
        local_fc[1] = 0.0;
        local_fc[2] = 0.0;
        local_100[0] = 0;
        local_100[1] = 0;
        local_100[2] = 0;
        local_100[3] = 0;
        local_fc[0] = 0.0;
        for (uVar8 = 0; uVar8 != bVar7; uVar8 = uVar8 + 1) {
          fVar12 = pfVar11[uVar8];
          if (fVar12 < 160000.0) {
            uVar5 = (uint)bVar10;
            if (uVar5 < 4) {
              local_100[uVar5] = (byte)uVar8;
              bVar10 = bVar10 + 1;
              local_fc[uVar5] = fVar12;
            }
            else {
              uVar5 = 0;
              pfVar6 = local_fc;
              for (uVar9 = 1; pfVar6 = pfVar6 + 1, uVar9 != 4; uVar9 = uVar9 + 1) {
                coprocessor_function2(10,8,0,in_cr2,in_cr3,in_cr2);
                if (local_fc[0] < *pfVar6) {
                  uVar5 = uVar9;
                }
              }
              pfVar6 = local_fc + (uVar5 & 0xff);
              if (fVar12 < *pfVar6) {
                local_100[uVar5 & 0xff] = (byte)uVar8;
                *pfVar6 = fVar12;
              }
            }
          }
        }
        if (bVar10 == 0) {
          *(undefined1 *)(param_3 + 4) = 0;
        }
        else {
          for (bVar7 = 0; (uint)bVar7 < (uint)bVar10; bVar7 = bVar7 + 1) {
            fVar12 = -1.0;
            uVar8 = 0xff;
            pfVar6 = local_fc;
            for (uVar5 = 0; bVar10 != uVar5; uVar5 = uVar5 + 1) {
              fVar13 = *pfVar6;
              if ((0.0 <= fVar13) && ((fVar12 < 0.0 || (fVar13 < fVar12)))) {
                uVar8 = uVar5 & 0xff;
                fVar12 = fVar13;
              }
              pfVar6 = pfVar6 + 1;
            }
            if (uVar8 != 0xff) {
              fVar12 = local_fc[uVar8];
              local_fc[uVar8] = -1.0;
              pbVar1 = (byte *)(param_3 + 4);
              bVar2 = *pbVar1;
              *pbVar1 = bVar2 + 1;
              *(int *)(pbVar1 + (uint)bVar2 * 8 + 4) =
                   (short)(ushort)local_100[uVar8] * 0x1ec + param_1 + 4;
              uVar3 = VectorFloatToUnsigned(fVar12,3);
              *(undefined4 *)(pbVar1 + (uint)bVar2 * 8 + 8) = uVar3;
            }
          }
        }
        return 0;
      }
    }
    uVar3 = 0;
    *(undefined1 *)(param_3 + 4) = 0;
  }
  return uVar3;
}
