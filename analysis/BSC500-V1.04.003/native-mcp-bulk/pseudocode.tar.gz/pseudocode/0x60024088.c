
void FUN_60024088(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  char cVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  ulonglong in_d0;
  undefined4 extraout_s1;
  int iVar8;
  undefined8 unaff_d9;
  undefined8 unaff_d10;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 local_18;
  
  local_18._4_4_ = (uint)(in_d0 >> 0x20);
  iVar1 = (int)local_18._4_4_ >> 0x1f;
  uVar4 = local_18._4_4_ & 0x7fffffff;
  iVar8 = (int)in_d0;
  if (0x40862e41 < uVar4) {
    cVar5 = 0x7fefffff < uVar4;
    if ((bool)cVar5) {
      if ((in_d0 & 0xfffff00000000) == 0 && iVar8 == 0) {
        return;
      }
      FUN_60138584(iVar8);
      return;
    }
    FUN_60160f64(iVar8,local_18._4_4_,0xfefa39ef,0x40862e42);
    if (cVar5 == '\0') {
      FUN_60163236(2);
      FUN_6013a020();
      return;
    }
    FUN_60160eec(iVar8,local_18._4_4_,0xd52d3051,0xc0874910);
    if (cVar5 == '\0') {
      FUN_60163236(2);
      FUN_6013a000();
      return;
    }
  }
  if (uVar4 < 0x3fd62e43) {
    cVar5 = 0x3e2fffff < uVar4;
    if (!(bool)cVar5) {
      uVar9 = FUN_601682c8(iVar8,local_18._4_4_,0x8800759c,0x7e37e43c);
      FUN_60160f64((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0,0x3ff00000);
      if (cVar5 == '\0') {
        FUN_601682c8(iVar8,local_18._4_4_,0,0x3ff00000);
        return;
      }
    }
    iVar1 = 0;
    local_18 = in_d0;
  }
  else {
    if (uVar4 < 0x3ff0a2b2) {
      unaff_d10 = FUN_60165558(iVar8,local_18._4_4_,(int)*(undefined8 *)(&UNK_60277250 + iVar1 * -8)
                               ,(int)((ulonglong)*(undefined8 *)(&UNK_60277250 + iVar1 * -8) >> 0x20
                                     ));
      unaff_d9 = *(undefined8 *)(&UNK_60277260 + iVar1 * -8);
      iVar1 = iVar1 * 2 + 1;
    }
    else {
      uVar9 = FUN_601678fc(iVar8,local_18._4_4_,0x652b82fe,0x3ff71547);
      FUN_601682c8((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),
                   (int)*(undefined8 *)(&UNK_60277240 + iVar1 * -8),
                   (int)((ulonglong)*(undefined8 *)(&UNK_60277240 + iVar1 * -8) >> 0x20));
      iVar1 = FUN_60167a50();
      uVar9 = FUN_6016759c();
      uVar7 = (undefined4)((ulonglong)uVar9 >> 0x20);
      uVar10 = FUN_601678fc((int)uVar9,uVar7,0xfee00000,0x3fe62e42);
      unaff_d10 = FUN_60138720((int)uVar10,(int)((ulonglong)uVar10 >> 0x20),iVar8,local_18._4_4_);
      unaff_d9 = FUN_601678fc((int)uVar9,uVar7,0x35793c76,0x3dea39ef);
    }
    local_18 = FUN_60165558((int)unaff_d10,(int)((ulonglong)unaff_d10 >> 0x20),(int)unaff_d9,
                            (int)((ulonglong)unaff_d9 >> 0x20));
  }
  uVar3 = (undefined4)(local_18 >> 0x20);
  uVar6 = (undefined4)local_18;
  uVar9 = FUN_601678fc(uVar6,uVar3,uVar6,uVar3);
  uVar7 = FUN_60138628((int)uVar9,&UNK_60277270,5);
  uVar9 = FUN_601678fc(uVar7,extraout_s1,(int)uVar9,(int)((ulonglong)uVar9 >> 0x20));
  uVar9 = FUN_60138720((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),uVar6,uVar3);
  uVar2 = (undefined4)((ulonglong)uVar9 >> 0x20);
  uVar7 = (undefined4)uVar9;
  if (iVar1 == 0) {
    uVar9 = FUN_60165558(uVar7,uVar2,0,0x40000000);
    uVar10 = FUN_601678fc(uVar6,uVar3,uVar7,uVar2);
    uVar9 = FUN_601675d8((int)uVar10,(int)((ulonglong)uVar10 >> 0x20),(int)uVar9,
                         (int)((ulonglong)uVar9 >> 0x20));
    uVar9 = FUN_60165558((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),uVar6,uVar3);
    FUN_60138720((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0,0x3ff00000);
  }
  else {
    uVar9 = FUN_60165558(0,0x40000000,uVar7,uVar2);
    uVar10 = FUN_601678fc(uVar6,uVar3,uVar7,uVar2);
    uVar9 = FUN_601675d8((int)uVar10,(int)((ulonglong)uVar10 >> 0x20),(int)uVar9,
                         (int)((ulonglong)uVar9 >> 0x20));
    uVar9 = FUN_60138720((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),(int)unaff_d9,
                         (int)((ulonglong)unaff_d9 >> 0x20));
    uVar9 = FUN_60165558((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),(int)unaff_d10,
                         (int)((ulonglong)unaff_d10 >> 0x20));
    uVar9 = FUN_60138720((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0,0x3ff00000);
    if (iVar1 < -0x3fd) {
      uVar9 = FUN_601678fc((int)uVar9,
                           (int)((ulonglong)uVar9 >> 0x20) + iVar1 * 0x100000 + 0x3e800000,0,
                           0x1700000);
      iVar1 = FUN_60138528((int)uVar9,(int)((ulonglong)uVar9 >> 0x20));
      if (iVar1 == 4) {
        FUN_6013a000();
      }
    }
  }
  return;
}
