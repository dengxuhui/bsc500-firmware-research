
uint FUN_600298bc(uint param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = param_1;
  if (((0x7f < param_1) && (uVar1 = 0, param_1 < 0x100)) && (param_2 == 0x1b5)) {
    uVar1 = (uint)*(ushort *)(&DAT_60436100 + param_1 * 2);
  }
  return uVar1;
}
