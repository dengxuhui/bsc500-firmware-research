
uint * FUN_6002ef50(undefined4 param_1,uint *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  char *pcVar4;
  undefined4 uVar5;
  
  if (((uint)param_2 & 3) == 0) {
    uVar3 = param_3 - 0x14U & 0xfffffffc;
    if (uVar3 < 0x3ffffff5) {
      *param_2 = param_3 - 8U & 0xfffffffc | 1;
      FUN_60123970(param_1,param_2 + -1,1,uVar3,param_1,param_2,param_3,param_4);
      iVar1 = FUN_60126b5a(param_2 + -1);
      *(undefined4 *)(iVar1 + 4) = 2;
      return param_2;
    }
    pcVar4 = "lv_tlsf_add_pool: Memory size must be between %u and %u bytes.\n";
    uVar5 = 0x14;
    param_3 = 0x40000008;
    uVar2 = 0x3de;
  }
  else {
    uVar2 = 0x3d2;
    pcVar4 = "lv_tlsf_add_pool: Memory must be aligned by %u bytes.\n";
    uVar5 = 4;
  }
  FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_tlsf.c",uVar2,
               "lv_tlsf_add_pool",pcVar4,uVar5,param_3);
  return (uint *)0x0;
}
