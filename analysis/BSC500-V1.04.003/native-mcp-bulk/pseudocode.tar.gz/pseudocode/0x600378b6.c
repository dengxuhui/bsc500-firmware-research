
void FUN_600378b6(undefined4 param_1,undefined2 param_2)

{
  int iVar1;
  
  iVar1 = FUN_60152ec0();
  if (iVar1 != 0) {
    *(undefined2 *)(iVar1 + 6) = param_2;
  }
  return;
}
