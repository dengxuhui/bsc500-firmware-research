
void FUN_60006df8(undefined4 *param_1)

{
  if (*(char *)(param_1 + 0x1c) != '\0') {
    (**(code **)*param_1)(param_1);
    *(undefined1 *)(param_1 + 0x1c) = 0;
  }
  return;
}
