
/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_60015cbc(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int local_38;
  short local_32;
  int local_30 [2];
  undefined1 auStack_28 [8];
  
  local_30[0] = 0;
  local_30[1] = 0;
  local_32 = 0;
  local_38 = 0;
  iVar1 = FUN_60166758(&local_38,param_1,1);
  if (iVar1 != 0) {
    return 0;
  }
  if ((local_38 == 0) || (iVar1 = FUN_6016506c(), iVar1 == 0)) {
    return 0;
  }
  iVar1 = FUN_6015cbf2(local_38);
  if (iVar1 == 0) {
    iVar1 = FUN_60133eee();
    if (iVar1 != 0) {
      iVar5 = FUN_60137fd4();
      if (iVar5 != 0) goto LAB_60015cfa;
      FUN_60133ef6(iVar1);
    }
    FUN_601667bc(local_38);
    uVar4 = 0xffffffff;
  }
  else {
    iVar5 = 0;
    iVar1 = 0;
LAB_60015cfa:
    do {
      iVar2 = FUN_6015d9d4(local_38);
      if (iVar2 != 0) {
        FUN_601667bc(local_38);
        FUN_6013810c(iVar5);
        FUN_60133ef6(iVar1);
        return 0;
      }
      iVar2 = 0;
      while ((iVar2 != 8 && (iVar3 = FUN_6015d9d4(local_38), iVar3 == 0))) {
        FUN_60161ef4(local_38,auStack_28 + iVar2,1,local_30 + 1);
        iVar2 = iVar2 + 1;
      }
      FUN_60138740(iVar5,iVar1,auStack_28,iVar2,local_30,&local_32);
      iVar2 = local_30[0];
    } while ((local_32 != 0x12) || (local_30[0] == 0));
    FUN_601667bc(local_38);
    FUN_6013810c(iVar5);
    FUN_60133ef6(iVar1);
    uVar4 = *(undefined4 *)(iVar2 + 0x18);
  }
  return uVar4;
}
