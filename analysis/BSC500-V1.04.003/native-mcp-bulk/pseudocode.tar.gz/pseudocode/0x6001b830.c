
longlong FUN_6001b830(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  
  if (*(ushort *)(param_1 + 0x188) != 0) {
    uVar2 = (uint)*(ushort *)(param_1 + 0x188);
    uStack_2c = param_3;
    uStack_28 = param_4;
LAB_6001b846:
    do {
      uVar4 = uVar2 - 1 & 0xffff;
      iVar3 = param_1 + uVar4 * 8 + 0x108;
      iVar1 = FUN_6014dd2c(iVar3,param_2);
      if (iVar1 != 0) {
        return CONCAT44(param_2,1);
      }
      iVar1 = FUN_6014dd2c(param_2,iVar3);
      if (iVar1 == 0) {
        iVar1 = FUN_601524c0(iVar3,param_2);
        if (iVar1 == 0) {
          if (((int)uVar2 < 2) || (uVar2 = uVar2 - 1, *(short *)(param_1 + 0x188) == 0)) {
            return (ulonglong)param_2 << 0x20;
          }
          goto LAB_6001b846;
        }
        FUN_6015245c(param_2,iVar3);
      }
      FUN_60026350(&uStack_2c,param_1 + 0x108,uVar4);
      uVar2 = (uint)*(ushort *)(param_1 + 0x188);
    } while (*(ushort *)(param_1 + 0x188) != 0);
  }
  return (ulonglong)param_2 << 0x20;
}
