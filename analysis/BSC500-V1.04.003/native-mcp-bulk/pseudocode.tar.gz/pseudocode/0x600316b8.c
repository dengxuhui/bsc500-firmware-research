
undefined4 FUN_600316b8(void)

{
  return uRam2000b3dc;
}
