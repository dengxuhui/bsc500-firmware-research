
void FUN_6000d73c(void)

{
  uRam2000b3a0 = FUN_6016717c();
  if (cRam2000b39c == '\x01') {
    FUN_6016507e(0x2000b3a8,3000,0);
    cRam2000b39c = '\0';
  }
  return;
}
