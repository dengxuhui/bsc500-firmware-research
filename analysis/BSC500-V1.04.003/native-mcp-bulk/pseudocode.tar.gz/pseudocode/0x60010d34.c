
void thunk_FUN_60154c98(void)

{
                    /* WARNING: Subroutine does not return */
  FUN_60154c98();
}
