
void FUN_6002f0dc(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined4 local_20;
  undefined4 uStack_1c;
  
  uVar4 = (uint)*(byte *)(param_1 + 0x8a);
  uVar3 = *(undefined4 *)(param_1 + 0x160);
  local_20 = 0;
  uStack_1c = param_4;
  if ((int)(uVar4 << 0x19) < 0) {
    iVar1 = FUN_6015cbf2(uVar3);
    FUN_60163c98(uVar3,iVar1 + 8);
  }
  if ((int)(uVar4 << 0x1a) < 0) {
    iVar1 = FUN_6015cbf2(uVar3);
    FUN_60163c98(uVar3,iVar1 + 1);
  }
  if ((int)(uVar4 << 0x1b) < 0) {
    FUN_60161ef4(uVar3,(int)&uStack_1c + 3,1,&local_20);
    iVar1 = FUN_6015cbf2(uVar3);
    FUN_60163c98(uVar3,(uStack_1c >> 0x18) + iVar1);
  }
  if ((int)(uVar4 << 0x1c) < 0) {
    FUN_60161ef4(uVar3,(int)&uStack_1c + 3,1,&local_20);
    iVar1 = FUN_6015cbf2(uVar3);
    FUN_60163c98(uVar3,(uStack_1c >> 0x18) + iVar1);
  }
  if ((int)(uVar4 << 0x1d) < 0) {
    FUN_60161ef4(uVar3,(int)&uStack_1c + 3,1,&local_20);
    iVar1 = FUN_6015cbf2(uVar3);
    FUN_60163c98(uVar3,(uStack_1c >> 0x18) + iVar1);
    iVar1 = FUN_6015cbf2(uVar3);
    FUN_60163c98(uVar3,iVar1 + -1);
    uVar2 = FUN_6015cbf2(uVar3);
    *(undefined4 *)(param_1 + 0x158) = uVar2;
    FUN_60161ef4(uVar3,(int)&uStack_1c + 3,1,&local_20);
    *(bool *)(param_1 + 0x15c) = uStack_1c._3_1_ == 'Q';
  }
  return;
}
