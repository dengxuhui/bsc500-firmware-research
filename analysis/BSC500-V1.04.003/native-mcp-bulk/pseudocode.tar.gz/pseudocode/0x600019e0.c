
int FUN_600019e0(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = param_3 + 4U & 0xfffffff8;
  for (iVar2 = -0x48; iVar2 != 0; iVar2 = iVar2 + 4) {
    *(undefined4 *)(uVar1 + iVar2) = 0xdeadbeef;
  }
  *(undefined4 *)(uVar1 - 0x20) = param_2;
  *(undefined4 *)(uVar1 - 0x1c) = 0;
  *(undefined4 *)(uVar1 - 0x18) = 0;
  *(undefined4 *)(uVar1 - 0x14) = 0;
  *(undefined4 *)(uVar1 - 0x10) = 0;
  *(undefined4 *)(uVar1 - 0xc) = param_4;
  *(undefined4 *)(uVar1 - 8) = param_1;
  *(undefined4 *)(uVar1 - 4) = 0x1000000;
  *(undefined4 *)(uVar1 - 0x48) = 0;
  *(undefined4 *)(uVar1 - 0x44) = 0;
  return uVar1 - 0x48;
}
