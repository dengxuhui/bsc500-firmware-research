
void FUN_6001cc64(undefined4 param_1,undefined2 param_2)

{
  FUN_6015c29c();
  FUN_6015968c(param_1,param_2);
  FUN_6015c2d8();
  return;
}
