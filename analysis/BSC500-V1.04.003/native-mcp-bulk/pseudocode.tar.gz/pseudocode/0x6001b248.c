
void FUN_6001b248(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = 0x60f3fb14;
  iVar2 = 0x60f68b54;
  for (iVar3 = 0; iVar3 != 0xe; iVar3 = iVar3 + 1) {
    *(int *)(iVar3 * 4 + 0x200859ac) = iVar2;
    *(int *)(iVar3 * 4 + 0x20085974) = iVar1;
    iVar1 = iVar1 + 12000;
    iVar2 = iVar2 + 6000;
  }
  return;
}
