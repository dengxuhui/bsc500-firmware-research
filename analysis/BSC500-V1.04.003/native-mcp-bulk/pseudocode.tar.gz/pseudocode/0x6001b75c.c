
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001b75c(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if ((param_2 != (undefined4 *)0x0) && (_DAT_2000a6dc != 0)) {
    *param_2 = param_1;
    puRam2000a6ec = param_2;
    *(undefined2 *)(param_2 + 0x15) = 0xffff;
    uVar1 = 1;
  }
  return uVar1;
}
