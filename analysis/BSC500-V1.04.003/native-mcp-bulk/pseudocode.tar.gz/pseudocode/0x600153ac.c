
void FUN_600153ac(int param_1)

{
  ZeroBytes(param_1 + 0xa8c,0x18);
  *(undefined2 *)(param_1 + 0xa9c) = 0x102;
  *(undefined4 *)(param_1 + 0xa94) = 0x1040502;
  *(undefined2 *)(param_1 + 0xa90) = 0x604;
  *(undefined4 *)(param_1 + 0xa8c) = 0x3020701;
  return;
}
