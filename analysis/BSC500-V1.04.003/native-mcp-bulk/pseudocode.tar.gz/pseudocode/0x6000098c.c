
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000098c(void)

{
  int iVar1;
  
  _DAT_2000958a = 0;
  for (iVar1 = 0; iVar1 != 0x1c0; iVar1 = iVar1 + 8) {
    *(int *)(iVar1 + 0x2007e738) = iVar1 + 0x2007e738;
    *(int *)(iVar1 + 0x2007e73c) = iVar1 + 0x2007e738;
  }
  _DAT_20009590 = 0;
  _DAT_20009594 = 0;
  DAT_20009588 = 0x37;
  thunk_EXT_FUN_000219ea(0x200095a0,0,0x20);
  _DAT_20009598 = &DAT_20009598;
  _DAT_2000959c = &DAT_20009598;
  return;
}
