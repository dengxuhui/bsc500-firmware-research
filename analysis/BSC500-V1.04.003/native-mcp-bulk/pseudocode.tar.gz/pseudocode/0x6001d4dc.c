
uint FUN_6001d4dc(uint param_1,int param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  uint uVar2;
  bool bVar3;
  
  uVar2 = param_1;
  if (0x7f < param_1) {
    bVar3 = param_1 >> 0x10 == 0;
    if (bVar3) {
      param_4 = 0x1b5;
    }
    uVar2 = 0;
    if (bVar3 && param_2 == param_4) {
      for (iVar1 = 0; iVar1 != 0x80; iVar1 = iVar1 + 1) {
        if ((ushort)(&DAT_60436200)[iVar1] == param_1) {
          uVar2 = iVar1 + 0x80U & 0xff;
          goto LAB_6001d4f4;
        }
      }
      uVar2 = 0;
    }
  }
LAB_6001d4f4:
  return uVar2 & 0xffff;
}
