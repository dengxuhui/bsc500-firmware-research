
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001b7c(void)

{
  char *local_18;
  undefined4 local_14;
  undefined4 uStack_10;
  undefined4 local_c;
  
  local_c = 0;
  local_14 = 0;
  uStack_10 = 0;
  local_18 = "m_msssage";
  _DAT_2000b5e4 = FUN_60168494(&local_18);
  if (_DAT_2000b5e4 != 0) {
    return;
  }
  FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
               "mMessageMutex && \"require faied\"","message_Init",0x33);
  FUN_6013dd48();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}
