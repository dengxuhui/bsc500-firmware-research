
uint FUN_6001b6d0(int param_1,uint param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  for (uVar1 = 0; param_2 != uVar1; uVar1 = uVar1 + 1) {
    uVar2 = 1 << (uVar1 & 0xff);
    if ((uVar2 & param_3) != 0 || param_3 == 0) {
      uVar3 = uVar3 | uVar2;
      *(uint *)(uVar1 * 4 + 0x40044000) = *(uint *)(param_1 + uVar1 * 8) & 0x7fffc;
      uRam40044088 = *(undefined4 *)(param_1 + uVar1 * 8 + 4);
    }
  }
  uRam40044084 = 0;
  if (param_3 == 0) {
    param_3 = uVar3;
  }
  uRam40044080 = param_3;
  return uVar3;
}
