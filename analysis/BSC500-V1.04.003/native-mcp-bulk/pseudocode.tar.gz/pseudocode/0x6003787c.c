
void FUN_6003787c(void)

{
  int iVar1;
  
  for (iVar1 = 0; iVar1 != 2; iVar1 = iVar1 + 1) {
    if (*(char *)(iVar1 + 0x200073c1) != -1) {
      FUN_601535c8(*(char *)(iVar1 + 0x200073c1),10);
    }
  }
  return;
}
