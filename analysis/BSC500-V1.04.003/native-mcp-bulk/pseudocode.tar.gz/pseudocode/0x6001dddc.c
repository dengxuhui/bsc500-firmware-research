
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6001dddc(void)

{
  return _DAT_2000a5ac & 1;
}
