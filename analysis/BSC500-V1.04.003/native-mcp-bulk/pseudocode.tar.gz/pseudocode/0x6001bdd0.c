
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001bdd0(byte param_1)

{
  DAT_20009cc4 = (param_1 ^ 0xff) & DAT_20009cc4;
  if (DAT_20009cc4 != 0) {
    return;
  }
  if (_DAT_20009aac != 0) {
    FUN_601649f0(_DAT_20009ab0);
    return;
  }
  return;
}
