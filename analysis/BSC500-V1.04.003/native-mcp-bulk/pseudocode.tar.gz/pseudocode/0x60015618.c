
undefined4 FUN_60015618(int param_1,int param_2,uint *param_3,uint *param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  undefined4 uVar9;
  uint uVar10;
  undefined8 uVar11;
  undefined4 local_6c;
  undefined4 uStack_68;
  int local_64 [5];
  uint local_50 [4];
  uint local_40 [4];
  
  local_64[0] = 0;
  local_6c = 0;
  uStack_68 = 0;
  if (param_1 == 0 || param_2 == 0) {
    return 0xffffffff;
  }
  if (param_3 == (uint *)0x0) {
    return 0xffffffff;
  }
  if (param_4 == (uint *)0x0) {
    return 0xffffffff;
  }
  iVar1 = FUN_60020350(param_2);
  if (iVar1 == 0) {
    uVar2 = FUN_601668a4();
    if ((uVar2 | 2) == 2) {
      local_40[0] = *param_3;
      local_40[1] = param_3[1];
      local_40[2] = param_3[2];
      local_40[3] = param_3[3];
      local_50[0] = *param_4;
      local_50[3] = param_4[3];
      local_50[1] = param_4[1];
      local_50[2] = param_4[2];
    }
    else {
      local_40[1] = param_3[1] >> 1;
      local_40[2] = param_3[2] >> 1;
      local_40[0] = *param_3 >> 1;
      local_40[3] = param_3[3] >> 1;
      local_50[0] = *param_4 >> 1;
      local_50[1] = param_4[1] >> 1;
      local_50[2] = param_4[2] >> 1;
      local_50[3] = param_4[3] >> 1;
    }
    if (local_40[0] < uRam2008055c) {
      return 0;
    }
    if (uRam20080564 < local_40[0]) {
      return 0;
    }
    if (local_50[0] < uRam20080560) {
      return 0;
    }
    if (uRam20080568 < local_50[0]) {
      return 0;
    }
    for (iVar1 = 0; iVar1 != 4; iVar1 = iVar1 + 1) {
      local_64[iVar1 + 1] =
           (local_50[iVar1] - uRam20080560) * ((uRam20080564 - uRam2008055c) + 1) +
           (local_40[iVar1] - uRam2008055c);
    }
    iVar1 = FUN_60166758(0x20080558,0x200803f8,1);
    if (iVar1 == 0) {
      iVar1 = 0;
      uVar9 = 0;
      while( true ) {
        if (iVar1 == 0x10) break;
        uVar2 = *(uint *)((int)local_40 + iVar1);
        if ((((uRam2008055c <= uVar2) && (uVar2 <= uRam20080564)) &&
            (uVar7 = *(uint *)((int)local_50 + iVar1), uRam20080560 <= uVar7)) &&
           ((uVar7 <= uRam20080568 &&
            ((iVar5 = local_64[1], iVar1 == 0 ||
             (iVar5 = *(int *)((int)local_64 + iVar1 + 4), iVar5 != *(int *)((int)local_64 + iVar1))
             ))))) {
          iVar5 = iVar5 * 5 + iRam20080528;
          if (cRam20080482 < '\0') {
            iVar5 = iVar5 + 0x10;
          }
          FUN_60163c98(uRam20080558,iVar5);
          uVar9 = FUN_60161ef4(uRam20080558,&uStack_68,5,&local_6c);
          uVar11 = FUN_6012222c(&uStack_68);
          uVar6 = (uint)((ulonglong)uVar11 >> 0x20);
          uVar10 = (uVar6 & 0x7fffffff) >> 0x18;
          uVar8 = (uint)uVar11 >> 0x18 | uVar6 << 8;
          if (uVar10 <= uRam20080534 && (uint)(uRam20080530 <= uVar8) <= uVar10 - uRam20080534) {
            uVar9 = FUN_60161ef4(uRam20080558,&uStack_68,5,&local_6c);
            uVar11 = FUN_6012222c(&uStack_68);
            uVar10 = (uint)((ulonglong)uVar11 >> 0x20);
            if (((uint)uVar11 >> 0x18 | uVar10 << 8) != uVar8 ||
                ((uVar10 ^ uVar6) & 0x7fffffff) >> 0x18 != 0) {
              FUN_60163c98(uRam20080558,iRam20080528 + uVar8);
              if (0x7fffffff < (uint)(int)cRam20080482) {
                iVar5 = FUN_6015cbf2(uRam20080558);
                FUN_60163c98(uRam20080558,iVar5 + 0x20);
              }
              uVar9 = FUN_60159a10(uVar2,uRam20080520);
              uVar11 = FUN_60166bb4(uVar9);
              FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),0,0x412e8480);
              iVar3 = FUN_60167a50();
              iVar5 = iRam20085898;
              uVar9 = FUN_60159a60(uVar7,uRam20080520);
              uVar11 = FUN_60166bb4(uVar9);
              FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),0,0x412e8480);
              iVar4 = FUN_60167a50();
              uVar9 = FUN_6001ee88(param_1,iVar3 - iVar5,iVar4 - iRam20085894,0x200803f8);
              FUN_60163c98(uRam20080558,iRam20080528 + uVar8);
              if (0x7fffffff < (uint)(int)cRam20080482) {
                iVar5 = FUN_6015cbf2(uRam20080558);
                FUN_60163c98(uRam20080558,iVar5 + 0x20);
              }
            }
          }
        }
        iVar1 = iVar1 + 4;
      }
      FUN_601667bc(uRam20080558);
      return uVar9;
    }
  }
  return 0xffffffff;
}
