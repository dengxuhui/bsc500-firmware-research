
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001a4d8(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = CONCAT22(_DAT_20034532,_DAT_20034530);
  uVar1 = FUN_60154888();
  FUN_601546c8(uVar1,0,uVar2);
  return;
}
