
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600074f0(uint param_1,uint param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint unaff_r6;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  bool bVar7;
  undefined *local_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 local_30;
  int local_2c;
  int local_28;
  
  local_2c = 0;
  local_28 = 0;
  bVar7 = (param_2 & param_1) != param_1;
  if (bVar7) {
    unaff_r6 = param_2;
  }
  if ((bVar7 && (param_2 & 0x40000000) != 0) &&
     (iVar1 = FUN_601169e8(param_1,&local_28), iVar1 != 0)) {
    uVar5 = 0;
    for (uVar3 = unaff_r6 & 0xbfffffff; uVar3 != 0; uVar3 = uVar3 >> 1) {
      if ((uVar3 & 1) != 0) {
        uVar6 = 1 << (uVar5 & 0xff);
        uVar4 = uVar6 | 0x40000000;
        iVar1 = FUN_601169e8(uVar4,&local_2c);
        if (iVar1 != 0) {
          if (_DAT_2000b3c4 == 0) {
            local_30 = 0;
            local_38 = 1;
            uStack_34 = 0;
            local_3c = &DAT_603fcde5;
            _DAT_2000b3c4 = FUN_60168494(&local_3c);
          }
          FUN_6016825e(_DAT_2000b3c4,0xffffffff);
          if ((*(uint *)(local_2c + 0x1c) & param_1 & 0xbfffffff) != param_1) {
            uVar2 = *(uint *)(local_2c + 0x24);
            if (param_3 == 0) {
              if (((uVar2 & param_1) == param_1) && (*(short *)(local_2c + 0x22) != 0)) {
                *(short *)(local_2c + 0x22) = *(short *)(local_2c + 0x22) + -1;
                *(uint *)(local_2c + 0x24) = uVar2 & (param_1 ^ 0xbfffffff) | 0x40000000;
                *(uint *)(local_28 + 0x1c) = *(uint *)(local_28 + 0x1c) & ~uVar6 | 0x40000000;
              }
            }
            else if ((uVar2 & param_1) != param_1) {
              *(uint *)(local_2c + 0x24) = uVar2 | param_1;
              *(uint *)(local_28 + 0x1c) = *(uint *)(local_28 + 0x1c) | uVar4;
              *(short *)(local_2c + 0x22) = *(short *)(local_2c + 0x22) + 1;
            }
          }
          if (_DAT_2000b3c4 != 0) {
            FUN_601682ae();
          }
        }
      }
      uVar5 = uVar5 + 1;
    }
  }
  return;
}
