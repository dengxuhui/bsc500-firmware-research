
void FUN_6001be68(undefined1 param_1,int param_2,undefined4 param_3,undefined1 *param_4,
                 undefined1 param_5,uint param_6)

{
  undefined1 *puVar1;
  undefined1 uVar2;
  int iVar3;
  int local_28;
  undefined4 uStack_24;
  undefined1 *local_20;
  
  if ((*(byte *)(param_6 * 0x28 + 0x20044a0f) == param_6) &&
     (local_28 = param_2, uStack_24 = param_3, local_20 = param_4, iVar3 = FUN_6015cb0c(&local_28),
     puVar1 = local_20, iVar3 != 0)) {
    FUN_60166858(local_20 + 2,0x12,0xff);
    puVar1[1] = param_1;
    *puVar1 = 2;
    if (param_2 != 0) {
      puVar1[2] = (char)param_2;
    }
    puVar1[4] = (char)param_3;
    if (param_4 != (undefined1 *)0x0) {
      puVar1[5] = (char)param_4;
    }
    puVar1[7] = param_5;
    uVar2 = FUN_60160db4(puVar1,0x13);
    puVar1[0x13] = uVar2;
    local_28 = CONCAT22(local_28._2_2_,0x14);
    FUN_6015cb40(&local_28,param_6);
  }
  return;
}
