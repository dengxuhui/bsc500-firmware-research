
undefined4 FUN_60029a14(undefined4 param_1,undefined4 param_2)

{
  FUN_6015bd24(param_2);
  return 0;
}
