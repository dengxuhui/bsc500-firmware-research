
undefined4 FUN_6001c044(void)

{
  return 0;
}
