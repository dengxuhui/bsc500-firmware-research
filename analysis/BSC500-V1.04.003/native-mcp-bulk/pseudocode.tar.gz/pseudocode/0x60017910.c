
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60017910(int *param_1,int param_2,int param_3,int param_4,int param_5)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  
  if (_DAT_2000b5e4 == 0) {
    FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
                 "mMessageMutex && \"message not init \"","message_bindEventListenr",0xdb,param_4);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  if (param_1 == (int *)0x0) {
    FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
                 "manager && \"messagelistener should be init\"","message_bindEventListenr",0xdc,
                 param_4);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar7 = param_2;
  iVar8 = param_3;
  iVar9 = param_4;
  piVar1 = (int *)FUN_60161f90(0x14,10,param_3,param_4,param_1,param_2,param_3);
  *piVar1 = param_3;
  piVar1[1] = param_2;
  piVar1[2] = param_4;
  piVar1[3] = param_5;
  piVar1[4] = 0;
  iVar2 = FUN_6016825e(_DAT_2000b5e4,5000);
  if (iVar2 == 0) {
    piVar4 = param_1 + 1;
    piVar5 = (int *)*piVar4;
    for (piVar6 = (int *)*piVar4; piVar6 != (int *)0x0; piVar6 = (int *)piVar6[4]) {
      if (piVar6[1] == param_2) {
        if ((piVar6[2] == param_4) && (*piVar6 == param_3)) {
          FUN_6015e008(piVar1);
          goto LAB_600179da;
        }
      }
      else if (piVar6[2] == param_4) {
        FUN_6015e008(piVar1);
        FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
                     "!multiTaskRegister && \"same listener not allowed register from different task\""
                     ,"message_bindEventListenr",0x115,iVar9);
        FUN_6013dd48();
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      piVar5 = piVar6;
    }
    if (piVar5 != (int *)0x0) {
      piVar4 = piVar5 + 4;
    }
    *piVar4 = (int)piVar1;
    *param_1 = *param_1 + 1;
LAB_600179da:
    FUN_601682ae(_DAT_2000b5e4);
    uVar3 = 1;
  }
  else {
    FUN_60167f3c(3,"MSG_SVC",1,"acquire mutex failed %s","message_bindEventListenr",iVar7,iVar8,
                 iVar9);
    uVar3 = 0;
  }
  return uVar3;
}
