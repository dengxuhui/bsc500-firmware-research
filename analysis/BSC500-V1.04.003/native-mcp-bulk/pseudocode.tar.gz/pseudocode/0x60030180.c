
undefined4 FUN_60030180(undefined4 *param_1)

{
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0;
    return 0;
  }
  return 0x16;
}
