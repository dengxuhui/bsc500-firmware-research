
undefined4 FUN_600243e0(void)

{
  ulonglong uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int iVar11;
  uint uVar12;
  char cVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  ulonglong in_d0;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 local_18;
  
  iVar11 = 0;
  local_18._0_4_ = (int)in_d0;
  local_18._4_4_ = (uint)(in_d0 >> 0x20);
  if ((int)local_18._4_4_ < 0x7ff00000) {
    if (((local_18._4_4_ & 0x7fffffff) < 0x7ff00001) &&
       (((local_18._4_4_ & 0x7fffffff) != 0x7ff00000 || ((int)local_18 == 0)))) {
      uVar3 = local_18._4_4_;
      uVar1 = in_d0;
      if ((int)local_18._4_4_ < 0x100000) {
        if ((int)local_18 == 0 && (in_d0 & 0x7fffffff00000000) == 0) {
          FUN_60163236(2);
          uVar14 = FUN_601259b8();
          uVar14 = FUN_60138558(uVar14,extraout_s1);
          return uVar14;
        }
        if ((longlong)in_d0 < 0) {
          FUN_60163236(1);
          uVar14 = FUN_60138608();
          return uVar14;
        }
        iVar11 = -0x36;
        local_18 = FUN_601678fc((int)local_18,local_18._4_4_,0,0x43500000);
        uVar3 = (uint)(local_18 >> 0x20);
        local_18 = local_18 & 0xffffffff;
        uVar1 = local_18;
      }
      local_18 = uVar1;
      uVar12 = uVar3 & 0xfffff;
      uVar2 = uVar12 + 0x95f64 & 0x100000;
      iVar11 = iVar11 + ((int)uVar3 >> 0x14) + -0x3ff + ((int)uVar2 >> 0x14);
      uVar17 = FUN_60165558((int)local_18,uVar2 ^ 0x3ff00000 | uVar12,0,0x3ff00000);
      uVar7 = (undefined4)((ulonglong)uVar17 >> 0x20);
      uVar14 = (undefined4)uVar17;
      uVar3 = uVar12 + 2 & 0xfffff;
      cVar13 = uVar3 == 3;
      if (uVar3 < 3) {
        FUN_60139f88(uVar14,uVar7,0,0);
        if (cVar13 == '\0') {
          uVar18 = FUN_601678fc(uVar14,uVar7,0x55555555,0x3fd55555);
          uVar18 = FUN_60138720((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),0,0x3fe00000);
          uVar19 = FUN_601678fc(uVar14,uVar7,uVar14,uVar7);
          uVar18 = FUN_601678fc((int)uVar19,(int)((ulonglong)uVar19 >> 0x20),(int)uVar18,
                                (int)((ulonglong)uVar18 >> 0x20));
          uVar4 = (undefined4)((ulonglong)uVar18 >> 0x20);
          if (iVar11 != 0) {
            uVar17 = FUN_6016759c(iVar11,uVar4);
            uVar5 = (undefined4)((ulonglong)uVar17 >> 0x20);
            uVar19 = FUN_601678fc((int)uVar17,uVar5,0x35793c76,0x3dea39ef);
            uVar18 = FUN_60138720((int)uVar19,(int)((ulonglong)uVar19 >> 0x20),(int)uVar18,uVar4);
            uVar18 = FUN_60165558((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),uVar14,uVar7);
            uVar17 = FUN_601678fc((int)uVar17,uVar5,0xfee00000,0x3fe62e42);
          }
          uVar14 = FUN_60165558((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),(int)uVar18,
                                (int)((ulonglong)uVar18 >> 0x20));
        }
        else {
          if (iVar11 == 0) {
            return 0;
          }
          uVar17 = FUN_6016759c(iVar11);
          uVar14 = (undefined4)((ulonglong)uVar17 >> 0x20);
          uVar18 = FUN_601678fc((int)uVar17,uVar14,0x35793c76,0x3dea39ef);
          uVar17 = FUN_601678fc((int)uVar17,uVar14,0xfee00000,0x3fe62e42);
          uVar14 = FUN_601682c8((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),(int)uVar18,
                                (int)((ulonglong)uVar18 >> 0x20));
        }
      }
      else {
        uVar17 = FUN_601682c8(uVar14,uVar7,0,0x40000000);
        uVar17 = FUN_601675d8(uVar14,uVar7,(int)uVar17,(int)((ulonglong)uVar17 >> 0x20));
        uVar8 = (undefined4)((ulonglong)uVar17 >> 0x20);
        uVar4 = (undefined4)uVar17;
        uVar17 = FUN_6016759c(iVar11);
        uVar9 = (undefined4)((ulonglong)uVar17 >> 0x20);
        uVar5 = (undefined4)uVar17;
        uVar17 = FUN_601678fc(uVar4,uVar8,uVar4,uVar8);
        uVar10 = (undefined4)((ulonglong)uVar17 >> 0x20);
        uVar6 = (undefined4)uVar17;
        uVar17 = FUN_601678fc(uVar6,uVar10,uVar6,uVar10);
        uVar16 = (undefined4)uVar17;
        uVar15 = FUN_60138628(uVar16,&UNK_60277298,3);
        uVar17 = FUN_601678fc(uVar15,extraout_s1_00,uVar16,(int)((ulonglong)uVar17 >> 0x20));
        uVar16 = FUN_60138628(uVar16,&UNK_602772b0,4);
        uVar18 = FUN_601678fc(uVar16,extraout_s1_01,uVar6,uVar10);
        uVar17 = FUN_601682c8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar17,
                              (int)((ulonglong)uVar17 >> 0x20));
        uVar16 = (undefined4)((ulonglong)uVar17 >> 0x20);
        uVar6 = (undefined4)uVar17;
        if ((int)(0x6b851 - uVar12 | uVar12 - 0x6147a) < 1) {
          if (iVar11 == 0) {
            uVar17 = FUN_60165558(uVar14,uVar7,uVar6,uVar16);
            uVar17 = FUN_601678fc((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar4,uVar8);
            uVar14 = FUN_60138720((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar14,uVar7);
          }
          else {
            uVar17 = FUN_601678fc(uVar5,uVar9,0x35793c76,0x3dea39ef);
            uVar18 = FUN_60165558(uVar14,uVar7,uVar6,uVar16);
            uVar18 = FUN_601678fc((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),uVar4,uVar8);
            uVar17 = FUN_60165558((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar17,
                                  (int)((ulonglong)uVar17 >> 0x20));
            uVar17 = FUN_60165558((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar14,uVar7);
            uVar18 = FUN_601678fc(uVar5,uVar9,0xfee00000,0x3fe62e42);
            uVar14 = FUN_60165558((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar17,
                                  (int)((ulonglong)uVar17 >> 0x20));
          }
        }
        else {
          uVar17 = FUN_601678fc(uVar14,uVar7,0,0x3fe00000);
          uVar17 = FUN_601678fc((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar14,uVar7);
          uVar15 = (undefined4)((ulonglong)uVar17 >> 0x20);
          uVar10 = (undefined4)uVar17;
          if (iVar11 == 0) {
            uVar17 = FUN_601682c8(uVar10,uVar15,uVar6,uVar16);
            uVar17 = FUN_601678fc((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar4,uVar8);
            uVar17 = FUN_60138720((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar10,uVar15);
            uVar14 = FUN_60138720((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar14,uVar7);
          }
          else {
            uVar17 = FUN_601678fc(uVar5,uVar9,0x35793c76,0x3dea39ef);
            uVar18 = FUN_601682c8(uVar10,uVar15,uVar6,uVar16);
            uVar18 = FUN_601678fc((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),uVar4,uVar8);
            uVar17 = FUN_601682c8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar17,
                                  (int)((ulonglong)uVar17 >> 0x20));
            uVar17 = FUN_60138720((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar10,uVar15);
            uVar17 = FUN_60165558((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),uVar14,uVar7);
            uVar18 = FUN_601678fc(uVar5,uVar9,0xfee00000,0x3fe62e42);
            uVar14 = FUN_60165558((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar17,
                                  (int)((ulonglong)uVar17 >> 0x20));
          }
        }
      }
      return uVar14;
    }
  }
  uVar14 = FUN_60138584((int)local_18);
  return uVar14;
}
