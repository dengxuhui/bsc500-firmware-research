
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001a8bc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  
  if (_DAT_2008dbe8 != 0) {
    uVar1 = FUN_60166a64();
    FUN_6016750c();
    FUN_60164d18(uVar1,0x80,param_1,param_2);
    FUN_60166a7c(7,0,1,uVar1);
    FUN_60167574();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("ulog.init_ok","ulog_vraw",0x296,param_4,param_4);
}
