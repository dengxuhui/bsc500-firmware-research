
void FUN_600387d8(int param_1,int param_2,int param_3)

{
  undefined1 auStack_34 [44];
  
  FUN_60163c5c(param_1 + param_2,auStack_34);
  if (param_3 != 0) {
    CopyBytes(param_3,auStack_34,0x24);
  }
  return;
}
