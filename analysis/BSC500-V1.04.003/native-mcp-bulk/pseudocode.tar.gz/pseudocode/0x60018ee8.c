
undefined4 FUN_60018ee8(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  code *pcVar4;
  uint in_fpscr;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined1 auStack_88 [32];
  undefined8 local_68;
  undefined8 local_60;
  float local_58;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_34;
  
  uRam2000c718 = 1;
  if ((char)uRam2000c6f0 == '\x03') {
    FUN_6014a9b0();
  }
  if ((char)uRam2000c6f0 != '\x01') {
    uRam2000c718 = 0;
    return 0xffffffff;
  }
  if (param_1 == 0) {
    uRam2000c718 = 0;
    return 0xffffffff;
  }
  iVar2 = FUN_60168220(param_1);
  if (0x59 < iVar2 - 5U) {
    uRam2000c718 = 0;
    return 0xffffffff;
  }
  iVar3 = iVar2 + param_1 + -4;
  uRam2000c6f0 = CONCAT11(uRam2000c6f0._1_1_,2);
  iVar2 = FUN_60168418(iVar3,&UNK_600191a4);
  if (iVar2 == 0) {
    pcVar4 = (code *)&UNK_60051631;
  }
  else {
    iVar2 = FUN_60168418(iVar3,&UNK_600191b0);
    if (iVar2 == 0) {
      pcVar4 = (code *)&UNK_60051c61;
    }
    else {
      iVar2 = FUN_60168418(iVar3,&UNK_600191bc);
      if (iVar2 != 0) {
        uRam2000c6f0 = 0x201;
        uRam2000c718 = 0;
        return 0xffffffff;
      }
      pcVar4 = (code *)&UNK_60051df1;
    }
  }
  iVar2 = FUN_60021f00(param_1);
  if (iVar2 == 0) {
    iVar2 = FUN_60022154(param_1);
    if (iVar2 == 0) {
      iVar2 = FUN_60021bf8(param_1);
      if (iVar2 == 0) {
        local_34 = 0;
        iVar2 = FUN_60166758(&local_34,param_1,1);
        if (iVar2 == 0) {
          local_3c = 1;
          local_44 = 1;
          local_40 = 0x7fffffff;
          local_4c = 0x7fffffff;
          local_48 = 0x7fffffff;
          local_50 = 0xffffffff;
          FUN_60132d1c();
          ZeroBytes(&local_68,0x18);
          ZeroBytes(auStack_88,0x20);
          do {
            do {
              do {
                iVar2 = FUN_6015d9d4(local_34);
                if (iVar2 != 0) {
                  FUN_601667bc(local_34);
                  iVar2 = FUN_60132d28(0x2000af60,auStack_88);
                  if (iVar2 != 0) goto LAB_600190ca;
                  iVar2 = FUN_60021df4(auStack_88);
                  if (iVar2 != 0) goto LAB_600190ce;
                  iVar2 = FUN_60021fec(auStack_88);
                  if (iVar2 == 0) {
                    iVar2 = FUN_6002183c(auStack_88);
                    if (iVar2 != 0) {
                      FUN_60021ee4();
                      FUN_60022138();
                      uRam2000c6f0 = 0x201;
                      uRam2000c718 = 0;
                      return 0xffffffff;
                    }
                    uRam2000c714 = 0;
                    uRam2000c6f0 = 0x103;
                    iVar2 = FUN_6015e0d0();
                    if (iVar2 != 0) {
                      uRam2000c700 = *(undefined4 *)(iVar2 + 0x20);
                    }
                    uRam20085ab9 = 4;
                    uRam20085b0c = 0;
                    uRam20085ae9 = 0;
                    uRam20085b08 = 0xbf800000;
                    uRam20085b3c = 0;
                    uRam20085b40 = uRam2000c700;
                    cRam20085ab8 = '\0';
                    if (bRam2000c6f2 < 3) {
                      cRam20085ab8 = bRam2000c6f2 + 1;
                    }
                    iVar2 = FUN_601623fc();
                    if (iVar2 != 0) {
                      uRam20085aec = 0xffffffff;
                      uRam20085af0 = 0xffffffff;
                      uRam20085af4 = 0xffffffff;
                      uRam20085b04 = *(undefined4 *)(iVar2 + 4);
                      uRam20085b00 = *(undefined4 *)(iVar2 + 8);
                    }
                    if (pcRam2000c6f4 != (code *)0x0) {
                      (*pcRam2000c6f4)(bRam2000c6f2);
                    }
                    uRam2000c718 = 0;
                    return 0;
                  }
                  FUN_60021ee4();
                  goto LAB_600190d2;
                }
                iVar2 = (*pcVar4)(local_34,&local_40,&local_48,&local_50,&local_4c,0);
              } while (((iVar2 == -1) || (iVar2 = FUN_60166dd0(&local_40), iVar2 == 1)) ||
                      (iVar2 = FUN_60166dd0(&local_48), uVar1 = local_44, iVar2 == 1));
              local_58 = (float)VectorSignedToFloat(local_4c,(byte)(in_fpscr >> 0x16) & 3);
              local_58 = local_58 / 100.0;
              uVar5 = FUN_6016759c(local_48);
              uVar6 = FUN_6016759c(uVar1);
              local_68 = FUN_601675d8((int)uVar5,(int)((ulonglong)uVar5 >> 0x20),(int)uVar6,
                                      (int)((ulonglong)uVar6 >> 0x20));
              uVar1 = local_3c;
              uVar5 = FUN_6016759c(local_40);
              uVar6 = FUN_6016759c(uVar1);
              local_60 = FUN_601675d8((int)uVar5,(int)((ulonglong)uVar5 >> 0x20),(int)uVar6,
                                      (int)((ulonglong)uVar6 >> 0x20));
              iVar2 = FUN_60132c70(0x2000af60,&local_68,auStack_88);
            } while (iVar2 != 0);
            iVar2 = FUN_60030b8c(auStack_88);
            if (iVar2 != 0) {
              FUN_6011c6ec();
LAB_60019116:
              FUN_6011c710();
              goto LAB_6001911a;
            }
            iVar2 = FUN_60030c34(auStack_88);
            if (iVar2 != 0) {
              FUN_6011c750();
              goto LAB_60019116;
            }
            iVar2 = FUN_60030a78(auStack_88);
          } while (iVar2 == 0);
          FUN_6011c750();
          FUN_6011c6ec();
LAB_6001911a:
          FUN_601667bc(local_34);
        }
        else {
LAB_600190ca:
          FUN_6011c750();
LAB_600190ce:
          FUN_6011c6ec();
LAB_600190d2:
          FUN_6011c710();
        }
      }
      else {
        FUN_6011c750();
        FUN_6011c6ec();
      }
    }
    else {
      FUN_6011c750();
    }
  }
  uRam2000c6f0 = 0x201;
  uRam2000c718 = 0;
  return 0xffffffff;
}
