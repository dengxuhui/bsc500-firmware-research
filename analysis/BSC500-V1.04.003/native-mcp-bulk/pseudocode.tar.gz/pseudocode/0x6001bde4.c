
void FUN_6001bde4(byte param_1)

{
  DAT_20009cc4 = param_1 | DAT_20009cc4;
  if (((DAT_20009cc4 & 0xf) != 0xf) && ((DAT_20009cc4 & 0x10) == 0)) {
    return;
  }
  FUN_6015de78();
  return;
}
