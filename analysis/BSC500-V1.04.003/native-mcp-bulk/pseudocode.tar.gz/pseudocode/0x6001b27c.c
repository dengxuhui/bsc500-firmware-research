
longlong FUN_6001b27c(undefined4 param_1,uint param_2)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  
  uVar7 = 0;
  iVar3 = FUN_601639fc();
  iVar5 = 0;
  do {
    uVar2 = uRam20085890;
    if (iVar5 == 0xe) {
      FUN_60168578("copy map data to pool\r\n");
      iVar5 = uRam20008304 - uVar7;
      if (uRam20008304 < uVar7) {
        iVar5 = 0;
      }
      FUN_60167214(uVar7 + 0x60d10d7c,iVar5);
      FUN_6007db44(0x60d10d7c,0x60f7d374,uVar7);
      *(undefined1 *)(iVar3 + 0x20) = 0;
      return (ulonglong)param_2 << 0x20;
    }
    iVar1 = iVar5 * 4;
    iVar10 = *(int *)(iVar1 + 0x200858d4);
    for (iVar8 = 0; iVar10 != iVar8; iVar8 = iVar8 + 1) {
      iVar9 = *(int *)(iVar1 + 0x200859ac);
      uVar6 = (uint)*(ushort *)(iVar9 + iVar8 * 2);
      if ((uVar2 < uVar7 + uVar6) ||
         (iVar4 = *(int *)(*(int *)(iVar1 + 0x20085974) + iVar8 * 4), uVar2 < iVar4 + uVar6)) {
        FUN_60168578("ERROR: %s copy_size > tile_size!!\r\n","way_level_offsets_copy");
        break;
      }
      CopyBytes(uVar7 + 0x60f7d374,iVar4 + 0x60d34d7c);
      uVar7 = uVar7 + *(ushort *)(iVar9 + iVar8 * 2);
    }
    iVar5 = iVar5 + 1;
  } while( true );
}
