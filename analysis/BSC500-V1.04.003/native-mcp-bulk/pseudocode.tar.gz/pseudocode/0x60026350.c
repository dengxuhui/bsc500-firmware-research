
void FUN_60026350(undefined4 *param_1,int param_2,uint param_3)

{
  uint uVar1;
  undefined4 *puVar2;
  
  param_1[1] = 0;
  *param_1 = 0;
  uVar1 = (uint)*(ushort *)(param_2 + 0x80);
  if (param_3 < uVar1) {
    *param_1 = *(undefined4 *)(param_2 + param_3 * 8);
    puVar2 = (undefined4 *)(param_2 + param_3 * 8);
    param_1[1] = puVar2[1];
    for (; (int)param_3 < (int)(uVar1 - 1); param_3 = param_3 + 1) {
      puVar2[1] = puVar2[3];
      *puVar2 = puVar2[2];
      uVar1 = (uint)*(ushort *)(param_2 + 0x80);
      puVar2 = puVar2 + 2;
    }
    *(short *)(param_2 + 0x80) = (short)uVar1 + -1;
  }
  return;
}
