
void FUN_60026478(int param_1,int param_2)

{
  char cVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  byte bVar5;
  char *pcVar6;
  bool bVar7;
  bool bVar8;
  undefined4 local_7c;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined1 local_6c;
  char local_6b;
  char local_6a;
  char local_69;
  undefined1 *local_68;
  undefined4 uStack_64;
  undefined1 *local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  undefined4 uStack_4c;
  
  FUN_60167f3c(7,"APP_WATCH_LOG",1,"[app_watch] decode\n");
  ZeroBytes(&local_6c,0x14);
  if ((param_1 != 0) && (param_2 != 0)) {
    ZeroBytes(0x20055a4c,0x61);
    pcVar6 = (char *)0x20055a6c;
    local_5c = 0x20055a6c;
    local_60 = &LAB_600389c8_1;
    local_68 = &LAB_600389c8_1;
    uStack_64 = 0x20055a4c;
    FUN_60161d4c(&local_58,param_1,param_2);
    local_7c = local_58;
    uStack_78 = uStack_54;
    uStack_74 = uStack_50;
    uStack_70 = uStack_4c;
    iVar3 = FUN_60161d60(&local_7c,0x6043763a,&local_6c);
    if (iVar3 != 0) {
      if (local_6b == '\x02') {
        FUN_60127660(local_6c,2,local_6a,0);
      }
      else {
        if (local_6b == '\x01') {
          if (local_6a == '\x01') {
            FUN_60167f3c(7,"APP_WATCH_LOG",1,"[app_watch] set device info\n");
            if ((local_69 != '\0') && (iVar3 = FUN_600580b8(), iVar3 == 0)) {
              FUN_60167f3c(7,"APP_WATCH_LOG",1,"  device_name: %s\n",0x20055a4c);
              FUN_60167f3c(7,"APP_WATCH_LOG",1,"  Manufa_infor: %s\n",0x20055a6c);
              ZeroBytes(&local_58,0x40);
              uVar4 = 0;
              for (; (uVar4 < 0x3f && (cVar1 = *pcVar6, cVar1 != '\0')); pcVar6 = pcVar6 + 1) {
                if (cVar1 != '_') {
                  *(char *)((int)&local_58 + uVar4) = cVar1;
                  uVar4 = uVar4 + 1;
                }
              }
              *(undefined1 *)((int)&local_58 + uVar4) = 0;
              for (uVar4 = 0; cVar1 = *(char *)((int)&local_58 + uVar4 * 2), cVar1 != '\0';
                  uVar4 = uVar4 + 1) {
                cVar2 = *(char *)((int)&local_58 + uVar4 * 2 + 1);
                if (9 < (byte)(cVar2 - 0x30U)) break;
                bVar5 = cVar1 - 0x30;
                bVar8 = 8 < bVar5;
                bVar7 = bVar5 == 9;
                if (bVar5 < 10) {
                  bVar8 = 0x1e < uVar4;
                  bVar7 = uVar4 == 0x1f;
                }
                if ((bVar8 && !bVar7) || (cVar2 == '\0')) break;
                *(byte *)(uVar4 + 0x20055a8c) = cVar2 - 0x30U | cVar1 << 4;
              }
              uRam20055aac = 1;
              FUN_6015f5c0(4);
              FUN_60127660(local_6c,local_6b,local_6a,0);
              FUN_600358dc();
              return;
            }
          }
          else {
            local_6b = '\x01';
          }
        }
        FUN_60129ec8(local_6c,local_6b,local_6a,0);
      }
    }
  }
  return;
}
