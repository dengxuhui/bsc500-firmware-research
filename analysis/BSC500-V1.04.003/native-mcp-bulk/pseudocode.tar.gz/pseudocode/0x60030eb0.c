
/* WARNING: Exceeded maximum restarts with more pending */

void FUN_60030eb0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  uint uVar2;
  undefined1 auStack_54 [16];
  uint local_44 [15];
  
  local_44[3] = 0;
  local_44[1] = 0;
  local_44[2] = 0;
  local_44[0] = 0x1000000;
  FUN_60161d4c(auStack_54,param_1,param_2);
  iVar1 = FUN_60161d60(auStack_54,&UNK_603e2bcc,local_44);
  if (iVar1 != 0) {
    uVar2 = local_44[0] >> 8 & 0xff;
    switch(uVar2) {
    case 0x60030fae:
      break;
    default:
      FUN_60129ec8(local_44[0] & 0xff,0,uVar2,0);
    }
  }
                    /* WARNING: This code block may not be properly labeled as switch case */
  return;
}
