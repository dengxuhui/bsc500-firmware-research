
undefined1 FUN_6001a2b4(int param_1)

{
  return *(undefined1 *)(param_1 + 0x57);
}
