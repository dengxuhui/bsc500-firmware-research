
void FUN_6000fbe8(void)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  int in_r3;
  uint uVar4;
  int local_18;
  
  local_18 = in_r3;
  uVar1 = FUN_601637b4(0x2000b9f8);
  uVar2 = FUN_60011418(&local_18);
  uVar4 = 0;
  while ((uVar2 != 0 && (uVar1 != 0))) {
    uVar3 = FUN_601637a0(0x2000b9f8);
    if (uVar2 <= uVar1) {
      CopyBytes(local_18 + uVar4,uVar3,uVar2);
      uVar4 = uVar2;
      goto LAB_6000fc3e;
    }
    CopyBytes(local_18 + uVar4,uVar3,uVar1);
    FUN_6016375e(0x2000b9f8,uVar1);
    uVar2 = uVar2 - uVar1;
    uVar4 = uVar4 + uVar1;
    uVar1 = FUN_601637b4(0x2000b9f8);
  }
  if (uVar4 == 0) {
    return;
  }
LAB_6000fc3e:
  FUN_60011430(uVar4);
  return;
}
