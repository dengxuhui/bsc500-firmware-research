
int FUN_600371e4(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  int local_18;
  
  local_18 = 0;
  if ((param_1 == 0) || (param_4 == (uint *)0x0)) {
    return 0xe;
  }
  if (2 < *param_4) {
    *param_4 = *param_4 - 3;
    *param_3 = 0x57;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_18,param_3 + 2);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fbe(param_1,param_2,&local_18,param_3 + 3);
    if (iVar1 != 0) {
      return iVar1;
    }
    if (local_18 == param_2) {
      *param_4 = 3;
      return 0;
    }
  }
  return 9;
}
