
uint FUN_60000aa0(void)

{
  uint in_fpscr;
  
  return in_fpscr & 0xfc3f0000 | 0x3000000;
}
