
undefined4 FUN_6000b708(void)

{
  undefined4 uVar1;
  
  ZeroBytes(0x20132d80,0x1280);
  FUN_6007db44(0x20130000,&UNK_602bca04,0x2d80);
  FUN_6007db44(0x20133f00,&UNK_602bf784,0xc0);
  if (iRam20133f00 == 0x50544348) {
    uVar1 = FUN_6001b6d0(0x20133f08,uRam20133f04 >> 3,0);
    return uVar1;
  }
  return 0;
}
