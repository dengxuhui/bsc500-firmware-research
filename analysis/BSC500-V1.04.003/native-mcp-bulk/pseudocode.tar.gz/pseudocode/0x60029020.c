
bool FUN_60029020(int param_1)

{
  int iVar1;
  
  iVar1 = FUN_60168220(0x200828c2);
  if ((iVar1 != 0) && (iVar1 = FUN_60168418(&UNK_60029068,iVar1 + 0x200828be), iVar1 == 0)) {
    iVar1 = FUN_6016727c("List.fit",0x200828c2,9);
    return iVar1 == 0 || param_1 - 1U < 20000000;
  }
  return false;
}
