
int FUN_6001a148(int param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  int iVar2;
  int local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  
  if (param_2 == 0) {
    iVar2 = 1;
  }
  else if (*(char *)(param_1 + 0x10) == '\0') {
    iVar2 = 8;
    if (*(char *)(param_1 + 0x11) == '\0') {
      iVar2 = 1;
    }
  }
  else if (*(char *)(param_1 + 0x11) == '\0') {
    iVar2 = FUN_601633f8(param_1,2,1,&local_24);
    if (iVar2 == 0) {
      uVar1 = FUN_60168220(param_2);
      iVar2 = FUN_60161838(local_24,param_2,uVar1,&local_28);
      if (iVar2 == 0 && local_28 == 0) {
        iVar2 = 0;
        FUN_6016192c(local_24,0,4,&local_20);
        *param_3 = local_20;
      }
      else {
        iVar2 = FUN_60136094(param_1,&local_1c,&local_20,0);
        if (iVar2 == 0) {
          iVar2 = FUN_6013756c(local_1c);
          if (iVar2 != 0) {
            FUN_601619f8(param_1,local_1c);
            uVar1 = FUN_60168220(param_2);
            FUN_6016158c(local_24,param_2,uVar1,&local_20,4);
            FUN_60161a54(local_24);
            FUN_60161de0(local_1c);
            *param_3 = local_20;
            return 0;
          }
                    /* WARNING: Subroutine does not return */
          thunk_FUN_6016804c("sqlitepager_iswriteable(pRoot)",
                             "./../../../../qwos/framework/kvdb/fs_kv/btree.c",0xbbc);
        }
      }
      FUN_60161a54(local_24);
    }
  }
  else {
    iVar2 = 8;
  }
  return iVar2;
}
