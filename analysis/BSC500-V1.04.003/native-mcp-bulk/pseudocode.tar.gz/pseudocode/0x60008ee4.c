
undefined4 FUN_60008ee4(undefined4 param_1,char *param_2)

{
  thunk_FUN_6001bd1c();
  if (*param_2 == '\x05') {
    cRam20007400 = **(char **)(param_2 + 8);
    if (cRam20007400 == '\0') {
      thunk_FUN_6001bdd0(4);
    }
    else {
      thunk_FUN_6001bd58();
      thunk_FUN_6001bde4(4);
    }
  }
  else if (*param_2 == '\x02') {
    thunk_FUN_6001bd58();
    thunk_FUN_6001be2c(*(undefined4 *)(param_2 + 8),*(undefined2 *)(param_2 + 2));
  }
  return 0;
}
