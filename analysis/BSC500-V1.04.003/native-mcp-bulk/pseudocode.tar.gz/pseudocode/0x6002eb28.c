
void FUN_6002eb28(undefined4 param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_601597fc(0x2000b818);
  if (puVar1 != (undefined4 *)0x0) {
    *puVar1 = param_1;
    return;
  }
                    /* WARNING: Subroutine does not return */
  thunk_FUN_6016804c("(new_drv != NULL)",
                     "./../../../../qwos/module/touchx/lv_engine/src/misc/lv_fs.c",0x193);
}
