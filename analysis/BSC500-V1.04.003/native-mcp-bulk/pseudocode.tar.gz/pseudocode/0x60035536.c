
undefined4 FUN_60035536(void)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_60041300();
  uVar2 = 0;
  if (iVar1 != 1) {
    uVar2 = 0xffffffff;
  }
  return uVar2;
}
