
undefined8 FUN_600007c8(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  FUN_60000aa0();
  FUN_60062fae();
  iVar1 = FUN_60140d54();
  iVar2 = FUN_6004fe60(0,0);
  *(int *)(iVar1 + 4) = iVar2 + 1;
  uVar3 = FUN_6004fe8c(0,0);
  *(undefined4 *)(iVar1 + 0xc) = uVar3;
  uVar3 = FUN_60268358(0,0);
  *(undefined4 *)(iVar1 + 0x10) = uVar3;
  FUN_6006d138();
  FUN_6006d02c();
  return CONCAT44(param_2,param_1);
}
