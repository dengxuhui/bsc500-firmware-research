
void FUN_600187a0(void)

{
  ushort uVar1;
  short sVar2;
  int *piVar3;
  undefined1 auStack_ac [96];
  undefined1 auStack_4c [32];
  undefined1 auStack_2c [8];
  int local_24 [2];
  
  uVar1 = FUN_60147734(0x200056d6,&UNK_603fc162,0,0,0,0);
  if (uVar1 < 2) {
    if (uVar1 == 0) {
      ZeroBytes(auStack_4c,0x20);
      ZeroBytes(auStack_ac,0x60);
      FUN_60161fb8(auStack_2c);
      sVar2 = FUN_6015ee0c(auStack_2c,0x200056d6,".dat",0,0,0,0);
      if (sVar2 != 0) {
        piVar3 = local_24;
        while (piVar3 = (int *)*piVar3, local_24 != piVar3) {
          ZeroBytes(auStack_4c,0x20);
          ZeroBytes(auStack_ac,0x60);
          CopyBytes(auStack_4c,piVar3[-2],piVar3[-1]);
          FUN_60164dec(auStack_ac,0x60,"%s/%s",0x200056d6,auStack_4c);
          FUN_60163bbe(auStack_ac);
        }
      }
      FUN_601607f4(auStack_2c);
      FUN_601629c8();
    }
  }
  else {
    ZeroBytes(auStack_4c,0x20);
    ZeroBytes(auStack_ac,0x60);
    FUN_60130ce4();
    FUN_60161fb8(auStack_2c);
    sVar2 = FUN_6015ee0c(auStack_2c,0x20005820,&UNK_603fc15b,0,0,0,0);
    if (sVar2 != 0) {
      piVar3 = local_24;
      while (piVar3 = (int *)*piVar3, local_24 != piVar3) {
        ZeroBytes(auStack_4c,0x20);
        ZeroBytes(auStack_ac,0x60);
        CopyBytes(auStack_4c,piVar3[-2],piVar3[-1]);
        FUN_60164dec(auStack_ac,0x60,"%s/%s",0x20005820,auStack_4c);
        FUN_60163bbe(auStack_ac);
      }
    }
    FUN_601607f4(auStack_2c);
  }
  return;
}
