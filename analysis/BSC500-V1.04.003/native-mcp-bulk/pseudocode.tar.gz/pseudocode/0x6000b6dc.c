
void FUN_6000b6dc(void)

{
  FUN_6007db44(0xb0fc000,&UNK_602b01a4,0x4000);
  FUN_6007db44(0x20100000,&UNK_602b41a4,0x8860);
  return;
}
