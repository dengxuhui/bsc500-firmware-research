
undefined4 FUN_60031058(int param_1)

{
  int iVar1;
  uint uVar2;
  uint local_7c;
  undefined1 auStack_78 [100];
  
  local_7c = 0;
  ZeroBytes(auStack_78,100);
  if ((iRam20009f80 == 0) && (iRam20009f80 = thunk_FUN_60162e34(0x260), iRam20009f80 == 0)) {
    return 0;
  }
  if (uRam20009f75._1_1_ == '\0') {
    FUN_601681f4(auStack_78,"%s/%s",0x20005bd4,"Schedules.fit");
    iVar1 = FUN_6015838c(iRam20009f80,auStack_78,1);
    if (iVar1 == 0) {
      uRam20009f75 = CONCAT11(1,(undefined1)uRam20009f75);
      iRam20009f7c = 0;
    }
    else if (uRam20009f75._1_1_ != '\x01') {
      return 1;
    }
  }
  if (*(int *)(iRam20009f80 + 0x14) == *(int *)(iRam20009f80 + 0xc)) {
    FUN_60159154();
    thunk_FUN_60166c0c(iRam20009f80);
    iRam20009f7c = 0;
  }
  else {
    FUN_6015576c(iRam20009f80,(uint)uRam20009f78 + param_1,0x600,&local_7c);
    uVar2 = (uint)uRam20009f78;
    uRam20009f78 = (ushort)(uVar2 + local_7c);
    iRam20009f7c = iRam20009f7c + local_7c;
    if ((0x5ff < local_7c) && (*(int *)(iRam20009f80 + 0xc) != iRam20009f7c)) {
      FUN_6015576c(iRam20009f80,param_1 + (uVar2 + local_7c & 0xffff),0x1a0,&local_7c);
      uRam20009f78 = uRam20009f78 + (short)local_7c;
      iRam20009f7c = iRam20009f7c + local_7c;
      if ((0x19f < local_7c) && (*(int *)(iRam20009f80 + 0xc) != iRam20009f7c)) {
        return 1;
      }
    }
    FUN_60159154();
    thunk_FUN_60166c0c(iRam20009f80);
  }
  iRam20009f80 = 0;
  uRam20009f75 = 1;
  return 1;
}
