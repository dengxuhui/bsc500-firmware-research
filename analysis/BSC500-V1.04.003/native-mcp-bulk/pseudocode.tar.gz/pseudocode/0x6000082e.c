
undefined4 FUN_6000082e(void)

{
  FUN_60000838();
  return 0;
}
