
undefined4 FUN_6003114c(int param_1,int param_2)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int *piVar9;
  undefined1 auStack_4b0 [64];
  int local_470 [154];
  undefined4 local_208;
  char *local_204;
  char *local_200;
  undefined1 local_1b8;
  char *local_1b4;
  char *local_1b0;
  undefined1 local_168;
  char *local_164;
  char *local_160;
  undefined1 local_118;
  ushort local_114;
  undefined4 local_110;
  undefined1 auStack_10c [112];
  int local_9c;
  undefined4 local_98;
  undefined4 local_94;
  undefined4 local_90;
  undefined4 local_8c;
  undefined4 local_88;
  uint local_84;
  undefined1 local_7f;
  undefined1 local_7e;
  undefined1 local_7d;
  uint local_7c;
  undefined4 local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 local_6c;
  undefined4 local_68;
  undefined4 local_64;
  int local_60 [5];
  undefined4 *local_4c;
  undefined4 *local_48;
  undefined4 *local_44;
  int local_40;
  int local_3c;
  int local_38;
  int local_34;
  int local_30;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  if (param_2 == 0) {
    return 0xffffffff;
  }
  ZeroBytes(auStack_10c,0x70);
  iVar3 = FUN_60168220(param_1);
  CopyBytes(auStack_10c,param_1,iVar3);
  auStack_10c[iVar3 + -1] = 0x78;
  local_110 = 0;
  iVar4 = FUN_60166758(&local_110,param_1,10);
  iVar3 = local_110;
  uVar2 = uRam200083e4;
  if (iVar4 != 0) {
    return 0xffffffff;
  }
  if (local_110 == 0) goto LAB_600314e2;
  iVar4 = FUN_60168220(uRam200083e4);
  iVar5 = FUN_60164ed8(iVar3,uVar2,iVar4,local_60);
  if ((iVar5 != 0) || (local_60[0] != iVar4)) goto LAB_600314e2;
  local_9c = CONCAT22(local_9c._2_2_,1);
  iVar4 = FUN_60164ed8(iVar3,&local_9c,2,local_60);
  iVar3 = local_110;
  if ((iVar4 != 0) || ((local_60[0] != 2 || (local_110 == 0)))) goto LAB_600314e2;
  local_60[0] = param_2;
  local_7c = 0;
  local_68 = *(undefined4 *)(param_2 + 0x44);
  local_64 = *(undefined4 *)(param_2 + 0x4c);
  local_70 = *(undefined4 *)(param_2 + 0x54);
  local_6c = *(undefined4 *)(param_2 + 0x5c);
  local_78 = *(undefined4 *)(param_2 + 100);
  local_74 = *(undefined4 *)(param_2 + 0x6c);
  local_30 = param_2 + 0x1e4;
  local_34 = param_2 + 0x7e;
  local_38 = param_2 + 0x7c;
  local_3c = param_2 + 0x78;
  local_40 = param_2 + 0x74;
  local_44 = &local_78;
  local_48 = &local_70;
  local_4c = &local_68;
  local_60[4] = param_2 + 0x40;
  local_60[3] = param_2 + 0x3f;
  local_60[2] = param_2 + 0x3e;
  local_60[1] = param_2 + 0x3d;
  for (iVar4 = 0; iVar4 != 0xd; iVar4 = iVar4 + 1) {
    iVar8 = local_60[iVar4];
    local_9c = CONCAT31(local_9c._1_3_,(&UNK_60031504)[iVar4]);
    iVar5 = FUN_60164ed8(iVar3,&local_9c,1,&local_7c);
    if ((iVar5 != 0) || (local_7c != 1)) goto LAB_600313b8;
    bVar1 = (&UNK_603e44c2)[iVar4];
    iVar5 = FUN_60164ed8(iVar3,iVar8,(uint)bVar1,&local_7c);
    if ((iVar5 != 0) || (local_7c != bVar1)) goto LAB_600313b8;
  }
  local_7d = 0xd;
  iVar4 = FUN_60164ed8(iVar3,&local_7d,1,&local_7c);
  iVar5 = -1;
  if ((iVar4 == 0) && (local_7c == 1)) {
    local_7e = *(undefined1 *)(param_2 + 0x80);
    iVar4 = FUN_60164ed8(iVar3,&local_7e,1,&local_7c);
    iVar5 = -1;
    if ((iVar4 == 0) && (local_7c == 1)) {
      local_7f = 0xe;
      for (iVar4 = 0; iVar4 != 0x160; iVar4 = iVar4 + 0x20) {
        iVar5 = param_2 + iVar4;
        local_9c = *(int *)(iVar5 + 0x84);
        local_98 = *(undefined4 *)(iVar5 + 0x88);
        local_94 = *(undefined4 *)(iVar5 + 0x8c);
        local_90 = *(undefined4 *)(iVar5 + 0x90);
        local_8c = *(undefined4 *)(iVar5 + 0x94);
        local_88 = *(undefined4 *)(iVar5 + 0x9c);
        local_84 = (uint)*(byte *)(iVar5 + 0xa0);
        iVar5 = FUN_60164ed8(iVar3,&local_7f,1,&local_7c);
        if ((((iVar5 != 0) || (local_7c != 1)) ||
            (iVar5 = FUN_60164ed8(iVar3,&local_9c,0x1c,&local_7c), iVar5 != 0)) ||
           (local_7c != 0x1c)) goto LAB_600313b8;
      }
      iVar5 = 0;
    }
  }
LAB_600313bc:
  if (iVar5 == 0) {
    local_114 = local_114 & 0xff;
    iVar3 = FUN_60166758(&local_208,auStack_10c,1);
    if (iVar3 == 0) {
      local_118 = 1;
      local_168 = 1;
      local_1b8 = 1;
      local_114 = 0x100;
      local_160 = "</point_dist>";
      local_164 = "<point_dist>";
      local_1b0 = "</leader_time>";
      local_1b4 = "<leader_time>";
      local_200 = "</Tracks>";
      local_204 = "<Tracks>";
      ZeroBytes(auStack_4b0,0x2a8);
      do {
        uVar6 = FUN_6003e730(param_2,&local_208,auStack_4b0,10);
        iVar3 = local_110;
        if (uVar6 == 0xffffffff) {
LAB_600314d6:
          FUN_601667bc(local_208);
          local_114 = local_114 & 0xff;
          goto LAB_600314e2;
        }
        if (uVar6 == 0) break;
        if (((uVar6 & 0xff) == 0) || (local_110 == 0)) goto LAB_600314d6;
        local_9c = 0;
        local_68 = CONCAT31(local_68._1_3_,0xf);
        piVar9 = local_470;
        for (uVar7 = uVar6 & 0xff; uVar7 != 0; uVar7 = uVar7 - 1) {
          local_60[0] = piVar9[-0x10];
          local_60[1] = piVar9[-0xe];
          local_60[2] = piVar9[-0xc];
          local_60[3] = *piVar9;
          CopyBytes(local_60 + 4,piVar9 + -0xb,0x2c,local_60 + 3);
          iVar4 = FUN_60164ed8(iVar3,&local_68,1,&local_9c);
          if (((iVar4 != 0) || (local_9c != 1)) ||
             ((iVar4 = FUN_60164ed8(iVar3,local_60,0x3c,&local_9c), iVar4 != 0 || (local_9c != 0x3c)
              ))) goto LAB_600314d6;
          piVar9 = piVar9 + 0x11;
        }
      } while (uVar6 == 10);
      FUN_601667bc(local_208);
      FUN_601667bc(local_110);
      return 0;
    }
  }
LAB_600314e2:
  FUN_601667bc(local_110);
  FUN_60163bbe(param_1);
  return 0xffffffff;
LAB_600313b8:
  iVar5 = -1;
  goto LAB_600313bc;
}
