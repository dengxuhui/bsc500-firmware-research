
void FUN_60018070(void)

{
  if (iRam2000aa9c != 0) {
    FUN_601667bc();
    iRam2000aa9c = 0;
  }
  return;
}
