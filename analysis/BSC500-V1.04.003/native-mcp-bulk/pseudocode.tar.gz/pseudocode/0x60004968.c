
void FUN_60004968(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 local_18;
  undefined4 uStack_14;
  
  local_18 = param_3;
  uStack_14 = param_4;
  if (DAT_2000bb11 == '\0') {
    FUN_60161424("(%s) has assert failed at %s.","init_ok","cm_backtrace_assert");
    FUN_60161424(&DAT_603f7cc3);
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  FUN_60161424(0x60432534);
  FUN_60161424(&DAT_603f7cc3);
  FUN_6000a660();
  puVar1 = (undefined4 *)getMainStackPointer();
  if (&local_18 == puVar1) {
    FUN_60161424("Assert on interrupt or bare metal(no OS) environment");
    FUN_60161424(&DAT_603f7cc3);
    uVar2 = 0;
    if (DAT_2000bb04 != '\0') {
      uVar2 = 0x200032c8;
    }
    uVar3 = 0;
    if (DAT_2000bb08 != '\0') {
      uVar3 = 0x1000;
    }
  }
  else {
    puVar1 = (undefined4 *)getProcessStackPointer();
    if (&local_18 != puVar1) goto LAB_600049ec;
    uVar2 = FUN_60163ab8();
    FUN_60161424("Assert on thread %s",uVar2);
    FUN_60161424(&DAT_603f7cc3);
    FUN_6015a194(&uStack_14,&local_18);
    uVar2 = uStack_14;
    uVar3 = local_18;
  }
  FUN_6000abcc(uVar2,uVar3,param_1);
LAB_600049ec:
  FUN_6000d764(param_1);
  return;
}
