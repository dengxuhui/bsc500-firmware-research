
undefined4 FUN_60019e1c(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  undefined4 local_28;
  int *local_24;
  undefined4 local_1c;
  
  if ((code *)piRam2004b8c4[1] != (code *)0x0) {
    (*(code *)piRam2004b8c4[1])();
  }
  (**(code **)(*piRam2004b8c4 + 8))(&local_28,piRam2004b8c4,0);
  if (local_24 == (int *)0x0) {
    cVar1 = '\r';
  }
  else {
    (**(code **)(*local_24 + 0x10))(local_24,0,1,4,local_28);
    (**(code **)(*local_24 + 0x20))(local_24,param_1);
    (**(code **)(*local_24 + 0x20))(local_24,param_2);
    (**(code **)(*piRam2004b8c4 + 0xc))(piRam2004b8c4,&local_28);
    (**(code **)(*local_24 + 0x70))(local_24,&local_1c);
    cVar1 = (char)local_24[5];
  }
  (**(code **)(*piRam2004b8c4 + 0x10))(piRam2004b8c4,&local_28);
  FUN_601675ca(piRam2004b8c4,cVar1,4);
  if ((code *)piRam2004b8c4[2] != (code *)0x0) {
    (*(code *)piRam2004b8c4[2])();
  }
  if (cVar1 != '\0') {
    local_1c = 0xffffffff;
  }
  return local_1c;
}
