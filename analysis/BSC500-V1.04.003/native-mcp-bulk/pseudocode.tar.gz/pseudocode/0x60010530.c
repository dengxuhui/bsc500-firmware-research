
void FUN_60010530(void)

{
  FUN_601673b8();
  return;
}
