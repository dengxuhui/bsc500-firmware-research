
int FUN_60037238(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  char cVar1;
  undefined2 *puVar2;
  int iVar3;
  int local_2c;
  undefined2 *local_28;
  int local_24;
  
  local_24 = 0;
  if (param_1 == 0) {
    return 0xe;
  }
  if (param_4 == (uint *)0x0) {
    return 0xe;
  }
  if (0x11 < *param_4) {
    *param_4 = *param_4 - 0x12;
    *param_3 = 0x53;
    local_2c = param_2;
    local_28 = param_3;
    iVar3 = FUN_60152fa4(param_1,param_2,&local_24,param_3 + 2,param_1);
    if (iVar3 != 0) {
      return iVar3;
    }
    local_28 = (undefined2 *)*param_4;
    iVar3 = FUN_600435f2(param_1,param_2,&local_24,&local_28,param_3 + 3);
    puVar2 = local_28;
    if (iVar3 != 0) {
      return iVar3;
    }
    *param_4 = *param_4 - (int)local_28;
    cVar1 = *(char *)(param_3 + 3);
    if (cVar1 == '\x01') {
      iVar3 = 0xc;
    }
    else {
      if ((((cVar1 == '\x02') && ((*(byte *)(param_3 + 7) | 2) == 6)) &&
          (iVar3 = FUN_6010fd8c(param_3[2],&local_2c), iVar3 != 5)) &&
         (iVar3 = FUN_60152e8c(param_1,param_2,&local_24,local_2c * 0xc + 0x20079340,
                               local_2c * 0xc + 0x20079344), iVar3 != 0)) {
        return iVar3;
      }
      iVar3 = 0x12;
    }
    if (local_24 == param_2) {
      *param_4 = iVar3 + (int)puVar2;
      return 0;
    }
  }
  return 9;
}
