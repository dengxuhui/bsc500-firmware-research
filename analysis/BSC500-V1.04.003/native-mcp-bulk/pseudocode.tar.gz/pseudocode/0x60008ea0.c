
undefined4 FUN_60008ea0(undefined4 param_1,char *param_2)

{
  thunk_FUN_6001bd1c();
  if (*param_2 == '\x05') {
    cRam200073f4 = **(char **)(param_2 + 8);
    if (cRam200073f4 == '\0') {
      thunk_FUN_6001bdd0(2);
    }
    else {
      thunk_FUN_6001bd58();
      thunk_FUN_6001bde4(2);
    }
  }
  else if (*param_2 == '\x02') {
    thunk_FUN_6001bd58();
    thunk_FUN_6001be18(*(undefined4 *)(param_2 + 8),*(undefined2 *)(param_2 + 2));
  }
  return 0;
}
