
undefined8 FUN_6001fc18(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 local_10;
  undefined4 local_c;
  
  local_c = 0x100008;
  local_10 = 0x1c200;
  (*(code *)0x20ce1)(0x1d,1,param_3,param_4,param_1,param_2);
  (*(code *)0x20ce1)(0x1c,1);
  (*(code *)0x20ce1)(0x48,1);
  (*(code *)0x20ce1)(0x49,1);
  (*(code *)0x20ce1)(0x4a,1);
  (*(code *)0x20ce1)(0x4c,1);
  FUN_60134aaa(0x1b,0xdc,0x30,1);
  FUN_60134aaa(0x1d,0xdd,0x30,1);
  iRam2000a07c = FUN_60166f2c(0x603eba8c);
  if (iRam2000a07c == 0) {
    FUN_60168578("dfu_uart_device init fial\n");
  }
  else {
    FUN_60123a64(0x2000a090,"dfu_uart_msg_mq",0x20048a8c,8,0x50,0);
    FUN_60166e68(iRam2000a07c,0x200);
    FUN_60165124(iRam2000a07c,3,&local_10);
    FUN_6015df6c(iRam2000a07c,&UNK_600288c9);
  }
  uVar1 = 0x19;
  uVar2 = 10;
  iRam2000a08c = FUN_60167f4a("dfu_uart_thread",&UNK_600288fd,0,0x800);
  if (iRam2000a08c != 0) {
    FUN_60167f8c();
    return CONCAT44(uVar2,uVar1);
  }
  FUN_60168578("rt_thread_create fail!!!\n");
  return CONCAT44(uVar2,uVar1);
}
