
undefined4 FUN_6000b59c(void)

{
  int iVar1;
  undefined4 local_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 local_30;
  int local_2c;
  
  if (((cRam2000a688 != '\0') && (iVar1 = FUN_60166dd0(0x2000a68c), iVar1 == 0)) &&
     (iVar1 = FUN_60166dd0(0x2000a694), iVar1 == 0)) {
    local_30 = uRam2000a6b0;
    local_38 = uRam2000a6b8;
    uStack_34 = uRam2000a6ac;
    local_2c = iRam2000a6b4 + 2000;
    local_40 = uRam2000a6c0;
    uStack_3c = uRam2000a6bc;
    iVar1 = FUN_601648ec(&local_40);
    if (iVar1 != 0) {
      FUN_60010750(0x2000a68c,0x2000a694,&local_40,&DAT_2004c610,&DAT_2004c614);
      FUN_600169a4();
      return 1;
    }
  }
  return 0;
}
