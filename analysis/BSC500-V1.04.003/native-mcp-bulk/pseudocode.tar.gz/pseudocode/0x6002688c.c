
void FUN_6002688c(int param_1,int param_2,undefined4 param_3)

{
  if (param_1 != 0) {
    FUN_60161424("function:%s\n",param_1);
  }
  if (param_2 != 0) {
    FUN_60035558(0x60161425,param_2,param_3);
    return;
  }
  FUN_60161424("hexdump NULL-POINTER!!!\r\n");
  return;
}
