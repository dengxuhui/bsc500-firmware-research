
undefined4 FUN_6001a630(int *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  uVar1 = 0xffffffff;
  if ((param_1 != (int *)0x0) && (param_2 != 0)) {
    uVar2 = param_1[1];
    if ((uint)param_1[2] < uVar2) {
      FUN_60100c64(*param_1 + param_1[2] * 0x18,param_2,param_3,param_4,param_4);
      param_1[2] = param_1[2] + 1;
    }
    else {
      iVar4 = 0;
      for (uVar5 = 0; uVar5 < uVar2 - 1; uVar5 = uVar5 + 1) {
        iVar3 = *param_1 + iVar4;
        FUN_60100c64(iVar3,iVar3 + 0x18);
        uVar2 = param_1[1];
        iVar4 = iVar4 + 0x18;
      }
      FUN_60100c64(*param_1 + param_1[2] * 0x18 + -0x18,param_2);
    }
    uVar1 = 0;
  }
  return uVar1;
}
