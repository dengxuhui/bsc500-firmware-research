
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001090(void)

{
  byte bVar1;
  int ****ppppiVar2;
  int iVar3;
  int ***pppiVar4;
  undefined4 uVar5;
  undefined4 extraout_r1;
  int ****ppppiVar6;
  ulonglong uVar7;
  int ***local_2c;
  int ***local_28;
  
  local_2c = (int ***)&local_2c;
  local_28 = (int ***)&local_2c;
  uVar7 = FUN_60167d0c();
  while (ppppiVar2 = _DAT_200095d8, uVar5 = (undefined4)(uVar7 >> 0x20),
        _DAT_200095d8 != (int ****)&DAT_200095d8) {
    iVar3 = FUN_6016717c();
    uVar5 = 0x7ffffffe;
    if (0x7ffffffe < (uint)(iVar3 - (int)ppppiVar2[6])) break;
    ppppiVar6 = ppppiVar2 + -7;
    if (pcRam200095c4 != (code *)0x0) {
      (*pcRam200095c4)(ppppiVar6);
    }
    FUN_6016374c(ppppiVar6);
    if (-1 < (int)((uint)*(byte *)((int)ppppiVar2 + -0xb) << 0x1e)) {
      *(byte *)((int)ppppiVar2 + -0xb) = *(byte *)((int)ppppiVar2 + -0xb) & 0xfe;
    }
    local_2c[1] = (int **)ppppiVar2;
    *ppppiVar2 = local_2c;
    ppppiVar2[1] = (int ***)&local_2c;
    DAT_200095c0 = 1;
    local_2c = (int ***)ppppiVar2;
    FUN_60167d14((int)uVar7);
    (*(code *)ppppiVar2[2])(ppppiVar2[3]);
    if (pcRam200095c8 != (code *)0x0) {
      (*pcRam200095c8)(ppppiVar6);
    }
    uVar7 = FUN_60167d0c();
    uVar5 = (undefined4)uVar7;
    DAT_200095c0 = 0;
    if ((int ****)local_2c != &local_2c) {
      pppiVar4 = *ppppiVar2;
      pppiVar4[1] = (int **)ppppiVar2[1];
      *ppppiVar2[1] = (int **)pppiVar4;
      *ppppiVar2 = (int ***)ppppiVar2;
      ppppiVar2[1] = (int ***)ppppiVar2;
      bVar1 = *(byte *)((int)ppppiVar2 + -0xb);
      uVar7 = (ulonglong)CONCAT14(bVar1,uVar5) & 0x3ffffffff;
      if ((bVar1 & 3) == 3) {
        *(byte *)((int)ppppiVar2 + -0xb) = bVar1 & 0xfe;
        FUN_60167bd4(ppppiVar6);
        uVar7 = CONCAT44(extraout_r1,uVar5);
      }
    }
  }
  FUN_60167d14((int)uVar7,uVar5);
  return;
}
