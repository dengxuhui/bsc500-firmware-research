
void FUN_600239e8(int param_1,code *param_2,undefined4 param_3)

{
  uint uVar1;
  code *pcVar2;
  
  param_1 = param_1 + -4;
  pcVar2 = (code *)0x60028547;
  if (param_2 != (code *)0x0) {
    pcVar2 = param_2;
  }
  while( true ) {
    if (param_1 == 0) {
      return;
    }
    uVar1 = *(uint *)(param_1 + 4) & 0x3ffffc;
    if (uVar1 == 0) break;
    (*pcVar2)(param_1 + 8,uVar1,~*(uint *)(param_1 + 4) & 1,param_3);
    param_1 = FUN_6013a814(param_1);
  }
  return;
}
