
void FUN_60008d42(void)

{
  FUN_60019e1c(1,0);
  FUN_60122458(1,0);
  return;
}
