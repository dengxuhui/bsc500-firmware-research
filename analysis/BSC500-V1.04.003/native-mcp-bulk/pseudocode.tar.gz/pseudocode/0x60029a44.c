
undefined4 FUN_60029a44(undefined4 param_1,undefined4 param_2,undefined1 *param_3)

{
  int iVar1;
  undefined1 *puVar2;
  undefined1 auStack_13c [8];
  byte local_134;
  undefined1 auStack_126 [258];
  
  *param_3 = 0;
  do {
    iVar1 = FUN_6015c834(param_2,auStack_13c);
    if (iVar1 != 0) {
      return 0xc;
    }
    puVar2 = param_3;
    if ((int)((uint)local_134 << 0x1b) < 0) {
      *param_3 = 0x2f;
      puVar2 = param_3 + 1;
    }
    FUN_60167370(puVar2,auStack_126);
    iVar1 = FUN_60168418(param_3,&UNK_60029ab0);
  } while ((iVar1 == 0) || (iVar1 = FUN_60168418(param_3,&UNK_60029ab4), iVar1 == 0));
  return 0;
}
