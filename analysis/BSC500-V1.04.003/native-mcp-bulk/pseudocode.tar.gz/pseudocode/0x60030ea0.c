
void FUN_60030ea0(void)

{
  FUN_601671d4(&LAB_6003de1c_1,0,0,0x12);
  return;
}
