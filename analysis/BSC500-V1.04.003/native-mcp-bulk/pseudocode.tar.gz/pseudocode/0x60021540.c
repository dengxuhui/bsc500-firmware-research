
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60021540(void)

{
  undefined4 uVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  undefined *local_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 local_30;
  short local_2c;
  undefined2 local_2a;
  int local_28;
  
  local_2a = 0;
  if (_DAT_2000a6d8 == 0) {
    local_30 = 0;
    local_38 = 0;
    uStack_34 = 0;
    local_3c = &DAT_603fc164;
    _DAT_2000a6d8 = FUN_60168494(&local_3c);
  }
  FUN_6016825e(_DAT_2000a6d8,0xffffffff);
  if (_DAT_2000a6dc == 0) {
    FUN_60168578("Error: s_pCurActivityFile is NULL\n");
  }
  uVar1 = FUN_6015cbf2(_DAT_2000a6dc);
  uVar4 = 0;
  do {
    if (uRam2008958c <= uVar4) {
      iVar6 = FUN_60163c98(_DAT_2000a6dc,uVar1);
      if (iVar6 != 0) {
        FUN_60168578("reseek to original_pos failed \n");
      }
      if (_DAT_2000a6d8 != 0) {
        FUN_601682ae();
      }
      return;
    }
    iVar6 = 0x15;
    for (uVar5 = 0; uVar5 < *(uint *)(uVar4 * 8 + 0x20089400); uVar5 = uVar5 + 1) {
      iVar7 = iVar6 + *(int *)(uVar4 * 8 + 0x200893fc);
      iVar2 = FUN_60163c98(_DAT_2000a6dc,iVar7);
      if (iVar2 == 0) {
        iVar2 = FUN_60161ef4(_DAT_2000a6dc,&local_2c,2,&local_28);
        if ((iVar2 == 0) && (local_28 == 2)) {
          iVar2 = iRam20053040 + local_2c * 0x14;
          local_2a = (undefined2)(iVar2 / 0x14);
          if (iVar2 == -0x7fff3cb1) {
            local_2a = 0xffff;
          }
          iVar2 = FUN_60163c98(_DAT_2000a6dc,iVar7);
          if (iVar2 != 0) {
            pcVar3 = "reseek failed at pos %ld, ret=%d\n";
            goto LAB_600215c2;
          }
          iVar2 = FUN_60164ed8(_DAT_2000a6dc,&local_2a,2,&local_3c);
          if ((iVar2 != 0) || (local_3c != (undefined *)0x2)) {
            pcVar3 = "write failed at pos %ld, ret=%d, bw=%u\n";
            goto LAB_6002161c;
          }
        }
        else {
          pcVar3 = "read failed at pos %ld, ret=%d, br=%u\n";
LAB_6002161c:
          FUN_60168578(pcVar3,iVar7 + -0x15,iVar2);
        }
      }
      else {
        pcVar3 = "seek failed at pos %u, ret=%d\n";
LAB_600215c2:
        FUN_60168578(pcVar3,iVar7 + -0x15,iVar2);
      }
      iVar6 = iVar6 + 0x25;
    }
    uVar4 = uVar4 + 1;
  } while( true );
}
