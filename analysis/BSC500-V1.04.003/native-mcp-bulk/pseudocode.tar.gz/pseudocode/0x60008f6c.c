
undefined4 FUN_60008f6c(undefined4 param_1,char *param_2)

{
  uint uVar1;
  uint uVar2;
  bool bVar3;
  
  if (*param_2 == '\x05') {
    cRam20007418 = **(char **)(param_2 + 8);
    FUN_60168578("[ble_app_gatts_set_cbk4] CCCD %d\r\n");
    uVar2 = FUN_601587e4(param_1);
    if (uVar2 < 2) {
      *(undefined1 *)(uVar2 + 0x200073c3) = 2;
    }
    else {
      FUN_60168578("[CH4_RX] Warning: Connection index %d not found in env\r\n",param_1);
    }
    if (cRam20007418 == '\0') {
      thunk_FUN_6001bdd0(0x10);
    }
    else {
      thunk_FUN_6001bd58();
      thunk_FUN_6001bde4(0x10);
    }
  }
  else if (*param_2 == '\x02') {
    FUN_60168578("[CH4_RX] Received %d bytes\r\n",*(undefined2 *)(param_2 + 2));
    FUN_60168578("[CH4_RX] Data: ");
    uVar2 = 0;
    while( true ) {
      uVar1 = (uint)*(ushort *)(param_2 + 2);
      bVar3 = 0xe < uVar2;
      if (uVar2 < 0x10) {
        bVar3 = uVar1 <= uVar2;
      }
      if (bVar3) break;
      FUN_60168578(&UNK_600090a0,*(undefined1 *)(*(int *)(param_2 + 8) + uVar2));
      uVar2 = uVar2 + 1;
    }
    if (0x10 < uVar1) {
      FUN_60168578("... (%d more bytes)",uVar1 - 0x10);
    }
    FUN_60168578(&UNK_6000909c);
    thunk_FUN_6001bd58();
    thunk_FUN_6001be54(*(undefined4 *)(param_2 + 8),*(undefined2 *)(param_2 + 2));
  }
  return 0;
}
