
void FUN_60034df4(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  int iVar2;
  
  for (uVar1 = 0; uVar1 < param_3; uVar1 = uVar1 + 4) {
    *(char *)(param_1 + uVar1) = (char)*(undefined4 *)(param_2 + uVar1);
    iVar2 = param_1 + uVar1;
    *(char *)(iVar2 + 1) = (char)((uint)*(undefined4 *)(param_2 + uVar1) >> 8);
    *(char *)(iVar2 + 2) = (char)*(undefined2 *)(param_2 + uVar1 + 2);
    *(undefined1 *)(iVar2 + 3) = *(undefined1 *)(param_2 + uVar1 + 3);
  }
  return;
}
