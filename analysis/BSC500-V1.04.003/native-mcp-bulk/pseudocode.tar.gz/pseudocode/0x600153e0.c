
/* WARNING: Possible PIC construction at 0x60015426: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6001542a) */

void FUN_600153e0(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  
  switch(param_1) {
  case 1:
    if (*(int **)(iRam2000be80 + 0xd8) == (int *)0x0) {
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x6001b938. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(iRam2000be80 + 0xd8) + 0xe0))();
    return;
  case 2:
    func_0x600ee0f0(iRam2000be80,0x8000002b);
    iVar2 = -0x7fffffd6;
    break;
  case 3:
    iVar2 = -0x7fffffca;
    break;
  case 4:
    iVar2 = -0x7fffffbd;
    break;
  case 5:
    iVar2 = -0x7fffffc8;
    break;
  case 6:
    iVar2 = -0x7fffffc1;
    break;
  case 7:
    piVar1 = *(int **)(iRam2000be80 + 0xd8);
    if ((piVar1 != (int *)0x0) && (piVar1[0x11] == 3)) {
                    /* WARNING: Could not recover jumptable at 0x6001b94e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar1 + 0xe0))();
      return;
    }
    return;
  case 8:
    if (*(int **)(iRam2000be88 + 0x524) == (int *)0x0) {
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x6001b818. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(**(int **)(iRam2000be88 + 0x524) + 0xe0))();
    return;
  default:
    return;
  }
  piVar1 = *(int **)(iRam2000be80 + 0xd8);
  if ((piVar1 != (int *)0x0) && (piVar1[0x12] == iVar2)) {
                    /* WARNING: Could not recover jumptable at 0x600ee102. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar1 + 0xe0))();
    return;
  }
  return;
}
