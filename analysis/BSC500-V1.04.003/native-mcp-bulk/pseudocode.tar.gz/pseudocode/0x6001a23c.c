
undefined4 FUN_6001a23c(void)

{
  return 0xc0;
}
