
int FUN_60036f28(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined2 *local_20;
  int local_1c;
  
  local_1c = 0;
  if (param_1 == 0) {
    return 0xe;
  }
  if (param_4 == (uint *)0x0) {
    return 0xe;
  }
  if (0x11 < *param_4) {
    *param_4 = *param_4 - 0x12;
    *param_3 = 0x36;
    iVar2 = param_1;
    iVar3 = param_2;
    local_20 = param_3;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 2,param_1,param_2);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 3,iVar2,iVar3);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar2 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 4,iVar2,iVar3);
    if (iVar2 != 0) {
      return iVar2;
    }
    local_20 = (undefined2 *)*param_4;
    iVar2 = FUN_600434b6(param_1,param_2,&local_1c,&local_20,param_3 + 5);
    if (iVar2 != 0) {
      return iVar2;
    }
    *param_4 = *param_4 - (int)local_20;
    if (local_1c == param_2) {
      *param_4 = (uint)(local_20 + 9);
      return 0;
    }
  }
  return 9;
}
