
undefined4 FUN_60023390(undefined4 param_1)

{
  FUN_600319ec();
  FUN_6003229a();
  uRam2007a660 = param_1;
  return 0;
}
