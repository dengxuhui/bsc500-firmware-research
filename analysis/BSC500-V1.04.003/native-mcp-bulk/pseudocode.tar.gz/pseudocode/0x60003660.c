
/* WARNING: Removing unreachable block (ram,0x6000366a) */
/* WARNING: Removing unreachable block (ram,0x6000366e) */
/* WARNING: Removing unreachable block (ram,0x60003672) */
/* WARNING: Removing unreachable block (ram,0x60003676) */
/* WARNING: Removing unreachable block (ram,0x600036a0) */
/* WARNING: Removing unreachable block (ram,0x600036ac) */
/* WARNING: Removing unreachable block (ram,0x600036ae) */
/* WARNING: Removing unreachable block (ram,0x60003578) */
/* WARNING: Removing unreachable block (ram,0x60003586) */
/* WARNING: Removing unreachable block (ram,0x60003588) */
/* WARNING: Removing unreachable block (ram,0x6000358a) */
/* WARNING: Removing unreachable block (ram,0x60003666) */
/* WARNING: Removing unreachable block (ram,0x6000361a) */
/* WARNING: Removing unreachable block (ram,0x60003702) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60003660(void)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  undefined4 unaff_r5;
  
  FUN_60161cdc(DAT_2004c600);
  uVar2 = (uint)(cRam2004c601 == '\x01');
  if (iRam2007eef0 == 0) {
    FUN_60167f3c(4,"APP.AUDIO",1,"not initialized",unaff_r5);
    return -1;
  }
  iVar3 = FUN_6016089c();
  uVar1 = _DAT_2007ef0c;
  if (iVar3 != 0) {
    uVar2 = 0;
  }
  _DAT_2007ef0c = uVar2;
  iVar3 = FUN_60158f2c();
  if (iVar3 == 0) {
    cRam2004c601 = uVar2 != 0;
    return 0;
  }
  _DAT_2007ef0c = uVar1;
  return iVar3;
}
