
bool FUN_6001b952(undefined1 param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined1 local_40;
  undefined1 local_3f;
  undefined4 local_3c;
  undefined4 uStack_38;
  
  ZeroBytes(&local_40,0x28);
  local_40 = param_1;
  local_3f = param_2;
  local_3c = param_3;
  uStack_38 = param_4;
  iVar1 = FUN_60031960(&local_40);
  return iVar1 != 0;
}
