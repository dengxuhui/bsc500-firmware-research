
void FUN_6001b8ac(undefined4 *param_1,int param_2,uint param_3)

{
  ushort uVar1;
  uint uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  uVar1 = *(ushort *)(param_2 + 0x80);
  param_1[1] = 0;
  *param_1 = 0;
  if (param_3 < uVar1) {
    *param_1 = *(undefined4 *)(param_2 + param_3 * 8);
    puVar4 = (undefined4 *)(param_2 + param_3 * 8);
    param_1[1] = puVar4[1];
    uVar1 = uVar1 - 1;
    *(ushort *)(param_2 + 0x80) = uVar1;
    uVar2 = (uint)uVar1;
    if (param_3 < uVar2) {
      uVar3 = *(undefined4 *)(param_2 + uVar2 * 8 + 4);
      *puVar4 = *(undefined4 *)(param_2 + uVar2 * 8);
      puVar4[1] = uVar3;
    }
  }
  return;
}
