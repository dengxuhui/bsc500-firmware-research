
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001c678(uint param_1)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  byte bVar5;
  
  iVar1 = FUN_6016518c();
  if (iVar1 != 0) {
    uVar2 = (uint)*(byte *)(iVar1 + 0x15);
    if (uVar2 <= param_1) {
      for (bVar5 = 0; bVar5 < uVar2; bVar5 = bVar5 + 1) {
        iVar3 = FUN_6015f2c4();
        if (iVar3 != 0) {
          ZeroBytes(iVar3,0xff4);
        }
        uVar2 = (uint)*(byte *)(iVar1 + 0x15);
      }
      _DAT_2000b290 = 0;
      return;
    }
    iVar1 = FUN_6015f2c4(param_1);
    if (iVar1 != 0) {
      iVar3 = -0xff4;
      do {
        if (iVar3 == 0) {
          return;
        }
        iVar4 = iVar1 + iVar3;
        iVar3 = iVar3 + 1;
      } while (*(char *)(iVar4 + 0xff4) == '\0');
      ZeroBytes(iVar1,0xff4);
      _DAT_2000b290 = (ushort)(byte)(DAT_2000b290 - 1);
    }
  }
  return;
}
