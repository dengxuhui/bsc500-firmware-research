
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000c0f8(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_60164b70();
  FUN_60161424("cur_position: [navi]%d  %d, [ride]%d  %d\n",*puVar1,puVar1[2],
               *(undefined4 *)(_DAT_20007b48 + 0xb4),*(undefined4 *)(_DAT_20007b48 + 0xbc));
  return;
}
