
void FUN_60009b20(void)

{
  int iVar1;
  
  iVar1 = FUN_60161a98();
  if (iVar1 != 0) {
    FUN_60161424("mtu[%d],channel:[%d,%d,%d],[%d,%d,%d],[%d,%d,%d],[%d,%d,%d]\n",DAT_2000736d,
                 DAT_20009acc,DAT_20009acd,DAT_20009acf,DAT_20044828,DAT_20044829,DAT_2004482b,
                 DAT_20044870,DAT_20044871,DAT_20044873,DAT_200448b8,DAT_200448b9,DAT_200448bb);
    return;
  }
  FUN_60161424("ble offline\n");
  return;
}
