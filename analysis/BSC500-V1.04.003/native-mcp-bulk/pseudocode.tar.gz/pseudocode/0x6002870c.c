
undefined4 FUN_6002870c(int param_1)

{
  int iVar1;
  uint local_7c;
  undefined1 auStack_78 [100];
  
  local_7c = 1;
  ZeroBytes(auStack_78,100);
  if ((iRam20009ec0 == 0) && (iRam20009ec0 = thunk_FUN_60162e34(0x260), iRam20009ec0 == 0)) {
LAB_6002884e:
    uRam20009eb9 = CONCAT11(uRam20009eb9._1_1_,1);
    if (cRam20009ebc == '\x01') {
      FUN_6011f0b8();
    }
    cRam20009ebc = 0;
    return 0;
  }
  if (uRam20009eb9._1_1_ == '\0') {
    FUN_601681f4(auStack_78,"%s/%s",0x20005820,0x20009ed4);
    iVar1 = FUN_60166758(0x20009ec0,auStack_78,1);
    if (iVar1 != 0) {
      goto LAB_6002884e;
    }
    uRam20009eb9 = CONCAT11(1,(undefined1)uRam20009eb9);
    if (iRam20009ec8 != 0) {
      FUN_60163c98(iRam20009ec0);
      iRam20009ecc = iRam20009ec8 + iRam20009ecc;
      if (uRam20009eb9._1_1_ != '\x01') {
        return 1;
      }
    }
  }
  iVar1 = FUN_6015d9d4(iRam20009ec0);
  if (iVar1 == 0) {
    FUN_60161ef4(iRam20009ec0,iRam20009ec4 + param_1,0x600,&local_7c);
    iRam20009ecc = iRam20009ecc + local_7c;
    iRam20009ec4 = iRam20009ec4 + local_7c;
    if ((0x5ff < local_7c) && (*(int *)(iRam20009ec0 + 0xc) != iRam20009ecc)) {
      FUN_60161ef4(iRam20009ec0,iRam20009ec4 + param_1,0x1a0,&local_7c);
      iRam20009ec4 = iRam20009ec4 + local_7c;
      iRam20009ecc = iRam20009ecc + local_7c;
      if ((0x19f < local_7c) && (*(int *)(iRam20009ec0 + 0xc) != iRam20009ecc)) {
        return 1;
      }
    }
    FUN_601667bc();
    uRam20009eb9 = 1;
    iRam20009ec0 = 0;
    FUN_601681f4(auStack_78,"%s/%s",0x20005820,0x20009ed4);
    FUN_60163bbe(auStack_78);
    if (cRam20009ebc == '\x01') {
      FUN_6011f0b8();
    }
  }
  else {
    FUN_601667bc();
    uRam20009eb9 = 1;
    iRam20009ec0 = 0;
    FUN_601681f4(auStack_78,"%s/%s",0x20005820,0x20009ed4);
    FUN_60163bbe(auStack_78);
    if (cRam20009ebc == '\x01') {
      FUN_6011f0b8();
    }
    iRam20009ec8 = 0;
    iRam20009ecc = 0;
  }
  cRam20009ebc = 0;
  return 1;
}
