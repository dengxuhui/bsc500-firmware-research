
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60016c40(void)

{
  int iVar1;
  
  iVar1 = FUN_60164940();
  _DAT_2000b214 = *(undefined4 *)(iVar1 + 0x10);
  FUN_6001e1be();
  FUN_6004c70c();
  FUN_6004c688();
  DAT_2000b204 = 1;
  FUN_6014bc0c();
  DAT_2000b206 = 1;
  return;
}
