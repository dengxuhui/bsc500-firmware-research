
undefined2 FUN_6001fd50(int param_1)

{
  int iVar1;
  
  if ((param_1 != 0) && (iVar1 = FUN_601631fc(param_1 + 8), iVar1 == 6)) {
    return *(undefined2 *)(param_1 + 0x34);
  }
  return 0;
}
