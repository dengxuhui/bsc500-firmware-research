
undefined4 FUN_60029b60(void)

{
  return 0x2007ba6c;
}
