
void FUN_600263ce(void)

{
  FUN_6015df1c(0x24,1);
  return;
}
