
void FUN_60028f08(int param_1)

{
  undefined4 uVar1;
  undefined4 local_78;
  char local_74 [100];
  
  ZeroBytes(local_74,100);
  local_78 = 0;
  if (param_1 != 0) {
    builtin_strncpy(local_74,"</Tracks>",10);
    uVar1 = FUN_60168220(local_74);
    FUN_60164ed8(param_1,local_74,uVar1,&local_78);
    FUN_601667bc(param_1);
  }
  return;
}
