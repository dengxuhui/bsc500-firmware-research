
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60010cd0(int param_1,int *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  undefined4 uVar4;
  int local_20;
  int *local_1c;
  undefined4 local_18;
  undefined4 uStack_14;
  
  local_20 = param_1;
  local_1c = param_2;
  local_18 = param_3;
  uStack_14 = param_4;
  iVar2 = FUN_6011d38c();
  piVar1 = _FUN_60010d2c;
  if (iVar2 == 0) {
    uVar4 = 0;
  }
  else {
    iVar2 = *_FUN_60010d2c;
    if (iVar2 == 0) {
      local_18 = 0;
      uStack_14 = 0;
      local_1c = (int *)0x1;
      local_20 = iRam60010d30;
      iVar2 = FUN_60168494(&local_20);
      *piVar1 = iVar2;
    }
    FUN_6016825e(iVar2,0xffffffff);
    for (piVar3 = piVar1 + 1; piVar3 = (int *)*piVar3, piVar3 != (int *)0x0; piVar3 = piVar3 + 0xc)
    {
      if (*piVar3 == param_1) {
        if (param_2 != (int *)0x0) {
          *param_2 = (int)piVar3;
        }
        uVar4 = 1;
        goto LAB_60010d1e;
      }
    }
    uVar4 = 0;
LAB_60010d1e:
    if (*piVar1 != 0) {
      FUN_601682ae();
    }
  }
  return uVar4;
}
