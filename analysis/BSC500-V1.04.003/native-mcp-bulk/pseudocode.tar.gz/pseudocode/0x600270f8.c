
undefined8 FUN_600270f8(undefined4 param_1,int *param_2,uint param_3,int param_4)

{
  int iVar1;
  int iVar2;
  ushort uVar3;
  undefined4 uVar4;
  uint local_1c;
  int local_18;
  
  local_1c = param_3;
  local_18 = param_4;
  iVar1 = FUN_60166758(&local_18,param_1,1);
  uVar4 = 0;
  if (iVar1 == 0) {
    local_1c = 0;
    uVar4 = *(undefined4 *)(local_18 + 0xc);
    iVar1 = FUN_60162e34(0x800);
    while ((iVar2 = FUN_60161ef4(local_18,iVar1,0x800,&local_1c), iVar2 == 0 && (local_1c != 0))) {
      for (uVar3 = 0; uVar3 < local_1c; uVar3 = uVar3 + 1) {
        *param_2 = (uint)*(byte *)(iVar1 + (uint)uVar3) + *param_2;
      }
    }
    FUN_60166c0c(iVar1);
    FUN_60168578("fit info [%d:%x]\n",uVar4,*param_2);
    FUN_601667bc(local_18);
  }
  return CONCAT44(param_2,uVar4);
}
