
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000fffc(int param_1,uint param_2,int param_3,int param_4,int param_5,undefined4 param_6)

{
  int iVar1;
  undefined *puVar2;
  uint uVar3;
  
  if (param_1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("log_buf","ulog_formater",0xfe);
  }
  if (7 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("level <= LOG_LVL_DBG","ulog_formater",0xff);
  }
  if (param_3 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&LAB_60413572_1,"ulog_formater",0x100);
  }
  if (param_5 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("format","ulog_formater",0x101);
  }
  _DAT_20009478 = 0;
  _DAT_2000947c = FUN_601626c0("\r\n");
  FUN_60016db4(&DAT_20009494,&DAT_20009490,&DAT_2000948c,&DAT_20009488,&DAT_20009484,&DAT_20009480);
  FUN_60162c3a(param_1 + _DAT_20009478,0x80 - _DAT_20009478,"%2d-%02d-%02d %02d:%02d:%02d",
               _DAT_20009494,_DAT_20009490,_DAT_2000948c,_DAT_20009488,_DAT_20009484,_DAT_20009480);
  iVar1 = FUN_601626c0(_DAT_20009478 + param_1);
  _DAT_20009478 = iVar1 + _DAT_20009478;
  iVar1 = FUN_600f40dc(_DAT_20009478,param_1 + _DAT_20009478,&LAB_603ebc40);
  _DAT_20009478 = iVar1 + _DAT_20009478;
  iVar1 = FUN_600f40dc(_DAT_20009478,param_1 + _DAT_20009478,
                       *(undefined4 *)(&DAT_600101e0 + param_2 * 4));
  _DAT_20009478 = iVar1 + _DAT_20009478;
  iVar1 = FUN_600f40dc(_DAT_20009478,param_1 + _DAT_20009478,param_3);
  _DAT_20009478 = iVar1 + _DAT_20009478;
  iVar1 = FUN_600f40dc(_DAT_20009478,param_1 + _DAT_20009478,&LAB_603ebc40);
  _DAT_20009478 = iVar1 + _DAT_20009478;
  iVar1 = FUN_60163aac();
  if (iVar1 == 0) {
    iVar1 = FUN_60163ab8();
    if (iVar1 == 0) {
      puVar2 = &DAT_60010204;
    }
    else {
      puVar2 = (undefined *)FUN_60163ab8();
    }
    iVar1 = FUN_601308ac(puVar2,0x10);
    FUN_6015f784(_DAT_20009478 + param_1,puVar2,iVar1);
  }
  else {
    iVar1 = FUN_600f40dc(_DAT_20009478,param_1 + _DAT_20009478,&DAT_60010200);
  }
  _DAT_20009478 = _DAT_20009478 + iVar1;
  iVar1 = FUN_600f40dc(_DAT_20009478,param_1 + _DAT_20009478,&DAT_603ec98a);
  _DAT_20009478 = _DAT_20009478 + iVar1;
  uVar3 = FUN_60164d18(param_1 + _DAT_20009478,0x80 - _DAT_20009478,param_5,param_6);
  _DAT_20009478 = _DAT_20009478 + uVar3;
  if (0x80 < _DAT_20009478) {
    _DAT_20009478 = 0x80;
  }
  if (0x7fffffff < uVar3) {
    _DAT_20009478 = 0x80;
  }
  if (0x80 < _DAT_20009478 + _DAT_2000947c) {
    _DAT_20009478 = 0x80 - _DAT_2000947c;
  }
  if (param_4 != 0) {
    iVar1 = FUN_600f40dc(_DAT_20009478,param_1 + _DAT_20009478,"\r\n");
    _DAT_20009478 = iVar1 + _DAT_20009478;
  }
  return;
}
