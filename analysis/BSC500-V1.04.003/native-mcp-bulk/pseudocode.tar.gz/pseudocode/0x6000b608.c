
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000b608(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = _DAT_200781d4;
  iVar1 = _DAT_200781cc;
  *param_1 = _DAT_200781cc;
  *param_2 = iVar1 - iVar2;
  return;
}
