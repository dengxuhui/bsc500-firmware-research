
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001c9ec(uint param_1)

{
  ushort uVar1;
  ushort uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint auStack_350 [200];
  uint local_30;
  uint local_2c;
  undefined4 local_28;
  
  iVar4 = FUN_60164e24();
  iVar5 = FUN_60164fe0();
  if (*(int *)(iVar4 + 4) != 0) {
    local_2c = 0;
    local_28 = 0;
    local_30 = 0x7fffffff;
    if ((iVar5 != 0) && ((param_1 == 0 || ((int)(_DAT_2000b200 - 50000) < (int)param_1)))) {
      ZeroBytes(auStack_350,800);
      *(undefined2 *)(iVar5 + 0x57c) = 100;
      ZeroBytes(iVar5 + 0x580,800);
      iVar6 = FUN_6016242c(iVar5 + 0x50,1,&local_28);
      if ((iVar6 == 0) && (iVar6 = FUN_600299c8(), iVar6 != -1)) {
        if (_DAT_2000b1fc != 0) {
          thunk_FUN_60163c98(local_28);
          iVar6 = FUN_60132428(local_28);
          if ((iVar6 == 0) &&
             (iVar6 = (**(code **)(iVar4 + 4))(local_28,&local_2c,&local_30), iVar6 == 0)) {
            if (param_1 < local_2c + 0x1e848) {
              _DAT_2000b1fc = 0;
            }
            thunk_FUN_60163c98(local_28,_DAT_2000b1fc);
          }
        }
        uVar8 = 0;
        local_30 = 0;
        local_2c = 0;
        uVar2 = 0;
        do {
          while( true ) {
            iVar6 = (**(code **)(iVar4 + 4))(local_28,&local_2c,&local_30);
            uVar3 = local_2c;
            if (iVar6 != 0) goto LAB_6001cb16;
            iVar6 = local_2c - param_1;
            if (iVar6 < 0) {
              iVar6 = -iVar6;
            }
            if (0x1e847 < iVar6) break;
            uVar7 = (uint)uVar2;
            if ((uVar7 == 0) || (uVar1 = uVar2, 0x9c4 < local_2c - uVar8)) {
              auStack_350[uVar7 * 2] = local_2c;
              auStack_350[uVar7 * 2 + 1] = local_30;
              uVar8 = uVar3;
              uVar1 = uVar2 + 1;
              if (99 < (ushort)(uVar2 + 1)) {
                uVar1 = uVar2;
              }
            }
            _DAT_2000b200 = uVar3;
            _DAT_2000b1fc = thunk_FUN_6015cbf2(local_28);
            uVar2 = uVar1;
          }
        } while (local_2c <= param_1);
LAB_6001cb16:
        FUN_600299ac();
        thunk_FUN_601667bc(local_28);
        _DAT_2000b1fc = 0;
        (**(code **)(iVar4 + 8))();
        auStack_350[(uint)uVar2 * 2] = local_2c;
        auStack_350[(uint)uVar2 * 2 + 1] = local_30;
        FUN_6007db44(iVar5 + 0x580,auStack_350,800);
        *(undefined2 *)(iVar5 + 0x8ae) = 0;
        *(ushort *)(iVar5 + 0x57c) = uVar2;
      }
    }
  }
  return;
}
