
ushort FUN_60031960(int param_1,undefined4 param_2,undefined4 param_3,uint3 param_4)

{
  int *local_10;
  undefined1 auStack_c [2];
  char local_a;
  char local_9;
  
  _auStack_c = CONCAT13(0xff,param_4 & 0xffff);
  local_10 = (int *)0x0;
  FUN_6015b64c(param_1,&local_10,&local_9,&local_a);
  if ((local_a != '\0') && (*(byte *)(param_1 + 1) - 7 < 2)) {
    return *(ushort *)((short)local_9 * 0x34 + *local_10 + 0x2c) & 1;
  }
  return 1;
}
