
int FUN_60036274(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  undefined2 *puVar2;
  undefined2 *local_20;
  int local_1c;
  
  local_1c = 0;
  if ((param_1 == 0) || (param_4 == (uint *)0x0)) {
    return 0xe;
  }
  if (9 < *param_4) {
    *param_4 = *param_4 - 10;
    puVar2 = param_3 + 2;
    *param_3 = 0x19;
    local_20 = param_3;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,puVar2);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60042e7e(param_1,param_2,&local_1c,param_3 + 4);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60100b98(*puVar2,&local_20);
    if (iVar1 == 0) {
      iVar1 = FUN_60043070(param_1,param_2,&local_1c,(int)local_20 * 0x24 + 0x20079220);
      if (iVar1 != 0) {
        return iVar1;
      }
      iVar1 = FUN_60154864(*puVar2);
      if (iVar1 != 0) {
        return iVar1;
      }
    }
    if (local_1c == param_2) {
      *param_4 = 10;
      return 0;
    }
  }
  return 9;
}
