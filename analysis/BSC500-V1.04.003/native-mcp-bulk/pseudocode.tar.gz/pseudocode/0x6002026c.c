
float FUN_6002026c(float *param_1,float *param_2)

{
  float fVar1;
  uint uVar2;
  uint in_fpscr;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr3;
  undefined4 in_cr4;
  float fVar3;
  float fVar4;
  float fVar5;
  float fVar6;
  
  fVar3 = 0.0;
  if ((param_1 != (float *)0x0) && (param_2 != (float *)0x0)) {
    fVar1 = *param_2;
    if (param_1[3] == 0.0) {
      fVar4 = param_2[2];
      param_1[4] = fVar1;
      param_1[3] = 1.4013e-45;
      param_1[2] = fVar4;
      return fVar3;
    }
    if (((uint)fVar1 < (uint)param_1[4]) || (uVar2 = (int)fVar1 - (int)param_1[4], 0x1e < uVar2)) {
      param_1[2] = 0.0;
      param_1[3] = 0.0;
      param_1[4] = 0.0;
      return fVar3;
    }
    if (uVar2 != 0) {
      param_1[3] = (float)((int)param_1[3] + 1);
      param_1[4] = fVar1;
      fVar1 = param_2[2];
      fVar4 = param_1[2];
      param_1[2] = fVar1;
      fVar5 = (float)VectorUnsignedToFloat(uVar2,(byte)(in_fpscr >> 0x16) & 3);
      if (0.001 <= fVar1) {
        fVar6 = (*param_1 + param_1[1]) * 9.8;
        fVar3 = 0.0;
        coprocessor_function2(10,3,0,in_cr3,in_cr4,in_cr0);
        fVar4 = (fVar1 - fVar4) / fVar5 + param_2[1] * fVar6 + fVar6 * 0.005 + fVar1 * fVar1 * 0.335
        ;
        if (0.001 <= fVar4) {
          fVar3 = fVar1 * fVar4;
          coprocessor_function2(10,8,2,in_cr0,in_cr0,in_cr1);
        }
      }
    }
  }
  return fVar3;
}
