
undefined4 FUN_60016cac(void)

{
  FUN_6001e638(uRam2000a534);
  FUN_60164e80(1);
  FUN_60164afc(0xc);
  FUN_60166af4(0x2000a558);
  return 0;
}
