
int FUN_600369ec(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  int local_1c;
  
  local_1c = 0;
  iVar1 = 0xe;
  if ((param_1 != 0) && (param_4 != (uint *)0x0)) {
    if (*param_4 < 0x10) {
      return 9;
    }
    *param_4 = *param_4 - 0x10;
    *param_3 = 0x1b;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 2,param_3);
    if (iVar1 == 0) {
      iVar1 = FUN_60152fbe(param_1,param_2,&local_1c,param_3 + 4);
      if ((iVar1 == 0) &&
         ((*(char *)(param_3 + 4) != '\x01' ||
          (iVar1 = FUN_60122df0(param_1,param_2,&local_1c,param_3 + 6), iVar1 == 0)))) {
        if (local_1c != param_2) {
          return 9;
        }
        *param_4 = 0x10;
        return 0;
      }
    }
  }
  return iVar1;
}
