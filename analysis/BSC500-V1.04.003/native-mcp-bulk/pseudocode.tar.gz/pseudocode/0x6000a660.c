
void FUN_6000a660(void)

{
  FUN_60161424("Firmware name: %s, hardware version: %s, software version: %s",0x2000bb15,0x2000bb35
               ,0x2000bb55);
  FUN_60161424(&DAT_603f7cc3);
  return;
}
