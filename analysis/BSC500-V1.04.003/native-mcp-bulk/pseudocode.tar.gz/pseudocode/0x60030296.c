
void FUN_60030296(undefined4 param_1,undefined4 param_2)

{
  FUN_6003db58(param_1,1,param_2);
  return;
}
