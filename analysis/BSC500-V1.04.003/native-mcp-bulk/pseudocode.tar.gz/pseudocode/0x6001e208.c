
void FUN_6001e208(ushort *param_1,ushort *param_2,int *param_3)

{
  ushort uVar1;
  ushort uVar2;
  uint uVar3;
  
  uVar2 = *param_1;
  if (uVar2 == 0) {
    if (((uint)(iRam20055600 - *param_3) < 3000) && (uRam200578a4 != 0xffff)) {
      uVar3 = uRam200578a4 / 3;
      uVar1 = (ushort)uVar3;
      uVar2 = *param_2;
      if (*param_2 <= uVar3) {
        uVar2 = uVar1;
      }
      uVar2 = uVar2 - uVar1;
    }
    else {
      uVar2 = 0;
    }
  }
  else {
    uRam200578a4 = uVar2;
    *param_3 = iRam20055600;
  }
  *param_2 = uVar2;
  return;
}
