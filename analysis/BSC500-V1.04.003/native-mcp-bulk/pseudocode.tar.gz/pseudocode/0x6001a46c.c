
void FUN_6001a46c(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  int iVar4;
  
  if (param_1 != 0) {
    puVar3 = *(undefined4 **)(param_1 + 0x24);
    iVar2 = *(int *)(param_1 + 0x30);
    iVar4 = *(int *)(param_1 + 0x34);
    FUN_60161424("thread_crush_dump: %s\n",param_1);
    for (; puVar3 < (undefined4 *)(iVar4 + iVar2); puVar3 = puVar3 + 1) {
      iVar1 = FUN_601597bc(*puVar3);
      if (iVar1 != 0) {
        FUN_60161424("0x%08x\n",*puVar3);
      }
    }
    FUN_60161424("crush_dump end\n");
    return;
  }
  return;
}
