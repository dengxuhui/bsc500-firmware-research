
int FUN_60032fb0(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int local_18;
  undefined4 uStack_14;
  
  iVar3 = 0;
  local_18 = 0;
  uStack_14 = param_4;
  if (param_2 << 0x18 < 0) {
    iVar3 = FUN_6015a168(&local_18,param_1);
    iVar3 = local_18 + iVar3;
  }
  if (param_2 << 0x19 < 0) {
    iVar1 = FUN_6015a168(&local_18,param_1 + iVar3);
    iVar3 = iVar1 + iVar3 + local_18;
  }
  if (param_2 << 0x1a < 0) {
    iVar1 = FUN_6015a168(&local_18,param_1 + iVar3);
    iVar3 = iVar1 + iVar3 + local_18;
  }
  if (param_2 << 0x1b < 0) {
    iVar1 = FUN_60158ee8(&uStack_14,param_1 + iVar3);
    iVar2 = FUN_60158ee8(&uStack_14,param_1 + iVar3 + iVar1);
    iVar3 = iVar3 + iVar1 + iVar2;
  }
  return iVar3;
}
