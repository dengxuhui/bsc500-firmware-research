
undefined4 FUN_60030d90(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  undefined4 uVar4;
  
  if (param_1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("mq != RT_NULL","rt_mq_control",0x8fc);
  }
  iVar1 = FUN_601631fc();
  if (iVar1 == 6) {
    if (param_2 == 1) {
      uVar2 = FUN_60167d0c();
      FUN_6015af1a(param_1 + 0x1c);
      piVar3 = (int *)*(int *)(param_1 + 0x30);
      while (piVar3 != (int *)0x0) {
        iVar1 = *piVar3;
        *(int *)(param_1 + 0x30) = iVar1;
        if ((int *)*(int *)(param_1 + 0x34) == piVar3) {
          *(undefined4 *)(param_1 + 0x34) = 0;
        }
        uVar4 = *(undefined4 *)(param_1 + 0x38);
        *(int **)(param_1 + 0x38) = piVar3;
        *piVar3 = uVar4;
        piVar3 = (int *)iVar1;
      }
      uVar4 = 0;
      *(undefined2 *)(param_1 + 0x2c) = 0;
      FUN_60167d14(uVar2);
      FUN_60163a08();
    }
    else {
      uVar4 = 0xffffffff;
    }
    return uVar4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("rt_object_get_type(&mq->parent.parent) == RT_Object_Class_MessageQueue",
               "rt_mq_control",0x8fd);
}
