
undefined4 FUN_60023d30(void)

{
  uint uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  longlong in_d0;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  undefined8 uVar7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined4 uVar11;
  int local_10;
  uint uStack_c;
  
  uStack_c = (uint)((ulonglong)in_d0 >> 0x20);
  uVar1 = uStack_c & 0x7fffffff;
  local_10 = (int)in_d0;
  if (uVar1 < 0x3ff00000) {
    if (0x3fdfffff < uVar1) {
      if (in_d0 < 0) {
        uVar7 = FUN_601682c8();
        uVar7 = FUN_601678fc((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x3fe00000);
        uVar2 = (undefined4)((ulonglong)uVar7 >> 0x20);
        uVar4 = (undefined4)uVar7;
        uVar5 = FUN_60138628(uVar4,&UNK_60277108,6);
        uVar7 = FUN_601678fc(uVar5,extraout_s1_01,uVar4,uVar2);
        uVar5 = FUN_60138628(uVar4,&UNK_60277138,4);
        uVar8 = FUN_601678fc(uVar5,extraout_s1_02,uVar4,uVar2);
        uVar8 = FUN_601682c8((int)uVar8,(int)((ulonglong)uVar8 >> 0x20),0,0x3ff00000);
        uVar9 = FUN_60138598(uVar4,uVar2);
        uVar4 = (undefined4)((ulonglong)uVar9 >> 0x20);
        uVar7 = FUN_601675d8((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),(int)uVar8,
                             (int)((ulonglong)uVar8 >> 0x20));
        uVar7 = FUN_601678fc((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),(int)uVar9,uVar4);
        uVar7 = FUN_60165558((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0x33145c07,0x3c91a626);
        uVar7 = FUN_601682c8((int)uVar9,uVar4,(int)uVar7,(int)((ulonglong)uVar7 >> 0x20));
        uVar7 = FUN_601678fc((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x40000000);
        uVar4 = FUN_60138720((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0x54442d18,0x400921fb);
        return uVar4;
      }
      uVar7 = FUN_60138720(local_10,uStack_c,0,0x3ff00000);
      uVar7 = FUN_601678fc((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x3fe00000);
      uVar5 = (undefined4)((ulonglong)uVar7 >> 0x20);
      uVar2 = (undefined4)uVar7;
      uVar7 = FUN_60138598();
      uVar3 = (undefined4)((ulonglong)uVar7 >> 0x20);
      uVar11 = 0;
      uVar4 = uVar3;
      uVar8 = FUN_601682c8((int)uVar7,uVar3,0,uVar3,0,uVar3);
      uVar9 = FUN_601678fc(uVar11,uVar4,uVar11,uVar4);
      uVar9 = FUN_60138720((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),uVar2,uVar5);
      uVar8 = FUN_601675d8((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),(int)uVar8,
                           (int)((ulonglong)uVar8 >> 0x20));
      uVar6 = FUN_60138628(uVar2,&UNK_60277108,6);
      uVar9 = FUN_601678fc(uVar6,extraout_s1_03,uVar2,uVar5);
      uVar6 = FUN_60138628(uVar2,&UNK_60277138,4);
      uVar10 = FUN_601678fc(uVar6,extraout_s1_04,uVar2,uVar5);
      uVar10 = FUN_601682c8((int)uVar10,(int)((ulonglong)uVar10 >> 0x20),0,0x3ff00000);
      uVar9 = FUN_601675d8((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),(int)uVar10,
                           (int)((ulonglong)uVar10 >> 0x20));
      uVar7 = FUN_601678fc((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),(int)uVar7,uVar3);
      uVar7 = FUN_601682c8((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),(int)uVar8,
                           (int)((ulonglong)uVar8 >> 0x20));
      uVar7 = FUN_601682c8(uVar11,uVar4,(int)uVar7,(int)((ulonglong)uVar7 >> 0x20));
      uVar4 = FUN_601678fc((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x40000000);
      return uVar4;
    }
    if (0x3c600000 < uVar1) {
      uVar7 = FUN_601678fc(local_10,uStack_c,local_10,uStack_c);
      uVar2 = (undefined4)((ulonglong)uVar7 >> 0x20);
      uVar4 = (undefined4)uVar7;
      uVar5 = FUN_60138628(uVar4,&UNK_60277108,6);
      uVar7 = FUN_601678fc(uVar5,extraout_s1,uVar4,uVar2);
      uVar5 = FUN_60138628(uVar4,&UNK_60277138,4);
      uVar8 = FUN_601678fc(uVar5,extraout_s1_00,uVar4,uVar2);
      uVar8 = FUN_601682c8((int)uVar8,(int)((ulonglong)uVar8 >> 0x20),0,0x3ff00000);
      uVar7 = FUN_601675d8((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),(int)uVar8,
                           (int)((ulonglong)uVar8 >> 0x20));
      uVar7 = FUN_601678fc(local_10,uStack_c,(int)uVar7,(int)((ulonglong)uVar7 >> 0x20));
      uVar7 = FUN_60138720((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0x33145c07,0x3c91a626);
      uVar7 = FUN_60138720((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),local_10,uStack_c);
      uVar4 = FUN_60138720((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0x54442d18,0x3ff921fb);
      return uVar4;
    }
  }
  else {
    if (local_10 != 0 || uVar1 != 0x3ff00000) {
      if ((uVar1 < 0x7ff00001) && ((uVar1 != 0x7ff00000 || (local_10 == 0)))) {
        FUN_60163236(1);
        uVar4 = FUN_60138608();
        return uVar4;
      }
      uVar4 = FUN_60138584(local_10);
      return uVar4;
    }
    if (0 < (int)uStack_c) {
      return 0;
    }
  }
  return 0x54442d18;
}
