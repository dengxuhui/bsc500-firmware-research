
void FUN_60024860(void)

{
  int iVar1;
  
  iVar1 = FUN_600339ac();
  if (iVar1 != 0) {
    FUN_6012cbf0();
    return;
  }
  return;
}
