
undefined4 FUN_6002183c(int param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 uVar5;
  uint uVar6;
  int iVar7;
  int local_54;
  int local_50;
  int *local_4c;
  char local_48 [28];
  undefined4 local_2c;
  undefined4 uStack_28;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  iVar2 = FUN_60030a78();
  if (iVar2 != 0) {
    return 0xffffffff;
  }
  uStack_28 = *(undefined4 *)(param_1 + 0x10);
  local_2c = *(undefined4 *)(param_1 + 0x14);
  ZeroBytes(local_48,0x1c);
  FUN_60134d56(0x2000c57c,&local_2c);
  FUN_60134e9e(0x2000c58c,&local_2c);
  iVar2 = FUN_60135184(0x2000afd0,&local_2c);
  if (iVar2 == 0) {
    FUN_60134e6a(0x2000c58c);
    iVar2 = FUN_601345ae(0x2007f8cc,&local_2c,0x2000c54c);
    if (iVar2 == 0) {
      uVar6 = 0xffffffff;
      local_4c = (int *)0x2000b014;
      iVar2 = 0;
      do {
        uVar6 = uVar6 + 1;
        if (uRam2000c554 <= uVar6) goto LAB_600218a8;
        uVar5 = 0x2000c5a4;
        cVar1 = *(char *)(iRam2000c54c + iVar2);
        iVar7 = iRam2000c54c + iVar2;
        if (cVar1 != '\0') {
          uVar5 = 0x2000c720;
        }
        FUN_60134c5c(uVar5,iVar7);
        iVar3 = 0x5c;
        piVar4 = local_4c;
        if (cVar1 == '\0') {
          iVar3 = 0x58;
          piVar4 = (int *)0x2000b010;
        }
        *(int *)(iVar3 + 0x2000afb8) = *piVar4 + 1;
        iVar7 = FUN_60135152(0x2000afc0,iVar7);
        iVar2 = iVar2 + 0x1c;
      } while (iVar7 == 0);
    }
    else {
LAB_600218a8:
      FUN_60135248(*(undefined4 *)(param_1 + 0x14),0x2000c5a4);
      FUN_60135248(*(undefined4 *)(param_1 + 0x14),0x2000c720);
      FUN_60134d48(0x2000c57c,0x2000afd8);
      FUN_60134e5c(0x2000c58c);
      FUN_6013523a(0x2000c5a4,0x2000afe8);
      FUN_6013523a(0x2000c720,0x2000aff0);
      uRam2000c928 = 0x78;
      iVar2 = FUN_6013503e(0x2000b00c);
      if (iVar2 == 0) {
        uVar6 = 0;
        do {
          if (uRam2000b010 <= uVar6) {
            iVar2 = FUN_60134ff0(0x2000b00c);
            if (iVar2 == 0) {
              uVar6 = 0;
              goto LAB_60021996;
            }
            break;
          }
          iVar2 = FUN_60135440(0x2000b00c,uVar6,0x2000c924);
          uVar6 = uVar6 + 1;
        } while (iVar2 == 0);
      }
    }
  }
  goto LAB_600219ac;
LAB_60021a3e:
  if (uRam2000afbc <= uVar6) goto LAB_60021aae;
  iVar2 = FUN_60135106(0x2000afb8,uVar6,local_48);
  if ((iVar2 != 0) || (iVar2 = FUN_60134ae8(0x2000c818,local_48,0x2000c924), iVar2 != 0))
  goto LAB_60021ab8;
  if (local_48[0] == '\0') {
    uRam2000c950 = uRam2000b01c;
    uRam2000c954 = uRam2000b020;
    iVar2 = FUN_60135440(0x2000b00c,local_54,0x2000c924);
    if (iVar2 != 0) goto LAB_60021ab8;
    FUN_601353cc(0x2000b018,0x2000c924);
    local_54 = local_54 + 1;
  }
  else {
    uRam2000c950 = uRam2000b028;
    uRam2000c954 = uRam2000b02c;
    iVar2 = FUN_60135408(0x2000b00c,local_50,0x2000c924);
    if (iVar2 != 0) goto LAB_60021ab8;
    FUN_601353cc(0x2000b024,0x2000c924);
    local_50 = local_50 + 1;
  }
  uVar6 = uVar6 + 1;
  goto LAB_60021a3e;
LAB_60021aae:
  iVar2 = FUN_60135086(0x2000b00c,uRam2000afcc);
  if (iVar2 == 0) {
    uVar6 = 0;
    do {
      if (uRam2000afd4 <= uVar6) {
        FUN_60135228(0x2000b018,0x2000c558);
        FUN_60135228(0x2000b024,0x2000c570);
        iVar2 = FUN_6013588c(0x2000b00c,0x2000c558);
        if (((((iVar2 == 0) && (iVar2 = FUN_60135820(0x2000b00c,0x2000c570), iVar2 == 0)) &&
             (iVar2 = FUN_601358f8(0x2000b00c,0x2000afd8), iVar2 == 0)) &&
            ((iVar2 = FUN_60135968(0x2000b00c,0x2000afe0), iVar2 == 0 &&
             (iVar2 = FUN_601359da(0x2000b00c,0x2000afe8), iVar2 == 0)))) &&
           ((iVar2 = FUN_60135a4c(0x2000b00c,0x2000aff0), iVar2 == 0 &&
            (iVar2 = FUN_60134f88(0x2000b00c), iVar2 == 0)))) {
          FUN_601667bc(uRam2000b00c);
          FUN_601667bc(uRam2000afb8);
          FUN_601667bc(uRam2000afc8);
          FUN_60163bbe(0x2008af54);
          FUN_60163bbe(0x2008b01c);
          if (iRam2000b000 != 0) {
            FUN_601667bc();
            iRam2000b000 = 0;
          }
          iVar2 = FUN_60166758(0x2000b000,0x2008ad60,1);
          if (iVar2 != 0) {
            iRam2000b000 = 0;
            return 0xffffffff;
          }
          uRam2000b004 = uRam2000b010;
          uRam2000b008 = uRam2000b014;
          uRam2000c564 = 0x2000c558;
          uRam2000c568 = 0x2000c738;
          uRam2000c56c = 0x2000afe8;
          uRam2000c73c = 0x2000b000;
          uRam2000c74c = uRam2000b010;
          uRam2000c754 = 0x2000b000;
          uRam2000c764 = uRam2000afcc;
          uRam2000c840 = 0x2000c750;
          uRam2000c844 = 0x2000afe0;
          return 0;
        }
        break;
      }
      iVar2 = FUN_601351b6(0x2000c828,uVar6,&local_2c);
      if (iVar2 != 0) break;
      iVar2 = FUN_601350d8(0x2000b00c,&local_2c);
      uVar6 = uVar6 + 1;
    } while (iVar2 == 0);
  }
LAB_60021ab8:
  FUN_601667bc(uRam2000b00c);
  FUN_601667bc(uRam2000afb8);
  uVar5 = uRam2000afc8;
  goto LAB_600219b8;
  while( true ) {
    iVar2 = FUN_60135408(0x2000b00c,uVar6,0x2000c924);
    uVar6 = uVar6 + 1;
    if (iVar2 != 0) break;
LAB_60021996:
    if (uRam2000b014 <= uVar6) {
      FUN_601667bc(uRam2000afc0);
      FUN_601667bc(uRam2000afd0);
      iVar2 = FUN_60166758(0x2000afb8,0x2008af54,1);
      if (iVar2 == 0) {
        uRam2000afbc = uRam2000afc4;
        iVar2 = FUN_60166758(0x2000afc8,0x2008b01c,1);
        if (iVar2 == 0) {
          uRam2000afcc = uRam2000afd4;
          uRam2000c838 = 0x2000afc8;
          uRam2000c83c = uRam2000afd4;
          local_54 = 0;
          uVar6 = 0;
          local_50 = 0;
          goto LAB_60021a3e;
        }
        uRam2000afc8 = 0;
        FUN_601667bc(uRam2000b00c);
        uVar5 = uRam2000afb8;
      }
      else {
        uRam2000afb8 = 0;
        uVar5 = uRam2000b00c;
      }
      FUN_601667bc(uVar5);
      goto LAB_600219ba;
    }
  }
LAB_600219ac:
  FUN_601667bc(uRam2000b00c);
  FUN_601667bc(uRam2000afc0);
  uVar5 = uRam2000afd0;
LAB_600219b8:
  FUN_601667bc(uVar5);
LAB_600219ba:
  FUN_60163bbe(0x2008ad60);
  FUN_60163bbe(0x2008af54);
  FUN_60163bbe(0x2008b01c);
  return 0xffffffff;
}
