
undefined4 FUN_6001a2bc(int *param_1,int param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  undefined4 local_34;
  int local_30;
  int iStack_2c;
  int iStack_28;
  
  *param_1 = 0;
  local_34 = 0;
  if (iRam2008d18c == 0) {
    if (param_2 == 0) {
      return 1;
    }
    iVar1 = FUN_60023714(param_2,&local_30,&local_34);
    if (iRam2008d18c == 0) {
      if (iVar1 != 0) {
        return 0xe;
      }
      iVar1 = FUN_60168220(param_2);
      piVar2 = (int *)FUN_601633cc(iVar1 * 2 + 0x288);
      if (piVar2 != (int *)0x0) {
        piVar3 = piVar2 + 0x9d;
        *piVar2 = (int)piVar3;
        piVar2[1] = (int)piVar3 + iVar1 + 1;
        FUN_60167370(piVar3,param_2);
        FUN_60167370(piVar2[1],param_2);
        iVar4 = piVar2[1];
        *(undefined4 *)(iVar4 + iVar1) = 0x6d65742d;
        *(undefined2 *)(iVar4 + iVar1 + 4) = 0x70;
        *(undefined1 *)((int)piVar2 + 0x52) = 0;
        *(undefined1 *)(piVar2 + 0x14) = 0;
        *(undefined2 *)((int)piVar2 + 0x55) = 0;
        if (param_3 < 7) {
          param_3 = 6;
        }
        piVar2[0xe] = 0;
        piVar2[0xf] = 0;
        piVar2[0x10] = param_3;
        *(undefined1 *)(piVar2 + 0x16) = 0;
        piVar2[8] = -1;
        *(char *)((int)piVar2 + 0x57) = (char)local_34;
        *(undefined1 *)((int)piVar2 + 0x53) = 1;
        piVar2[2] = local_30;
        piVar2[3] = iStack_2c;
        piVar2[4] = iStack_28;
        piVar2[0xc] = param_4;
        piVar2[0x18] = 0;
        piVar2[0x19] = 0;
        piVar2[0x1a] = 0;
        ZeroBytes(piVar2 + 0x1c,0x200,iStack_28,piVar2 + 5);
        piVar2[0x9c] = param_5;
        *param_1 = (int)piVar2;
        return 0;
      }
      FUN_60138452(&local_30);
    }
  }
  return 7;
}
