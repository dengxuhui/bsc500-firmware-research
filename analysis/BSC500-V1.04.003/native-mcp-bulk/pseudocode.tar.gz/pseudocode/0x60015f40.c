
bool FUN_60015f40(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  uint local_28;
  int local_24;
  uint local_20;
  undefined1 auStack_1c [12];
  
  if ((*(char *)(param_2 + 0x10) == '\x01') && ((*(uint *)(param_2 + 0x14) & 0x1f) - 1 < 2)) {
    iVar1 = FUN_601609d0(auStack_1c,*(undefined4 *)(param_2 + 4),2);
    if (iVar1 != 0) {
      return false;
    }
    local_20 = 0;
    local_28 = 0;
    local_24 = 0;
    FUN_60160948(auStack_1c,0,2);
    FUN_6015c478(auStack_1c,&local_20);
    FUN_60160948(auStack_1c,0,0);
    iVar1 = FUN_6015c2f4(auStack_1c,&local_28,4,&local_24);
    if ((((iVar1 == 0) && (local_24 == 4)) && ((local_28 & 0x1f) - 1 < 2)) && (4 < local_20)) {
      iVar2 = local_20 - 4;
      iVar1 = FUN_6015f71c(iVar2);
      *(int *)(param_2 + 0x18) = iVar1;
      if (iVar1 != 0) {
        iVar1 = FUN_6015c2f4(auStack_1c,iVar1,iVar2,&local_24);
        FUN_60160a64(auStack_1c);
        return iVar1 == 0;
      }
    }
    FUN_60160a64(auStack_1c);
  }
  return false;
}
