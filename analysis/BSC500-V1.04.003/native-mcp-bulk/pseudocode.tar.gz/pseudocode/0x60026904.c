
undefined4 FUN_60026904(void)

{
  int iVar1;
  
  iVar1 = FUN_60163840(uRam20008d24);
  if (iVar1 != 8) {
    if (iVar1 == 4) {
      return 0x11;
    }
    if (iVar1 != 0) {
      return 3;
    }
  }
  return 0;
}
