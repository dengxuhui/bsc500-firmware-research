
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016098(void)

{
  ushort uVar1;
  char *pcVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  pcVar2 = (char *)FUN_60164940();
  iVar3 = FUN_60164fe0();
  iVar4 = FUN_60117f68();
  if (iVar4 != 0) {
    FUN_6001c9ec(0);
  }
  iVar4 = FUN_601673b8();
  if ((iVar4 == 0) || (iVar4 = FUN_60117f68(), iVar4 != 0)) {
    _DAT_2000b1f4 = *(int *)(pcVar2 + 0x14);
    _DAT_2000b1f8 = 0;
  }
  else {
    if (*pcVar2 != '\0') {
      if (iVar3 != 0) {
        uVar5 = (*(int *)(pcVar2 + 0x14) - _DAT_2000b1f4) * (*(ushort *)(pcVar2 + 4) / 10) +
                _DAT_2000b1f8;
        uVar1 = *(ushort *)(iVar3 + 0x8ac);
        _DAT_2000b1f4 = *(int *)(pcVar2 + 0x14);
        _DAT_2000b1f8 = uVar5;
        while( true ) {
          if ((uVar5 <= *(uint *)(iVar3 + (uint)uVar1 * 8 + 0xd4)) ||
             (((uint)*(ushort *)(iVar3 + 200) <= (uint)uVar1 &&
              (*(uint *)(iVar3 + (uint)*(ushort *)(iVar3 + 200) * 8 + 0xc4) < uVar5)))) break;
          uVar1 = uVar1 + 1;
          *(ushort *)(iVar3 + 0x8ac) = uVar1;
        }
        FUN_6001c9ec();
        uVar5 = _DAT_2000b1f8;
        uVar1 = *(ushort *)(iVar3 + 0x8ae);
        while ((*(uint *)(iVar3 + (uint)uVar1 * 8 + 0x588) < uVar5 &&
               (((uint)uVar1 < (uint)*(ushort *)(iVar3 + 0x57c) ||
                (uVar5 <= *(uint *)(iVar3 + (uint)*(ushort *)(iVar3 + 0x57c) * 8 + 0x578)))))) {
          uVar1 = uVar1 + 1;
          *(ushort *)(iVar3 + 0x8ae) = uVar1;
        }
      }
      return 0;
    }
    _DAT_2000b1f4 = *(int *)(pcVar2 + 0x14);
  }
  return 0xffffffff;
}
