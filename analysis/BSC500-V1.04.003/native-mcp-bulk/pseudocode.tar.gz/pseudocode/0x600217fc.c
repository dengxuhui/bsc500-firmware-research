
undefined4 FUN_600217fc(void)

{
  return uRam2000a470;
}
