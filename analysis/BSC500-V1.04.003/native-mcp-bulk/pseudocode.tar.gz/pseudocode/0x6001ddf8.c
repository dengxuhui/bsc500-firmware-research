
byte FUN_6001ddf8(byte *param_1,int param_2)

{
  byte bVar1;
  byte *pbVar2;
  
  bVar1 = 0;
  for (pbVar2 = param_1; (int)pbVar2 - (int)param_1 < param_2; pbVar2 = pbVar2 + 1) {
    bVar1 = bVar1 ^ *pbVar2;
  }
  return bVar1;
}
