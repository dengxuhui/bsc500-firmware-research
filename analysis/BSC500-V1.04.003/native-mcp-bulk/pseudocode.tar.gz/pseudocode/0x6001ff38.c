
undefined4 FUN_6001ff38(undefined4 param_1)

{
  switch(param_1) {
  case 0:
  case 1:
  case 2:
  case 3:
  case 4:
    return param_1;
  case 5:
  case 6:
    return 10;
  case 7:
    return 6;
  case 8:
    return 7;
  case 9:
  case 10:
    return 5;
  case 0xb:
    return 8;
  case 0xc:
    return 9;
  default:
    return 0xff;
  }
}
