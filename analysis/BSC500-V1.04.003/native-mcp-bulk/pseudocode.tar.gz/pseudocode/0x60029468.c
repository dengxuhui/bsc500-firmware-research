
void FUN_60029468(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 auStack_78 [16];
  undefined4 local_68;
  undefined4 local_64;
  undefined4 local_60;
  undefined4 uStack_5c;
  undefined4 local_58;
  undefined4 uStack_54;
  undefined1 auStack_4c [12];
  uint uStack_40;
  undefined4 uStack_38;
  undefined3 uStack_34;
  undefined1 uStack_30;
  undefined1 uStack_2f;
  undefined1 uStack_2e;
  undefined1 uStack_2d;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  int iStack_20;
  undefined4 uStack_1c;
  undefined2 *puStack_18;
  undefined4 uStack_14;
  
  local_64 = 0;
  local_68 = 0x1f;
  local_60 = 0;
  uStack_5c = 0;
  local_58 = 0;
  uStack_54 = 0;
  FUN_60161d4c(auStack_78,param_1,param_2);
  iVar1 = FUN_60161d60(auStack_78,&UNK_60278b74,&local_68);
  FUN_60168578("Factory Test: Decode status: %d\n",iVar1);
  if ((iVar1 != 0) && (local_68._1_1_ == '\x01')) {
    switch(local_68 >> 0x18) {
    case 1:
      uStack_34 = 0;
      puStack_18 = (undefined2 *)0x0;
      uStack_14 = 0;
      uStack_38 = 0;
      uStack_30 = 0x1f;
      uStack_2f = 0;
      uStack_2e = 0;
      uStack_2d = 0;
      uStack_2c = 0;
      uStack_28 = 0;
      uStack_24 = 0;
      iStack_20 = 0;
      uStack_1c = 0;
      iVar1 = FUN_6013a780(&uStack_14,&puStack_18,0x9e);
      if (iVar1 == 0) {
        uStack_24 = func_0x60125834();
        uStack_1c = CONCAT31(uStack_34,uStack_38._3_1_);
        uStack_28 = 0x6004b1cb;
        uStack_2d = 1;
        uStack_2c = CONCAT31(uStack_2c._1_3_,1);
        uStack_30 = 0x1f;
        uStack_2f = 1;
        iStack_20 = uStack_38 << 8;
        FUN_601648d4(auStack_4c,uStack_14,0x4b0);
        FUN_60164868(auStack_4c,&UNK_60278b74,&uStack_30);
        *puStack_18 = (short)uStack_40;
        FUN_6012374c();
        uVar2 = FUN_6015f2e8(uStack_14,*puStack_18);
        FUN_6013a800(uStack_30,uStack_2f,uStack_2d,0,uStack_40 & 0xffff,uVar2);
      }
      FUN_60168578("Factory Test: SN send triggered\n");
      break;
    case 2:
    case 4:
      FUN_60153cb0(0x26);
      break;
    case 3:
      FUN_60153c10();
      break;
    default:
      goto LAB_6002957c;
    }
    FUN_60127660(local_68 & 0xff,local_68._1_1_,local_68._3_1_,0);
  }
LAB_6002957c:
  return;
}
