
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6001ddd0(void)

{
  return (_DAT_2000a5ac & 3) >> 1;
}
