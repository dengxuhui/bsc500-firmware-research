
int FUN_600376f6(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  undefined2 *puVar2;
  int local_1c;
  
  local_1c = 0;
  if ((param_1 == 0) || (param_4 == (uint *)0x0)) {
    return 0xe;
  }
  if (7 < *param_4) {
    *param_4 = *param_4 - 8;
    *param_3 = 0x71;
    puVar2 = param_3;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 2,param_3);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 3,puVar2);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fbe(param_1,param_2,&local_1c,param_3 + 4);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 5,puVar2);
    if (iVar1 != 0) {
      return iVar1;
    }
    if (local_1c == param_2) {
      *param_4 = 8;
      return 0;
    }
  }
  return 9;
}
