
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60025e6c */
/* WARNING: Restarted to delay deadcode elimination for space: register */

uint FUN_60025ae0(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint *param_6)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  ushort uVar5;
  uint uVar6;
  uint uVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  uint uVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  uint uVar20;
  undefined4 *puVar21;
  uint uVar22;
  undefined4 uVar23;
  int iVar24;
  int iVar25;
  int iVar26;
  int iVar27;
  uint uVar28;
  uint uVar29;
  int iVar30;
  undefined4 uVar31;
  undefined8 in_d0;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  undefined4 extraout_s1_05;
  undefined4 extraout_s1_06;
  undefined8 uVar32;
  undefined8 uVar33;
  undefined8 uVar34;
  undefined8 uVar35;
  uint local_8c;
  uint local_6c;
  
  uVar23 = (undefined4)((ulonglong)in_d0 >> 0x20);
  uVar32 = FUN_601678fc();
  uVar8 = FUN_601682c8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3fe00000);
  uVar8 = FUN_60137818(uVar8);
  uVar9 = FUN_60167a50(uVar8,extraout_s1);
  uVar32 = FUN_601678fc();
  uVar8 = FUN_601682c8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3fe00000);
  uVar8 = FUN_60137818(uVar8);
  uVar10 = FUN_60167a50(uVar8,extraout_s1_00);
  iVar11 = (uVar10 >> 0x10) - (uint)*(ushort *)(param_1 + 0xe);
  uVar1 = *(ushort *)(param_1 + 0xc);
  uVar8 = FUN_60133450(param_4);
  uVar31 = FUN_60133498(param_4);
  uVar32 = FUN_60165558((int)in_d0,uVar23,uVar8,extraout_s1_01);
  uVar33 = FUN_601682c8(uVar8,extraout_s1_01,(int)in_d0,uVar23);
  uVar34 = FUN_60165558();
  uVar35 = FUN_601682c8(uVar31,extraout_s1_02);
  uVar32 = FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x41900000);
  uVar8 = FUN_601682c8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3fe00000);
  uVar8 = FUN_60137818(uVar8);
  uVar10 = FUN_60167a50(uVar8,extraout_s1_03);
  uVar32 = FUN_601678fc((int)uVar33,(int)((ulonglong)uVar33 >> 0x20),0,0x41900000);
  uVar8 = FUN_601682c8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3fe00000);
  uVar8 = FUN_60137818(uVar8);
  uVar12 = FUN_60167a50(uVar8,extraout_s1_04);
  uVar32 = FUN_601678fc((int)uVar34,(int)((ulonglong)uVar34 >> 0x20),0,0x41900000);
  uVar8 = FUN_601682c8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3fe00000);
  uVar8 = FUN_60137818(uVar8);
  uVar13 = FUN_60167a50(uVar8,extraout_s1_05);
  iVar14 = (int)(short)iVar11;
  iVar15 = (uVar9 >> 0x10) - (uint)uVar1;
  iVar16 = (int)(short)iVar15;
  uVar1 = (short)(uVar12 >> 0x10) - *(short *)(param_1 + 0xc);
  uVar5 = (short)(uVar10 >> 0x10) - *(short *)(param_1 + 0xc);
  uVar32 = FUN_601678fc((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),0,0x41900000);
  uVar8 = FUN_601682c8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3fe00000);
  uVar8 = FUN_60137818(uVar8);
  uVar9 = FUN_60167a50(uVar8,extraout_s1_06);
  iVar30 = 0;
  uVar3 = (short)(uVar9 >> 0x10) - *(short *)(param_1 + 0xe);
  uVar4 = (short)(uVar13 >> 0x10) - *(short *)(param_1 + 0xe);
  local_8c = 0xffffffff;
  local_6c = 0x7ffffff;
  do {
    iVar25 = 0;
    uVar17 = iVar11 - iVar30;
    for (uVar28 = iVar15 - iVar30; iVar26 = (int)(short)uVar28, iVar26 <= iVar16 + iVar30;
        uVar28 = uVar28 + 1) {
      if ((((-1 < iVar26) && (iVar26 <= (short)uVar1)) && ((short)uVar5 <= iVar26)) &&
         (iVar26 < *(short *)(param_1 + 8))) {
        iVar27 = iVar26 - iVar16;
        uVar29 = uVar17;
        if (iVar27 < 0) {
          iVar27 = -iVar27;
        }
        while( true ) {
          iVar24 = (int)(short)uVar29;
          if (iVar30 + iVar14 < iVar24) break;
          if (((-1 < iVar24) && (iVar24 <= (short)uVar3)) &&
             (((short)uVar4 <= iVar24 && (iVar24 < *(short *)(param_1 + 10))))) {
            if (iVar27 < iVar30) {
              iVar18 = iVar24 - iVar14;
              if (iVar18 < 0) {
                iVar18 = -iVar18;
              }
              if (iVar18 < iVar30) goto LAB_60025ec6;
            }
            iVar18 = (int)*(short *)(param_1 + 8) * (int)(short)uVar29 + iVar26;
            uVar19 = FUN_60133560(param_1,iVar18);
            uVar20 = FUN_60133560(param_1,iVar18 + 1);
            for (; uVar19 < uVar20; uVar19 = uVar19 + 1) {
              puVar21 = (undefined4 *)FUN_6012ece8(param_1,uVar19,3);
              uVar6 = local_8c;
              uVar7 = local_6c;
              if (((((uVar28 & 0xffff) != (uint)uVar5) ||
                   ((uVar10 & 0xffff) <= (uint)*(ushort *)(puVar21 + 1))) &&
                  ((((uVar28 & 0xffff) != (uint)uVar1 ||
                    ((uint)*(ushort *)(puVar21 + 1) <= (uVar12 & 0xffff))) &&
                   (((uVar29 & 0xffff) != (uint)uVar4 ||
                    ((uVar13 & 0xffff) <= (uint)*(ushort *)((int)puVar21 + 6))))))) &&
                 ((uVar2 = *(ushort *)((int)puVar21 + 6), (uVar29 & 0xffff) != (uint)uVar3 ||
                  ((uint)uVar2 <= (uVar9 & 0xffff))))) {
                uVar32 = FUN_6016759c((uint)*(ushort *)(puVar21 + 1) |
                                      ((uint)*(ushort *)(param_1 + 0xc) + iVar26) * 0x10000);
                uVar8 = FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3e500000);
                uVar32 = FUN_6016759c((uint)uVar2 |
                                      ((uint)*(ushort *)(param_1 + 0xe) + iVar24) * 0x10000);
                uVar23 = FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x3e500000);
                uVar22 = FUN_601335f0(uVar8,extraout_s1_06,uVar23);
                if (uVar22 < local_6c) {
                  iVar18 = FUN_6011fdbe(param_2,*puVar21,1);
                  do {
                    uVar6 = uVar19;
                    uVar7 = uVar22;
                    if ((int)((uint)*(byte *)(iVar18 + 0x13) << 0x1c) < 0) break;
                    iVar18 = FUN_600354ec(param_2,iVar18,uVar19);
                    uVar6 = local_8c;
                    uVar7 = local_6c;
                  } while (iVar18 != 0);
                }
              }
              local_6c = uVar7;
              local_8c = uVar6;
            }
            iVar25 = iVar25 + 1;
          }
LAB_60025ec6:
          uVar29 = uVar29 + 1;
        }
      }
    }
    iVar30 = iVar30 + 1;
    if (iVar25 == 0) {
      *param_6 = local_6c;
      return local_8c;
    }
  } while( true );
}
