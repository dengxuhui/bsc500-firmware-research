
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_60023988(void)

{
  return _DAT_2005563c * 0x2000000 + 0x88000000U | _DAT_20055638 << 0x15 | _DAT_20055634 << 0x10 |
         _DAT_20055630 << 0xb | _DAT_2005562c << 5 | _DAT_20055628 >> 1;
}
