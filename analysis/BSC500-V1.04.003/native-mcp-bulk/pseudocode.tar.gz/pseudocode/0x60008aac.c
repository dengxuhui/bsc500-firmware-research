
undefined8 FUN_60008aac(uint param_1,int param_2,int param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  char *pcVar3;
  ushort *puVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  
  if (((DAT_20009a4e == '\0') || (DAT_20009a4d != '\x01')) ||
     (uVar1 = (uint)DAT_20009a50, uVar1 == 0)) {
    uVar1 = 0;
  }
  else {
    iVar2 = param_2;
    if (param_1 == 0) {
      puVar4 = (ushort *)0x2007e98a;
      if (param_2 == 0) {
        puVar4 = (ushort *)0x2007e988;
      }
      uVar1 = (uint)*puVar4;
      pcVar3 = "[BL_ALS] lux=%d, dark=%d, bright=%d (first row)\n";
      param_1 = 0;
    }
    else {
      iVar6 = uVar1 - 1;
      if (param_1 < *(uint *)(iVar6 * 8 + 0x2007e984)) {
        iVar2 = 0;
        for (iVar8 = 0; uVar1 * 8 + -8 != iVar8; iVar8 = iVar8 + 8) {
          uVar7 = *(uint *)(iVar8 + 0x2007e98c);
          if (param_1 < uVar7) {
            iVar6 = 4;
            if (param_2 != 0) {
              iVar6 = 6;
            }
            uVar5 = *(uint *)(iVar8 + 0x2007e984);
            uVar1 = (uint)*(ushort *)(iVar8 + 0x2007e984 + iVar6);
            if (uVar7 == uVar5) {
              pcVar3 = "[BL_ALS] lux=%d, dark=%d, bright=%d (range[%d])\n";
              iVar2 = iVar2 + 1;
            }
            else {
              iVar6 = 0xc;
              if (param_2 != 0) {
                iVar6 = 0xe;
              }
              uVar1 = uVar1 + ((param_1 - uVar5) * (*(ushort *)(iVar8 + 0x2007e984 + iVar6) - uVar1)
                              ) / (uVar7 - uVar5);
              pcVar3 = "[BL_ALS] lux=%d, dark=%d, bright=%d (interp[%d-%d])\n";
              param_3 = iVar2 + 1;
            }
            goto LAB_60008b70;
          }
          iVar2 = iVar2 + 1;
        }
        puVar4 = (ushort *)(iVar6 * 8 + 0x2007e98a);
        if (param_2 == 0) {
          puVar4 = (ushort *)(iVar6 * 8 + 0x2007e988);
        }
        uVar1 = (uint)*puVar4;
        pcVar3 = "[BL_ALS] lux=%d, dark=%d, bright=%d (default)\n";
        iVar2 = param_2;
      }
      else {
        puVar4 = (ushort *)(iVar6 * 8 + 0x2007e98a);
        if (param_2 == 0) {
          puVar4 = (ushort *)(iVar6 * 8 + 0x2007e988);
        }
        uVar1 = (uint)*puVar4;
        pcVar3 = "[BL_ALS] lux=%d, dark=%d, bright=%d (last row)\n";
      }
    }
LAB_60008b70:
    FUN_60168578(pcVar3,param_1,param_2,uVar1,iVar2,param_3,param_4);
    param_2 = iVar2;
  }
  return CONCAT44(param_2,uVar1);
}
