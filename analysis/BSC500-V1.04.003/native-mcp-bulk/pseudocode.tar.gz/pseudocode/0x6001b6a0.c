
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001b6a0(int param_1,int param_2)

{
  undefined1 auStack_2c [12];
  int local_20;
  
  FUN_60163c5c(param_1 + param_2,auStack_2c);
  if (_DAT_2000bc70 != local_20) {
    _DAT_2000bc74 = FUN_60164d88(auStack_2c);
    _DAT_2000bc70 = local_20;
  }
  return _DAT_2000bc74;
}
