
bool FUN_60035c50(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  undefined4 local_34;
  uint uStack_30;
  undefined4 local_2c;
  int iStack_28;
  
  bVar3 = 0;
  uVar5 = 1;
  do {
    if (9 < uVar5) {
      return bVar3 != 0;
    }
    if (uVar5 == 5) goto LAB_60035d66;
    uStack_30 = 0;
    local_2c = 0;
    iStack_28 = 0;
    local_34._0_2_ = CONCAT11((char)uVar5,1);
    local_34 = CONCAT22(1,(undefined2)local_34);
    switch(uVar5 & 0x7f) {
    case 1:
      iVar4 = 0x45d6;
      goto code_r0x60035ce0;
    case 2:
      iVar4 = 0x45d4;
code_r0x60035ce0:
      if (*(short *)(&DAT_2004bb98 + iVar4 + (uint)bRam20009dc2 * 0x14) == 0x7fff) {
code_r0x60035d4e:
        uStack_30 = 0;
      }
      else {
        local_2c = 1;
        iStack_28 = (int)*(short *)(&DAT_2004bb98 + iVar4 + (uint)bRam20009dc2 * 0x14);
code_r0x60035d24:
        uStack_30 = 1;
      }
      break;
    case 3:
      uStack_30 = DAT_2004c73c & 1;
      break;
    case 4:
      uStack_30 = (DAT_2004c73c & 3) >> 1;
      break;
    case 6:
      if ((*(ushort *)((uint)bRam20009dc2 * 0x14 + 0x20050170) & 0x3f) == 0) goto code_r0x60035d24;
      goto code_r0x60035d4e;
    case 7:
      if (-1 < (int)((uint)DAT_2004c73c << 0x1d)) goto code_r0x60035d4e;
      goto code_r0x60035d24;
    case 8:
      cVar1 = *(char *)((short)(ushort)bRam20009dc2 * 0x5a4 + 0x2004ce98);
      if (cVar1 == '\0') goto code_r0x60035d4e;
      if (cVar1 == '\n') {
        uStack_30 = 2;
      }
      else if (cVar1 == '\x0f') {
        uStack_30 = 3;
      }
      else if (cVar1 == -1) {
        uStack_30 = 4;
      }
    }
    bVar2 = FUN_6012b8c0(param_1,param_2);
    bVar3 = FUN_6012cc1c(param_1,&UNK_602a6230,&local_34);
    bVar3 = bVar3 & bVar2;
LAB_60035d66:
    uVar5 = uVar5 + 1;
  } while( true );
}
