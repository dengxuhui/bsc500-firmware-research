
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600182e4(void)

{
  return _DAT_2000ca8c;
}
