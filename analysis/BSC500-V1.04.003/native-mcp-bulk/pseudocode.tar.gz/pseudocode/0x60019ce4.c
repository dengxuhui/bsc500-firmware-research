
undefined4 FUN_60019ce4(char *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  char *local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 uStack_14;
  
  local_20 = param_1;
  local_1c = param_2;
  local_18 = param_3;
  uStack_14 = param_4;
  if (iRam2000b53c == 0) {
    local_18 = 0;
    uStack_14 = 0;
    local_1c = 1;
    local_20 = "sensor";
    iRam2000b53c = FUN_60168494(&local_20);
  }
  FUN_6016825e(iRam2000b53c,0xffffffff);
  puVar1 = (undefined4 *)0x2000b540;
  do {
    puVar1 = (undefined4 *)*puVar1;
    if (puVar1 == (undefined4 *)0x0) {
LAB_60019d3a:
      uVar2 = 1;
LAB_60019d3c:
      if (iRam2000b53c != 0) {
        FUN_601682ae();
      }
      return uVar2;
    }
    if ((char *)*puVar1 == param_1) {
      if ((((puVar1[1] != 0) && ((float)puVar1[8] != 0.0)) && (*(char *)(puVar1 + 9) != '\0')) &&
         (*(char *)(puVar1 + 6) == '\0')) {
        FUN_60163840(puVar1[7]);
        uVar2 = VectorFloatToUnsigned(1000.0 / (float)puVar1[8],3);
        uVar2 = FUN_6016507e(puVar1[7],uVar2,puVar1);
        goto LAB_60019d3c;
      }
      goto LAB_60019d3a;
    }
    puVar1 = puVar1 + 0xc;
  } while( true );
}
