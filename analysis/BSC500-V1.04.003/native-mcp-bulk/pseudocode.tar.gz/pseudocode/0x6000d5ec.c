
void FUN_6000d5ec(void)

{
  int iVar1;
  undefined4 uVar2;
  uint uVar3;
  undefined2 local_2e;
  undefined1 auStack_2c [20];
  
  uVar3 = 0;
  while( true ) {
    iVar1 = FUN_6013f31e(&UNK_6043e960);
    if (3 < uVar3) {
      return;
    }
    if (iVar1 != 0) break;
    ZeroBytes(auStack_2c,0x14);
    iVar1 = FUN_60161fcc(&UNK_6043e960,auStack_2c,0);
    if (iVar1 == 0) {
      local_2e = 0x14;
      uVar2 = FUN_600563c8(auStack_2c);
      iVar1 = FUN_6012ea18(auStack_2c,&local_2e,uVar2);
      if (iVar1 != 0) {
        FUN_6015e16c(&UNK_6043e960,auStack_2c);
        return;
      }
      uVar3 = uVar3 + 1;
    }
  }
  return;
}
