
void FUN_6000fb80(void)

{
  FUN_60161424("ble_deal:%d, %d\n",DAT_20009d48,DAT_20009d49);
  return;
}
