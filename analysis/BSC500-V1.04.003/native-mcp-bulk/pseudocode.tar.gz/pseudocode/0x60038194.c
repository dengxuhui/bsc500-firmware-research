
void FUN_60038194(void)

{
  ZeroBytes(0x2008b548,0x418);
  return;
}
