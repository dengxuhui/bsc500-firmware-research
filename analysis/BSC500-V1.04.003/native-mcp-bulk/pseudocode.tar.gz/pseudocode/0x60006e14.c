
void FUN_60006e14(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_60010bac();
  puVar1[0x1a] = 0;
  puVar1[0x1b] = 0;
  *puVar1 = &UNK_602978f4;
  return;
}
