
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60016db4(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6)

{
  *param_1 = _DAT_20055618;
  *param_2 = _DAT_20055614;
  *param_3 = _DAT_20055610;
  *param_4 = _DAT_2005560c;
  *param_5 = _DAT_20055608;
  *param_6 = _DAT_20055604;
  return;
}
