
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60006ec0(int param_1,int param_2,int param_3)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  bool bVar6;
  undefined4 local_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  
  if (_DAT_2000b5e4 == 0) {
    FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
                 "mMessageMutex && \"message not init \"","_registerTaskInner",0x75);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar2 = FUN_6015cb64();
  if (iVar2 != param_1) {
    FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
                 "(taskId == currentTaskId) && \"registerTaskWithSender must called in same task id task\""
                 ,"_registerTaskInner",0x7c);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar2 = FUN_6016825e(_DAT_2000b5e4,5000);
  if (iVar2 == 0) {
    bVar1 = false;
    bVar6 = false;
    local_2c = 0;
    uStack_28 = 0;
    local_34 = 0;
    uStack_30 = 0;
    for (iVar2 = 0; iVar2 != 4; iVar2 = iVar2 + 1) {
      piVar4 = *(int **)(iVar2 * 4 + 0x2000b5e8);
      if (piVar4 == (int *)0x0 && !bVar6) {
        local_34 = FUN_6013a3fc(param_1);
        piVar4 = (int *)FUN_60161f90(0x14,10);
        *piVar4 = param_1;
        piVar4[1] = param_2;
        iVar5 = FUN_60168494(&local_34);
        piVar4[2] = iVar5;
        piVar4[3] = param_3;
        piVar4[4] = 0;
        *(int **)(iVar2 * 4 + 0x2000b5e8) = piVar4;
        bVar6 = true;
      }
      else if ((piVar4 != (int *)0x0) && (bVar6)) {
        bVar1 = (bool)(bVar1 | *piVar4 == param_1);
      }
    }
    FUN_601682ae(_DAT_2000b5e4);
    if (bVar1) {
      FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.","!repeat && \"reapt\"",
                   "_registerTaskInner",0x98);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    if (!bVar6) {
      FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
                   "find && \"register overflow\"","_registerTaskInner",0x99);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    uVar3 = 1;
  }
  else {
    FUN_60167f3c(3,"MSG_SVC",1,"acquire mutex failed %s","_registerTaskInner");
    uVar3 = 0;
  }
  return uVar3;
}
