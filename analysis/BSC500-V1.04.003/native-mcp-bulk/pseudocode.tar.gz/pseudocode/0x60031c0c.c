
void FUN_60031c0c(undefined1 param_1)

{
  uRam2008b54a = param_1;
  return;
}
