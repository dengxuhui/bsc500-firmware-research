
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60015a2c(undefined4 param_1,ushort *param_2,undefined4 *param_3,undefined4 *param_4,
                int param_5)

{
  bool bVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  undefined1 auStack_48 [36];
  
  iVar3 = thunk_FUN_60162e34(100);
  FUN_60167214(iVar3,100);
  *param_2 = 0;
  iVar4 = FUN_6015c8a2(0x20080878,param_1);
  if (iVar4 == 0) {
    while (*param_2 < 499) {
      iVar4 = FUN_6015c834(0x20080878,0x200828ac);
      uVar2 = uRam200828ac;
      if (iVar4 != 0) goto LAB_60015a58;
      if (cRam200828c2 != '.') {
        iVar4 = 0;
        if (cRam200828c2 == '\0') goto LAB_60015a58;
        iVar4 = FUN_6001cc80(uRam200828ac);
        if (iVar4 == 0) {
          if (param_5 != 0) {
            FUN_601681f4(iVar3,"%s/%s",param_1,0x200828c2);
            FUN_6015c57c(iVar3);
          }
        }
        else {
          FUN_60167214(iVar3,100);
          uVar5 = FUN_60163b68(iVar3,0x200828c2,100);
          iVar4 = FUN_60023a2c(uVar5,auStack_48);
          if (iVar4 != 0) {
            if (*param_2 < 199) {
              uVar5 = FUN_60164ff4(auStack_48);
              uVar6 = (uint)*param_2;
              param_3[uVar6] = uVar5;
              if (param_4 != (undefined4 *)0x0) {
                param_4[uVar6] = uVar2;
              }
              FUN_60023a7c(param_3,param_4,uVar6 + 1 & 0xffff);
              *param_2 = *param_2 + 1;
            }
            else {
              if (*param_2 == 199) {
                FUN_6015d9f4(param_3 + 1,param_3,0x31c);
                FUN_6015d9f4(param_4 + 1,param_4,0x31c);
              }
              *param_2 = 200;
              uVar5 = FUN_60164ff4(auStack_48);
              *param_3 = uVar5;
              if (param_4 != (undefined4 *)0x0) {
                *param_4 = uVar2;
              }
              FUN_60023b18(param_3,param_4,200);
            }
          }
        }
      }
    }
    iVar4 = 0;
  }
LAB_60015a58:
  if (iVar3 == 0) {
    if ((_DAT_e000edf0 & 1) != 0) {
      software_bkpt(0);
    }
    bVar1 = (bool)isCurrentModePrivileged();
    if (bVar1) {
      isIRQinterruptsEnabled();
    }
    disableIRQinterrupts();
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&DAT_60434315,"exf_scan_activity_filename_sorted_oldest",0x2ba);
  }
  thunk_FUN_60166c0c(iVar3);
  return iVar4;
}
