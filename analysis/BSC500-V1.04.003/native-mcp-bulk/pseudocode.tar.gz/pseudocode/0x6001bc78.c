
void FUN_6001bc78(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 local_c;
  
  local_c = param_4;
  iVar1 = FUN_60161d80(9,2,param_3,param_4,param_3);
  local_c = CONCAT22(local_c._2_2_,param_1);
  if (iVar1 != 0) {
    FUN_6002643a(0x200789c0,&local_c);
  }
  return;
}
