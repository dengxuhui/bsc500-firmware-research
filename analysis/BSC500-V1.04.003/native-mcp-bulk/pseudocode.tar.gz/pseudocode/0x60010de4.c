
void FUN_60010de4(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  ushort *puVar1;
  undefined1 uVar2;
  undefined1 uVar3;
  byte bVar4;
  char cVar5;
  byte bVar6;
  undefined1 uVar7;
  undefined2 uVar8;
  byte bVar9;
  undefined1 uVar10;
  ushort uVar11;
  undefined4 uVar12;
  uint uVar13;
  byte bVar14;
  undefined4 uVar15;
  byte *pbVar16;
  int iVar17;
  bool bVar18;
  
  FUN_6001e1c0(param_2 + 8,param_1 + 0xec,0x2000a488,param_4,param_4);
  *(undefined1 *)(param_1 + 0xed) = *(undefined1 *)(param_2 + 8);
  puVar1 = (ushort *)(param_2 + 0x14);
  uVar11 = *puVar1;
  uVar7 = *(undefined1 *)(param_2 + 0xe);
  uVar10 = *(undefined1 *)(param_2 + 0x1a);
  uVar2 = *(undefined1 *)(param_2 + 0x1c);
  *(undefined1 *)(param_1 + 0xd8) = *(undefined1 *)(param_2 + 2);
  uVar3 = *(undefined1 *)(param_2 + 0x1e);
  *(undefined1 *)(param_1 + 0xee) = uVar7;
  uVar7 = *(undefined1 *)(param_2 + 0xb7);
  *(undefined1 *)(param_1 + 0xef) = uVar10;
  *(undefined1 *)(param_1 + 0xf9) = uVar2;
  *(undefined1 *)(param_1 + 0xfb) = uVar3;
  *(undefined1 *)(param_1 + 0xf0) = uVar7;
  if ((ushort)(uVar11 - 3000) < 0xf447) {
    if (uVar11 < 0xbb9) goto LAB_60010e70;
    uVar11 = 0xffff;
    *(undefined2 *)(param_1 + 0xf2) = 0xffff;
  }
  else {
    FUN_6001e208(puVar1,param_1 + 0xf2,0x2000a48c);
    uVar11 = *puVar1;
  }
  *(ushort *)(param_1 + 0xf4) = uVar11;
LAB_60010e70:
  uVar11 = *(ushort *)(param_2 + 0xa6);
  if ((0xf446 < (ushort)(uVar11 - 3000)) || (bVar18 = 3000 < uVar11, uVar11 = 0xffff, bVar18)) {
    *(ushort *)(param_1 + 0xf6) = uVar11;
  }
  uVar15 = *(undefined4 *)(param_2 + 0x16);
  uVar12 = *(undefined4 *)(param_2 + 4);
  iVar17 = 0;
  *(undefined4 *)(param_1 + 0xe0) = *(undefined4 *)(param_2 + 10);
  *(undefined4 *)(param_1 + 0xe4) = uVar15;
  *(undefined2 *)(param_2 + 6) = 0;
  *(undefined1 *)(param_1 + 0xf8) = *(undefined1 *)(param_2 + 0x1b);
  *(undefined1 *)(param_1 + 0xfc) = *(undefined1 *)(param_2 + 0x1f);
  uVar10 = *(undefined1 *)(param_2 + 0x1d);
  *(undefined4 *)(param_1 + 0xdc) = uVar12;
  *(undefined2 *)(param_2 + 0x18) = 0;
  *(undefined2 *)(param_2 + 0xc) = 0;
  uVar8 = *(undefined2 *)(param_2 + 0xa8);
  *(undefined1 *)(param_1 + 0xfa) = uVar10;
  *(undefined2 *)(param_1 + 0xe8) = uVar8;
  *(undefined2 *)(param_1 + 0xea) = *(undefined2 *)(param_2 + 0x432);
  *(undefined2 *)(param_1 + 0x114) = *(undefined2 *)(param_2 + 0x44c);
  *(undefined2 *)(param_1 + 0x116) = *(undefined2 *)(param_2 + 0x44a);
  FUN_6001b988(param_1);
  *(undefined2 *)(param_1 + 0xfd) = *(undefined2 *)(param_2 + 0x54);
  bVar9 = *(byte *)(param_2 + 0x65);
  cVar5 = *(char *)(param_2 + 0x67);
  bVar14 = *(byte *)(param_2 + 0x68);
  bVar6 = *(byte *)(param_2 + 0x66);
  *(undefined1 *)(param_1 + 0xff) = *(undefined1 *)(param_2 + 0x60);
  *(undefined1 *)(param_1 + 0x100) = *(undefined1 *)(param_2 + 0x61);
  *(undefined1 *)(param_1 + 0x101) = *(undefined1 *)(param_2 + 0x62);
  uVar10 = *(undefined1 *)(param_2 + 99);
  *(byte *)(param_1 + 0x105) = bVar6;
  *(byte *)(param_1 + 0x106) = bVar6;
  *(byte *)(param_1 + 0x104) = bVar14 | cVar5 << 5;
  *(undefined1 *)(param_1 + 0x102) = uVar10;
  bVar14 = 0xff;
  *(byte *)(param_1 + 0x103) = bVar9 | *(char *)(param_2 + 100) << 5;
  do {
    pbVar16 = (byte *)(param_2 + 0x98);
    switch(iVar17) {
    case 0:
      break;
    case 1:
      pbVar16 = (byte *)(param_2 + 0x9b);
      break;
    case 2:
      pbVar16 = (byte *)(param_2 + 0x9e);
      break;
    case 3:
      pbVar16 = (byte *)(param_2 + 0xa1);
      break;
    case 4:
      bVar9 = bVar14;
      if (bVar6 < bVar14) {
        bVar9 = bVar6;
      }
      if (99 < bVar6) {
        bVar9 = bVar14;
      }
      *(byte *)(param_2 + 0x462) = bVar9;
      cVar5 = *(char *)(param_2 + 0x69);
      if (cVar5 == '\0') {
        uVar10 = 0;
      }
      else if (cVar5 == '\x03') {
        uVar10 = 1;
      }
      else if (cVar5 == '\x04') {
        uVar10 = 2;
      }
      else {
        uVar10 = 0xff;
      }
      *(undefined1 *)(param_1 + 0x109) = uVar10;
      *(undefined2 *)(param_1 + 0x10a) = 0xffff;
      uVar13 = *(uint *)(param_2 + 0x420);
      if (uVar13 != 0xffffffff) {
        if ((int)(uVar13 << 0xe) < 0) {
          *(byte *)(param_1 + 0x10a) =
               (byte)((uVar13 << 7) >> 0x1c) + ((byte)(uVar13 >> 0xf) & 0x30);
          uVar13 = *(uint *)(param_2 + 0x420);
        }
        if (uVar13 >> 0x19 != 0x7f) {
          *(byte *)(param_1 + 0x10b) = (byte)(uVar13 >> 0x19);
        }
      }
      *(undefined2 *)(param_1 + 0x110) = 0xffff;
      *(undefined2 *)(param_1 + 0x10e) = 0xffff;
      uVar13 = (uint)*(byte *)(param_2 + 0x42c);
      if (uVar13 != 0xff) {
        if ((uVar13 & 0x3f) >> 3 != 0) {
          *(ushort *)(param_1 + 0x10e) =
               (ushort)((uVar13 << 0x1a) >> 0x1d) |
               (ushort)((*(uint *)(param_2 + 0x420) & 0x1c0) << 2);
          uVar13 = (uint)*(byte *)(param_2 + 0x42c);
        }
        if ((uVar13 & 7) != 0) {
          *(ushort *)(param_1 + 0x110) =
               (short)(uVar13 & 7) + ((ushort)(*(uint *)(param_2 + 0x420) >> 1) & 0x700);
        }
      }
      *(undefined2 *)(param_1 + 0x10c) = *(undefined2 *)(param_2 + 0x438);
      *(undefined2 *)(param_1 + 0x112) = *(undefined2 *)(param_2 + 0x42e);
      return;
    default:
      goto LAB_60010f9c;
    }
    bVar9 = *pbVar16;
    if ((bVar9 | 2) == 3) {
      *(byte *)(param_1 + 0x107) = pbVar16[2];
    }
    bVar4 = pbVar16[2];
    if ((bVar9 & 0xfe) == 2) {
      *(byte *)(param_1 + 0x108) = bVar4;
    }
    if (((byte)(bVar4 - 1) < 3) && (bVar9 = bVar4 * '(' - 0x14, bVar9 < bVar14)) {
      bVar14 = bVar9;
    }
LAB_60010f9c:
    iVar17 = iVar17 + 1;
  } while( true );
}
