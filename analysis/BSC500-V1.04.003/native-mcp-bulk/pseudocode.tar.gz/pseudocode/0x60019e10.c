
undefined1 FUN_60019e10(void)

{
  return DAT_2008ddbf;
}
