
undefined4 FUN_60020122(int param_1,undefined1 *param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  undefined4 uStack_28;
  
  if (param_1 == 0 || param_2 == (undefined1 *)0x0) {
    return 0xffffffff;
  }
  uStack_28 = param_4;
  FUN_6003029e(param_1,*param_2);
  iVar4 = 0;
  iVar6 = (int)&uStack_28 + 3;
  do {
    if (iVar4 == 0x30) {
      return 0;
    }
    iVar3 = param_1 + iVar4;
    uVar1 = *(uint *)(param_1 + 8);
    uVar5 = *(uint *)(iVar3 + 0x10);
    *(undefined1 *)(iVar3 + 0x1c) = 0xff;
    if ((uVar5 < uVar1) && (uVar1 = *(uint *)(param_1 + 4), uVar1 != 0)) {
      uStack_28 = CONCAT13(0xff,(undefined3)uStack_28);
      if (uVar5 < uVar1) {
        FUN_6003db8a(param_1,uVar5 + 1,iVar6);
        if (uStack_28 >> 0x18 != 0xff) {
          *(uint *)(iVar3 + 0x14) = *(int *)(iVar3 + 0x14) - (uStack_28 >> 0x18);
          *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + -1;
        }
        FUN_600302ce(param_1,iVar6);
        uVar2 = uStack_28 >> 0x18;
      }
      else {
        FUN_600302ce(param_1,iVar6);
        uVar2 = uStack_28 >> 0x18;
        if (uVar1 != uVar5) {
          if (uVar2 != 0xff) {
            *(uint *)(iVar3 + 0x14) = uVar2 + *(int *)(iVar3 + 0x14);
            *(int *)(iVar3 + 0x18) = *(int *)(iVar3 + 0x18) + 1;
          }
          goto LAB_600201ec;
        }
      }
      if (uVar2 == 0xff) {
        uVar1 = *(uint *)(iVar3 + 0x18);
      }
      else {
        uVar1 = *(int *)(iVar3 + 0x18) + 1;
        *(uint *)(iVar3 + 0x14) = *(int *)(iVar3 + 0x14) + uVar2;
        *(uint *)(iVar3 + 0x18) = uVar1;
      }
      if ((uint)(*(int *)(iVar3 + 0x10) << 1) / 3 < uVar1) {
        *(char *)(iVar3 + 0x1c) = (char)(*(uint *)(iVar3 + 0x14) / uVar1);
      }
    }
LAB_600201ec:
    iVar4 = iVar4 + 0x10;
  } while( true );
}
