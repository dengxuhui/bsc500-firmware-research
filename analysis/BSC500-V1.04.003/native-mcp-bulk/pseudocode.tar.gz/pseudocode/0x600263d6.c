
undefined4 FUN_600263d6(int param_1,uint param_2,int param_3,uint *param_4)

{
  byte bVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint local_14;
  
  local_14 = 0;
  uVar3 = 0xe;
  if ((param_1 != 0) && (param_4 != (uint *)0x0)) {
    if (param_2 < 2) {
      return 9;
    }
    if (param_3 == 0) {
      return 0xe;
    }
    uVar2 = FUN_60035854(param_1,param_2,&local_14,param_3,param_3);
    uVar3 = 9;
    if ((local_14 == param_2) &&
       (bVar1 = *(byte *)(param_3 + 0x2c), *param_4 = param_2, bVar1 < 0x10)) {
      uVar3 = uVar2;
    }
  }
  return uVar3;
}
