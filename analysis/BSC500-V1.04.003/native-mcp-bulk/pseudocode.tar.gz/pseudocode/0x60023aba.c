
void FUN_60023aba(int param_1,int param_2,int param_3)

{
  ushort uVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  
  iVar4 = param_3 + -1;
  uVar1 = 0;
  do {
    uVar5 = (uint)uVar1;
    if (iVar4 <= (int)uVar5) {
      return;
    }
    iVar2 = *(int *)(param_1 + iVar4 * 4);
    uVar1 = uVar1 + 1;
  } while (iVar2 <= *(int *)(param_1 + uVar5 * 4));
  iVar6 = (param_3 + ~uVar5) * 4;
  FUN_6015d9f4(param_1 + (uVar5 + 1) * 4,param_1 + uVar5 * 4,iVar6);
  *(int *)(param_1 + uVar5 * 4) = iVar2;
  if (param_2 != 0) {
    uVar3 = *(undefined4 *)(param_2 + iVar4 * 4);
    FUN_6015d9f4(param_2 + (uVar5 + 1) * 4,param_2 + uVar5 * 4,iVar6);
    *(undefined4 *)(param_2 + uVar5 * 4) = uVar3;
  }
  return;
}
