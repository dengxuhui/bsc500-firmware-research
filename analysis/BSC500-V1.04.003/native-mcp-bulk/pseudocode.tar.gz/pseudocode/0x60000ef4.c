
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000ef4(uint param_1)

{
  if (param_1 - 3 < 5) {
    _DAT_e000ed0c = _DAT_e000ed0c & 0xf8ff | (param_1 & 7) << 8 | 0x5fa0000;
    return;
  }
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}
