
longlong FUN_60005398(undefined4 param_1,uint param_2)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  
  iVar2 = FUN_60164eb0(2);
  piVar7 = (int *)(iVar2 + 4);
  uVar3 = FUN_6015de24("semaphore",piVar7);
  FUN_60168578("%-*.s v   suspend thread\n",uVar3,"semaphore");
  FUN_6015de60(uVar3);
  FUN_60168578(" --- --------------\n");
  piVar5 = piVar7;
  while (piVar5 = (int *)*piVar5, piVar5 != piVar7) {
    piVar1 = piVar5 + 2;
    piVar6 = (int *)*piVar1;
    param_2 = (uint)*(ushort *)(piVar5 + 4);
    uVar4 = FUN_6015dd58(piVar1);
    if (piVar6 == piVar1) {
      FUN_60168578("%-*.*s %03d %d\n",uVar3,0x10,piVar5 + -5,param_2,uVar4);
    }
    else {
      FUN_60168578("%-*.*s %03d %d:",uVar3,0x10,piVar5 + -5,param_2,uVar4);
      FUN_6015dd6c(piVar1);
      FUN_60168578(&DAT_603f7cc3);
    }
  }
  return (ulonglong)param_2 << 0x20;
}
