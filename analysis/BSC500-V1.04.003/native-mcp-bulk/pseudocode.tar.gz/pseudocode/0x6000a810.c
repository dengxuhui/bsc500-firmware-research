
void FUN_6000a810(void)

{
  code *pcVar1;
  int iVar2;
  
  for (iVar2 = 0; iVar2 != 8; iVar2 = iVar2 + 1) {
    pcVar1 = *(code **)(iVar2 * 4 + 0x20045ef4);
    if (pcVar1 != (code *)0x0) {
      (*pcVar1)();
    }
  }
  return;
}
