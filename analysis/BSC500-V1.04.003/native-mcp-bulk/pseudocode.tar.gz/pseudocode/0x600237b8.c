
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x600238e2 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_600237b8(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  undefined8 in_d7;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined4 local_44;
  
  local_44 = (undefined4)((ulonglong)in_d7 >> 0x20);
  FUN_60032460(&local_44,param_3);
  uVar8 = FUN_60166bb4(local_44);
  uVar1 = FUN_601678fc((int)uVar8,(int)((ulonglong)uVar8 >> 0x20),0xaaaaaaab,0x3f91df46);
  uVar2 = *param_3;
  uVar6 = FUN_6015dac8(uVar1);
  uVar5 = *param_3;
  uVar1 = FUN_6012f7e0(uVar1);
  uVar8 = FUN_60166bb4(uVar5);
  uVar8 = FUN_601678fc(uVar1,extraout_s1_00,(int)uVar8,(int)((ulonglong)uVar8 >> 0x20));
  uVar9 = FUN_60166bb4();
  uVar9 = FUN_601678fc((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0xf8cedada,0xbe97e92f);
  uVar9 = FUN_601682c8((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0xf6fd21ff,0x40377075);
  FUN_601672d4((int)uVar8,(int)((ulonglong)uVar8 >> 0x20));
  uVar8 = FUN_60166bb4();
  uVar5 = (undefined4)((ulonglong)uVar8 >> 0x20);
  FUN_601672d4((int)uVar9,(int)((ulonglong)uVar9 >> 0x20));
  uVar9 = FUN_60166bb4();
  uVar1 = FUN_601678fc((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0xaaaaaaab,0x3f91df46);
  uVar7 = FUN_6012f7e0(uVar1);
  uVar1 = FUN_6015dac8(uVar1);
  FUN_601678fc(uVar1,extraout_s1_02,(int)uVar8,uVar5);
  fVar3 = (float)FUN_601672d4();
  uVar1 = FUN_60166bb4();
  uVar9 = FUN_60166bb4(uVar2);
  FUN_601678fc(uVar6,extraout_s1,(int)uVar9,(int)((ulonglong)uVar9 >> 0x20));
  fVar4 = (float)FUN_601672d4();
  uVar2 = FUN_60166bb4();
  uVar1 = FUN_6015d758(uVar1,extraout_s1_02,uVar2);
  FUN_601678fc(uVar1,extraout_s1_03,0xd03cf26,0x404ca5dc);
  uVar1 = FUN_601672d4();
  *param_1 = uVar1;
  FUN_601678fc(uVar7,extraout_s1_01,(int)uVar8,uVar5);
  FUN_601672d4();
  uVar1 = FUN_60166bb4();
  uVar2 = FUN_60166bb4(fVar3 * fVar3 + fVar4 * fVar4);
  uVar2 = FUN_6015d550(uVar2);
  uVar1 = FUN_6015d758(uVar1,extraout_s1_03,uVar2);
  FUN_601678fc(uVar1,extraout_s1_04,0xd03cf26,0x404ca5dc);
  uVar1 = FUN_601672d4();
  *param_2 = uVar1;
  return;
}
