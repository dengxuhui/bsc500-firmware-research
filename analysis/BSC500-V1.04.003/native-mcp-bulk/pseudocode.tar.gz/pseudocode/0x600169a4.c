
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600169a4(void)

{
  undefined1 auStack_3c [44];
  
  FUN_60163c5c(_DAT_200555fc + iRam20009b48,auStack_3c);
  FUN_60010b28(_DAT_2004c610,_DAT_2004c614,_DAT_2004c60c);
  FUN_60010720(auStack_3c,_DAT_2004c610,_DAT_2004c614,0x20009b40,0x20009b44);
  return;
}
