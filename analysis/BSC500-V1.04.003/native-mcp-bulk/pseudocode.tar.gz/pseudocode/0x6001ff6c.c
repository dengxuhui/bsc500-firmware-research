
int FUN_6001ff6c(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int local_14;
  
  iVar2 = 0;
  local_14 = 0;
  if (param_2 << 0x19 < 0) {
    iVar2 = FUN_6015a168(&local_14,param_1,param_3,param_4,param_3);
    iVar2 = local_14 + iVar2;
  }
  if (param_2 << 0x1a < 0) {
    iVar1 = FUN_6015a168(&local_14,param_1 + iVar2);
    iVar2 = iVar1 + iVar2 + local_14;
  }
  return iVar2;
}
