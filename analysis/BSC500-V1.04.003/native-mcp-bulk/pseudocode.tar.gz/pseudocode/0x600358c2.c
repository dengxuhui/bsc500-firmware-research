
void FUN_600358c2(undefined4 *param_1,ushort *param_2)

{
  ushort uVar1;
  
  *param_1 = 0xffffffff;
  uVar1 = *param_2;
  *(undefined1 *)((int)param_1 + 6) = 0xff;
  *(char *)((int)param_1 + 5) = (char)((uint)uVar1 * 5 >> 7);
  *(char *)(param_1 + 1) = (char)((uint)uVar1 * 5) * '\x02';
  return;
}
