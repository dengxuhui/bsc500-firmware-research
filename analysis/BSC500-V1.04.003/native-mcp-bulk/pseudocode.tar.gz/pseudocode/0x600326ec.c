
void FUN_600326ec(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined1 auStack_68 [16];
  undefined1 auStack_58 [60];
  
  ZeroBytes(auStack_58,0x38);
  uRam20009ff8 = 0;
  if (iRam2000a004 != 0) {
    thunk_FUN_60166c0c();
  }
  _uRam2000a008 = 0;
  uRam2000a000 = 0;
  iRam2000a004 = 0;
  uRam2000a00c = 0;
  puRam2000a010 = &UNK_6004030d;
  puRam2000a014 = auStack_58;
  FUN_60161d4c(auStack_68,param_1,param_2);
  iVar1 = FUN_60161d60(auStack_68,&UNK_60434dc4,0x2000a008);
  if (iVar1 == 0) {
    FUN_60129ec8(_uRam2000a008 & 0xff,0,uRam2000a008._1_1_,0);
  }
  else if (uRam2000a008._1_1_ == '\x01') {
    FUN_60127660(_uRam2000a008 & 0xff,0,1,0);
  }
  return;
}
