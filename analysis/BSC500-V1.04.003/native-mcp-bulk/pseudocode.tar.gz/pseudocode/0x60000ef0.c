
undefined4 FUN_60000ef0(void)

{
  return 0;
}
