
void FUN_6001bc9c(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 local_c;
  
  local_c = param_4;
  iVar1 = FUN_60161d80(9,2,param_3,param_4,param_3);
  local_c = CONCAT31(local_c._1_3_,param_1);
  if (iVar1 != 0) {
    FUN_60026458(0x200789c0,&local_c);
  }
  return;
}
