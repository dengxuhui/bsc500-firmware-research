
void FUN_600378c4(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_60152ec0();
  if (iVar1 != 0) {
    *(undefined4 *)(iVar1 + 0x10) = param_2;
  }
  return;
}
