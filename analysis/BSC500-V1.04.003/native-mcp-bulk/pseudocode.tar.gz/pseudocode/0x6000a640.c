
void FUN_6000a640(void)

{
  FUN_6001928c(0x10015000,&DAT_60e6f710,0x2000);
  thunk_EXT_FUN_00020440(10);
  return;
}
