
int FUN_6001cbf8(undefined4 *param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  
  uVar2 = *param_1;
  iVar1 = FUN_6012cf64(param_1,0,param_3,param_4,param_4);
  if (iVar1 == 0) {
    iVar3 = 0;
    do {
      iVar1 = FUN_601319e8(uVar2,param_1[6]);
      if (iVar1 != 0) break;
      if (*(char *)param_1[7] == -0x1b || *(char *)param_1[7] == '\0') {
        iVar3 = iVar3 + 1;
        if (iVar3 == param_2) {
          return 0;
        }
      }
      else {
        iVar3 = 0;
      }
      iVar1 = FUN_6012b07c(param_1,1);
    } while (iVar1 == 0);
  }
  if (iVar1 == 4) {
    iVar1 = 7;
  }
  return iVar1;
}
