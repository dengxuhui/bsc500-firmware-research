
undefined4 FUN_60019d88(undefined4 param_1,uint param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  char *local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 uStack_18;
  int local_14;
  
  uVar3 = 0;
  local_14 = 0;
  iVar1 = FUN_60010cd0(param_1,&local_14);
  if (iVar1 != 0) {
    if (iRam2000b53c == 0) {
      local_1c = 0;
      uStack_18 = 0;
      local_20 = 1;
      local_24 = "sensor";
      iRam2000b53c = FUN_60168494(&local_24);
    }
    FUN_6016825e(iRam2000b53c,0xffffffff);
    uVar2 = *(uint *)(local_14 + 0x28);
    if (param_3 == 0) {
      if (((uVar2 & param_2) == param_2) && (*(short *)(local_14 + 0x26) != 0)) {
        *(short *)(local_14 + 0x26) = *(short *)(local_14 + 0x26) + -1;
        *(uint *)(local_14 + 0x28) = uVar2 & ~param_2 | 0x40000000;
      }
    }
    else if ((uVar2 & param_2) != param_2) {
      *(uint *)(local_14 + 0x28) = uVar2 | param_2;
      *(short *)(local_14 + 0x26) = *(short *)(local_14 + 0x26) + 1;
    }
    if (iRam2000b53c != 0) {
      FUN_601682ae();
    }
    uVar3 = 1;
  }
  return uVar3;
}
