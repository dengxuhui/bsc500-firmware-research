
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001ac14(void)

{
  char cVar1;
  short sVar2;
  uint uVar3;
  int iVar4;
  char *pcVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  
  iVar4 = FUN_60164e24();
  pcVar5 = (char *)FUN_60164940();
  iVar6 = FUN_601232d4(0);
  uVar7 = FUN_60122010(0);
  iVar8 = FUN_601673b8();
  if ((iVar8 == 0) || (iVar8 = FUN_60117f68(), iVar8 != 0)) {
    _DAT_2000b280 = 0;
    return;
  }
  uVar9 = (uint)DAT_2000b27a;
  if (uVar9 != DAT_2000b278) {
    _DAT_2000b280 = 0;
    DAT_2000b27b = '\0';
    FUN_60168578("%s,last_step_%d,s_cur_step_%d\n","update_duration_param");
    uVar9 = (uint)DAT_2000b278;
    if (uVar9 < DAT_2000b27a) {
      _DAT_2000b280 = 0;
    }
  }
  uVar3 = _DAT_2000b288;
  if (*pcVar5 != '\x01') goto switchD_6001acac_caseD_8;
  uVar9 = FUN_6012e9a0(0);
  if (uVar9 <= uVar3) {
    uVar9 = (uint)DAT_2000b278;
    goto switchD_6001acac_caseD_8;
  }
  if ((_DAT_2008dfdc == 1) && (iVar8 = FUN_6001c4e4(iVar6,pcVar5), iVar8 != 0)) {
    _DAT_2008dfdc = 0;
    _DAT_2000b28c = _DAT_2000b28c + 1;
  }
  uVar9 = (uint)DAT_2000b278;
  switch(*(undefined1 *)(iVar6 + uVar9 * 0x18 + 1)) {
  case 6:
  case 9:
    cVar1 = pcVar5[1];
    break;
  case 7:
  case 10:
    sVar2 = *(short *)(pcVar5 + 6);
    goto LAB_6001acc6;
  default:
    goto switchD_6001acac_caseD_8;
  case 0xb:
    sVar2 = *(short *)(pcVar5 + 4);
LAB_6001acc6:
    if (sVar2 == -1) goto LAB_6001acce;
    goto switchD_6001acac_caseD_8;
  case 0xc:
    cVar1 = pcVar5[2];
  }
  if (cVar1 == -1) {
LAB_6001acce:
    _DAT_2000b288 = _DAT_2000b288 + 1;
  }
switchD_6001acac_caseD_8:
  switch(*(undefined1 *)(iVar6 + uVar9 * 0x18 + 0xc)) {
  case 0:
  case 3:
    if (_DAT_2000b280 == 0) {
      _DAT_2000b280 = *(uint *)(pcVar5 + 0x14);
    }
    if (((*pcVar5 == '\x01') && (*(uint *)(pcVar5 + 0x14) != _DAT_2000b280)) &&
       (iVar8 = FUN_601628cc(), iVar8 == 0)) {
      _DAT_2000b284 = (*(int *)(pcVar5 + 0x14) - _DAT_2000b280) + _DAT_2000b284;
    }
    _DAT_2000b280 = *(uint *)(pcVar5 + 0x14);
    break;
  case 1:
    if (_DAT_2000b280 == 0) {
      _DAT_2000b280 = *(uint *)(pcVar5 + 0xc);
    }
    if (((*pcVar5 == '\x01') && (*(uint *)(pcVar5 + 0xc) != _DAT_2000b280)) &&
       (iVar8 = FUN_601628cc(), iVar8 == 0)) {
      _DAT_2000b284 = (*(int *)(pcVar5 + 0xc) - _DAT_2000b280) + _DAT_2000b284;
    }
    _DAT_2000b280 = *(uint *)(pcVar5 + 0xc);
    break;
  case 2:
    if (_DAT_2000b280 == 0) {
      _DAT_2000b280 = (uint)*(ushort *)(pcVar5 + 8);
    }
    if (((*pcVar5 == '\x01') && (_DAT_2000b280 != *(ushort *)(pcVar5 + 8))) &&
       (iVar8 = FUN_601628cc(), iVar8 == 0)) {
      _DAT_2000b284 = (*(ushort *)(pcVar5 + 8) - _DAT_2000b280) + _DAT_2000b284;
    }
    _DAT_2000b280 = (uint)*(ushort *)(pcVar5 + 8);
  }
  if (_DAT_2000b284 != 0) {
    iVar8 = iVar6 + (uint)DAT_2000b278 * 0x18;
    uVar9 = *(uint *)(iVar8 + 0x10);
    if ((_DAT_2000b284 != uVar9) && (DAT_2000b27b == '\0')) {
      cVar1 = *(char *)(iVar8 + 0xc);
      if (cVar1 == '\x02') {
        if (uVar9 <= _DAT_2000b284 + 1 && 1 < uVar9) goto LAB_6001ae14;
      }
      else if (cVar1 == '\x01') {
        if ((uVar9 * 100 <= _DAT_2000b284 + 0xdac) && (0xdac < uVar9 * 100)) goto LAB_6001ae14;
      }
      else if ((cVar1 == '\0') && ((uVar9 <= _DAT_2000b284 + 4 && (5 < uVar9)))) {
LAB_6001ae14:
        DAT_2000b27b = '\x01';
        if (*(code **)(iVar4 + 0x10) != (code *)0x0) {
          (**(code **)(iVar4 + 0x10))(2);
        }
      }
    }
  }
  uVar9 = (uint)DAT_2000b278;
  DAT_2000b27a = DAT_2000b278;
  iVar4 = FUN_601627c4();
  if (uVar7 <= uVar9) {
    if (iVar4 != 0) {
      return;
    }
    FUN_601630fc();
    return;
  }
  if (iVar4 != 0) {
    return;
  }
  uVar7 = (uint)DAT_2000b278;
  iVar6 = iVar6 + uVar7 * 0x18;
  cVar1 = *(char *)(iVar6 + 0xc);
  uVar9 = *(uint *)(iVar6 + 0x10);
  if (cVar1 == '\x01') {
    uVar3 = uVar9 * 100;
  }
  else {
    uVar3 = uVar9;
    if (cVar1 == '\x03') goto LAB_6001ae48;
  }
  if (uVar3 <= _DAT_2000b284) {
    switch(*(undefined1 *)(iVar6 + 0x24)) {
    case 0:
    case 3:
      _DAT_2000b280 = *(uint *)(pcVar5 + 0x14);
      break;
    case 1:
      _DAT_2000b280 = *(uint *)(pcVar5 + 0xc);
      break;
    case 2:
      _DAT_2000b280 = (uint)*(ushort *)(pcVar5 + 8);
    }
    if (cVar1 == '\x01') {
      uVar9 = uVar9 * 100;
    }
    _DAT_2000b284 = uVar9;
    FUN_601630fc();
    uVar7 = (uint)DAT_2000b278;
  }
LAB_6001ae48:
  FUN_600330c8(uVar7);
  return;
}
