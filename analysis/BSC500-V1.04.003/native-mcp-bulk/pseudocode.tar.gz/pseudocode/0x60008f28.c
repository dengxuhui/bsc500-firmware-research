
undefined4 FUN_60008f28(undefined4 param_1,char *param_2)

{
  thunk_FUN_6001bd1c();
  if (*param_2 == '\x05') {
    cRam2000740c = **(char **)(param_2 + 8);
    if (cRam2000740c == '\0') {
      thunk_FUN_6001bdd0(8);
    }
    else {
      thunk_FUN_6001bd58();
      thunk_FUN_6001bde4(8);
    }
  }
  else if (*param_2 == '\x02') {
    thunk_FUN_6001bd58();
    thunk_FUN_6001be40(*(undefined4 *)(param_2 + 8),*(undefined2 *)(param_2 + 2));
  }
  return 0;
}
