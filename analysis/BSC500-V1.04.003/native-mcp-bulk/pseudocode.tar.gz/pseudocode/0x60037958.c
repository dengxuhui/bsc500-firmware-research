
bool FUN_60037958(void)

{
  int iVar1;
  bool bVar2;
  
  iVar1 = FUN_60154068(0);
  FUN_60167f3c(7,"WATCH_PB",1,"[WATCH_PB] Communication success check\n");
  if (iVar1 == 0) {
    iVar1 = FUN_60154040(0);
    if (iVar1 != 0) {
      FUN_60168578("ble_cyclecomputer_communicated\r\n");
      iVar1 = FUN_6016727c(iVar1,0x2000a2c4,6);
      bVar2 = false;
      if ((iVar1 == 0) && ((char)uRam2000a2cd != '\0')) {
        uRam2000a2d2 = 0;
        uRam2000a2cd = 0x100;
        bVar2 = true;
      }
      return bVar2;
    }
    return false;
  }
  FUN_60168578("[WATCH] Communication success\n");
  iVar1 = FUN_6016727c(iVar1,0x20008418,6);
  if (iVar1 != 0) {
    return false;
  }
  bVar2 = (int)((uint)bRam20008420 << 0x1a) < 0;
  if (bVar2) {
    uRam20008426 = 0;
    bRam20008420 = (bRam20008420 & 0x9f) + 0x40;
  }
  return bVar2;
}
