
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d850(int *param_1,int *param_2)

{
  FUN_600185d0(_DAT_2000b308,&DAT_2000b30c);
  *param_1 = _DAT_2000b30c;
  *param_2 = _DAT_2000b30c - _DAT_2000b314;
  return;
}
