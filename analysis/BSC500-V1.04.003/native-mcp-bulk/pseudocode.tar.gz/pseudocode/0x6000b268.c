
void FUN_6000b268(void)

{
  int iVar1;
  
  if (cRam20009aa3 == '\0' && DAT_20053074 == '\0') {
    cRam20009aa3 = '\x01';
    iVar1 = FUN_6012d794();
    if ((iVar1 == 0) && (cRam20009aa6 == '\0')) {
      FUN_601489b8(0x80000025);
      cRam20009aa6 = 1;
      return;
    }
  }
  else if ((DAT_20053074 != '\0') && (cRam20009aa3 != '\0')) {
    cRam20009aa3 = '\0';
    iVar1 = FUN_6012d794();
    if (iVar1 == 0) {
      thunk_FUN_60059aa8(0x80000026);
      return;
    }
  }
  return;
}
