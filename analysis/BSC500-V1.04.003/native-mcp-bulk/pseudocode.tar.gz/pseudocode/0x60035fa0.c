
void FUN_60035fa0(int param_1)

{
  int iVar1;
  
  if (param_1 != 0) {
    if (*(char *)(param_1 + 7) != '\0') {
      FUN_60167f3c(3,0x603f8fab,1,"receive err response");
      FUN_60154cb4(&LAB_60048e9c_1);
      iVar1 = FUN_60154040(0);
      if (iVar1 != 0) {
        FUN_601540ec();
      }
      iVar1 = FUN_60154068(0);
      if (iVar1 != 0) {
        FUN_60154138(iVar1,1,1);
      }
      FUN_60155e04(4);
    }
    FUN_6015b29c(1);
    return;
  }
  FUN_60167f3c(3,0x603f8fab,1,"status handle receive null data");
  return;
}
