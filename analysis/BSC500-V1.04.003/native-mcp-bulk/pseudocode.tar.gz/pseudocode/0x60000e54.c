
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000e54(void)

{
  longlong lVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined4 uVar5;
  uint uVar6;
  
  uVar5 = 1;
  uVar2 = thunk_EXT_FUN_00021290(1,1);
  if (uVar2 < 0x7270e01) {
    uVar5 = 0;
    uVar6 = (uVar2 * 10 + 500000) / 1000000;
    lVar1 = (ulonglong)uVar6 * 1000000000;
    uVar3 = FUN_60162a88((int)lVar1,(int)((ulonglong)lVar1 >> 0x20),uVar2,0);
    uVar4 = (uint)(uVar3 < 9000);
    if (11000 < uVar3) {
      uVar4 = 0xffffffff;
    }
    _DAT_4000c004 =
         (uVar4 + uVar6) * 0x400 & 0x1ffc00 |
         (uVar2 / 50000000) * 0x80 + 0x80 & 0x380 | uVar2 / 2000000 + 1;
  }
  return uVar5;
}
