
undefined4 FUN_60013394(int param_1)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  undefined2 local_44 [8];
  byte local_34;
  undefined2 local_32;
  undefined4 local_30;
  undefined4 uStack_2c;
  byte local_28;
  undefined4 local_20;
  undefined4 uStack_1c;
  byte local_18;
  
  uVar1 = 0xffffffff;
  if ((param_1 != 0) && (cRam2000abf8 == '\x01')) {
    FUN_60133efe(0x20080250);
    local_20 = 0;
    uStack_1c = 0;
    local_18 = *(byte *)(param_1 + 0x72);
    uVar3 = (uint)local_18;
    for (uVar2 = 0; uVar3 != uVar2; uVar2 = uVar2 + 1) {
      *(undefined1 *)((int)&local_20 + uVar2) = *(undefined1 *)(*(int *)(param_1 + 0x6c) + uVar2);
    }
    FUN_60133f20(0x20080298,&local_20);
    FUN_60133f88(0x200802d8);
    FUN_60133f90(0x200802dc);
    local_30 = 0;
    uStack_2c = 0;
    local_28 = *(byte *)(param_1 + 0x71);
    uVar3 = (uint)local_28;
    for (uVar2 = 0; uVar3 != uVar2; uVar2 = uVar2 + 1) {
      *(undefined1 *)((int)&local_30 + uVar2) = *(undefined1 *)(*(int *)(param_1 + 0x68) + uVar2);
    }
    FUN_60133fa0(0x200802fc,&local_30);
    ZeroBytes(local_44,0x14);
    local_34 = *(byte *)(param_1 + 0x70);
    uVar2 = (uint)local_34;
    for (uVar3 = 0; uVar2 != uVar3; uVar3 = uVar3 + 1) {
      local_44[uVar3] = *(undefined2 *)(*(int *)(param_1 + 100) + uVar3 * 2);
    }
    local_32 = *(undefined2 *)(param_1 + 0x1e);
    FUN_60134004(0x20080338,local_44);
    FUN_601340a4(0x200803a0);
    FUN_601340ac(0x200803a4);
    FUN_601340c6(0x200803bc);
    cRam2000abf8 = '\x02';
    uVar1 = 0;
  }
  return uVar1;
}
