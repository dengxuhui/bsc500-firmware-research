
int FUN_60028fe4(int param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  
  iVar2 = param_2;
  if (param_2 < 0) {
    iVar2 = -param_2;
  }
  iVar2 = FUN_60039bf8(param_1,iVar2);
  iVar3 = iVar2 + -1;
  bVar1 = *(byte *)(param_1 + iVar3);
  if (-1 < (int)((uint)bVar1 << 0x19)) {
    if (-1 < param_2) {
      return iVar2;
    }
    *(byte *)(param_1 + iVar3) = bVar1 | 0x40;
    return iVar2;
  }
  *(byte *)(param_1 + iVar3) = bVar1 | 0x80;
  *(byte *)(param_1 + iVar2) = (byte)((uint)param_2 >> 0x19) & 0x40;
  return iVar2 + 1;
}
