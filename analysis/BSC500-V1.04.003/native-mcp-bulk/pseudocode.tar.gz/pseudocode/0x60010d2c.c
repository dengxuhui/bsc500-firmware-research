
void FUN_60010d2c(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  int unaff_r6;
  undefined4 unaff_r7;
  
  *(undefined4 *)unaff_r7 = unaff_r7;
                    /* WARNING: Subroutine does not return */
  FUN_60154c98(0,param_3 - unaff_r6,param_3,param_4,param_3,param_4);
}
