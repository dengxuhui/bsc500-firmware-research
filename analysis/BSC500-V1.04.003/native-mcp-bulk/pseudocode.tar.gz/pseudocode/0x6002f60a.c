
int FUN_6002f60a(int param_1,int param_2,undefined4 param_3,ushort param_4)

{
  short sVar1;
  uint uVar2;
  undefined4 local_18;
  undefined4 uStack_14;
  
  uStack_14 = (uint)param_4;
  local_18 = 0;
  if ((param_1 == 0) || (uVar2 = FUN_6016506c(param_1), uVar2 <= (uint)(param_2 * 2))) {
    sVar1 = 0x7fff;
  }
  else {
    FUN_60163c98(param_1,param_2 << 1);
    FUN_60161ef4(param_1,(int)&uStack_14 + 2,2,&local_18);
    sVar1 = FUN_6003cfc4((int)&uStack_14 + 2);
  }
  return (int)sVar1;
}
