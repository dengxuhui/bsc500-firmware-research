
void FUN_6000c174(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 in_r3;
  
  iVar2 = iRam200852dc;
  iVar1 = iRam200852d8;
  if (DAT_2000a84a != '\0') {
    uRam2000a7ec = uRam2000a804;
    uRam2000a7f0 = uRam2000a808;
    uRam2000a7f4 = uRam2000a80c;
    uRam2000a7f8 = uRam2000a810;
    iRam2000a7fc = uRam2000a814;
    uRam2000a800 = uRam2000a818;
    return;
  }
  uRam2000a800 = CONCAT31(uRam2000a800._1_3_,cRam200852d4);
  if (((cRam200852d4 != '\0') && (iVar3 = FUN_60166dd0(0x200852c0), iVar3 == 0)) &&
     (iVar3 = FUN_60166dd0(0x200852c8), iVar3 == 0)) {
    uRam2000a7ec = uRam200852c0;
    uRam2000a7f0 = uRam200852c4;
    uRam2000a7f4 = uRam200852c8;
    uRam2000a7f8 = uRam200852cc;
    uRam2004c6d0 = uRam200852c0;
    uRam2004c6d4 = uRam200852c8;
    if (iRam200852d0 != 0x7fff) {
      iRam2000a7fc = iRam200852d0;
    }
    return;
  }
  if (iVar1 == 0x7fffffff || iVar2 == 0x7fffffff) {
    return;
  }
  FUN_60162cb0(0x2000a7ec,iVar1,10000000);
  FUN_60162cb0(0x2000a7f4,iVar2,10000000,in_r3);
  return;
}
