
void FUN_600185d0(undefined4 param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  char cVar3;
  
  FUN_60166b98();
  cVar3 = '\0';
  thunk_EXT_FUN_000219ea(param_2,0,0x1c);
  uVar1 = FUN_600239b8(param_1);
  FUN_600239e8(uVar1,&LAB_60020bba_1,param_2);
  FUN_60166b64();
  uVar2 = param_2[2];
  *param_2 = 0x340000;
  *(char *)(param_2 + 6) = 'd' - (char)((uVar2 * 100) / 0x340000);
  if (uVar2 != 0) {
    cVar3 = 'd' - (char)((uint)(param_2[3] * 100) / uVar2);
  }
  *(char *)((int)param_2 + 0x19) = cVar3;
  return;
}
