
int FUN_600373e4(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  uint uVar1;
  int iVar2;
  int local_28;
  uint local_24;
  int local_20;
  
  local_20 = 0;
  if (param_1 == 0) {
    return 0xe;
  }
  if (param_4 == (uint *)0x0) {
    return 0xe;
  }
  if (0xf < *param_4) {
    *param_4 = *param_4 - 0x10;
    *param_3 = 0x50;
    iVar2 = FUN_60152fa4(param_1,param_2,&local_20,param_3 + 2);
    if (iVar2 != 0) {
      return iVar2;
    }
    local_24 = *param_4;
    iVar2 = FUN_6011ea84(param_1,param_2,&local_20,&local_24,param_3 + 3);
    uVar1 = local_24;
    if (iVar2 != 0) {
      return iVar2;
    }
    *param_4 = *param_4 - local_24;
    if (((*(char *)(param_3 + 6) == '\x06') &&
        (iVar2 = FUN_6010fd8c(param_3[2],&local_28), iVar2 != 5)) &&
       (iVar2 = FUN_60152e8c(param_1,param_2,&local_20,local_28 * 0xc + 0x20079340,
                             local_28 * 0xc + 0x20079344), iVar2 != 0)) {
      return iVar2;
    }
    if (local_20 == param_2) {
      *param_4 = uVar1 + 0x10;
      return 0;
    }
  }
  return 9;
}
