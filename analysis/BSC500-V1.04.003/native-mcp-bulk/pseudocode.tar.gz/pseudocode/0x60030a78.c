
undefined4 FUN_60030a78(int param_1)

{
  char cVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  uint uVar6;
  int iVar7;
  int *local_34;
  undefined4 local_30;
  undefined4 uStack_2c;
  
  if (param_1 != 0) {
    local_30 = 0;
    uStack_2c = 0;
    iVar2 = FUN_6012e4dc(0x2000c768,param_1,&local_30);
    if (iVar2 != 0) {
      return 0;
    }
    FUN_60134d56(0x2000c57c,&local_30);
    FUN_60134e9e(0x2000c58c,&local_30);
    iVar2 = FUN_60135184(0x2000afd0,&local_30);
    if (iVar2 == 0) {
      iVar2 = FUN_6012e27c(0x2007f8cc,&local_30,0x2000c54c);
      if (iVar2 != 0) {
        return 0;
      }
      uVar6 = 0xffffffff;
      local_34 = (int *)0x2000b014;
      iVar2 = 0;
      do {
        uVar6 = uVar6 + 1;
        if (uRam2000c554 <= uVar6) {
          return 0;
        }
        uVar3 = 0x2000c5a4;
        cVar1 = *(char *)(iRam2000c54c + iVar2);
        iVar7 = iRam2000c54c + iVar2;
        if (cVar1 != '\0') {
          uVar3 = 0x2000c720;
        }
        FUN_60134c5c(uVar3,iVar7);
        iVar4 = 0x5c;
        piVar5 = local_34;
        if (cVar1 == '\0') {
          iVar4 = 0x58;
          piVar5 = (int *)0x2000b010;
        }
        *(int *)(iVar4 + 0x2000afb8) = *piVar5 + 1;
        iVar7 = FUN_60135152(0x2000afc0,iVar7);
        iVar2 = iVar2 + 0x1c;
      } while (iVar7 == 0);
    }
    FUN_601667bc(uRam2000b00c);
    FUN_601667bc(uRam2000afc0);
    FUN_601667bc(uRam2000afd0);
    FUN_60163bbe(0x2008ad60);
    FUN_60163bbe(0x2008af54);
    FUN_60163bbe(0x2008b01c);
  }
  return 0xffffffff;
}
