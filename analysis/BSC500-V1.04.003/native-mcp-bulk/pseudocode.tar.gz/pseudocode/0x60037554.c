
longlong FUN_60037554(int param_1,uint param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  uint uVar2;
  undefined2 *puVar3;
  uint local_20;
  
  local_20 = 0;
  iVar1 = 0xe;
  uVar2 = param_2;
  if ((param_1 != 0) && (param_4 != (uint *)0x0)) {
    if (*param_4 < 0x10) {
LAB_600375fe:
      return CONCAT44(uVar2,9);
    }
    *param_4 = *param_4 - 0x10;
    *param_3 = 0x76;
    puVar3 = param_3;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_20,param_3 + 2,param_2,param_3);
    if (((iVar1 == 0) &&
        (iVar1 = FUN_60152fa4(param_1,param_2,&local_20,param_3 + 3,uVar2,puVar3), iVar1 == 0)) &&
       (iVar1 = FUN_60152fa4(param_1,param_2,&local_20,param_3 + 4,uVar2,puVar3), iVar1 == 0)) {
      iVar1 = FUN_60152fa4(param_1,param_2,&local_20,param_3 + 8,uVar2,puVar3);
      if (iVar1 == 0) {
        iVar1 = FUN_60122b2a(param_1,param_2,&local_20,param_3 + 6);
        if (iVar1 == 0) {
          uVar2 = (uint)(ushort)param_3[8];
          iVar1 = FUN_60152e36(param_1,param_2,&local_20,param_3 + 6,uVar2,uVar2);
          if (iVar1 == 0) {
            if (local_20 == param_2) {
              *param_4 = 0x10;
              return (ulonglong)uVar2 << 0x20;
            }
            goto LAB_600375fe;
          }
        }
      }
    }
  }
  return CONCAT44(uVar2,iVar1);
}
