
void FUN_60011ee4(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = thunk_FUN_6016717c();
  if (3999 < (uint)(iVar2 - *(int *)(param_1 + 0x20))) {
    iVar2 = FUN_6013d6ca(*(undefined4 *)(param_1 + 0x14));
    if (iVar2 == 0) {
      FUN_60163840(*(undefined4 *)(param_1 + 0x14));
    }
    iVar2 = 0;
    while (iVar2 != 8) {
      iVar1 = iVar2 * 4;
      iVar2 = iVar2 + 1;
      if (*(int *)(iVar1 + 0x20009d4c) == param_1) {
        *(int *)(iVar1 + 0x20009d6c) = param_1;
      }
    }
  }
  return;
}
