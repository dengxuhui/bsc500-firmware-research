
int FUN_600330d8(int param_1)

{
  uint uVar1;
  ulonglong uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  ulonglong in_d0;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined8 in_d1;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined8 uVar14;
  undefined8 local_28;
  
  local_28._4_4_ = (uint)(in_d0 >> 0x20);
  uVar1 = local_28._4_4_;
  uVar9 = local_28._4_4_ & 0x7fffffff;
  uVar7 = 0xbff00000;
  iVar5 = (int)in_d0;
  if ((uVar9 < 0x3e300000) && (iVar3 = FUN_60167a50(iVar5,local_28._4_4_), iVar3 == 0)) {
    if (iVar5 == 0 && (param_1 == -1 && (in_d0 & 0x7fffffff00000000) == 0)) {
      in_d0 = FUN_60133872(iVar5,local_28._4_4_);
      uVar7 = 0x3ff00000;
    }
    else if (param_1 == 1) {
      iVar3 = FUN_60138528(iVar5,local_28._4_4_);
      if (iVar3 != 4) {
        return iVar5;
      }
      FUN_6013a000();
      return iVar5;
    }
    iVar5 = FUN_601675d8(0,uVar7,(int)in_d0,(int)(in_d0 >> 0x20));
  }
  else {
    uVar2 = in_d0;
    if (0x3fe59427 < uVar9) {
      uVar2 = in_d0;
      if ((longlong)in_d0 < 0) {
        local_28 = FUN_60138558(iVar5,local_28._4_4_);
        in_d1 = FUN_60138558();
        uVar2 = local_28;
      }
      local_28 = uVar2;
      uVar12 = FUN_60138720((int)local_28,(int)(local_28 >> 0x20),0x54442d18,0x3fe921fb);
      uVar13 = FUN_60165558(0x33145c07,0x3c81a626,(int)in_d1,(int)((ulonglong)in_d1 >> 0x20));
      local_28 = FUN_601682c8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,
                              (int)((ulonglong)uVar13 >> 0x20));
      in_d1 = 0;
      uVar2 = local_28;
    }
    local_28 = uVar2;
    uVar8 = (undefined4)(local_28 >> 0x20);
    uVar10 = (undefined4)local_28;
    uVar12 = FUN_601678fc(uVar10,uVar8,uVar10,uVar8);
    uVar6 = (undefined4)((ulonglong)uVar12 >> 0x20);
    uVar7 = (undefined4)uVar12;
    uVar4 = FUN_601678fc(uVar7,uVar6,uVar7,uVar6);
    uVar11 = FUN_60138628(uVar4,&UNK_60277620,6);
    uVar4 = FUN_60138628(uVar4,&UNK_60277650,6);
    uVar12 = FUN_601678fc(uVar4,extraout_s1_00,uVar7,uVar6);
    uVar13 = FUN_601678fc(uVar10,uVar8,uVar7,uVar6);
    uVar4 = (undefined4)((ulonglong)uVar13 >> 0x20);
    uVar12 = FUN_601682c8(uVar11,extraout_s1,(int)uVar12,(int)((ulonglong)uVar12 >> 0x20));
    uVar12 = FUN_601678fc((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,uVar4);
    uVar11 = (undefined4)((ulonglong)in_d1 >> 0x20);
    uVar12 = FUN_601682c8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)in_d1,uVar11);
    uVar12 = FUN_601678fc((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),uVar7,uVar6);
    uVar12 = FUN_601682c8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)in_d1,uVar11);
    uVar13 = FUN_601678fc((int)uVar13,uVar4,0x55555563,0x3fd55555);
    uVar12 = FUN_601682c8((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),(int)uVar12,
                          (int)((ulonglong)uVar12 >> 0x20));
    uVar4 = (undefined4)((ulonglong)uVar12 >> 0x20);
    uVar7 = (undefined4)uVar12;
    uVar12 = FUN_601682c8(uVar10,uVar8,uVar7,uVar4);
    uVar6 = (undefined4)((ulonglong)uVar12 >> 0x20);
    iVar5 = (int)uVar12;
    if (uVar9 < 0x3fe59428) {
      if (param_1 != 1) {
        uVar12 = FUN_60138720(uVar10,uVar8,0,uVar6);
        uVar12 = FUN_60138720((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),uVar7,uVar4);
        uVar13 = FUN_601675d8(0,0xbff00000,iVar5,uVar6);
        uVar4 = (undefined4)((ulonglong)uVar13 >> 0x20);
        uVar8 = 0;
        uVar7 = uVar4;
        uVar14 = FUN_601678fc(0,uVar4,0,uVar6,0,uVar4);
        uVar14 = FUN_601682c8((int)uVar14,(int)((ulonglong)uVar14 >> 0x20),0,0x3ff00000);
        uVar12 = FUN_601678fc(uVar8,uVar7,(int)uVar12,(int)((ulonglong)uVar12 >> 0x20));
        uVar12 = FUN_601682c8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar14,
                              (int)((ulonglong)uVar14 >> 0x20));
        uVar12 = FUN_601678fc((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,uVar4);
        iVar5 = FUN_601682c8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),uVar8,uVar7);
      }
    }
    else {
      uVar12 = FUN_6016759c(param_1);
      uVar11 = (undefined4)((ulonglong)uVar12 >> 0x20);
      uVar13 = FUN_601682c8(iVar5,uVar6,(int)uVar12,uVar11);
      uVar14 = FUN_601678fc(iVar5,uVar6,iVar5,uVar6);
      uVar13 = FUN_601675d8((int)uVar14,(int)((ulonglong)uVar14 >> 0x20),(int)uVar13,
                            (int)((ulonglong)uVar13 >> 0x20));
      uVar13 = FUN_60165558((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),uVar7,uVar4);
      uVar13 = FUN_60138720((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),uVar10,uVar8);
      uVar13 = FUN_601678fc((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),0,0x40000000);
      uVar12 = FUN_60138720((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),(int)uVar12,uVar11);
      uVar13 = FUN_6016759c(1 - ((int)uVar1 >> 0x1e & 2U));
      iVar5 = FUN_601678fc((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),(int)uVar12,
                           (int)((ulonglong)uVar12 >> 0x20));
    }
  }
  return iVar5;
}
