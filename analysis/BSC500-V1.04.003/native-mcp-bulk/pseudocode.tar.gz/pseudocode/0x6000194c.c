
void FUN_6000194c(int param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 0x54) = param_4;
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined1 **)(param_1 + 0x2c) = &LAB_600021bc_1;
    *(undefined4 *)(param_1 + 0x30) = 0x60003801;
    *(undefined1 **)(param_1 + 0x34) = &LAB_60001f84_1;
    *(undefined1 **)(param_1 + 0x38) = &LAB_600021fc_1;
    *(undefined1 **)(param_1 + 0x3c) = &LAB_60002498_1;
    *(undefined1 **)(param_1 + 0x40) = &LAB_60002098_1;
    *(undefined1 *)(param_1 + 0x1c) = 0;
    FUN_601637f8(param_1,param_2,param_3);
    *(undefined ***)(param_1 + 0x44) = &PTR_LAB_60254618_1_602a598c;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("serial != RT_NULL","rt_hw_serial_register",0x488,param_4,param_4);
}
