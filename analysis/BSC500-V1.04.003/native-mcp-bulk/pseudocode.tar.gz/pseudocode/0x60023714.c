
undefined4 FUN_60023714(undefined4 param_1,int *param_2,undefined4 *param_3)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = FUN_601633cc(0x260);
  iVar2 = FUN_60165194(1,1,0);
  if ((iVar1 != 0) && (iVar2 != 0)) {
    iVar3 = FUN_6015838c(iVar1,param_1,0x13);
    if (iVar3 == 0) {
      *param_3 = 0;
    }
    else {
      iVar3 = FUN_6015838c(iVar1,param_1,0x11);
      if (iVar3 != 0) {
        FUN_601634dc(iVar1);
        goto LAB_60023762;
      }
      *param_3 = 1;
    }
    *param_2 = iVar1;
    param_2[1] = iVar2;
    param_2[2] = 0;
    return 0;
  }
  if (iVar1 != 0) {
    FUN_601634dc(iVar1);
  }
  if (iVar2 == 0) {
    return 0xe;
  }
LAB_60023762:
  FUN_6013a280(iVar2);
  return 0xe;
}
