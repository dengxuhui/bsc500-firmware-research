
void FUN_6001a3c0(int param_1,int param_2)

{
  *(bool *)(param_1 + 0x54) = param_2 == 3;
  *(bool *)(param_1 + 0x53) = param_2 == 1;
  if ((param_2 != 1) && (*(undefined1 *)(param_1 + 0x58) = 0, *(char *)(param_1 + 0x52) == '\0')) {
    *(undefined1 *)(param_1 + 0x52) = 1;
    return;
  }
  return;
}
