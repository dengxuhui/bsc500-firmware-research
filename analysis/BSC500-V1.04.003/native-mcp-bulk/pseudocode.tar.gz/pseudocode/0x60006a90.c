
void FUN_60006a90(void)

{
  FUN_6000a810();
  FUN_6000fe04();
  FUN_6000fbe8();
  FUN_6000a640();
  FUN_601544f4(3,0,0);
  FUN_601544f4(1,0,0);
  FUN_6015baec(1,0,0);
  FUN_6015baec(0,0,0);
  FUN_6015baec(3,0,0);
  FUN_6015baec(2,0,0);
  FUN_601544f4(2,0,0);
  thunk_EXT_FUN_00020440(5);
  return;
}
