
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_600319ec(char *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  char *local_20;
  undefined4 local_1c;
  undefined4 uStack_18;
  undefined4 local_14;
  
  local_20 = param_1;
  local_1c = param_2;
  uStack_18 = param_3;
  local_14 = param_4;
  FUN_600511f0();
  FUN_60162c50(0x24,0);
  FUN_6015df1c(0x24,0);
  FUN_6003fddc();
  uRam20008f84 = 0;
  if (iRam20008f98 == 0) {
    local_14 = 0;
    local_1c = 0;
    uStack_18 = 0;
    local_20 = "sd_sync";
    iRam20008f98 = FUN_60165194(1,0,&local_20);
  }
  else {
    while (iVar1 = FUN_601515bc(iRam20008f98), iVar1 != 0) {
      FUN_60165040(iRam20008f98,0);
    }
  }
  if (_DAT_20008f9c != 0) {
    return CONCAT44(local_1c,local_20);
  }
  local_14 = 0;
  local_1c = 0;
  uStack_18 = 0;
  local_20 = "sd_mutex";
  _DAT_20008f9c = FUN_60168494(&local_20);
  return CONCAT44(local_1c,local_20);
}
