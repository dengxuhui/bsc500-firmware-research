
void FUN_600286a8(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined1 auStack_60 [16];
  undefined1 local_50;
  char local_4f;
  
  ZeroBytes(&local_50,0x3c);
  FUN_60161d4c(auStack_60,param_1,param_2);
  iVar1 = FUN_60161d60(auStack_60,&UNK_602ad230,&local_50);
  if (iVar1 == 0) {
    FUN_60129ec8(local_50,0,local_4f,0);
  }
  else if (local_4f == '\x02') {
    FUN_60038bac();
  }
  return;
}
