
void FUN_60020a48(char *param_1,char *param_2,uint param_3,int param_4,int param_5,int param_6,
                 uint param_7)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  char *pcVar5;
  char cVar6;
  int iVar7;
  char local_35;
  char *local_34;
  char *pcStack_30;
  uint uStack_2c;
  int iStack_28;
  
  iStack_28 = param_4;
  uStack_2c = param_3;
  pcStack_30 = param_2;
  local_34 = param_1;
  pcVar5 = "0123456789ABCDEF";
  cVar6 = '0';
  if (-1 < (int)(param_7 << 0x19)) {
    pcVar5 = "0123456789abcdef";
  }
  if ((int)(param_7 << 0x1b) < 0) {
    param_7 = param_7 & 0xfffffffe;
  }
  if ((param_7 & 1) == 0) {
    cVar6 = ' ';
  }
  if ((int)(param_7 << 0x1e) < 0) {
    if (-1 < (int)param_3) {
      if ((int)(param_7 << 0x1d) < 0) {
        iVar7 = 0x2b;
      }
      else {
        iVar7 = (param_7 & 8) << 2;
      }
      goto LAB_60020a9c;
    }
    param_3 = -param_3;
    iVar7 = 0x2d;
  }
  else {
    iVar7 = 0;
LAB_60020a9c:
    if (param_3 == 0) {
      iVar4 = 1;
      local_34 = (char *)CONCAT31((int3)((uint)param_1 >> 8),0x30);
      goto LAB_60020ae8;
    }
  }
  iVar4 = 0;
  while (param_3 != 0) {
    if (param_4 == 10) {
      uVar1 = param_3 / 10;
      param_3 = param_3 % 10;
    }
    else {
      uVar1 = param_3 >> 4;
      param_3 = param_3 & 0xf;
    }
    *(char *)((int)&local_34 + iVar4) = pcVar5[param_3];
    iVar4 = iVar4 + 1;
    param_3 = uVar1;
  }
LAB_60020ae8:
  iVar3 = param_6;
  if (param_6 < iVar4) {
    iVar3 = iVar4;
  }
  param_5 = param_5 - iVar3;
  if ((param_7 & 0x11) == 0) {
    iVar2 = param_5 - (uint)(0 < param_5 && iVar7 != 0);
    while (param_5 = iVar2 + -1, 0 < iVar2) {
      if (param_1 < param_2) {
        *param_1 = ' ';
      }
      param_1 = param_1 + 1;
      iVar2 = param_5;
    }
  }
  if (iVar7 != 0) {
    if (param_1 < param_2) {
      *param_1 = (char)iVar7;
    }
    param_1 = param_1 + 1;
    param_5 = param_5 + -1;
  }
  iVar7 = param_5;
  if (-1 < (int)(param_7 << 0x1b)) {
    while (param_5 = iVar7 + -1, 0 < iVar7) {
      if (param_1 < param_2) {
        *param_1 = cVar6;
      }
      param_1 = param_1 + 1;
      iVar7 = param_5;
    }
  }
  for (; iVar4 < iVar3; iVar3 = iVar3 + -1) {
    if (param_1 < param_2) {
      *param_1 = '0';
    }
    param_1 = param_1 + 1;
  }
  while ((param_6 != 0 && (0 < iVar4))) {
    if (param_1 < param_2) {
      *param_1 = (&local_35)[iVar4];
    }
    param_1 = param_1 + 1;
    iVar4 = iVar4 + -1;
  }
  for (; 0 < param_5; param_5 = param_5 + -1) {
    if (param_1 < param_2) {
      *param_1 = ' ';
    }
    param_1 = param_1 + 1;
  }
  return;
}
