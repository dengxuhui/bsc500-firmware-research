
void FUN_60018148(void)

{
  if (iRam2000ab14 != 0) {
    FUN_601667bc();
    iRam2000ab14 = 0;
    FUN_60163bbe(0x2008b960);
    return;
  }
  return;
}
