
void FUN_6002fb20(undefined4 param_1,undefined4 param_2)

{
  undefined1 uVar1;
  int iVar2;
  code *pcVar3;
  undefined4 uVar4;
  undefined1 auStack_a0 [16];
  undefined1 local_90;
  char local_8f;
  char local_8e;
  byte local_47;
  uint local_44;
  undefined1 local_3c;
  
  ZeroBytes(&local_90,0x7c);
  FUN_60161d4c(auStack_a0,param_1,param_2);
  iVar2 = FUN_60161d60(auStack_a0,&UNK_603df56a,&local_90);
  FUN_60167f3c(7,"WATCH_PB",1,"peripheral_watch_cyc_decode\r\n");
  if (iVar2 != 0) {
    if (local_8f == '\x05') {
      if (local_8e == '\x02') {
        uVar1 = FUN_6015240c();
        FUN_60035e54(uVar1);
        FUN_60167f3c(7,"WATCH_PB",1,"[WATCH_PB] DEVICE INFO GET response received\n");
      }
      FUN_60167f3c(7,"WATCH_PB",1,"PERIPHERAL_WATCH_SERVICE_PWS_DEVICE_INFO\r\n");
    }
    else if ((local_8f == '\x04') && (local_8e == '\x06')) {
      FUN_60167f3c(7,"WATCH_PB",1,"[WATCH_TRANSFER] [SLAVE] total_file_size=%d\n",local_44);
      FUN_60167f3c(7,"WATCH_PB",1,"[WATCH_TRANSFER] [SLAVE] file_type=%d\n",local_47);
      uVar4 = 0;
      if (local_47 < 10) {
        if ((1 << (uint)local_47 & 0x206U) != 0) {
          iVar2 = FUN_60039f20(local_44 >> 10);
          uVar4 = 2;
          if (iVar2 == 0) {
            uVar4 = 1;
          }
        }
      }
      FUN_60038194();
      FUN_6003f1d8(local_3c);
      FUN_60155e04(uVar4);
      pcVar3 = (code *)FUN_6015d0ac();
      if (pcVar3 != (code *)0x0) {
        (*pcVar3)(0xf,0,0x11,1,0);
      }
      FUN_60127660(local_90,local_8f,local_8e,0);
    }
  }
  return;
}
