
undefined4 FUN_60022bf4(byte *param_1,int param_2,uint param_3,int *param_4)

{
  byte bVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  undefined4 local_98;
  undefined1 auStack_94 [112];
  
  if (param_2 == 0) {
    return 0xffffffff;
  }
  if (param_4 == (int *)0x0) {
    return 0xffffffff;
  }
  if (param_3 < *param_1) {
    ZeroBytes(auStack_94,0x70);
    iVar5 = *(int *)(param_1 + (short)param_3 * 0x1ec + 0x44);
    if ((*(int *)(param_1 + 0x6e3c) != 0) && (iVar5 == *(int *)(*(int *)(param_1 + 0x6e3c) + 0x40)))
    {
      return 1;
    }
    *param_4 = iVar5;
    iVar3 = FUN_60168220(param_1 + (short)param_3 * 0x1ec + 4);
    iVar4 = FUN_60168220(param_2);
    CopyBytes(auStack_94,param_2,iVar4);
    auStack_94[iVar4] = 0x2f;
    iVar5 = FUN_601681f4(auStack_94 + iVar4 + 1,&UNK_603fcbb8,iVar5);
    if (0 < iVar5) {
      iVar5 = iVar5 + iVar4 + 1;
      CopyBytes(auStack_94 + iVar5,param_1 + (short)param_3 * 0x1ec + 4,iVar3);
      CopyBytes(auStack_94 + iVar5 + iVar3,"_segment.cnb",0xc);
      iVar5 = FUN_60168220(auStack_94);
      local_98 = 0;
      iVar3 = FUN_60166758(&local_98,auStack_94,1);
      if (iVar3 == 0) {
        FUN_601667bc(local_98);
        iVar3 = FUN_60163bbe(auStack_94);
        if (iVar3 != 0) {
          return 0xffffffff;
        }
      }
      auStack_94[iVar5 + -1] = 0x78;
      iVar5 = FUN_60163bbe(auStack_94);
      if (iVar5 == 0) {
        bVar1 = *param_1;
        for (uVar6 = param_3; (int)(uVar6 & 0xff) < (int)(bVar1 - 1); uVar6 = uVar6 + 1) {
          sVar2 = (short)(uVar6 & 0xff);
          FUN_6007db44(param_1 + sVar2 * 0x1ec + 4,param_1 + sVar2 * 0x1ec + 0x1f0,0x1ec);
        }
        if (param_3 < param_1[1]) {
          param_1[1] = param_1[1] - 1;
        }
        *param_1 = (byte)(bVar1 - 1);
        return 0;
      }
    }
  }
  return 0xffffffff;
}
