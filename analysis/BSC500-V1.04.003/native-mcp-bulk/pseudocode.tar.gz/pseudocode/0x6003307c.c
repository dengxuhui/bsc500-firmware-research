
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6003307c(undefined1 param_1)

{
  if (*_DAT_20005200 != '\0') {
    DAT_2008bc0a = param_1;
    FUN_60167010(0x11);
    FUN_60167f3c(6,&DAT_603fbe23,1,&LAB_603edbe2_1,"workout_step_lap");
  }
  return;
}
