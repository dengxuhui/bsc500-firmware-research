
undefined4 FUN_60033048(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_6011f6a4();
  FUN_60035546(iVar1,param_1);
  uVar2 = FUN_6011f6a4();
  FUN_6013bb40(&DAT_6043dd0a,uVar2);
  FUN_6015c4f0(iVar1 + 0x10,0x15,0xff);
  return 0;
}
