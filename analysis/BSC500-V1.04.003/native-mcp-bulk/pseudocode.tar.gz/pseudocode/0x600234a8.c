
undefined4 FUN_600234a8(undefined4 param_1)

{
  char cVar1;
  undefined4 local_24;
  int *local_20;
  undefined4 local_18;
  
  if ((code *)piRam2004b8c4[1] != (code *)0x0) {
    (*(code *)piRam2004b8c4[1])();
  }
  (**(code **)(*piRam2004b8c4 + 8))(&local_24,piRam2004b8c4,0);
  if (local_20 == (int *)0x0) {
    cVar1 = '\r';
  }
  else {
    (**(code **)(*local_20 + 0x10))(local_20,0,1,5,local_24);
    (**(code **)(*local_20 + 0x20))(local_20,param_1);
    (**(code **)(*piRam2004b8c4 + 0xc))(piRam2004b8c4,&local_24);
    (**(code **)(*local_20 + 0x70))(local_20,&local_18);
    cVar1 = (char)local_20[5];
  }
  (**(code **)(*piRam2004b8c4 + 0x10))(piRam2004b8c4,&local_24);
  FUN_601675ca(piRam2004b8c4,cVar1,5);
  if ((code *)piRam2004b8c4[2] != (code *)0x0) {
    (*(code *)piRam2004b8c4[2])();
  }
  if (cVar1 != '\0') {
    local_18 = 0xffffffff;
  }
  return local_18;
}
