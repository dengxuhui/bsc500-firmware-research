
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4
FUN_60010750(undefined4 *param_1,undefined4 *param_2,int param_3,int *param_4,int *param_5)

{
  uint uVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  uint in_fpscr;
  uint uVar7;
  float fVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  undefined8 in_d6;
  undefined8 in_d7;
  undefined8 uVar17;
  undefined8 uVar18;
  undefined4 local_5c;
  undefined8 local_58;
  
  local_5c = (undefined4)((ulonglong)in_d6 >> 0x20);
  local_58 = in_d7;
  iVar4 = FUN_60166dd0();
  if ((iVar4 != 0) || (iVar4 = FUN_60166dd0(param_2), iVar4 != 0)) {
    return 0;
  }
  fVar12 = (float)VectorSignedToFloat(uRam200051e4,(byte)(in_fpscr >> 0x16) & 3);
  fVar8 = (float)VectorSignedToFloat(uRam200051e0,(byte)(in_fpscr >> 0x16) & 3);
  fVar16 = (float)VectorSignedToFloat(param_1[1],(byte)(in_fpscr >> 0x16) & 3);
  fVar13 = (float)VectorSignedToFloat(*param_1,(byte)(in_fpscr >> 0x16) & 3);
  uVar17 = FUN_60166bb4(ABS(fVar13 / fVar16 - fVar8 / fVar12));
  iVar4 = FUN_60167bc4((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0x9999999a,0x3fb99999);
  if (iVar4 == 0) {
    fVar8 = (float)VectorSignedToFloat(param_2[1],(byte)(in_fpscr >> 0x16) & 3);
    fVar12 = (float)VectorSignedToFloat(*param_2,(byte)(in_fpscr >> 0x16) & 3);
    fVar12 = fVar12 / fVar8;
  }
  else {
    fVar14 = (float)VectorSignedToFloat(uRam200051ec,(byte)(in_fpscr >> 0x16) & 3);
    fVar8 = (float)VectorSignedToFloat(uRam200051e8,(byte)(in_fpscr >> 0x16) & 3);
    fVar15 = (float)VectorSignedToFloat(param_2[1],(byte)(in_fpscr >> 0x16) & 3);
    fVar12 = (float)VectorSignedToFloat(*param_2,(byte)(in_fpscr >> 0x16) & 3);
    fVar12 = fVar12 / fVar15;
    uVar17 = FUN_60166bb4(ABS(fVar12 - fVar8 / fVar14));
    iVar4 = FUN_60167bc4((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0x9999999a,0x3fb99999);
    if (iVar4 != 0) {
      return 0;
    }
  }
  uVar17 = FUN_601673c4(((*(int *)(param_3 + 0x14) * 0x16f + *(int *)(param_3 + 0xc) +
                         (uint)(*(int *)(param_3 + 0x10) * 0x113) / 9) -
                        (((*(int *)(param_3 + 0x10) + 9U) / 0xc + *(int *)(param_3 + 0x14)) * 7 >> 2
                        )) + -0xb25a2);
  uVar17 = FUN_601682c8((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0,0x3fe00000);
  uVar18 = FUN_60166bb4(fVar12 / -360.0);
  FUN_601682c8((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),(int)uVar18,
               (int)((ulonglong)uVar18 >> 0x20));
  uVar5 = FUN_601672d4();
  fVar8 = (float)FUN_6001b658(uVar5);
  fVar8 = (float)FUN_60127be0(fVar12 + fVar8 + 180.0);
  FUN_600237b8(uVar5,&local_58,&local_5c,(int)&local_58 + 4);
  fVar14 = (float)FUN_60021718(fVar8 - (float)local_58);
  uVar17 = FUN_60166bb4(local_58._4_4_);
  FUN_601675d8(0x72474539,0xbfd10ff9,(int)uVar17,(int)((ulonglong)uVar17 >> 0x20));
  fVar8 = (float)FUN_601672d4();
  uVar17 = FUN_60166bb4(fVar8 + -0.5833333);
  uVar5 = FUN_601678fc((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0xaaaaaaab,0x3f91df46);
  uVar9 = FUN_6012f7e0(uVar5);
  uVar17 = FUN_60166bb4(fVar13 / fVar16);
  uVar5 = FUN_601678fc((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0xaaaaaaab,0x3f91df46);
  uVar10 = FUN_6012f7e0(uVar5);
  uVar17 = FUN_60166bb4(local_5c);
  uVar6 = FUN_601678fc((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0xaaaaaaab,0x3f91df46);
  uVar11 = FUN_6012f7e0(uVar6);
  uVar17 = FUN_601678fc(uVar10,extraout_s1_00,uVar11,extraout_s1_01);
  uVar17 = FUN_60165558(uVar9,extraout_s1,(int)uVar17,(int)((ulonglong)uVar17 >> 0x20));
  uVar5 = FUN_6015dac8(uVar5);
  uVar6 = FUN_6015dac8(uVar6);
  uVar18 = FUN_601678fc(uVar5,extraout_s1_02,uVar6,extraout_s1_03);
  FUN_601675d8((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),(int)uVar18,
               (int)((ulonglong)uVar18 >> 0x20));
  fVar8 = (float)FUN_601672d4();
  uVar5 = FUN_60166bb4();
  fVar12 = 12.0;
  fVar13 = fVar14 / -15.0 + 12.0;
  uVar1 = in_fpscr & 0xfffffff | (uint)(fVar8 < 1.0) << 0x1f;
  uVar7 = uVar1 | (uint)NAN(fVar8) << 0x1c;
  if ((byte)(uVar1 >> 0x1f) == ((byte)(uVar7 >> 0x1c) & 1)) {
    fVar12 = 0.0;
    iVar4 = -1;
  }
  else {
    uVar1 = in_fpscr & 0xfffffff | (uint)(fVar8 < -1.0) << 0x1f | (uint)(fVar8 == -1.0) << 0x1e;
    uVar7 = uVar1 | (uint)NAN(fVar8) << 0x1c;
    bVar2 = (byte)(uVar1 >> 0x18);
    if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar7 >> 0x1c) & 1)) {
      iVar4 = 1;
    }
    else {
      uVar5 = FUN_60023d30(uVar5);
      uVar17 = FUN_601678fc(uVar5,extraout_s1_04,0xd03cf26,0x404ca5dc);
      FUN_601675d8((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0,0x402e0000);
      fVar12 = (float)FUN_601672d4();
      iVar4 = 0;
    }
  }
  fVar16 = (fVar13 + fVar12) * 3600.0;
  fVar8 = (fVar13 - fVar12) * 3600.0;
  _DAT_2000bc6c = (int)fVar16;
  _DAT_2000bc68 = (int)fVar8;
  if (iVar4 == -1) {
    _DAT_2000bc6c = -0x15180;
  }
  else {
    if (iVar4 != 1) goto LAB_60010a72;
    _DAT_2000bc6c = 0x15180;
  }
  _DAT_2000bc68 = (int)fVar8 + _DAT_2000bc6c;
  _DAT_2000bc6c = (int)fVar16 + _DAT_2000bc6c;
LAB_60010a72:
  iVar3 = _DAT_2000bc6c;
  iVar4 = _DAT_2000bc68;
  fVar12 = (float)VectorSignedToFloat(param_2[1],(byte)(uVar7 >> 0x16) & 3);
  fVar8 = (float)VectorSignedToFloat(*param_2,(byte)(uVar7 >> 0x16) & 3);
  uVar17 = FUN_60166bb4(fVar8 / fVar12);
  FUN_601675d8((int)uVar17,(int)((ulonglong)uVar17 >> 0x20),0,0x400e0000);
  _DAT_2000bc64 = FUN_60167a50();
  _DAT_2000bc64 = _DAT_2000bc64 * 900;
  uRam200051e0 = *param_1;
  uRam200051e4 = param_1[1];
  uRam200051e8 = *param_2;
  uRam200051ec = param_2[1];
  DAT_2000bc60 = 1;
  *param_4 = iVar4;
  *param_5 = iVar3;
  return 1;
}
