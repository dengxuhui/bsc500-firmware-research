
int * FUN_600354ec(uint *param_1,int *param_2,int param_3)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = ((int)param_2 + (-0x10 - (int)param_1)) / 0x14;
  iVar3 = iVar4 + 1;
  if (*param_2 == param_3) {
    piVar2 = (int *)0x0;
    if ((param_1[iVar4 + 0x18] + 1 < *param_1) &&
       (piVar1 = (int *)FUN_6011fdbe(param_1,param_1[iVar4 + 0x18] + 1,iVar3), *piVar1 == param_3))
    {
      piVar2 = piVar1;
    }
  }
  else {
    if (param_2[2] != -1) {
      piVar2 = (int *)FUN_6011fdbe(param_1,param_2[2],iVar3);
      return piVar2;
    }
    piVar2 = (int *)0x0;
  }
  return piVar2;
}
