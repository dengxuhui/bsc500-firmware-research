
void FUN_6002f69c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined1 auStack_130 [16];
  undefined1 uStack_120;
  char local_11f;
  char local_11d;
  undefined1 uStack_114;
  undefined1 uStack_10f;
  undefined1 uStack_10d;
  undefined *local_108;
  undefined1 *puStack_104;
  undefined *local_f8;
  undefined1 *local_f4;
  undefined4 local_bc;
  undefined4 *local_b8;
  undefined4 uStack_ac;
  undefined1 uStack_a4;
  undefined1 local_77;
  undefined4 local_70;
  undefined4 uStack_6c;
  undefined1 auStack_64 [24];
  undefined1 auStack_4c [48];
  
  ZeroBytes(auStack_4c,0x2d);
  ZeroBytes(auStack_64,0x18);
  local_70 = 0;
  uStack_6c = 0;
  ZeroBytes(&uStack_120,0xb0);
  local_108 = &UNK_6003d06d;
  local_b8 = &local_70;
  local_f8 = &UNK_6003cff9;
  local_bc = 0x6003cfc9;
  puStack_104 = auStack_4c;
  local_f4 = auStack_64;
  FUN_60161d4c(auStack_130,param_1,param_2);
  iVar1 = FUN_60161d60(auStack_130,&DAT_602a6ba2,&uStack_120);
  if (iVar1 == 0) {
    return;
  }
  if (local_11f != '\x02') {
    if ((local_11f != '\x01') || (local_11d != '\v')) goto LAB_6002f742;
    goto LAB_6002f738;
  }
  switch(local_11d) {
  case '\0':
    func_0x6003cb4c(param_4,uStack_114);
    break;
  case '\x01':
    func_0x6003cb6c(param_4,uStack_10f);
    break;
  case '\x02':
    func_0x6003cb1e(param_4,auStack_4c);
    break;
  case '\x03':
    func_0x6003caf2(param_4,uStack_10d);
    break;
  case '\x04':
    func_0x6003cad0(param_4,auStack_64);
    break;
  case '\x06':
    func_0x6003cb08(param_4,uStack_ac);
    break;
  case '\a':
    func_0x600f729c(param_4,uStack_a4);
    break;
  case '\x14':
    func_0x6003cb4c(param_4,uStack_114);
    func_0x6003cb6c(param_4,uStack_10f);
    func_0x6003cb1e(param_4,auStack_4c);
    func_0x6003caf2(param_4,uStack_10d);
    func_0x6003cad0(param_4,auStack_64);
    func_0x6003cb08(param_4,uStack_ac);
    func_0x600f729c(param_4,uStack_a4);
  case '\v':
LAB_6002f738:
    FUN_6003cb36(param_4,local_77);
  }
LAB_6002f742:
  FUN_60133d0c(param_4);
  return;
}
