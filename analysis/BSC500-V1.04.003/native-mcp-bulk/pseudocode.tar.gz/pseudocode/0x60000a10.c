
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000a10(void)

{
  _DAT_200095d8 = &DAT_200095d8;
  _DAT_200095dc = &DAT_200095d8;
  FUN_6016305c(0x2008d4b8,"timer",&LAB_60000e1c_1,0,0x20002ac4,0x400,7,10);
  FUN_60167f8c(0x2008d4b8);
  return;
}
