
void FUN_6003589e(undefined4 *param_1,char *param_2)

{
  *(undefined2 *)(param_1 + 1) = 0xffff;
  *param_1 = 0xffffffff;
  *(char *)((int)param_1 + 6) = *param_2 << 1;
  return;
}
