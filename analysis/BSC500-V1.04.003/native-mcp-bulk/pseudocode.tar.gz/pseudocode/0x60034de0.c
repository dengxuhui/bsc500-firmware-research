
int FUN_60034de0(int param_1)

{
  return param_1 * 0x14 + 0x20189724;
}
