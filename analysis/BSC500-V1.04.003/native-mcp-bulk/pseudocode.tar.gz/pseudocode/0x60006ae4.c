
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006ae4(uint param_1,int param_2,undefined4 param_3,int param_4,undefined4 param_5)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if (7 < param_1) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("level <= LOG_LVL_DBG","ulog_voutput",0x206,param_4,param_2,param_3);
  }
  if (param_2 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&LAB_60413572_1,"ulog_voutput",0x20b,param_4,0,param_3);
  }
  if (param_4 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("format","ulog_voutput",0x20c,0,param_2,param_3);
  }
  if (_DAT_2008dbe8 != 0) {
    uVar1 = FUN_60166a64();
    FUN_6016750c();
    uVar2 = FUN_6000fffc(uVar1,param_1,param_2,param_3,param_4);
    uVar1 = FUN_60166a7c(param_1,param_2,0,uVar1);
    FUN_60167574(uVar1,uVar2,param_5,param_4);
    return;
  }
  return;
}
