
void FUN_60017e54(void)

{
  if (iRam2000aa10 != 0) {
    FUN_601667bc();
    iRam2000aa10 = 0;
  }
  return;
}
