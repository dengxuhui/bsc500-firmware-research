
int FUN_60026e8c(int param_1,uint param_2)

{
  byte bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  
  if (param_2 != 0) {
    uVar5 = param_2;
    if ((param_2 < 0x80) ||
       (uVar5 = ~(-1 << (0x1aU - LZCOUNT(param_2) & 0xff)) + param_2, uVar5 < 0x80)) {
      uVar7 = uVar5 >> 2;
      iVar6 = 0;
    }
    else {
      if (uVar5 >> 0x1e != 0) {
        return 0;
      }
      uVar7 = uVar5 >> (0x1aU - LZCOUNT(uVar5) & 0xff) ^ 0x20;
      iVar6 = 0x19 - LZCOUNT(uVar5);
    }
    uVar5 = -1 << (uVar7 & 0xff) & *(uint *)(param_1 + iVar6 * 4 + 0x118);
    if (uVar5 == 0) {
      uVar5 = -1 << (iVar6 + 1U & 0xff) & *(uint *)(param_1 + 0x114);
      if (uVar5 == 0) {
        return 0;
      }
      bVar2 = (byte)uVar5;
      bVar3 = (byte)(uVar5 >> 8);
      bVar4 = (byte)(uVar5 >> 0x10);
      bVar1 = (byte)(uVar5 >> 0x18);
      iVar6 = LZCOUNT((uint)(byte)((((((((bVar2 & 1) << 1 | bVar2 >> 1 & 1) << 1 | bVar2 >> 2 & 1)
                                       << 1 | bVar2 >> 3 & 1) << 1 | bVar2 >> 4 & 1) << 1 |
                                    bVar2 >> 5 & 1) << 1 | bVar2 >> 6 & 1) << 1 | bVar2 >> 7) <<
                      0x18 | (uint)(byte)((((((((bVar3 & 1) << 1 | bVar3 >> 1 & 1) << 1 |
                                              bVar3 >> 2 & 1) << 1 | bVar3 >> 3 & 1) << 1 |
                                            bVar3 >> 4 & 1) << 1 | bVar3 >> 5 & 1) << 1 |
                                          bVar3 >> 6 & 1) << 1 | bVar3 >> 7) << 0x10 |
                      (uint)(byte)((((((((bVar4 & 1) << 1 | bVar4 >> 1 & 1) << 1 | bVar4 >> 2 & 1)
                                       << 1 | bVar4 >> 3 & 1) << 1 | bVar4 >> 4 & 1) << 1 |
                                    bVar4 >> 5 & 1) << 1 | bVar4 >> 6 & 1) << 1 | bVar4 >> 7) << 8 |
                      (uint)(byte)((((((((bVar1 & 1) << 1 | bVar1 >> 1 & 1) << 1 | bVar1 >> 2 & 1)
                                       << 1 | bVar1 >> 3 & 1) << 1 | bVar1 >> 4 & 1) << 1 |
                                    bVar1 >> 5 & 1) << 1 | bVar1 >> 6 & 1) << 1 | bVar1 >> 7));
      uVar5 = *(uint *)(param_1 + iVar6 * 4 + 0x118);
      if (uVar5 == 0) {
                    /* WARNING: Subroutine does not return */
        thunk_FUN_6016804c("sl_map && \"internal error - second level bitmap is null\"",
                           "./../../../../qwos/middleware/memory_algo/tlsf.c",0x270);
      }
    }
    bVar2 = (byte)uVar5;
    bVar3 = (byte)(uVar5 >> 8);
    bVar4 = (byte)(uVar5 >> 0x10);
    bVar1 = (byte)(uVar5 >> 0x18);
    iVar6 = *(int *)(param_1 + iVar6 * 0x80 +
                     LZCOUNT((uint)(byte)((((((((bVar2 & 1) << 1 | bVar2 >> 1 & 1) << 1 |
                                              bVar2 >> 2 & 1) << 1 | bVar2 >> 3 & 1) << 1 |
                                            bVar2 >> 4 & 1) << 1 | bVar2 >> 5 & 1) << 1 |
                                          bVar2 >> 6 & 1) << 1 | bVar2 >> 7) << 0x18 |
                             (uint)(byte)((((((((bVar3 & 1) << 1 | bVar3 >> 1 & 1) << 1 |
                                              bVar3 >> 2 & 1) << 1 | bVar3 >> 3 & 1) << 1 |
                                            bVar3 >> 4 & 1) << 1 | bVar3 >> 5 & 1) << 1 |
                                          bVar3 >> 6 & 1) << 1 | bVar3 >> 7) << 0x10 |
                             (uint)(byte)((((((((bVar4 & 1) << 1 | bVar4 >> 1 & 1) << 1 |
                                              bVar4 >> 2 & 1) << 1 | bVar4 >> 3 & 1) << 1 |
                                            bVar4 >> 4 & 1) << 1 | bVar4 >> 5 & 1) << 1 |
                                          bVar4 >> 6 & 1) << 1 | bVar4 >> 7) << 8 |
                             (uint)(byte)((((((((bVar1 & 1) << 1 | bVar1 >> 1 & 1) << 1 |
                                              bVar1 >> 2 & 1) << 1 | bVar1 >> 3 & 1) << 1 |
                                            bVar1 >> 4 & 1) << 1 | bVar1 >> 5 & 1) << 1 |
                                          bVar1 >> 6 & 1) << 1 | bVar1 >> 7)) * 4 + 0x178);
    if (iVar6 != 0) {
      if ((*(uint *)(iVar6 + 4) & 0x3ffffc) < param_2) {
                    /* WARNING: Subroutine does not return */
        thunk_FUN_6016804c("block_size(block) >= size",
                           "./../../../../qwos/middleware/memory_algo/tlsf.c",0x341);
      }
      FUN_6006b688(param_1,iVar6);
      return iVar6;
    }
  }
  return 0;
}
