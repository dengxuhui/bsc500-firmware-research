
undefined4 FUN_60020350(int param_1)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  undefined8 uVar7;
  undefined4 local_34;
  undefined4 local_28;
  
  local_28 = 0;
  if (param_1 != 0) {
    uVar1 = FUN_60168220(param_1);
    if (99 < uVar1) {
      return 0xffffffff;
    }
    ZeroBytes(0x20080460,0xf8);
    FUN_60166858(0x20080496,0x85,0xff);
    uRam20080492 = 0xff;
    uRam2008048e = 0xffffffff;
    uRam2008048a = 0xffffffff;
    uRam20080486 = 0xffffffff;
    ZeroBytes(0x200803f8,100);
    iVar2 = FUN_60168220(param_1);
    CopyBytes(0x200803f8,param_1,iVar2 + 1);
    iVar2 = FUN_60166758(0x20080558,0x200803f8,1);
    if (iVar2 != 0) {
      return 0xffffffff;
    }
    uRam60c7e740 = 0;
    FUN_60161ef4(uRam20080558,0x60c7e740,0x14,&local_28);
    iVar2 = FUN_6016727c(0x60c7e740,"mapsforge binary OSM",0x14);
    if (iVar2 == 0) {
      FUN_60161ef4(uRam20080558,0x60c7e740,4,&local_28);
      uRam20080460 = (*(code *)&UNK_60030261)(0x60c7e740);
      FUN_60161ef4(uRam20080558,0x60c7e740,1,&local_28);
      uVar3 = uRam20080558;
      bRam20080555 = (byte)uRam60c7e740 >> 7;
      iVar2 = FUN_6015cbf2(uRam20080558);
      FUN_60163c98(uVar3,iVar2 + 3);
      FUN_60161ef4(uRam20080558,0x60c7e740,8,&local_28);
      uRam20080468 = FUN_6012222c(0x60c7e740);
      uVar3 = uRam20080558;
      iVar2 = FUN_6015cbf2(uRam20080558);
      FUN_60163c98(uVar3,iVar2 + 8);
      FUN_60161ef4(uRam20080558,0x60c7e740,4,&local_28);
      uRam20080470 = (*(code *)&UNK_60030261)(0x60c7e740);
      FUN_60161ef4(uRam20080558,0x60c7e740,4,&local_28);
      uRam20080474 = (*(code *)&UNK_60030261)(0x60c7e740);
      FUN_60161ef4(uRam20080558,0x60c7e740,4,&local_28);
      uRam20080478 = (*(code *)&UNK_60030261)(0x60c7e740);
      FUN_60161ef4(uRam20080558,0x60c7e740,4,&local_28);
      uRam2008047c = (*(code *)&UNK_60030261)(0x60c7e740);
      FUN_600270d4(0x200803f8);
      FUN_60161ef4(uRam20080558,0x60c7e740,2,&local_28);
      uRam20080480 = FUN_6015bd50(0x60c7e740);
      FUN_60161ef4(uRam20080558,0x60c7e740,1,&local_28);
      uVar3 = uRam20080558;
      iVar2 = FUN_6015cbf2(uRam20080558);
      FUN_60163c98(uVar3,(uRam60c7e740 & 0xff) + iVar2);
      FUN_60161ef4(uRam20080558,0x20080482,1,&local_28);
      FUN_6002f0dc(0x200803f8);
      FUN_60161ef4(uRam20080558,0x60c7e740,2,&local_28);
      uRam20080484 = FUN_6015bd50(0x60c7e740);
      FUN_6002f1bc(0x200803f8);
      FUN_60161ef4(uRam20080558,0x60c7e740,2,&local_28);
      uRam20080494 = FUN_6015bd50(0x60c7e740);
      FUN_6002f2e8(0x200803f8);
      local_34 = FUN_60161ef4(uRam20080558,0x2008051b,1,&local_28);
      uVar1 = (uint)bRam2008051b;
      iVar2 = 0;
      iVar6 = 0x129;
      iVar5 = 0;
      if (2 < uVar1) {
        bRam2008051b = 2;
        uVar1 = 2;
      }
      for (uVar4 = 0; uVar4 < uVar1; uVar4 = uVar4 + 1) {
        FUN_60161ef4(uRam20080558,iVar2 + 0x20080520,1,&local_28);
        FUN_60161ef4(uRam20080558,iVar6 + 0x200803f8,1,&local_28);
        FUN_60161ef4(uRam20080558,iVar2 + 0x20080522,1,&local_28);
        FUN_60161ef4(uRam20080558,0x60c7e740,8,&local_28);
        uVar7 = FUN_6012222c(0x60c7e740);
        *(undefined8 *)(iVar2 + 0x20080528) = uVar7;
        local_34 = FUN_60161ef4(uRam20080558,0x60c7e740,8,&local_28);
        uVar7 = FUN_6012222c(0x60c7e740);
        *(undefined8 *)(iVar2 + 0x20080530) = uVar7;
        uVar7 = FUN_6016759c(uRam20080474);
        uVar3 = FUN_601675d8((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x412e8480);
        uVar3 = FUN_60159978(uVar3,*(undefined1 *)(iVar2 + 0x20080520));
        *(undefined4 *)(iVar5 + 0x2008055c) = uVar3;
        uVar7 = FUN_6016759c(uRam20080470);
        uVar3 = FUN_601675d8((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x412e8480);
        uVar3 = FUN_60159878(uVar3,*(undefined1 *)(iVar2 + 0x20080520));
        *(undefined4 *)(iVar5 + 0x20080560) = uVar3;
        uVar7 = FUN_6016759c(uRam2008047c);
        uVar3 = FUN_601675d8((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x412e8480);
        uVar3 = FUN_60159978(uVar3,*(undefined1 *)(iVar2 + 0x20080520));
        *(undefined4 *)(iVar5 + 0x20080564) = uVar3;
        uVar7 = FUN_6016759c(uRam20080478);
        uVar3 = FUN_601675d8((int)uVar7,(int)((ulonglong)uVar7 >> 0x20),0,0x412e8480);
        uVar3 = FUN_60159878(uVar3,*(undefined1 *)(iVar2 + 0x20080520));
        uVar1 = (uint)bRam2008051b;
        *(undefined4 *)(iVar5 + 0x20080568) = uVar3;
        iVar6 = iVar6 + 0x18;
        iVar5 = iVar5 + 0x10;
        iVar2 = iVar2 + 0x18;
      }
      FUN_601667bc(uRam20080558);
      return local_34;
    }
    FUN_601667bc();
  }
  return 0xffffffff;
}
