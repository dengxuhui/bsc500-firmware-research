
void FUN_60006e38(int param_1)

{
  if ((iRam2000b864 != 0) && (*(char *)(iRam2000b864 + 8) != '\0')) {
    *(undefined4 *)(param_1 + 400) = 0;
    *(undefined1 *)(param_1 + 0x18b) = 1;
    if (iRam2000b860 != 0) {
      *(undefined4 *)(iRam2000b860 + 0x3c) = 0;
    }
  }
  return;
}
