
/* WARNING: Removing unreachable block (ram,0x600319e0) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_600233b0(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  int iVar1;
  int iVar2;
  
  iRam20008f0c = param_2;
  _DAT_20008f08 = 0;
  _DAT_20008efc = param_3;
  _DAT_20008f00 = param_4;
  uRam20008f04 = param_5;
  if ((param_2 != 0) && (iRam20008f10 = param_1, param_1 != 0)) {
    if ((char)uRam20008f28 != '\0' || DAT_20008f29 != '\0') {
      return 8;
    }
    puRam20008f2c = &UNK_60031a71;
    uRam20008f28 = 0x101;
    iVar1 = FUN_6003f130(&UNK_6003cbcd);
    iVar2 = 0;
    if (iVar1 != 0) {
      puRam20008f2c = (undefined *)0x0;
      uRam20008f28 = 0;
      iVar2 = iVar1;
      if (iVar1 != 7) {
        iVar2 = 3;
      }
    }
    return iVar2;
  }
  return 7;
}
