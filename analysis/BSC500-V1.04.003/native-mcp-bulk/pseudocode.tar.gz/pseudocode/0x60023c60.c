
undefined4 FUN_60023c60(undefined2 param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  
  puVar1 = (undefined4 *)FUN_6011f6b4();
  *(undefined2 *)(puVar1 + 5) = param_1;
  *(undefined1 *)((int)puVar1 + 0x16) = 2;
  *puVar1 = 0x20;
  puVar1[1] = 0x6b726f77;
  puVar1[2] = 0x74756f;
  puVar1 = (undefined4 *)FUN_6011f6b4();
  FUN_60035536();
  uVar2 = FUN_6011f6b4();
  FUN_6013bb40(&DAT_6043dcf8,uVar2);
  *puVar1 = 0xffffffff;
  puVar1[1] = 0;
  puVar1[2] = 0;
  puVar1[3] = 0;
  puVar1[4] = 0;
  *(undefined1 *)((int)puVar1 + 0x16) = 0xff;
  *(undefined2 *)(puVar1 + 5) = 0xffff;
  return 0;
}
