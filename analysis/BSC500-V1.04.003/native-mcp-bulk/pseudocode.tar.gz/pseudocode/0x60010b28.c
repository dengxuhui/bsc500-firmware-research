
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60010b28(int param_1,int param_2,undefined4 param_3)

{
  int iVar1;
  
  _DAT_2000bc64 = param_3;
  iVar1 = param_1;
  if (param_1 < 0) {
    iVar1 = -param_1;
  }
  if (iVar1 < 0x15180) {
    iVar1 = param_2;
    if (param_2 < 0) {
      iVar1 = -param_2;
    }
    if ((param_1 != param_2) && (iVar1 < 0x15180)) {
      DAT_2000bc60 = 1;
      _DAT_2000bc68 = param_1;
      _DAT_2000bc6c = param_2;
    }
  }
  return;
}
