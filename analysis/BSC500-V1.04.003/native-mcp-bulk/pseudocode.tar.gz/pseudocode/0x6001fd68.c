
undefined4 FUN_6001fd68(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  
  if (param_1 != 0) {
    iVar1 = FUN_60030d90(param_1 + 8,1,0);
    uVar2 = 0;
    if (iVar1 != 0) {
      uVar2 = 0xffffffff;
    }
    return uVar2;
  }
  return 0xfffffffc;
}
