
undefined1 FUN_60032f14(uint param_1)

{
  undefined1 uVar1;
  
  if (param_1 == 0x12) {
    uVar1 = 0;
  }
  else if (param_1 - 0x14 < 7) {
    uVar1 = 1;
  }
  else if (param_1 == 0x13) {
    uVar1 = 2;
  }
  else if (param_1 < 2) {
    uVar1 = 3;
  }
  else if (param_1 - 7 < 2) {
    uVar1 = 4;
  }
  else if ((param_1 < 0xb) && ((1 << (param_1 & 0xff) & 0x60cU) != 0)) {
    uVar1 = 5;
  }
  else if (param_1 - 4 < 3) {
    uVar1 = 6;
  }
  else {
    if (param_1 - 0xb < 7) {
      if (param_1 != 0xc && param_1 != 0x10) {
        return 7;
      }
    }
    else if (param_1 != 0xc && param_1 != 0x10) {
      if (param_1 == 0x1b) {
        return 9;
      }
      if (param_1 - 0x1c < 3) {
        return 10;
      }
      if (param_1 == 0x1f) {
        return 0xb;
      }
      if (param_1 == 0x20) {
        return 0xc;
      }
      if (param_1 < 0x21) {
        return 0xff;
      }
      return 0xd;
    }
    uVar1 = 8;
  }
  return uVar1;
}
