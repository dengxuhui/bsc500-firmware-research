
void FUN_6002ab04(undefined4 param_1,undefined4 param_2)

{
  short sVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  undefined4 uVar5;
  char *pcVar6;
  uint uVar7;
  undefined1 auStack_130 [16];
  undefined1 *local_120;
  undefined2 local_11c;
  undefined1 *local_118;
  undefined2 local_114;
  undefined4 local_110;
  undefined2 local_10c;
  char *local_108;
  undefined2 local_104;
  char *local_100;
  undefined2 local_fc;
  int local_f8;
  undefined2 local_f4;
  undefined1 auStack_f0 [36];
  undefined1 auStack_cc [36];
  char acStack_a8 [36];
  undefined1 local_84;
  char local_83;
  byte local_82;
  undefined *local_80;
  char **local_7c;
  undefined *local_78;
  char **ppcStack_74;
  undefined *local_70;
  int *local_6c;
  undefined *local_68;
  undefined4 *local_64;
  char local_58;
  uint local_54;
  undefined *local_50;
  undefined1 **local_4c;
  char local_48;
  int local_44;
  char local_40;
  char local_3f;
  undefined *local_3c;
  undefined1 **local_38;
  char local_34;
  int local_30;
  undefined *local_2c;
  
  ZeroBytes(&local_84,0x60);
  ZeroBytes(acStack_a8,0x21);
  ZeroBytes(auStack_cc,0x21);
  ZeroBytes(auStack_f0,0x21);
  sVar1 = sRam20050e0e;
  iVar2 = thunk_FUN_60162e34(0x200);
  pcVar3 = (char *)thunk_FUN_60162e34(0x140);
  if ((iVar2 == 0) || (pcVar3 == (char *)0x0)) {
    FUN_6011f5ec(1,0,0,0,2);
    if (iVar2 != 0) {
      thunk_FUN_60166c0c(iVar2);
    }
  }
  else {
    local_f4 = 0x200;
    local_fc = 0x140;
    local_104 = 0x21;
    local_10c = 0x21;
    local_114 = 0x21;
    local_11c = 0x21;
    local_110 = 0x20050eca;
    local_120 = auStack_f0;
    local_118 = auStack_cc;
    local_108 = acStack_a8;
    local_100 = pcVar3;
    local_f8 = iVar2;
    FUN_60167214(iVar2,0x200);
    FUN_60167214(pcVar3,0x140);
    ZeroBytes(auStack_cc,0x21);
    ZeroBytes(auStack_f0,0x21);
    FUN_60167214(0x20050e0c,0x102);
    sRam20050e0e = sVar1;
    ZeroBytes(&local_84,0x60);
    ppcStack_74 = &local_100;
    uRam20009eb2 = 0;
    uRam20009eae = 0;
    uRam20009eaa = 0;
    uRam20009ea8 = 0;
    local_6c = &local_f8;
    local_70 = &UNK_60046501;
    local_78 = &UNK_60046501;
    local_7c = &local_108;
    local_80 = &UNK_60046501;
    local_68 = &UNK_60046501;
    local_50 = &UNK_60046501;
    local_3c = &UNK_60046501;
    local_64 = &local_110;
    local_4c = &local_118;
    local_38 = &local_120;
    local_2c = &UNK_60035709;
    FUN_60161d4c(auStack_130,param_1,param_2);
    iVar4 = FUN_60161d60(auStack_130,&UNK_603d42ee,&local_84);
    FUN_60168578("PB decode status: %d\r\n",iVar4);
    FUN_60167214(0x20050e12,0x21);
    if (*pcVar3 == '\0') {
      pcVar6 = acStack_a8;
      uVar7 = FUN_60168220(pcVar6);
      if (0x1f < uVar7) {
        uVar7 = 0x20;
      }
    }
    else {
      uVar7 = 0x20;
      pcVar6 = pcVar3;
    }
    CopyBytes(0x20050e12,pcVar6,uVar7);
    uRam20050ec9 = 0;
    CopyBytes(0x20050e33,iVar2,0x96);
    thunk_FUN_60166c0c(iVar2);
    thunk_FUN_60166c0c(pcVar3);
    if (iVar4 == 0) {
      FUN_60129ec8(local_84,local_83,local_82,0);
    }
    else {
      FUN_6003aed4(auStack_f0);
      if (local_82 != 8) {
        FUN_60127660(local_84,local_83,local_82,0);
      }
      if (local_83 == '\x03') {
        if (local_82 != 6) {
          return;
        }
        uRam20050f0c = 3;
        if (local_44 == 0) {
          uRam20050f0c = 2;
        }
        if (local_48 == '\0') {
          uRam20050f0c = 2;
        }
        if (pcRam20044a84 == (code *)0x0) {
          return;
        }
        if ((local_40 == '\0') || (local_3f == '\0')) {
          if ((local_58 != '\0') && (1 < local_54)) {
            return;
          }
          sRam20050e0e = sRam20050e0e + 1;
          FUN_6013a040(0x20050e0c);
          uVar5 = 3;
        }
        else {
          uVar5 = 0xe;
        }
      }
      else {
        if (local_83 != '\x02') {
          if (local_83 != '\x01') {
            return;
          }
          if (local_82 == 9) {
            if (uRam20009ea8._1_1_ == '\0') {
              FUN_60045684();
            }
            FUN_6003ae70();
            return;
          }
          if (local_82 == 8) {
            FUN_6003af34();
            return;
          }
          if (local_82 != 1) {
            return;
          }
          if (local_34 != '\0') {
            FUN_6003a3ac(local_30 == 0);
          }
          if ((char)uRam20009ea8 == '\0') {
            return;
          }
          if ((char)uRam20009eaa != '\0') {
            FUN_6003a320(0);
            FUN_6003a348(0);
            FUN_6003a398(0);
            FUN_6003a384(0);
            FUN_6003a370(0);
            FUN_6003a2e4(0);
            FUN_6003a35c(0);
            FUN_6003a30c(0);
            FUN_6003a2d0(0);
            FUN_6003a334(0);
            FUN_6003a2f8(0);
          }
          for (iVar2 = 2; iVar2 != 0xd; iVar2 = iVar2 + 1) {
            switch(*(undefined1 *)(iVar2 + 0x20009ea8)) {
            case 1:
              FUN_6003a320(1);
              break;
            case 2:
              FUN_6003a348(1);
              break;
            case 3:
              FUN_6003a398(1);
              break;
            case 4:
              FUN_6003a384(1);
              break;
            case 5:
              FUN_6003a370(1);
              break;
            case 6:
              FUN_6003a2e4(1);
              break;
            case 7:
              FUN_6003a35c(1);
              break;
            case 8:
              FUN_6003a30c(1);
              break;
            case 9:
              FUN_6003a2d0(1);
              break;
            case 10:
              FUN_6003a334(1);
              break;
            case 0xb:
              FUN_6003a2f8(1);
            }
          }
          return;
        }
        if (local_82 - 3 < 2) {
          if (pcRam20044a84 == (code *)0x0) {
            return;
          }
          uVar5 = 2;
        }
        else {
          if (local_82 != 2) {
            return;
          }
          if (pcRam20044a84 == (code *)0x0) {
            return;
          }
          uRam20050f0c = 1;
          sRam20050e0e = sRam20050e0e + 1;
          FUN_6013a040(0x20050e0c);
          uVar5 = 1;
        }
      }
      (*pcRam20044a84)(uVar5,0x20050e0c,0x102);
    }
  }
  return;
}
