
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60011418(int *param_1)

{
  int iVar1;
  
  iVar1 = _DAT_20044734;
  if (param_1 != (int *)0x0) {
    *param_1 = _DAT_20044734 + 0x60e6f718;
  }
  return 0x1ff8 - iVar1;
}
