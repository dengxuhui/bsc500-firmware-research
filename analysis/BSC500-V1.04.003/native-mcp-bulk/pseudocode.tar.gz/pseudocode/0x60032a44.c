
void FUN_60032a44(undefined4 param_1,undefined4 param_2)

{
  undefined2 uVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 uVar4;
  char *pcVar5;
  uint uVar6;
  undefined2 *puVar7;
  undefined4 uVar8;
  undefined1 uVar9;
  char cVar10;
  int *piVar11;
  undefined1 auStack_128 [16];
  undefined4 local_118;
  undefined4 uStack_114;
  undefined4 local_110;
  undefined1 auStack_10c [64];
  undefined2 *puStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined2 *puStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined3 uStack_b4;
  uint uStack_b0;
  undefined4 uStack_a8;
  undefined1 uStack_68;
  undefined1 uStack_64;
  uint uStack_60;
  undefined1 uStack_5c;
  undefined4 uStack_58;
  undefined1 uStack_54;
  undefined1 uStack_4c;
  undefined *puStack_44;
  undefined2 **ppuStack_40;
  undefined1 uStack_3c;
  undefined *puStack_38;
  undefined2 **ppuStack_34;
  undefined1 uStack_30;
  undefined4 uStack_2c;
  undefined2 *puStack_28;
  
  ZeroBytes(auStack_10c,0x3f);
  local_110 = 0;
  local_118 = 0;
  uStack_114 = 0;
  uRam2000a05c = 0;
  uRam2000a060 = 0;
  ZeroBytes(0x200559c8,0x80);
  puRam20055a30 = &local_118;
  puRam200559d4 = &LAB_600389c8_1;
  puRam20055a2c = &UNK_60040c11;
  puRam200559d8 = auStack_10c;
  FUN_60161d4c(auStack_128,param_1,param_2);
  iVar3 = FUN_60161d60(auStack_128,&UNK_6043593e,0x200559c8);
  if (iVar3 == 0) {
    FUN_60129ec8(uRam200559c8,0,uRam200559c9,cRam200559ca);
    return;
  }
  cVar10 = cRam200559ca;
  uVar2 = uRam200559c8;
  switch(uRam200559c9) {
  case 1:
    if (cRam200559ca == '\x01') {
      uVar8 = func_0x600f4388();
      FUN_60167214(uVar8,0x4f);
      uVar8 = uRam200559d0;
      uVar4 = func_0x600f4388();
      ZeroBytes(&uStack_a8,0x4f);
      uStack_b4 = 0;
      uStack_bc = 0;
      uStack_b8 = 0;
      FUN_601681f4(&uStack_bc,&DAT_603f17d1,uVar8);
      FUN_60161fb8(0x2000a068);
      FUN_6015ee0c(0x2000a068,0x2000585c,".fit",0,0,0,0);
      piVar11 = (int *)0x2000a070;
      do {
        piVar11 = (int *)*piVar11;
        if (piVar11 == (int *)0x2000a070) goto code_r0x60032b3c;
        ZeroBytes(&uStack_a8,0x4f);
        uVar6 = piVar11[-1];
        if (0x4e < uVar6) {
          uVar6 = 0x4e;
        }
        CopyBytes(&uStack_a8,piVar11[-2],uVar6);
        iVar3 = FUN_60166834(&uStack_a8,&uStack_bc);
      } while (iVar3 == 0);
      CopyBytes(uVar4,&uStack_a8,0x4f);
code_r0x60032b3c:
      FUN_601607f4(0x2000a068);
      pcVar5 = (char *)func_0x600f4388();
      if (*pcVar5 != '\0') {
        uVar8 = func_0x600f4388();
        FUN_60164914(0x800002,uVar8);
        FUN_60127660(uRam200559c8,0,uRam200559c9,cRam200559ca);
        return;
      }
      uVar8 = 0x42;
      cVar10 = '\0';
      uVar2 = uRam200559c8;
      uVar9 = uRam200559c9;
    }
    else {
      uVar8 = 6;
      uVar9 = 1;
    }
    break;
  case 2:
    if (cRam200559ca == '\x13') {
      puStack_cc = (undefined2 *)0x0;
      puStack_28 = (undefined2 *)0x0;
      ZeroBytes(&uStack_a8,0x80);
      uVar6 = FUN_60147734(0x2000585c,".fit",0,0,0,0);
      iVar3 = FUN_6013a780(&puStack_cc,&puStack_28,0x6e);
      if (iVar3 != 0) {
        return;
      }
      uStack_3c = 0;
      uStack_4c = 0;
      uStack_54 = 0;
      uStack_58 = 0x14;
      uStack_5c = 1;
      uStack_64 = 1;
      uStack_68 = 1;
      uStack_a8 = 0x13020f;
      uStack_60 = uVar6 & 0xffff;
    }
    else {
      if (cRam200559ca == '\x12') {
        puStack_28 = (undefined2 *)0x0;
        puStack_c0 = (undefined2 *)0x0;
        uRam2000a05c = uRam20055a20;
        uRam2000a060 = uRam20055a28;
        ZeroBytes(&uStack_a8,0x80);
        uStack_c4 = 0;
        puStack_cc = (undefined2 *)0x0;
        uStack_c8 = 0;
        iVar3 = FUN_6013a780(&puStack_28,&puStack_c0,0x6e);
        if (iVar3 != 0) {
          return;
        }
        ppuStack_40 = &puStack_cc;
        uStack_a8 = CONCAT13(uStack_a8._3_1_,0x120000);
        uStack_a8 = CONCAT22(uStack_a8._2_2_,0x20f);
        puStack_44 = &UNK_60040a69;
        FUN_601648d4(&uStack_bc,puStack_28,0x640);
        FUN_60164868(&uStack_bc,&UNK_6043593e,&uStack_a8);
        *puStack_c0 = (short)uStack_b0;
        FUN_6012c348();
        uVar1 = *puStack_c0;
        puVar7 = puStack_28;
        goto code_r0x60032d0a;
      }
      if (cRam200559ca != '\x11') {
        uVar8 = 6;
        uVar9 = 2;
        break;
      }
      puStack_cc = (undefined2 *)0x0;
      puStack_28 = (undefined2 *)0x0;
      ZeroBytes(&uStack_a8,0x80);
      puStack_c0 = (undefined2 *)((uint)puStack_c0 & 0xffffff00);
      iVar3 = FUN_6013a780(&puStack_cc,&puStack_28,0x6e);
      if (iVar3 != 0) {
        return;
      }
      uStack_2c = 100;
      uStack_30 = 1;
      uStack_3c = 1;
      uStack_a8 = CONCAT13(uStack_a8._3_1_,0x110000);
      uStack_a8 = CONCAT22(uStack_a8._2_2_,0x20f);
      ppuStack_34 = &puStack_c0;
      puStack_38 = &UNK_6004012d;
    }
    FUN_601648d4(&uStack_bc,puStack_cc,0x640);
    FUN_60164868(&uStack_bc,&UNK_6043593e,&uStack_a8);
    *puStack_28 = (short)uStack_b0;
    FUN_6012c348();
    uVar1 = *puStack_28;
    puVar7 = puStack_cc;
code_r0x60032d0a:
    uVar8 = FUN_6015f2e8(puVar7,uVar1);
    FUN_6013a800(uStack_a8 & 0xff,0,uStack_a8._1_1_,uStack_a8._2_1_,uStack_b0 & 0xffff,uVar8);
    return;
  case 3:
    if (cRam200559ca == '!') {
      uVar8 = 0;
      uVar2 = 0xf;
      cVar10 = '!';
    }
    else {
      uVar8 = 6;
    }
    uVar9 = 3;
    break;
  case 4:
    if (cRam200559ca == '1') {
      FUN_60127660(uRam200559c8,0,4,0x31);
      FUN_60164914(0x800005,0);
      return;
    }
    uVar8 = 6;
    uVar9 = 4;
    break;
  default:
    uVar8 = 6;
    uVar9 = uRam200559c9;
  }
  FUN_6011f5ec(uVar2,0,uVar9,cVar10,uVar8);
  return;
}
