
void FUN_60010720(int param_1,int param_2,int param_3,int *param_4,int *param_5)

{
  if (*(int *)(param_1 + 0xc) != 0) {
    iRam2000cc78 = FUN_60164d88();
  }
  param_3 = iRam2000cc78 + param_3;
  *param_4 = iRam2000cc78 + param_2;
  *param_5 = param_3;
  return;
}
