
void FUN_6001e1c0(byte *param_1,byte *param_2,int *param_3)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  
  if (*param_1 == 0) {
    if (((uint)(iRam20055600 - *param_3) < 3000) && (bRam200578a2 != 0xff)) {
      uVar3 = bRam200578a2 / 3;
      bVar1 = (byte)uVar3;
      bVar2 = *param_2;
      if (*param_2 <= uVar3) {
        bVar2 = bVar1;
      }
      bVar2 = bVar2 - bVar1;
    }
    else {
      bVar2 = 0;
    }
  }
  else {
    bRam200578a2 = *param_1;
    *param_3 = iRam20055600;
    bVar2 = *param_1;
  }
  *param_2 = bVar2;
  return;
}
