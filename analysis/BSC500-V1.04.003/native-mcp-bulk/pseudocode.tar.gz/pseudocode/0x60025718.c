
int FUN_60025718(undefined4 param_1,int param_2,int param_3,int *param_4,int param_5,int param_6,
                uint param_7,uint param_8)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint *puVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined4 uVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  undefined4 uVar16;
  int iVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  undefined4 uVar20;
  undefined8 uVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  undefined1 local_58 [8];
  undefined8 local_50;
  undefined1 local_48 [8];
  undefined8 local_40;
  
  iVar15 = param_3 * 4 + -4;
  iVar1 = param_3 * 0x50;
  piVar2 = (int *)(iVar1 + 0x200496fc);
  *piVar2 = -1;
  *(undefined4 *)(iVar15 * 0x14 + 0x20049724) = 0xffffffff;
  iVar9 = iVar15 * 0x14;
  *(undefined4 *)(iVar1 + 0x200496ec) = 0xffffffff;
  *(undefined4 *)(iVar1 + 0x20049710) = 0xffffffff;
  *(undefined4 *)(iVar1 + 0x20049714) = 0xffffffff;
  *(int *)(iVar9 + 0x20049728) = -1;
  *(int *)(iVar1 + 0x20049700) = -1;
  piVar3 = (int *)(iVar1 + 0x200496e8);
  *piVar3 = -1;
  if (((5 < param_7) || (iVar11 = param_5, param_8 < 6)) &&
     ((iVar11 = param_6, param_7 < 6 || (5 < param_8)))) {
    uVar14 = param_7;
    if (param_7 < 6) {
      uVar14 = param_8;
    }
    if (uVar14 < 6) {
      if (param_7 < param_8) {
        iVar11 = param_5;
      }
    }
    else {
      iVar6 = param_3 * 4 + -3;
      FUN_60136908(param_1,param_5,0,&local_40,local_48);
      FUN_60136908(param_1,param_6,0,&local_50,local_58);
      uVar24 = local_40;
      uVar16 = (undefined4)((ulonglong)local_40 >> 0x20);
      uVar18 = (undefined4)local_40;
      iVar7 = FUN_60167bb6(uVar18,uVar16,0,0x40080000);
      uVar21 = local_50;
      iVar11 = param_3 + -0x10000;
      uVar19 = (undefined4)local_50;
      uVar12 = (undefined4)((ulonglong)local_50 >> 0x20);
      if ((iVar7 == 0) && (iVar7 = FUN_60167ba8(uVar19,uVar12,0,0xc0080000), iVar7 == 0)) {
        uVar21 = FUN_601682c8(uVar19,uVar12,0x54442d18,0x401921fb);
        local_50 = uVar21;
      }
      else {
        iVar7 = FUN_60167ba8(uVar18,uVar16,0,0xc0080000);
        if ((iVar7 == 0) && (iVar7 = FUN_60167bb6(uVar19,uVar12,0,0x40080000), iVar7 == 0)) {
          uVar24 = FUN_601682c8(uVar18,uVar16,0x54442d18,0x401921fb);
          local_40 = uVar24;
        }
      }
      uVar18 = (undefined4)((ulonglong)uVar24 >> 0x20);
      uVar21 = FUN_60165558((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),(int)uVar24,uVar18);
      uVar22 = FUN_601673c4(param_7);
      uVar16 = (undefined4)((ulonglong)uVar22 >> 0x20);
      uVar21 = FUN_601678fc((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),(int)uVar22,uVar16);
      uVar23 = FUN_601673c4(param_8 + param_7);
      uVar12 = (undefined4)((ulonglong)uVar23 >> 0x20);
      uVar21 = FUN_601675d8((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),(int)uVar23,uVar12);
      uVar24 = FUN_601682c8((int)uVar24,uVar18,(int)uVar21,(int)((ulonglong)uVar21 >> 0x20));
      uVar18 = (undefined4)((ulonglong)uVar24 >> 0x20);
      iVar7 = param_3 * 8;
      *(undefined8 *)(iVar7 + 0x2000aeb0) = uVar24;
      uVar21 = FUN_60165558(local_58._0_4_,local_58._4_4_,local_48._0_4_,local_48._4_4_);
      uVar21 = FUN_601678fc((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),(int)uVar22,uVar16);
      uVar21 = FUN_601675d8((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),(int)uVar23,uVar12);
      uVar21 = FUN_601682c8(local_48._0_4_,local_48._4_4_,(int)uVar21,
                            (int)((ulonglong)uVar21 >> 0x20));
      *(undefined8 *)(iVar7 + 0x2000aec8) = uVar21;
      iVar8 = FUN_60167bb6((int)uVar24,uVar18,0x54442d18,0x400921fb);
      if (iVar8 == 0) {
        uVar21 = FUN_601682c8((int)uVar24,uVar18,0x54442d18,0xc01921fb);
        *(undefined8 *)(iVar7 + 0x2000aeb0) = uVar21;
      }
      iVar7 = param_4[1];
      iVar8 = param_4[2];
      iVar13 = param_4[3];
      iVar17 = param_4[4];
      *(int *)(iVar9 + 0x20049724) = *param_4;
      *(int *)(iVar9 + 0x20049728) = iVar7;
      *(int *)(iVar9 + 0x2004972c) = iVar8;
      *(int *)(iVar9 + 0x20049730) = iVar13;
      *(int *)(iVar9 + 0x20049734) = iVar17;
      *(int *)(iVar9 + 0x20049728) = iVar11;
      *(uint *)(iVar9 + 0x20049734) = param_4[4] & 0xf8000000U | param_7 & 0x7ffffff;
      puVar4 = (undefined4 *)(param_2 + (((int)param_4 + (-0x10 - param_2)) / 0x14) * 4 + 0x60);
      *(undefined4 *)(iVar15 * 4 + 0x2000aee0) = *puVar4;
      iVar7 = param_4[1];
      iVar15 = param_4[2];
      iVar8 = param_4[3];
      iVar9 = param_4[4];
      *piVar3 = *param_4;
      *(int *)(iVar1 + 0x200496f0) = iVar15;
      *(int *)(iVar1 + 0x200496f4) = iVar8;
      *(int *)(iVar1 + 0x200496f8) = iVar9;
      *piVar3 = iVar11;
      *(int *)(iVar1 + 0x200496ec) = iVar7;
      *(uint *)(iVar6 * 0x14 + 0x20049734) = param_4[4] & 0xf8000000U | param_8 & 0x7ffffff;
      *(undefined4 *)(iVar6 * 4 + 0x2000aee0) = *puVar4;
      if ((0 < iRam2000aea8) &&
         (iVar9 = iRam2000aea8 * 4 + -4, *(int *)(iVar9 * 0x14 + 0x20049724) == param_5)) {
        iVar15 = iRam2000aea8 * 0x50;
        if (*(int *)(iVar15 + 0x200496ec) == param_6) {
          iVar9 = iVar9 * 0x14;
          iVar6 = param_3 * 4 + -2;
          param_7 = param_7 & 0x7ffffff;
          puVar5 = (uint *)(iVar9 + 0x20049734);
          if ((*puVar5 & 0x7ffffff) < param_7) {
            uVar18 = *(undefined4 *)(iVar15 + 0x200496ec);
            uVar12 = *(undefined4 *)(iVar15 + 0x200496f0);
            uVar19 = *(undefined4 *)(iVar15 + 0x200496f4);
            uVar16 = *(undefined4 *)(iVar15 + 0x200496f8);
            *piVar2 = *(int *)(iVar15 + 0x200496e8);
            *(undefined4 *)(iVar1 + 0x20049700) = uVar18;
            *(undefined4 *)(iVar1 + 0x20049704) = uVar12;
            *(undefined4 *)(iVar1 + 0x20049708) = uVar19;
            *(undefined4 *)(iVar1 + 0x2004970c) = uVar16;
            *(int *)(iVar1 + 0x20049700) = iVar11;
            uVar14 = *puVar5 & 0x7ffffff;
            uVar10 = param_7;
          }
          else {
            uVar16 = *(undefined4 *)(iVar9 + 0x20049728);
            uVar19 = *(undefined4 *)(iVar9 + 0x2004972c);
            uVar12 = *(undefined4 *)(iVar9 + 0x20049730);
            uVar18 = *(undefined4 *)(iVar9 + 0x20049734);
            *piVar2 = iVar11;
            *(undefined4 *)(iVar1 + 0x20049700) = uVar16;
            *(undefined4 *)(iVar1 + 0x20049704) = uVar19;
            *(undefined4 *)(iVar1 + 0x20049708) = uVar12;
            *(undefined4 *)(iVar1 + 0x2004970c) = uVar18;
            uVar10 = *puVar5 & 0x7ffffff;
            uVar14 = param_7;
          }
          iVar15 = iRam2000aea8 * 4 + -1;
          *(uint *)(iVar6 * 0x14 + 0x20049734) = uVar10 - uVar14 | param_4[4] & 0xf8000000U;
          uVar16 = *puVar4;
          uVar12 = *(undefined4 *)(iVar1 + 0x20049704);
          uVar18 = *(undefined4 *)(iVar1 + 0x20049708);
          uVar19 = *(undefined4 *)(iVar1 + 0x2004970c);
          *(undefined4 *)(iVar6 * 4 + 0x2000aee0) = uVar16;
          iVar9 = *piVar2;
          uVar20 = *(undefined4 *)(iVar1 + 0x20049700);
          *(undefined4 *)(iVar15 * 4 + 0x2000aee0) = uVar16;
          iVar1 = iVar15 * 0x14;
          *(int *)(iVar15 * 0x14 + 0x20049724) = iVar9;
          *(undefined4 *)(iVar1 + 0x20049728) = uVar20;
          *(undefined4 *)(iVar1 + 0x2004972c) = uVar12;
          *(undefined4 *)(iVar1 + 0x20049730) = uVar18;
          *(undefined4 *)(iVar1 + 0x20049734) = uVar19;
        }
      }
    }
  }
  iRam2000aea8 = param_3;
  return iVar11;
}
