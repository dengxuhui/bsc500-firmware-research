
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600356a4(undefined *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  undefined *local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 uStack_1c;
  
  local_28 = param_1;
  local_24 = param_2;
  local_20 = param_3;
  uStack_1c = param_4;
  if (_DAT_2000b3c4 == 0) {
    local_20 = 0;
    uStack_1c = 0;
    local_24 = 1;
    local_28 = &DAT_603fcde5;
    _DAT_2000b3c4 = FUN_60168494(&local_28);
  }
  FUN_6016825e(_DAT_2000b3c4,0xffffffff);
  uVar3 = 0;
  puVar2 = _DAT_2000b3c8;
  while (puVar1 = puVar2, puVar1 != (undefined4 *)0x0) {
    puVar2 = (undefined4 *)puVar1[0xb];
    if (((undefined *)*puVar1 == param_1) && ((code *)puVar1[5] != (code *)0x0)) {
      uVar3 = (*(code *)puVar1[5])(param_2);
    }
  }
  if (_DAT_2000b3c4 != 0) {
    FUN_601682ae();
  }
  return uVar3;
}
