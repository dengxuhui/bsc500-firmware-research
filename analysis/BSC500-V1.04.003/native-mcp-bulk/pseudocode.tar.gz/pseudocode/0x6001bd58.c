
void FUN_6001bd58(void)

{
  return;
}
