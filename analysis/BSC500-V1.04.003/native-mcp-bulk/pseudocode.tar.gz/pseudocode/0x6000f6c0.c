
undefined4 FUN_6000f6c0(int param_1,int param_2)

{
  int *piVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  char *local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 uStack_20;
  
  if (param_2 == 0) {
    uVar6 = 0;
  }
  else {
    if (iRam2000b53c == 0) {
      local_24 = 0;
      uStack_20 = 0;
      local_28 = 1;
      local_2c = "sensor";
      iRam2000b53c = FUN_60168494(&local_2c);
    }
    FUN_6016825e(iRam2000b53c,0xffffffff);
    uVar6 = 1;
    piVar5 = piRam2000b540;
LAB_6000f700:
    piVar4 = piVar5;
    if (piVar4 != (int *)0x0) {
      piVar5 = (int *)piVar4[0xc];
      if (*piVar4 == param_1) {
        piVar4 = piVar4 + 0xb;
        piVar2 = piVar4;
        do {
          piVar1 = (int *)*piVar2;
          if (piVar1 == (int *)0x0) {
            piVar2 = (int *)thunk_FUN_60162e34(0xc,1);
            if (piVar2 == (int *)0x0) {
              uVar6 = 0;
            }
            else {
              *piVar2 = param_2;
              iVar3 = *piVar4;
              piVar2[1] = iVar3;
              if (iVar3 != 0) {
                *(int **)(iVar3 + 8) = piVar2 + 1;
              }
              piVar2[2] = (int)piVar4;
              *piVar4 = (int)piVar2;
            }
            break;
          }
          piVar2 = piVar1 + 1;
        } while (*piVar1 != param_2);
      }
      goto LAB_6000f700;
    }
    if (iRam2000b53c != 0) {
      FUN_601682ae();
    }
  }
  return uVar6;
}
