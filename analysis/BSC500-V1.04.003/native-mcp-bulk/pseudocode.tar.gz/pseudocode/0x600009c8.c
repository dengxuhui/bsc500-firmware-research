
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600009c8(void)

{
  char cVar1;
  bool bVar2;
  int iVar3;
  int iVar4;
  
  iVar3 = FUN_6015f970(_DAT_20009594);
  iVar4 = FUN_6015f970(*(undefined1 *)(iVar3 + 0x2000959f));
  iVar3 = *(int *)((iVar4 + (iVar3 + -1) * 8) * 8 + 0x2007e730);
  _DAT_20009590 = iVar3 + -0x1c;
  _DAT_2007e56c = iVar3 + 8;
  cVar1 = isThreadModePrivileged();
  isUsingMainStack();
  bVar2 = (bool)isCurrentModePrivileged();
  if (bVar2) {
    setThreadModePrivileged(cVar1 == '\x01');
    bVar2 = (bool)isThreadMode();
    if (bVar2) {
      cVar1 = isUsingMainStack();
      setStackMode(cVar1 == '\x01');
    }
  }
  _DAT_2007e568 = 0;
  _DAT_2007e900 = 1;
  _DAT_e000ed20 = _DAT_e000ed20 | 0xff0000;
  _DAT_e000ed04 = 0x10000000;
  bVar2 = (bool)isCurrentModePrivileged();
  if (bVar2) {
    setMainStackPointer(*_DAT_e000ed08);
  }
  enableFIQinterrupts();
  enableIRQinterrupts();
  return *_DAT_e000ed08;
}
