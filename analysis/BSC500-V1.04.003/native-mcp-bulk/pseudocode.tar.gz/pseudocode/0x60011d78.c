
void FUN_60011d78(int param_1)

{
  int iVar1;
  
  if (cRam2000a3f0 == '\x01') {
    iVar1 = FUN_6015eff4();
    if (3000 < (uint)(**(int **)(iVar1 + 4) - iRam2000a3f4)) {
      *(undefined1 *)(param_1 + 2) = 0;
      FUN_60168578("[BLE_HRM_TIMEOUT] No data for %u ms, set heart_rate to 0xff\r\n");
      return;
    }
  }
  return;
}
