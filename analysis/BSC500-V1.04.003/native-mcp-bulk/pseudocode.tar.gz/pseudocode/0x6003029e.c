
undefined4 FUN_6003029e(int *param_1,undefined1 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  
  if (param_1 == (int *)0x0) {
    uVar1 = 0xffffffff;
  }
  else {
    *(undefined1 *)(*param_1 + param_1[3]) = param_2;
    uVar2 = param_1[3] + 1;
    if ((uint)param_1[2] <= uVar2) {
      uVar2 = 0;
    }
    param_1[3] = uVar2;
    if ((uint)param_1[1] < (uint)param_1[2]) {
      param_1[1] = param_1[1] + 1;
    }
    uVar1 = 0;
  }
  return uVar1;
}
