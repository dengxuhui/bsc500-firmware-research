
bool FUN_6001b5b8(int param_1)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  
  bVar3 = false;
  iVar1 = FUN_60163e34(0);
  if (iVar1 != 0) {
    iVar2 = FUN_60168418(iVar1 + 0x50,"ftp_test");
    bVar3 = iVar2 == 0;
    if ((iVar2 == 0) && (param_1 != 0)) {
      CopyBytes(iVar1 + 0x50,"ftp_result",0xb);
      bVar3 = true;
    }
  }
  return bVar3;
}
