
uint FUN_60033428(uint *param_1,uint *param_2)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint *puVar6;
  
  param_1[8] = 0;
  while (uVar1 = (*(code *)param_1[3])(param_1), uVar1 != 0) {
    if (uVar1 == 0x25) {
      uVar4 = 0;
      while (((uVar1 = (*(code *)param_1[3])(param_1), 0x1f < (int)uVar1 && (uVar1 < 0x31)) &&
             ((byte)"0123456789ABCDEF@0X"[uVar1 + 8] != 0))) {
        uVar4 = uVar4 | (byte)"0123456789ABCDEF@0X"[uVar1 + 8];
      }
      if ((int)(uVar4 << 0x1e) < 0) {
        uVar4 = uVar4 & 0xfffffffb;
      }
      param_1[7] = 0;
      iVar5 = 0;
      param_1[6] = 0;
      puVar6 = param_2;
      do {
        if (uVar1 == 0x2a) {
          param_2 = puVar6 + 1;
          param_1[iVar5 + 6] = *puVar6;
          uVar1 = (*(code *)param_1[3])(param_1);
          if (iVar5 == 1) {
            if ((int)param_1[7] < 0) {
              uVar4 = uVar4 & 0xffffffdf;
            }
            break;
          }
        }
        else {
          iVar2 = FUN_6012a568(uVar1);
          if (iVar2 != 0) {
            param_1[iVar5 + 6] = uVar1 - 0x30;
            while( true ) {
              uVar1 = (*(code *)param_1[3])(param_1);
              iVar2 = FUN_6012a568();
              if (iVar2 == 0) break;
              param_1[iVar5 + 6] = (uVar1 + param_1[iVar5 + 6] * 10) - 0x30;
            }
          }
          param_2 = puVar6;
          if (iVar5 == 1) break;
        }
        if (uVar1 != 0x2e) break;
        uVar1 = (*(code *)param_1[3])(param_1);
        iVar5 = iVar5 + 1;
        uVar4 = uVar4 | 0x20;
        puVar6 = param_2;
      } while (iVar5 < 2);
      if ((int)param_1[6] < 0) {
        uVar4 = uVar4 | 1;
        param_1[6] = -param_1[6];
      }
      if ((uVar4 & 1) != 0) {
        uVar4 = uVar4 & 0xffffffef;
      }
      if ((uVar1 == 0x6c) || (uVar1 == 0x68)) {
        uVar3 = (*(code *)param_1[3])(param_1);
        if (uVar3 == uVar1) {
          if (uVar1 == 0x6c) goto LAB_60033594;
          uVar1 = 0x400;
          goto LAB_6003354a;
        }
        if (uVar1 == 0x6c) {
          uVar1 = 0x40;
        }
        else {
          uVar1 = 0x100;
        }
        uVar4 = uVar4 | uVar1;
        uVar1 = uVar3;
      }
      else {
        if (uVar1 != 0x4c) {
          if (uVar1 == 0x6a) {
LAB_60033594:
            uVar1 = 0x80;
            goto LAB_6003354a;
          }
          if ((uVar1 != 0x74) && (uVar1 != 0x7a)) goto LAB_60033560;
        }
        uVar1 = 0;
LAB_6003354a:
        uVar4 = uVar4 | uVar1;
        uVar1 = (*(code *)param_1[3])(param_1);
      }
LAB_60033560:
      if (uVar1 == 0) break;
      if (uVar1 - 0x41 < 0x1a) {
        uVar1 = uVar1 + 0x20;
        uVar4 = uVar4 | 0x800;
      }
      *param_1 = uVar4;
      iVar5 = FUN_6026850c(param_1,uVar1,param_2);
      if (iVar5 == 0) goto LAB_6003344c;
      if (iVar5 == 1) {
        param_2 = param_2 + 1;
      }
      else {
        param_2 = (uint *)(((int)param_2 + 7U & 0xfffffff8) + 8);
      }
    }
    else {
LAB_6003344c:
      (*(code *)param_1[1])(uVar1,param_1[2]);
      param_1[8] = param_1[8] + 1;
    }
  }
  return param_1[8];
}
