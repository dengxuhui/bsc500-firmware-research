
int FUN_600363b4(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  int local_18;
  
  local_18 = 0;
  if ((param_1 == 0) || (param_4 == (uint *)0x0)) {
    return 0xe;
  }
  if (5 < *param_4) {
    *param_4 = *param_4 - 6;
    *param_3 = 0x1a;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_18,param_3 + 2);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60042f1c(param_1,param_2,&local_18,param_3 + 4);
    if (iVar1 != 0) {
      return iVar1;
    }
    if (local_18 == param_2) {
      *param_4 = 6;
      return 0;
    }
  }
  return 9;
}
