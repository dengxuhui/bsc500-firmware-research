
void FUN_600268e8(void)

{
  int iVar1;
  
  iVar1 = FUN_60167b4c();
  uRam20004f09 = 10;
  if (iVar1 == 0) {
    uRam20004f09 = 5;
  }
  return;
}
