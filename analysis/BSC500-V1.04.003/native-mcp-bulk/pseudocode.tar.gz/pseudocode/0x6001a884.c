
undefined4 FUN_6001a884(undefined4 *param_1,int param_2)

{
  undefined4 uVar1;
  uint uVar2;
  
  uVar1 = 0xffffffff;
  if ((param_1 != (undefined4 *)0x0) && (param_2 != 0)) {
    uVar2 = FUN_60164ed8(*param_1,param_2,0x18,&stack0xfffffff4);
    uVar1 = 0;
    if ((uVar2 | 0x18) != 0) {
      uVar1 = 0xffffffff;
    }
  }
  return uVar1;
}
