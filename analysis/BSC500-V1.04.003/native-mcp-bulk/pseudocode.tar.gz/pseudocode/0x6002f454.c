
void FUN_6002f454(void)

{
  int iVar1;
  int iVar2;
  undefined1 *in_stack_000001a0;
  undefined1 *in_stack_000001a8;
  undefined1 uStack000001c0;
  char cStack000001c1;
  char cStack000001c2;
  char cStack000001cc;
  undefined1 uStack000001cd;
  char in_stack_000001d4;
  undefined4 in_stack_000001d8;
  char in_stack_000001dc;
  undefined1 in_stack_000001e0;
  char in_stack_000001e4;
  undefined1 in_stack_000001e8;
  char in_stack_00000204;
  char in_stack_00000220;
  int in_stack_00000224;
  char in_stack_00000228;
  char in_stack_00000229;
  
  ZeroBytes();
  ZeroBytes(&stack0x00000074,100);
  ZeroBytes(&stack0x00000010,100);
  iVar1 = FUN_60163834();
  in_stack_000001a0 = &stack0x00000010;
  in_stack_000001a8 = &stack0x00000074;
  FUN_60161d4c();
  iVar2 = FUN_60161d60();
  if ((iVar2 != 0) && (cStack000001c1 == '\x01')) {
    if ((in_stack_00000228 == '\0') || (in_stack_00000229 != '\x01')) {
      if ((((in_stack_00000220 != '\0') && (in_stack_00000224 != *(int *)(iVar1 + 100))) ||
          (iVar2 = FUN_6016727c(iVar1 + 0x31,&stack0x00000010,0x17), iVar2 != 0)) ||
         ((iVar2 = FUN_6016727c(iVar1 + 0x19,&stack0x000000d8,0x17), iVar2 != 0 ||
          (iVar2 = FUN_6016727c(iVar1 + 0x49,&stack0x00000074,0x17), iVar2 != 0)))) {
        *(undefined1 *)(iVar1 + 0x70) = 1;
      }
      if (cStack000001c2 != '\0') {
        iVar2 = FUN_60168220(&stack0x0000013c);
        if (iVar2 != 0) {
          *(undefined1 *)(iVar1 + 0x18) = 0;
          CopyBytes(iVar1 + 1,&stack0x0000013c,0x17);
        }
        if (cStack000001cc != '\0') {
          *(undefined1 *)(iVar1 + 0x6d) = uStack000001cd;
        }
        if (in_stack_000001d4 != '\0') {
          *(undefined1 *)(iVar1 + 0x6c) = 1;
          *(undefined4 *)(iVar1 + 0x68) = in_stack_000001d8;
        }
        if (in_stack_000001e4 != '\0') {
          *(undefined1 *)(iVar1 + 0x6e) = in_stack_000001e8;
        }
        if (in_stack_000001dc != '\0') {
          *(undefined1 *)(iVar1 + 0x6f) = in_stack_000001e0;
        }
      }
      if (in_stack_00000204 != '\0') {
        iVar2 = FUN_60168220(&stack0x000000d8);
        if (iVar2 != 0) {
          *(undefined1 *)(iVar1 + 0x30) = 0;
          CopyBytes(iVar1 + 0x19,&stack0x000000d8,0x17);
        }
        iVar2 = FUN_60168220(&stack0x00000074);
        if (iVar2 != 0) {
          *(undefined1 *)(iVar1 + 0x60) = 0;
          CopyBytes(iVar1 + 0x49,&stack0x00000074,0x17);
        }
        iVar2 = FUN_60168220(&stack0x00000010);
        if (iVar2 != 0) {
          *(undefined1 *)(iVar1 + 0x48) = 0;
          CopyBytes(iVar1 + 0x31,&stack0x00000010,0x17);
        }
        if (in_stack_00000220 != '\0') {
          if (in_stack_00000224 != *(int *)(iVar1 + 100)) {
            *(int *)(iVar1 + 100) = in_stack_00000224;
          }
        }
      }
      FUN_60138570(0x40000007);
    }
    else {
      FUN_60163e70(0x8000006f,0,0);
    }
    FUN_60127660(uStack000001c0,0,1,0);
  }
  return;
}
