
uint FUN_6002f044(uint param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if ((param_1 & 3) == 0) {
    iVar2 = param_1 + 0x74;
    *(uint *)(param_1 + 8) = param_1;
    *(uint *)(param_1 + 0xc) = param_1;
    *(undefined4 *)(param_1 + 0x10) = 0;
    for (iVar1 = 0; iVar1 != 0x18; iVar1 = iVar1 + 1) {
      *(undefined4 *)(param_1 + iVar1 * 4 + 0x14) = 0;
      for (iVar3 = 0; iVar3 != 0x20; iVar3 = iVar3 + 1) {
        *(uint *)(iVar2 + iVar3 * 4) = param_1;
      }
      iVar2 = iVar2 + 0x80;
    }
  }
  else {
    FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_tlsf.c",0x42f,
                 "lv_tlsf_create","lv_tlsf_create: Memory must be aligned to %u bytes.\n",4);
    param_1 = 0;
  }
  return param_1;
}
