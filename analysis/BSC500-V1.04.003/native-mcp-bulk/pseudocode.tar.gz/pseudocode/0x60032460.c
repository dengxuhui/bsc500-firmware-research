
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x6003262c */
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_60032460(float *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  float fVar3;
  float fVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  undefined4 extraout_s1_05;
  undefined8 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 uVar12;
  
  uVar9 = FUN_60166bb4();
  uVar5 = (undefined4)((ulonglong)uVar9 >> 0x20);
  uVar1 = (undefined4)uVar9;
  uVar9 = FUN_601678fc(uVar1,uVar5,0x8da5f901,0x3fef8a09);
  FUN_601682c8((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0x83126e98,0x407640c0);
  uVar2 = FUN_601672d4();
  uVar2 = FUN_60127be0(uVar2);
  uVar9 = FUN_601678fc(uVar1,uVar5,0xcaf35bd9,0xbe13c626);
  uVar9 = FUN_601682c8((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0x2320968,0x3f911c2a);
  uVar10 = FUN_60166bb4(uVar2);
  uVar8 = (undefined4)((ulonglong)uVar10 >> 0x20);
  fVar3 = (float)FUN_601672d4((int)uVar9,(int)((ulonglong)uVar9 >> 0x20));
  uVar9 = FUN_60166bb4();
  uVar6 = (undefined4)((ulonglong)uVar9 >> 0x20);
  uVar11 = FUN_601678fc();
  uVar2 = FUN_601678fc((int)uVar10,uVar8);
  uVar7 = FUN_6012f7e0(uVar2);
  uVar11 = FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),uVar7,extraout_s1);
  uVar2 = FUN_6015dac8(uVar2);
  uVar12 = FUN_601678fc(uVar2,extraout_s1_00,(int)uVar9,uVar6);
  uVar12 = FUN_601682c8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),0,0x3ff00000);
  uVar11 = FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),(int)uVar12,
                        (int)((ulonglong)uVar12 >> 0x20));
  FUN_601682c8((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),(int)uVar10,uVar8);
  FUN_601672d4();
  uVar10 = FUN_60166bb4();
  uVar2 = FUN_601678fc((int)uVar10,(int)((ulonglong)uVar10 >> 0x20),0xaaaaaaab,0x3f91df46);
  uVar8 = FUN_6015dac8(uVar2);
  FUN_60165558(uVar8,extraout_s1_01,(int)uVar9,uVar6);
  fVar4 = (float)FUN_601672d4();
  uVar9 = FUN_60166bb4(fVar3 * fVar3);
  uVar8 = FUN_60165558(0,0x3ff00000,(int)uVar9,(int)((ulonglong)uVar9 >> 0x20));
  uVar8 = FUN_6015d550(uVar8);
  uVar2 = FUN_6012f7e0(uVar2);
  FUN_601678fc(uVar8,extraout_s1_02,uVar2,extraout_s1_03);
  fVar3 = (float)FUN_601672d4();
  uVar2 = FUN_60166bb4(fVar3 * fVar3 + fVar4 * fVar4);
  uVar2 = FUN_6015d550(uVar2);
  uVar2 = FUN_601672d4(uVar2,extraout_s1_04);
  *param_2 = uVar2;
  uVar2 = FUN_60166bb4(fVar3);
  uVar8 = FUN_60166bb4(fVar4);
  uVar2 = FUN_6015d758(uVar2,extraout_s1_04,uVar8);
  FUN_601678fc(uVar2,extraout_s1_05,0xd03cf26,0x404ca5dc);
  fVar3 = (float)FUN_601672d4();
  uVar9 = FUN_601678fc(uVar1,uVar5,0x56bdc946,0x3f08b0c8);
  FUN_601682c8((int)uVar9,(int)((ulonglong)uVar9 >> 0x20),0xe0ded289,0x4071af0b);
  fVar4 = (float)FUN_601672d4();
  coprocessor_function2(10,3,0,in_cr0,in_cr0,in_cr1);
  *param_1 = fVar4 + fVar3;
  return;
}
