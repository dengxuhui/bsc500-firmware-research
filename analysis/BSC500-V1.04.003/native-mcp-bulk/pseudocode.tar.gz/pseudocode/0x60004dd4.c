
void FUN_60004dd4(void)

{
  FUN_6000df90();
  FUN_6000af0c();
  return;
}
