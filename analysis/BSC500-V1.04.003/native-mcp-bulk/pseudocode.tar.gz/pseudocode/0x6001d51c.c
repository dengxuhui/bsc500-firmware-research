
undefined4 FUN_6001d51c(int *param_1)

{
  int iVar1;
  int iVar2;
  char *pcVar3;
  uint uVar4;
  undefined4 uVar5;
  int *piVar6;
  char acStack_154 [4];
  undefined2 auStack_150 [54];
  undefined1 auStack_e4 [96];
  undefined1 auStack_84 [80];
  undefined1 auStack_34 [24];
  
  ZeroBytes(auStack_34,0x15);
  ZeroBytes(auStack_84,0x50);
  ZeroBytes(auStack_e4,0x60);
  ZeroBytes(acStack_154,0x6e);
  FUN_601681f4(auStack_34,&UNK_6001d764,param_1[2]);
  piVar6 = param_1 + 3;
  iVar1 = FUN_60168220(piVar6);
  CopyBytes(auStack_e4,piVar6,iVar1 + 1);
  FUN_60161fb8(0x2007b390);
  iVar1 = *param_1;
  if (iVar1 == 1) {
    FUN_6015ee0c(0x2007b390,0x2000585c,".fit",0,0,0,0);
    piVar6 = (int *)0x2007b398;
    do {
      piVar6 = (int *)*piVar6;
      if (piVar6 == (int *)0x2007b398) goto LAB_6001d754;
      ZeroBytes(auStack_84,0x50);
      ZeroBytes(acStack_154,0x6e);
      uVar4 = piVar6[-1];
      if (0x4e < uVar4) {
        uVar4 = 0x4e;
      }
      CopyBytes(auStack_84,piVar6[-2],uVar4);
      iVar1 = FUN_60166834(auStack_84,auStack_34);
    } while (iVar1 == 0);
    uVar5 = 0x2000585c;
LAB_6001d736:
    pcVar3 = acStack_154;
    FUN_601681f4(pcVar3,"%s/%s",uVar5,auStack_84);
LAB_6001d750:
    FUN_6015c57c(pcVar3);
  }
  else if (iVar1 == 0xf) {
LAB_6001d58c:
    if (param_1[2] != 0) {
      FUN_6015ee0c(0x2007b390,0x20005712,&UNK_6001d7c0,".fit",&UNK_6001d7b4,&UNK_6001d7ac,0);
      piVar6 = (int *)0x2007b398;
      do {
        piVar6 = (int *)*piVar6;
        if (piVar6 == (int *)0x2007b398) goto LAB_6001d754;
        ZeroBytes(auStack_84,0x50);
        ZeroBytes(acStack_154,0x6e);
        uVar4 = piVar6[-1];
        if (0x4e < uVar4) {
          uVar4 = 0x4e;
        }
        CopyBytes(auStack_84,piVar6[-2],uVar4);
        iVar1 = FUN_60166834(auStack_84,auStack_34);
      } while ((iVar1 == 0) || (iVar1 = FUN_60166834(auStack_84,auStack_e4), iVar1 == 0));
      iVar1 = FUN_6012b774(auStack_84);
      uVar5 = 0;
      if (iVar1 != 0) goto LAB_6001d756;
      FUN_601681f4(acStack_154,"%s/%s",0x20005712,auStack_84);
      FUN_6015c57c(acStack_154);
      iVar1 = FUN_60168220(acStack_154);
      iVar2 = FUN_60168220(acStack_154);
      builtin_strncpy(acStack_154 + iVar2,".tcn",4);
      *(undefined2 *)((int)auStack_150 + iVar2) = 0x78;
      FUN_6015c57c(acStack_154);
      acStack_154[iVar1] = '\0';
      iVar2 = FUN_60168220(acStack_154);
      builtin_strncpy(acStack_154 + iVar2,".tna",4);
      *(undefined2 *)((int)auStack_150 + iVar2) = 0x76;
      FUN_6015c57c(acStack_154);
      acStack_154[iVar1] = '\0';
      iVar2 = FUN_60168220(acStack_154);
      builtin_strncpy(acStack_154 + iVar2,".tcl",4);
      *(undefined2 *)((int)auStack_150 + iVar2) = 0x6d;
      FUN_6015c57c(acStack_154);
      acStack_154[iVar1] = '\0';
      iVar1 = FUN_60168220(acStack_154);
      builtin_strncpy(acStack_154 + iVar1,".tsg",4);
      *(undefined2 *)((int)auStack_150 + iVar1) = 0x6e;
      FUN_6015c57c(acStack_154);
    }
  }
  else {
    if (iVar1 == 8) {
      FUN_6015ee0c(0x2007b390,0x2000578a,&UNK_6001d798,0,0,0,0);
      piVar6 = (int *)0x2007b398;
      do {
        piVar6 = (int *)*piVar6;
        if (piVar6 == (int *)0x2007b398) goto LAB_6001d754;
        ZeroBytes(auStack_84,0x50);
        ZeroBytes(acStack_154,0x6e);
        uVar4 = piVar6[-1];
        if (0x4e < uVar4) {
          uVar4 = 0x4e;
        }
        CopyBytes(auStack_84,piVar6[-2],uVar4);
        iVar1 = FUN_60166834(auStack_84,auStack_34);
      } while (iVar1 == 0);
      uVar5 = 0x2000578a;
      goto LAB_6001d736;
    }
    if (iVar1 == 0xb) {
      iVar1 = FUN_60168418(piVar6,"Schedules");
      if (iVar1 == 0) {
        pcVar3 = "0:/iGPSPORT/Schedule/Schedules.fit";
        goto LAB_6001d750;
      }
    }
    else if (iVar1 == 2) goto LAB_6001d58c;
  }
LAB_6001d754:
  uVar5 = 1;
LAB_6001d756:
  FUN_601607f4(0x2007b390);
  return uVar5;
}
