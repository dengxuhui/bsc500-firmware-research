
undefined4 FUN_6000ad50(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined1 auStack_44 [48];
  
  iVar2 = 0x200076c0;
  iVar3 = 0xd;
  do {
    if (iVar3 == 0) {
      iVar2 = 0;
      do {
        if (iVar2 == 0x1a4) {
          return 1;
        }
        iVar3 = FUN_6015c8a2(auStack_44,iVar2 + 0x20007428);
        if (iVar3 == 0) {
          FUN_6015bd24(auStack_44);
        }
        else if ((iVar3 == 0xd) || (iVar3 = FUN_6015ad48(iVar2 + 0x20007428), iVar3 != 0)) {
          return 0;
        }
        iVar2 = iVar2 + 0x23;
      } while( true );
    }
    iVar1 = FUN_6015c8a2(auStack_44,iVar2);
    if (iVar1 == 0) {
      FUN_6015bd24(auStack_44);
    }
    else {
      if (iVar1 == 0xd) {
        return 0;
      }
      iVar1 = FUN_6015ad48(iVar2);
      if (iVar1 != 0) {
        return 0;
      }
    }
    iVar2 = iVar2 + 0x23;
    iVar3 = iVar3 + -1;
  } while( true );
}
