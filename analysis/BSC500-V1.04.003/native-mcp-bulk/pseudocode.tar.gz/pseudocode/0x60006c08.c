
void FUN_60006c08(undefined4 param_1,uint param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  bool bVar2;
  bool bVar3;
  byte in_Q;
  
  uVar1 = param_2 | param_4;
  if ((int)uVar1 < 0) {
    if ((int)(uVar1 + 0x100000) < 0) {
      if (-1 < (int)(uVar1 - 0x100000)) {
        return;
      }
      if (param_4 == param_2) {
        return;
      }
      return;
    }
    if (param_2 << 1 < 0xffe00000 && param_4 << 1 < 0xffe00000) {
      return;
    }
  }
  else {
    bVar3 = SCARRY4(uVar1,0x100000);
    bVar2 = -1 < (int)(uVar1 + 0x100000);
    if (bVar2) {
      bVar3 = SBORROW4(uVar1,0x100000);
    }
    if (bVar2 && -1 < (int)(uVar1 - 0x100000)) {
      if (param_2 == param_4) {
        return;
      }
      return;
    }
    if (!bVar3) {
      return;
    }
    if (-1 < (int)(param_2 + 0x100000) && -1 < (int)(param_4 + 0x100000)) {
      return;
    }
  }
  FUN_60167aae();
  (*(code *)0x60006c70)((uint)(in_Q | 0x10) << 0x1b);
  return;
}
