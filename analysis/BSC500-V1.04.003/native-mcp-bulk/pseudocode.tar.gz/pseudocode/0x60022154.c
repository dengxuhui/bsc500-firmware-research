
undefined4 FUN_60022154(int param_1)

{
  uint uVar1;
  int iVar2;
  
  if ((param_1 != 0) && (uVar1 = FUN_60168220(), uVar1 < 0x5f)) {
    FUN_601681f4(0x2008b0e4,&UNK_600221ec,param_1);
    iVar2 = FUN_60166758(0x2000b0ac,0x2008b0e4,10);
    if (iVar2 == 0) {
      uRam2000b0b4 = 100;
      uRam2000b0ec = 0;
      iVar2 = FUN_60135e50(0x2000b0ac);
      if (((iVar2 == 0) && (iVar2 = FUN_60136026(0x2000b0ac,0x2000b0b0), iVar2 == 0)) &&
         (iVar2 = FUN_60135fe0(0x2000b0ac,0), iVar2 == 0)) {
        FUN_6013a686(0x200895f0);
        FUN_6013a670(0x2000b0c0);
        FUN_6013a65a(0x2000b0d8);
        if (iRam2000b0a8 != 0) {
          FUN_601667bc();
          iRam2000b0a8 = 0;
        }
        FUN_6015b858();
        return 0;
      }
      FUN_601667bc(uRam2000b0ac);
      uRam2000b0ac = 0;
      FUN_60163bbe(0x2008b0e4);
    }
    else {
      uRam2000b0ac = 0;
    }
  }
  return 0xffffffff;
}
