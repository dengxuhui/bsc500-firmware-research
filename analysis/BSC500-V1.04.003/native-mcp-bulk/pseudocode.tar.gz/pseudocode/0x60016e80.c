
void FUN_60016e80(undefined4 *param_1)

{
  FUN_601608ac(param_1,0x58);
  *param_1 = 0xf00140;
  param_1[1] = 0xffffffff;
  param_1[2] = 0;
  param_1[0x10] = 0x6002c259;
  param_1[0x11] = 0x6002c259;
  param_1[0x12] = 0x54;
  *(undefined2 *)(param_1 + 0xe) = 0x7e0;
  param_1[4] = param_1[4] & 0xfffe0037 | 0x4108;
  return;
}
