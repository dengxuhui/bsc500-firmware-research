
void FUN_6002eb60(undefined4 param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_2 + 0x24);
  if (iVar1 != 0) {
    if (*(char *)(param_2 + 0x10) == '\x01') {
      FUN_60160a64(iVar1);
    }
    if (*(int *)(iVar1 + 0xc) != 0) {
      FUN_60160aa4();
    }
    if (*(int *)(iVar1 + 0x10) != 0) {
      FUN_60160aa4();
    }
    FUN_60160aa4(iVar1);
    *(undefined4 *)(param_2 + 0x24) = 0;
  }
  return;
}
