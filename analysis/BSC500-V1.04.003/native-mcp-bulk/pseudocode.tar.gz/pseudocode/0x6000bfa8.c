
void FUN_6000bfa8(char *param_1,int param_2)

{
  bool bVar1;
  int iVar2;
  undefined1 *puVar3;
  uint uVar4;
  
  if ((*(short *)(param_1 + 0xd0) == -1) || (param_1[0x8c] != '\x01')) {
    if (param_1[0xcc] != '\0') {
      bVar1 = false;
      if (((int)*(short *)(param_1 + 0x26) != 0x7fff) &&
         (*(uint *)(param_2 + 4) < (uint)(int)*(short *)(param_1 + 0x26))) {
        bVar1 = true;
      }
      iVar2 = FUN_6015c548(*(undefined4 *)(param_1 + 0xc4),0);
      if ((!bVar1) && (iVar2 != 0)) {
        puVar3 = (undefined1 *)0x2000adab;
        cRam2000adaa = 0;
        if (bRam2000adab != 0) {
          puVar3 = (undefined1 *)(param_2 + 0x329);
        }
        *puVar3 = 1;
        return;
      }
      if (cRam2000adaa == '\x01') {
        *(undefined1 *)(param_2 + 0x329) = 0;
        bRam2000adab = 0;
        return;
      }
      cRam2000adaa = 1;
      bRam2000adab = 0;
      return;
    }
    iVar2 = FUN_6011679c(0,param_1[0xda],param_1[0xd8],*(undefined2 *)(param_1 + 0xd6));
    if (iVar2 == 0) {
      if ((*param_1 == '\0') || (iVar2 = FUN_6012d794(), iVar2 != 0)) goto LAB_6000c074;
      uVar4 = *(uint *)(param_1 + 0xac);
      if (*(char *)(param_2 + 0x329) != '\0') {
        if ((uVar4 < uRam20055600) && (10000 < uRam20055600 - uVar4)) {
          *(undefined1 *)(param_2 + 0x329) = 0;
        }
        bRam2000adab = 0;
        return;
      }
      if (uRam20055600 <= uVar4) {
        bRam2000adab = 0;
        return;
      }
      if (0x5dc < (uRam20055600 - uVar4) - 500) {
        bRam2000adab = 0;
        return;
      }
      bRam2000adab = bRam2000adab + 1;
      if (bRam2000adab < 3) {
        return;
      }
    }
    else {
      cRam2000adaa = '\0';
    }
  }
  else {
    if ((((int)*(short *)(param_1 + 0x26) != 0x7fff) &&
        (*(uint *)(param_2 + 4) < (uint)(int)*(short *)(param_1 + 0x26))) ||
       (iVar2 = FUN_6011679c(*(short *)(param_1 + 0xd0),0,0,0), iVar2 == 0)) {
LAB_6000c074:
      bRam2000adab = 0;
      *(undefined1 *)(param_2 + 0x329) = 0;
      return;
    }
    cRam2000adaa = '\0';
  }
  *(undefined1 *)(param_2 + 0x329) = 1;
  return;
}
