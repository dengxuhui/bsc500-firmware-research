
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60015da0(int param_1,undefined4 *param_2,int *param_3)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  short local_3a;
  int local_38 [2];
  undefined4 auStack_30 [3];
  
  auStack_30[1] = 0;
  local_38[1] = 0;
  auStack_30[0] = 0;
  if ((param_1 == 0) || (iVar1 = FUN_6016506c(param_1), iVar1 == 0)) {
LAB_60015e3c:
    uVar3 = 0xffffffff;
  }
  else {
    do {
      iVar1 = FUN_6015d9d4(param_1);
      if (iVar1 != 0) goto LAB_60015e3c;
      iVar1 = 0;
      while ((iVar1 != 8 && (iVar2 = FUN_6015d9d4(param_1), iVar2 == 0))) {
        FUN_60161ef4(param_1,(int)auStack_30 + iVar1,1,local_38 + 1);
        iVar1 = iVar1 + 1;
      }
      FUN_60138740(_DAT_2000b300,_DAT_2000b304,auStack_30,iVar1,local_38,&local_3a);
    } while ((local_3a != 0x14) || (local_38[0] == 0));
    *param_2 = *(undefined4 *)(local_38[0] + 0xc);
    iVar1 = (uint)*(ushort *)(local_38[0] + 0x14) * 0x14 + -50000;
    if (*(ushort *)(local_38[0] + 0x14) == 0xffff) {
      iVar1 = 0x7fffffff;
    }
    *param_3 = iVar1;
    uVar3 = 0;
  }
  return uVar3;
}
