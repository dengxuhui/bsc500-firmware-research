
bool FUN_6001cc80(void)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_60029020();
  if (iVar1 == 0) {
    return false;
  }
  piVar2 = (int *)FUN_6015d9e4();
  if ((*(char *)(*piVar2 + (uint)bRam200828c2) == ' ') &&
     (*(char *)(*piVar2 + (uint)bRam200828c3) == ' ')) {
    return true;
  }
  iVar1 = FUN_6016727c("List.fit",0x200828c2,9);
  return iVar1 == 0;
}
