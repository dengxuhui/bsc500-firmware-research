
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60021198 */
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4
FUN_60020be0(undefined *param_1,uint param_2,undefined4 param_3,int param_4,undefined4 param_5,
            undefined4 param_6,int param_7)

{
  int iVar1;
  undefined *puVar2;
  char *pcVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int *piVar9;
  int iVar10;
  int iVar11;
  int *piVar12;
  int iVar13;
  undefined8 *puVar14;
  uint uVar15;
  uint uVar16;
  int iVar17;
  undefined4 *puVar18;
  uint uVar19;
  int iVar20;
  uint uVar21;
  int iVar22;
  undefined8 *puVar23;
  int iVar24;
  undefined8 *puVar25;
  uint uVar26;
  bool bVar27;
  undefined8 in_d0;
  undefined8 uVar28;
  undefined8 uVar29;
  undefined4 *local_1b4;
  undefined4 local_18c;
  undefined4 uStack_188;
  undefined4 local_184;
  undefined4 uStack_180;
  int local_17c [3];
  undefined8 auStack_170 [6];
  undefined4 local_13c;
  int local_138 [5];
  char local_124 [132];
  undefined1 local_a0 [8];
  undefined4 local_98;
  undefined4 uStack_94;
  int local_8c [20];
  undefined4 local_3c;
  
  ZeroBytes(local_124,0x80);
  local_138[3] = 0;
  local_138[4] = 0;
  local_138[1] = 0;
  local_138[2] = 0;
  local_184 = 0;
  uStack_180 = 0;
  local_13c = 0;
  local_138[0] = 0;
  local_18c = 0;
  uStack_188 = 0;
  local_17c[0] = -1;
  local_17c[1] = 0;
  local_17c[2] = 0;
  if (iRam2000b104 != 0) {
    return 0xffffffff;
  }
  if (iRam2000b108 != 0) {
    return 0xffffffff;
  }
  if (iRam2000b10c != 0) {
    return 0xffffffff;
  }
  if (iRam2000b110 != 0) {
    return 0xffffffff;
  }
  if (iRam2007d264 != 0) {
    FUN_601495f0("%s in progress!!\r\n","qw_router_impl");
    return 0xffffffff;
  }
  uVar26 = 1;
  iRam2007d264 = 1;
  FUN_6005b53a();
  uVar21 = 1;
  uRam2007d268 = param_6;
  uRam2000af08 = 0;
  _DAT_2000af0c = 0;
  uRam2000af4c = 0;
  builtin_strncpy(local_124,"0:/iGPSPORT/Router",0x13);
  bVar27 = param_2 != 2;
  if (bVar27 || param_1 == (undefined *)0x0) {
    param_2 = 2;
  }
  uVar19 = 2;
  puVar2 = &UNK_602a9ef0;
  if (!bVar27 && param_1 != (undefined *)0x0) {
    puVar2 = param_1;
  }
  puVar14 = (undefined8 *)(puVar2 + 8);
  puVar25 = auStack_170;
  puVar23 = auStack_170 + 4;
  for (; puVar25 = puVar25 + 1, uVar21 <= param_2; uVar21 = uVar21 + 1) {
    local_138[uVar21 - 1] = local_138[uVar21 - 1] + 3;
    uVar29 = *puVar14;
    uVar28 = FUN_601678fc((int)puVar14[-1],(int)((ulonglong)puVar14[-1] >> 0x20),0xa2529d39,
                          0x3f91df46);
    *puVar23 = uVar28;
    in_d0 = FUN_601678fc((int)uVar29,(int)((ulonglong)uVar29 >> 0x20),0xa2529d39,0x3f91df46);
    puVar23 = puVar23 + 1;
    puVar14 = puVar14 + 2;
    *puVar25 = in_d0;
    if ((uVar26 & 0xffff) < uVar21) {
      uVar26 = uVar21;
    }
    if (uVar21 < (uVar19 & 0xffff)) {
      uVar19 = uVar21;
    }
  }
  uRam20008310 = 5;
  switch(param_3) {
  case 0:
  case 2:
    uRam20008310 = 4;
    break;
  case 1:
    uRam20008310 = 1;
    break;
  case 4:
    uRam20008310 = 7;
  }
  uRam20008378 = param_5;
  iVar10 = 0;
  do {
    if (iVar10 == 2) {
      uVar26 = uVar26 & 0xffff;
      if (uVar26 <= (uVar19 & 0xffff)) {
        pcVar3 = "Error: At least two waypoints must be specified.\r";
        goto LAB_60020e3e;
      }
      FUN_601681f4(&local_18c,&UNK_60021490,0x2000b114);
      uStack_188._0_3_ = CONCAT12(0x4e,(undefined2)uStack_188);
      FUN_600fe938(local_124,0,&local_18c);
      iVar10 = FUN_60058a60();
      if (iVar10 == 0) {
        FUN_601368b0();
        FUN_60106338();
        iRam2007d264 = 0;
        return 0xffffffff;
      }
      uStack_188._0_3_ = CONCAT12(0x53,(undefined2)uStack_188);
      FUN_600fe938(local_124,0,&local_18c);
      iVar4 = FUN_60058b96();
      if (iVar4 == 0) {
        FUN_60136886(iVar10);
      }
      else {
        uStack_188._0_3_ = CONCAT12(0x57,(undefined2)uStack_188);
        FUN_600fe938(local_124,0,&local_18c);
        iVar5 = FUN_60058c0a();
        if (iVar5 == 0) {
          FUN_60136886(iVar10);
          FUN_60136860(iVar4);
        }
        else {
          uStack_188._0_3_ = CONCAT12(0x52,(undefined2)uStack_188);
          FUN_600fe938(local_124,0,&local_18c);
          iVar6 = FUN_60058afc();
          if (iVar6 != 0) {
            iVar7 = FUN_60058d30(0x2000830c,iVar5);
            if (iVar7 != 0) {
              FUN_60149068(0x603fc650);
              FUN_60136886(iVar10);
              goto LAB_60021016;
            }
            uRam20008384 = 0xffff;
            uVar21 = uVar19;
            goto LAB_60020ec2;
          }
          FUN_60136886(iVar10);
          FUN_60136860(iVar4);
          FUN_60136820(iVar5);
        }
      }
      FUN_601368b0();
      FUN_60106338();
      iRam2007d264 = 0;
      return 0xffffffff;
    }
    piVar9 = local_138 + iVar10;
    iVar10 = iVar10 + 1;
  } while (1 < *piVar9 - 1U);
  pcVar3 = "Error: All waypoints must have latitude and longitude.\r";
LAB_60020e3e:
  FUN_60149068(pcVar3);
LAB_60020e42:
  FUN_601368b0();
  FUN_60106338();
  iRam2007d264 = 0;
  return 0xffffffff;
LAB_60020ec2:
  uVar15 = uVar21 & 0xffff;
  if (uVar15 <= uVar26) {
    if (local_138[uVar15 - 1] != 3) goto LAB_60020f44;
    in_d0 = auStack_170[uVar15];
    iVar7 = FUN_60033ad0((int)in_d0,(int)((ulonglong)in_d0 >> 0x20),(int)auStack_170[uVar15 + 3],
                         iVar10,iVar4,iVar5,1000);
    if (iVar7 != -1) {
      uVar8 = FUN_60136b1c(iVar4,iVar7,1);
      iVar7 = FUN_60025718(iVar10,iVar4,uVar15,uVar8);
      if (iVar7 != -1) {
        local_17c[uVar15] = iVar7;
        goto LAB_60020f44;
      }
    }
    FUN_601495f0(0x603fc5aa,uVar15);
    FUN_60136886(iVar10);
LAB_60021016:
    FUN_60136860(iVar4);
    goto LAB_6002101c;
  }
  goto LAB_60020f4a;
LAB_60020f44:
  uVar21 = uVar21 + 1;
  goto LAB_60020ec2;
LAB_60020f4a:
  uVar8 = FUN_6016759c(param_4);
  iVar24 = 0;
  iVar22 = -1;
  iVar7 = -1;
  uVar21 = 0xffff;
  do {
    uVar15 = uVar19 & 0xffff;
    if (uVar26 + 1 == uVar15) {
      FUN_60149068(0x603fc68b);
      local_8c[0x12] = 1;
      local_8c[0x10] = 1;
      local_8c[0x11] = 0x7fffffff;
      local_8c[0xe] = 1;
      local_8c[0xf] = 0x7fffffff;
      local_8c[0xc] = 1;
      local_8c[0xd] = 0x7fffffff;
      local_8c[10] = 1;
      local_8c[0xb] = 0x7fffffff;
      local_8c[8] = 1;
      local_8c[9] = 0x7fffffff;
      local_8c[6] = 0;
      local_8c[7] = 0x7fffffff;
      local_8c[4] = 0;
      local_8c[5] = 0;
      local_8c[2] = 0;
      local_8c[3] = 0;
      local_3c = 0;
      local_8c[0] = 0;
      local_8c[1] = 0;
      FUN_601681f4(local_8c + 1,0x603fc695,0x2000b114);
      uVar8 = FUN_600fe938("0:/iGPSPORT/Router",0,local_8c + 1);
      iVar7 = FUN_60166758(local_8c,uVar8,1);
      if (iVar7 != 0) {
        local_8c[0] = 0;
      }
      iVar7 = FUN_60161ab0(0x708);
      if (iVar7 == 0) {
        FUN_60149068(0x603fc5e0);
      }
      else {
        ZeroBytes(iVar7,0x708);
        if ((param_7 == 0) || (uVar26 = FUN_60168220(param_7), 0x7f < uVar26)) {
          param_7 = 0x603fc69d;
        }
        iVar22 = FUN_60166758(&local_3c,param_7,10);
        if (iVar22 == 0) {
          FUN_60028f58(local_3c);
          local_1b4 = (undefined4 *)(iVar7 + 4);
          iVar22 = 0;
          do {
            iVar20 = local_138[iVar22 + 2];
            piVar9 = (int *)FUN_6012726c(iVar20,*(undefined4 *)(iVar20 + 0x20),
                                         *(undefined4 *)(iVar20 + 0x24));
            iVar20 = iVar22 + 1;
            do {
              iVar11 = *piVar9;
              if (iVar11 + 0x10000U < 0xffff) {
                FUN_60133d58(iVar11,&local_98,local_a0);
              }
              else {
                uVar8 = FUN_60058c9e(iVar10,iVar11,6);
                FUN_60136908(iVar10,*piVar9,uVar8,&local_98);
              }
              piVar12 = (int *)piVar9[3];
              iVar11 = iVar20;
              if (piVar12 != (int *)0x0) {
                iVar11 = iVar22;
              }
              if ((iVar20 < iVar24) && (piVar12 == (int *)0x0)) {
                iVar11 = local_138[iVar22 + 3];
                iVar11 = FUN_6012726c(iVar11,*(undefined4 *)(iVar11 + 0x20),
                                      *(undefined4 *)(iVar11 + 0x24));
                piVar12 = *(int **)(iVar11 + 0xc);
                iVar11 = iVar20;
              }
              iVar13 = *piVar9;
              if (iVar13 + 0x10000U < 0xffff) {
                iVar13 = FUN_60025ae0(local_98,(int)((ulonglong)in_d0 >> 0x20),local_a0._0_4_,iVar10
                                      ,iVar4,iVar5,1000);
              }
              iVar13 = FUN_6002f60a(local_8c[0],iVar13);
              if ((iVar13 - 0x7fffU & 0xffff) < 2) {
                iVar13 = 0;
              }
              uVar28 = FUN_601678fc(local_98,uStack_94,0x1a63c1f8,0x404ca5dc);
              FUN_601678fc((int)uVar28,(int)((ulonglong)uVar28 >> 0x20),0,0x416312d0);
              uVar8 = FUN_60167a50();
              if (local_8c[0xd] == 0x7fffffff) {
                FUN_60162cb0(local_8c + 0xd,uVar8,10000000);
                uVar28 = FUN_601678fc(local_a0._0_4_,local_a0._4_4_,0x1a63c1f8,0x404ca5dc);
                FUN_601678fc((int)uVar28,(int)((ulonglong)uVar28 >> 0x20),0,0x416312d0);
                uVar8 = FUN_60167a50();
                FUN_60162cb0(local_8c + 0xb,uVar8,10000000);
                FUN_600f82f8(local_3c,local_8c + 0xd,local_8c + 0xb,iVar13 * 100);
              }
              else {
                FUN_60162cb0(local_8c + 0x11,uVar8,10000000);
                uVar28 = FUN_601678fc(local_a0._0_4_,local_a0._4_4_,0x1a63c1f8,0x404ca5dc);
                FUN_601678fc((int)uVar28,(int)((ulonglong)uVar28 >> 0x20),0,0x416312d0);
                uVar8 = FUN_60167a50();
                FUN_60162cb0(local_8c + 0xf,uVar8,10000000);
                FUN_6015ce30(local_8c + 6,local_8c + 0x11,local_8c + 0xf,local_8c + 0xd);
                iVar1 = local_8c[5];
                uVar26 = VectorFloatToUnsigned(local_8c[6],3);
                if (2000 < uVar26) {
                  local_8c[0xd] = local_8c[0x11];
                  local_8c[0xe] = local_8c[0x12];
                  local_8c[0xb] = local_8c[0xf];
                  local_8c[0xc] = local_8c[0x10];
                  if ((uint)local_8c[5] < 0x96) {
                    uVar8 = FUN_6015e874(local_8c + 0x11,10000000);
                    iVar17 = iVar7 + iVar1 * 0xc;
                    *(undefined4 *)(iVar17 + 4) = uVar8;
                    uVar8 = FUN_6015e874(local_8c + 0xf,10000000);
                    *(undefined4 *)(iVar7 + iVar1 * 0xc) = uVar8;
                    *(int *)(iVar17 + 8) = iVar13 * 100;
                    local_8c[5] = local_8c[5] + 1;
                    if (0x95 < (uint)local_8c[5]) {
                      FUN_600301dc(iVar7,local_8c + 5,1000);
                      puVar18 = local_1b4;
                      for (uVar26 = 0; uVar26 < (uint)local_8c[5]; uVar26 = uVar26 + 1) {
                        FUN_60162cb0(local_8c + 9,*puVar18,10000000);
                        FUN_60162cb0(local_8c + 7,puVar18[-1],10000000);
                        FUN_600f82f8(local_3c,local_8c + 9,local_8c + 7,puVar18[1]);
                        puVar18 = puVar18 + 3;
                      }
                      local_8c[5] = 0;
                      ZeroBytes(iVar7,0x708);
                    }
                  }
                }
              }
              piVar9 = piVar12;
            } while (iVar22 == iVar11);
            iVar22 = iVar11;
          } while (iVar11 < iVar24);
          if (local_8c[5] - 1U < 0x95) {
            FUN_600301dc(iVar7,local_8c + 5,1000);
            for (uVar26 = 0; uVar26 < (uint)local_8c[5]; uVar26 = uVar26 + 1) {
              FUN_60162cb0(local_8c + 9,*local_1b4,10000000);
              FUN_60162cb0(local_8c + 7,local_1b4[-1],10000000);
              FUN_600f82f8(local_3c,local_8c + 9,local_8c + 7,local_1b4[1]);
              local_1b4 = local_1b4 + 3;
            }
            ZeroBytes(iVar7,0x708);
          }
          FUN_60028f08(local_3c);
          if (local_8c[0] != 0) {
            FUN_601667bc();
          }
        }
        else {
          FUN_60149068(0x603fc600);
        }
        FUN_6015ccd4(iVar7);
      }
      FUN_60058924();
      for (uVar26 = 0; (int)(uVar26 & 0xffff) < iVar24; uVar26 = uVar26 + 1) {
        FUN_60127138(local_138[(uVar26 & 0xffff) + 2]);
      }
      FUN_60136886(iVar10);
      FUN_60136860(iVar4);
      FUN_60136820(iVar5);
      FUN_601367d4(iVar6);
      FUN_601368b0();
      FUN_60106338();
      FUN_6005b538();
      iRam2007d264 = 0;
      return 0;
    }
    iVar20 = iVar7;
    uVar16 = uVar21;
    if ((local_138[uVar15 - 1] == 3) && (iVar20 = local_17c[uVar15], uVar16 = uVar19, iVar7 != -1))
    {
      if ((param_4 != -999) && (iVar22 == -1)) {
        FUN_60025f10(uVar8,iVar10,iVar4,iVar5,iVar7);
      }
      FUN_601495f0("Routing from waypoint %d to waypoint %d\n",uVar21 & 0xffff,uVar15);
      iVar7 = FUN_600248b8(iVar10,iVar4,iVar5,iVar6);
      local_138[iVar24 + 2] = iVar7;
      if (iVar7 == 0) {
        FUN_60136886(iVar10);
        FUN_60136860(iVar4);
LAB_6002101c:
        FUN_60136820(iVar5);
        FUN_601367d4(iVar6);
        goto LAB_60020e42;
      }
      iVar22 = *(int *)(iVar7 + 0x2c);
      iVar24 = iVar24 + 1;
    }
    uVar19 = uVar19 + 1;
    iVar7 = iVar20;
    uVar21 = uVar16;
  } while( true );
}
