
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x6001a55e */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_6001a500(int *param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined8 *puVar4;
  int iVar5;
  uint uVar6;
  float fVar7;
  undefined8 uVar8;
  undefined4 uVar9;
  undefined8 uVar10;
  undefined8 uVar11;
  
  uVar1 = 0xffffffff;
  if (((param_1 != (int *)0x0) && (param_2 != 0)) && (param_3 != 0)) {
    uVar6 = param_1[2];
    FUN_60100c64(*param_1 + uVar6 * 0x18);
    iVar2 = param_1[2];
    param_1[2] = iVar2 + 1U;
    if (uVar6 < 2) {
      if (iVar2 != 0) {
        return 1;
      }
      FUN_60100c64(param_3,*param_1);
    }
    else {
      puVar4 = (undefined8 *)*param_1;
      if (iVar2 + 1U < (uint)param_1[1]) {
        puVar3 = puVar4 + iVar2 * 3;
        uVar1 = (undefined4)*puVar4;
        FUN_60161ad0(uVar1,(int)((ulonglong)*puVar4 >> 0x20),(int)puVar4[1],
                     (int)((ulonglong)puVar4[1] >> 0x20),(int)*puVar3,
                     (int)((ulonglong)*puVar3 >> 0x20),(int)puVar3[1],puVar3 + 2,puVar4 + 2);
        uVar6 = 0;
        iVar2 = 0;
        do {
          uVar6 = uVar6 + 1;
          if (param_1[2] - 1U <= uVar6) {
            return 1;
          }
          puVar4 = (undefined8 *)*param_1;
          uVar8 = *(undefined8 *)((int)puVar4 + iVar2 + 0x18);
          uVar10 = *(undefined8 *)((int)puVar4 + iVar2 + 0x20);
          FUN_60161ad0((int)uVar8,(int)((ulonglong)uVar8 >> 0x20),(int)uVar10,
                       (int)((ulonglong)uVar10 >> 0x20),(int)*puVar4,
                       (int)((ulonglong)*puVar4 >> 0x20),(int)puVar4[1],puVar4 + 2);
          iVar5 = *param_1 + iVar2;
          uVar8 = *(undefined8 *)(iVar5 + 0x18);
          uVar10 = *(undefined8 *)(iVar5 + 0x20);
          iVar5 = *param_1 + param_1[2] * 0x18;
          uVar11 = *(undefined8 *)(iVar5 + -0x18);
          uVar9 = (undefined4)((ulonglong)uVar8 >> 0x20);
          fVar7 = (float)uVar8;
          FUN_60161ad0(fVar7,uVar9,(int)uVar10,(int)((ulonglong)uVar10 >> 0x20),(int)uVar11,
                       (int)((ulonglong)uVar11 >> 0x20),(int)*(undefined8 *)(iVar5 + -0x10));
          FUN_60136d08(uVar1,uVar9,fVar7);
          iVar2 = iVar2 + 0x18;
        } while (fVar7 <= (float)param_1[3]);
        puVar4 = (undefined8 *)(*param_1 + param_1[2] * 0x18 + -0x30);
      }
      else {
        puVar4 = puVar4 + iVar2 * 3 + -3;
      }
      FUN_60100c64(param_3,puVar4);
      FUN_60100c64(*param_1,*param_1 + param_1[2] * 0x18 + -0x30);
      FUN_60100c64(*param_1 + 0x18,*param_1 + param_1[2] * 0x18 + -0x18);
      param_1[2] = 2;
    }
    uVar1 = 0;
  }
  return uVar1;
}
