
undefined4 FUN_60029cc8(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 uVar2;
  undefined8 uVar3;
  undefined8 uVar4;
  
  iVar1 = FUN_60123188();
  uVar2 = 0;
  if (((iVar1 != 0) && (iVar1 = FUN_60123188(param_2), iVar1 != 0)) &&
     (iVar1 = FUN_6003a548(param_1,param_2), iVar1 != 1)) {
    uVar3 = *param_2;
    uVar4 = FUN_601678fc((int)param_2[1],(int)((ulonglong)param_2[1] >> 0x20),0x54442d18,0x400921fb)
    ;
    uVar2 = FUN_601675d8((int)uVar4,(int)((ulonglong)uVar4 >> 0x20),0,0x40668000);
    uVar3 = FUN_60165558((int)uVar3,(int)((ulonglong)uVar3 >> 0x20),(int)*param_1,
                         (int)((ulonglong)*param_1 >> 0x20));
    uVar2 = FUN_6015dac8(uVar2);
    uVar3 = FUN_601678fc((int)uVar3,(int)((ulonglong)uVar3 >> 0x20),uVar2,extraout_s1);
    uVar3 = FUN_601678fc((int)uVar3,(int)((ulonglong)uVar3 >> 0x20),0,0x40fb1980);
    uVar2 = (undefined4)((ulonglong)uVar3 >> 0x20);
    uVar3 = FUN_601678fc((int)uVar3,uVar2,(int)uVar3,uVar2);
    uVar4 = FUN_60165558((int)param_2[1],(int)((ulonglong)param_2[1] >> 0x20),(int)param_1[1],
                         (int)((ulonglong)param_1[1] >> 0x20));
    uVar4 = FUN_601678fc((int)uVar4,(int)((ulonglong)uVar4 >> 0x20),0,0x40fb1980);
    uVar2 = (undefined4)((ulonglong)uVar4 >> 0x20);
    uVar4 = FUN_601678fc((int)uVar4,uVar2,(int)uVar4,uVar2);
    uVar2 = FUN_601682c8((int)uVar3,(int)((ulonglong)uVar3 >> 0x20),(int)uVar4,
                         (int)((ulonglong)uVar4 >> 0x20));
    uVar2 = FUN_6015d550(uVar2);
    uVar2 = FUN_601672d4(uVar2,extraout_s1_00);
  }
  return uVar2;
}
