
int * FUN_6002f64e(undefined4 param_1,undefined4 param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  
  piVar1 = (int *)FUN_60162e34(8);
  if (piVar1 != (int *)0x0) {
    if (param_3 == 0) {
      iVar2 = FUN_6012a4e4(param_1,param_2,0);
      *piVar1 = iVar2;
      *(undefined1 *)(piVar1 + 1) = 1;
    }
    else {
      iVar2 = FUN_60162e34(0x38);
      *piVar1 = iVar2;
      *(undefined1 *)(piVar1 + 1) = 0;
      FUN_6015b3a0(iVar2,param_1,param_3,param_2,0);
      iVar2 = *piVar1;
    }
    if (iVar2 != 0) {
      return piVar1;
    }
    FUN_60166c0c(piVar1);
  }
  return (int *)0x0;
}
