
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001a8b4(void)

{
  return _DAT_2008dbe8;
}
