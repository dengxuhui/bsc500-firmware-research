
int FUN_60037604(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  undefined2 *puVar2;
  int local_1c;
  
  local_1c = 0;
  if ((param_1 == 0) || (param_4 == (uint *)0x0)) {
    return 0xe;
  }
  if (0xb < *param_4) {
    *param_4 = *param_4 - 0xc;
    *param_3 = 0x74;
    puVar2 = param_3;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 2,param_3);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 3,puVar2);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60152fa4(param_1,param_2,&local_1c,param_3 + 6,puVar2);
    if (iVar1 != 0) {
      return iVar1;
    }
    iVar1 = FUN_60122b2a(param_1,param_2,&local_1c,param_3 + 4);
    if (iVar1 != 0) {
      return iVar1;
    }
    if (local_1c == param_2) {
      *param_4 = 0xc;
      return 0;
    }
  }
  return 9;
}
