
/* WARNING: Type propagation algorithm not settling */

void FUN_6000df90(void)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int *piVar9;
  undefined1 auStack_13c [4];
  undefined1 auStack_138 [4];
  undefined1 auStack_134 [97];
  undefined4 uStack_d3;
  undefined2 uStack_6e;
  undefined1 auStack_6c [64];
  undefined4 local_2c;
  undefined4 local_28;
  
  local_2c = 0;
  local_28 = 0;
  uVar1 = FUN_60147734(0x20005820,&UNK_603fc15b,0,0,0,0);
  uVar7 = (uint)uVar1;
  FUN_60167f3c(6,&DAT_603fbe23,1,"fitbp = %d\n",uVar7);
  if (uVar7 != 0) {
    FUN_60161fb8(0x2007b3e0);
    FUN_601340d8(0x2007b3e0,0x20005820,&UNK_603fc15b,0,0,0,0,0,uVar7 - 1);
    piVar9 = (int *)0x2007b3e8;
    while (piVar9 = (int *)*piVar9, piVar9 != (int *)0x2007b3e8) {
      ZeroBytes(auStack_6c,0x40);
      ZeroBytes((int)&uStack_d3 + 3,100);
      ZeroBytes(auStack_134,100);
      CopyBytes(auStack_6c,piVar9[-2],piVar9[-1]);
      iVar2 = FUN_60168220(auStack_6c);
      FUN_60167f3c(6,&DAT_603fbe23,1,"check fitbp %s\n",auStack_6c);
      FUN_601681f4(auStack_134,&LAB_603f7d56_1,0x20005802,auStack_6c);
      iVar3 = FUN_60166758(&local_28,auStack_134,1);
      if (iVar3 == 0) {
        iVar3 = FUN_6016506c(local_28);
        if (iVar3 == 0x400) {
          FUN_60161ef4(local_28,0x2007dfc8,0x400,auStack_138);
          FUN_601667bc(local_28);
          FUN_60167f3c(6,&DAT_603fbe23,1,"found fit backup %s: %d,%d\n",auStack_6c,uRam2007dfc8,
                       uRam2007e3b8);
          *(undefined2 *)((int)&uStack_6e + iVar2) = 0;
          FUN_601681f4(auStack_134,&LAB_603f7d56_1,0x200056b8,auStack_6c);
          if ((uRam2007e3b8 < 0x3ed) &&
             (iVar3 = FUN_60166758(&local_28,auStack_134,2), uVar7 = uRam2007dfc8, iVar3 == 0)) {
            uVar4 = FUN_6016506c(local_28);
            FUN_60167f3c(6,&DAT_603fbe23,1,"ride_fit_info_backup_apply %d,%d\n",uVar7,uVar4);
            uVar7 = uRam2007dfc8;
            uVar5 = FUN_6016506c(local_28);
            uVar8 = uRam2007dfc8;
            if (uVar7 <= uVar5) {
              uVar4 = FUN_6016506c(local_28);
              FUN_60167f3c(6,&DAT_603fbe23,1,"write offset %d, fsize = %d\n",uVar8,uVar4);
              FUN_60163c98(local_28,0);
              FUN_60164ed8(local_28,0x2007e3ba,0xe,auStack_13c);
              FUN_60163c98(local_28,uRam2007dfc8);
              FUN_60164ed8(local_28,0x2007dfcc,uRam2007e3b8,auStack_13c);
              uVar8 = uRam2007dfc8 + uRam2007e3b8;
              uVar7 = FUN_6016506c(local_28);
              if (uVar8 < uVar7) {
                FUN_60163c98(local_28,uRam2007dfc8 + uRam2007e3b8);
                FUN_60163c68(local_28);
                uVar4 = FUN_6016506c(local_28);
                FUN_60167f3c(6,&DAT_603fbe23,1,"truncate %d\n",uVar4);
              }
              FUN_601667bc(local_28);
            }
          }
        }
        iVar3 = (int)&uStack_d3 + 3;
        FUN_6007db44(iVar3,auStack_134,100);
        iVar6 = FUN_60168220(iVar3);
        *(undefined4 *)(iVar3 + iVar6 + -3) = 0x746164;
        iVar3 = FUN_60166758(&local_2c,iVar3,1);
        if (iVar3 == 0) {
          FUN_601667bc(local_2c);
          *(undefined1 *)((int)&uStack_d3 + iVar6 + 2) = 0x69;
          *(undefined1 *)((int)&uStack_d3 + iVar6 + 3) = 0x74;
          *(undefined1 *)((int)&uStack_d3 + iVar6) = 0x74;
          *(undefined1 *)((int)&uStack_d3 + iVar6 + 1) = 0x66;
          FUN_60162054(auStack_134);
        }
      }
      *(undefined2 *)((int)&uStack_6e + iVar2) = 0x7062;
      FUN_601681f4(auStack_134,&LAB_603f7d56_1,0x20005802,auStack_6c);
      FUN_60167f3c(6,&DAT_603fbe23,1,"delete fitbp %s\n",auStack_134);
      FUN_60163bbe(auStack_134);
    }
    FUN_601607f4(0x2007b3e0);
  }
  FUN_600187a0();
  return;
}
