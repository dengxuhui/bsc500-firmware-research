
undefined4 * FUN_6002c3c4(int *param_1,undefined4 *param_2,uint param_3)

{
  undefined4 *puVar1;
  uint uVar2;
  undefined4 uVar3;
  int *piVar4;
  int iVar5;
  
  if ((param_3 & 1) == 0) {
    if ((int)(param_3 << 0x1e) < 0) {
      param_2[10] = param_2[10] & 0x80000000 | 0x6000;
      uVar2 = FUN_6011fa3e(param_2);
      if (uVar2 * 2 < (param_2[10] & 0x7fffffff)) {
        param_2[10] = (param_2[10] & 0x80000000) + (uVar2 & 0x3fffffff) * 2;
      }
      iVar5 = FUN_6015f71c();
      param_2[5] = iVar5;
      if (iVar5 == 0) {
        param_2[10] = param_2[10] & 0x80000000 | 0xc00;
        iVar5 = FUN_6015f71c(0xc00);
        param_2[5] = iVar5;
        if (iVar5 == 0) {
          return (undefined4 *)0x0;
        }
      }
      param_2[2] = *param_2;
      param_2[3] = param_2[1];
      *(undefined2 *)((int)param_2 + 0xe) = *(undefined2 *)((int)param_2 + 2);
      uVar2 = (int)(param_2[10] & 0x7fffffff) /
              (int)(short)(((short)param_2[1] - (short)*param_2) + 1);
      *(short *)((int)param_2 + 0x12) = (short)(uVar2 >> 1);
      *(short *)(param_2 + 4) = (short)((int)uVar2 / 3);
      return param_2;
    }
    puVar1 = param_2 + 2;
    *puVar1 = *param_2;
    param_2[3] = param_2[1];
    uVar2 = FUN_6011fa3e(param_2);
    param_2[10] = (param_2[10] & 0x80000000) + (uVar2 & 0x3fffffff) * 2;
    uVar3 = FUN_6015f71c();
    param_2[5] = uVar3;
    FUN_601608ac(uVar3,param_2[10] & 0x7fffffff);
    param_2[10] = param_2[10] & 0x7fffffff;
    if (param_2[5] != 0) {
      *param_1 = param_2[5];
      param_1[1] = (int)puVar1;
      param_1[2] = (int)puVar1;
      piVar4 = (int *)FUN_6015bb78();
      *(uint *)(*piVar4 + 0x10) = *(uint *)(*piVar4 + 0x10) & 0xffffffbf;
      return param_2;
    }
  }
  return (undefined4 *)0x0;
}
