
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000ea94(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = _DAT_2000953c;
  }
  if (param_2 != (undefined4 *)0x0) {
    *param_2 = _DAT_20009550;
  }
  if (param_3 != (undefined4 *)0x0) {
    *param_3 = _DAT_20009554;
  }
  return;
}
