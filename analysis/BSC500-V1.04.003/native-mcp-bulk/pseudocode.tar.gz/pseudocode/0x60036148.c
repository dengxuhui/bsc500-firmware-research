
void FUN_60036148(void)

{
  if (cRam2004473d != '\0') {
    return;
  }
  cRam2004473d = 1;
  FUN_601671d4(&UNK_6004268d,0,&UNK_600426f9,0x22);
  return;
}
