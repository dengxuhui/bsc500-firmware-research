
void FUN_6001bd1c(void)

{
  uRam2000ca34 = uRam2000ca28;
  return;
}
