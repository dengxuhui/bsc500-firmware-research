
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600214e4(short *param_1,ushort param_2,undefined4 param_3)

{
  if (param_1 == (short *)0x0) {
                    /* WARNING: Subroutine does not return */
    thunk_FUN_6016804c("timer != QW_TIMER_NULL","./../../../../qwos/middleware/qw_timer/qw_timer.c",
                       0xc1);
  }
  if (*param_1 == 0x5157) {
    return;
  }
  (*(code *)*_DAT_2000b690)();
  *(short **)(param_1 + 2) = param_1 + 2;
  *(short **)(param_1 + 4) = param_1 + 2;
  *(undefined4 *)(param_1 + 6) = param_3;
  *param_1 = 0x5157;
  param_1[1] = param_2 & 0xfe;
  param_1[0xc] = 0;
  param_1[0xd] = 0;
                    /* WARNING: Could not recover jumptable at 0x60021528. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)_DAT_2000b690[1])();
  return;
}
