
uint FUN_600387f8(uint param_1,byte *param_2,int param_3,int param_4)

{
  for (; param_3 != 0; param_3 = param_3 + -1) {
    param_1 = *(uint *)(&UNK_602a975c + ((uint)*param_2 ^ param_1 & 0xff) * 4) ^ param_1 >> 8;
    param_2 = param_2 + 1;
  }
  if (param_4 != 0) {
    param_1 = ~param_1;
  }
  return param_1;
}
