
void FUN_60028f58(int param_1)

{
  undefined4 uVar1;
  undefined4 local_78;
  char local_74 [100];
  
  ZeroBytes(local_74,100);
  local_78 = 0;
  if (param_1 != 0) {
    FUN_601681f4(local_74,&UNK_60028fbc,"<Encode>2</Encode>");
    uVar1 = FUN_60168220(local_74);
    FUN_60164ed8(param_1,local_74,uVar1,&local_78);
    FUN_60167214(local_74 + 9,0x5b);
    builtin_strncpy(local_74,"<Tracks>",9);
    uVar1 = FUN_60168220(local_74);
    FUN_60164ed8(param_1,local_74,uVar1,&local_78);
  }
  return;
}
