
void FUN_600270d4(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x80);
  if (*(int *)(param_1 + 0x78) < iVar1) {
    *(int *)(param_1 + 0x80) = *(int *)(param_1 + 0x78);
    *(int *)(param_1 + 0x78) = iVar1;
  }
  iVar1 = *(int *)(param_1 + 0x84);
  if (iVar1 < *(int *)(param_1 + 0x7c)) {
    *(int *)(param_1 + 0x84) = *(int *)(param_1 + 0x7c);
    *(int *)(param_1 + 0x7c) = iVar1;
  }
  return;
}
