
undefined4 FUN_6003018e(uint *param_1,uint param_2)

{
  undefined4 uVar1;
  
  uVar1 = 0x16;
  if ((param_1 != (uint *)0x0) && (param_2 < 3)) {
    *param_1 = *param_1 & 0xfffffff0 | param_2;
    uVar1 = 0;
  }
  return uVar1;
}
