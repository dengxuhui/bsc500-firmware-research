
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001ccd0(int *param_1)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar2 = *param_1;
  if (iVar2 != 0) {
    uVar3 = *(undefined4 *)(iVar2 + 0x168);
    if (*(int *)(iVar2 + 0x164) == 0) {
      FUN_6015c57c(iVar2 + 4);
    }
    else {
      FUN_60156428(uVar3);
      FUN_60107b98(*param_1);
      FUN_60107c50(*param_1);
      if (*(int *)(iVar2 + 0x164) != 0) {
        thunk_FUN_60166c0c();
      }
      if (*(int *)(iVar2 + 0x16c) != 0) {
        FUN_6012c99c(*(int *)(iVar2 + 0x16c) + 0x24);
        thunk_FUN_60166c0c(*(undefined4 *)(iVar2 + 0x16c));
      }
    }
    thunk_FUN_60166c0c(uVar3);
    thunk_FUN_60166c0c(iVar2);
    *param_1 = 0;
    return;
  }
  if ((_DAT_e000edf0 & 1) != 0) {
    software_bkpt(0);
  }
  bVar1 = (bool)isCurrentModePrivileged();
  if (bVar1) {
    isIRQinterruptsEnabled();
  }
  disableIRQinterrupts();
                    /* WARNING: Subroutine does not return */
  FUN_6016804c(&UNK_603f8649,"fd_clean_abort_file_by_fd",0x15c);
}
