
undefined4 FUN_60021718(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 extraout_s1;
  undefined8 uVar3;
  undefined8 uVar4;
  
  uVar3 = FUN_60166bb4();
  uVar2 = (undefined4)((ulonglong)uVar3 >> 0x20);
  uVar4 = FUN_601678fc((int)uVar3,uVar2,0x16c16c17,0x3f66c16c);
  uVar1 = FUN_601682c8((int)uVar4,(int)((ulonglong)uVar4 >> 0x20),0,0x3fe00000);
  uVar1 = FUN_60137818(uVar1);
  uVar4 = FUN_601678fc(uVar1,extraout_s1,0,0xc0768000);
  FUN_601682c8((int)uVar3,uVar2,(int)uVar4,(int)((ulonglong)uVar4 >> 0x20));
  uVar1 = FUN_601672d4();
  return uVar1;
}
