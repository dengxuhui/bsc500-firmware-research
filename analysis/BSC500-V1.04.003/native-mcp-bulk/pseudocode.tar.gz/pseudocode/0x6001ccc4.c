
void FUN_6001ccc4(void)

{
  FUN_60027f50();
  return;
}
