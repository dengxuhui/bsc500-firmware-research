
bool FUN_6000f99c(undefined4 param_1,undefined4 param_2,undefined4 *param_3,undefined4 param_4)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  bool bVar7;
  undefined4 local_2c;
  undefined4 *local_28;
  undefined4 local_24;
  
  local_2c = param_2;
  local_28 = param_3;
  local_24 = param_4;
  iVar2 = FUN_60010b70(param_1,&local_28,param_3,param_4,param_1);
  puVar1 = local_28;
  if (local_28 != (undefined4 *)0x0) {
    iVar3 = 0x2002dfa8;
    for (iVar5 = 0; iVar5 != 4; iVar5 = iVar5 + 1) {
      if (*(undefined4 **)(iVar5 * 0x1c + 0x2002df9c) == local_28) {
        for (uVar6 = 0; uVar6 != 3; uVar6 = uVar6 + 1) {
          if (*(int *)(iVar3 + uVar6 * 4) == 0) {
            if ((uVar6 & 0xff) == 3) {
              return false;
            }
            iVar3 = *(int *)(iVar2 * 0x1c + 0x2002dfa4);
            if (iVar3 == 0) {
              return false;
            }
            FUN_6016825e(iVar3,0xffffffff);
            FUN_6016350c(puVar1);
            iVar5 = FUN_6001a148(puVar1,param_2,&local_24);
            FUN_601634e4(puVar1);
            iVar4 = FUN_601633f8(puVar1,local_24,1,&local_2c);
            bVar7 = iVar4 == 0 && iVar5 == 0;
            if (bVar7) {
              *(undefined4 *)(iVar2 * 0x1c + uVar6 * 4 + 0x2002dfa8) = local_2c;
              *param_3 = local_2c;
            }
            FUN_601682ae(iVar3);
            return bVar7;
          }
        }
      }
      iVar3 = iVar3 + 0x1c;
    }
  }
  return false;
}
