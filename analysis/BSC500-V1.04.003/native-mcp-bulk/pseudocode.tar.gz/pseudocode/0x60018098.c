
undefined4 FUN_60018098(void)

{
  if (cRam2000ca88 == '\x04') {
    FUN_6015d1e4(0x2000bce8,0x2000aab0);
    return 0x2000aab0;
  }
  return 0;
}
