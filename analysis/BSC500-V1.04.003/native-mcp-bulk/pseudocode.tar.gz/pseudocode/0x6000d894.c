
void FUN_6000d894(int *param_1,int *param_2)

{
  int local_18;
  int local_14;
  
  local_18 = 0;
  local_14 = 0;
  FUN_600186a0(&local_14,&local_18);
  *param_1 = local_14;
  *param_2 = local_14 - local_18;
  return;
}
