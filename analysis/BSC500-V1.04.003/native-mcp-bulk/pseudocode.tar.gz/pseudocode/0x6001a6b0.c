
undefined4 FUN_6001a6b0(int *param_1,int param_2)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  float *pfVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  float *pfVar10;
  undefined4 in_cr0;
  undefined4 in_cr1;
  float fVar11;
  
  uVar1 = 0xffffffff;
  if ((param_1 != (int *)0x0) && (param_2 != 0)) {
    uVar4 = param_1[3];
    if (uVar4 < (uint)param_1[2]) {
      FUN_60100c64(*param_1 + uVar4 * 0x18,param_2);
      iVar2 = param_1[3];
      param_1[3] = iVar2 + 1U;
      if (2 < iVar2 + 1U) {
        iVar3 = *param_1 + iVar2 * 0x18;
        *(float *)(param_1[1] + iVar2 * 4 + -4) =
             *(float *)(iVar3 + 0x10) - *(float *)(iVar3 + -0x20);
      }
    }
    else {
      iVar2 = *param_1;
      iVar3 = param_1[1];
      uVar9 = uVar4 - 1;
      pfVar10 = (float *)(param_2 + 0x10);
      uVar7 = 1;
      *(float *)(iVar3 + uVar9 * 4) =
           *(float *)(param_2 + 0x10) - *(float *)(iVar2 + (uVar4 - 2) * 0x18 + 0x10);
      pfVar5 = (float *)(iVar3 + 8);
      for (uVar8 = 2; uVar8 < uVar4; uVar8 = uVar8 + 1) {
        fVar11 = *pfVar5;
        pfVar5 = pfVar5 + 1;
        coprocessor_function2(10,8,2,in_cr0,in_cr1,in_cr0);
        if (fVar11 < *(float *)(iVar3 + 4)) {
          uVar7 = uVar8;
        }
      }
      if (1 < uVar7) {
        iVar6 = iVar2 + uVar7 * 0x18;
        pfVar5 = pfVar10;
        if (uVar7 < uVar9) {
          pfVar5 = (float *)(iVar6 + 0x28);
        }
        *(float *)(iVar3 + uVar7 * 4 + -4) = *pfVar5 - *(float *)(iVar6 + -0x20);
      }
      if (uVar7 < uVar9) {
        iVar6 = iVar2 + uVar7 * 0x18;
        if (uVar7 < uVar4 - 2) {
          pfVar10 = (float *)(iVar6 + 0x40);
        }
        *(float *)(iVar3 + uVar7 * 4 + 4) = *pfVar10 - *(float *)(iVar6 + -8);
      }
      iVar3 = uVar7 * 0x18;
      for (; uVar7 < uVar4 - 1; uVar7 = uVar7 + 1) {
        FUN_60100c64(iVar2 + iVar3,iVar2 + iVar3 + 0x18);
        iVar2 = *param_1;
        uVar4 = param_1[3];
        iVar3 = iVar3 + 0x18;
        *(undefined4 *)(param_1[1] + uVar7 * 4) = *(undefined4 *)(param_1[1] + uVar7 * 4 + 4);
      }
      FUN_60100c64(iVar2 + (uVar4 - 1) * 0x18,param_2);
    }
    uVar1 = 0;
  }
  return uVar1;
}
