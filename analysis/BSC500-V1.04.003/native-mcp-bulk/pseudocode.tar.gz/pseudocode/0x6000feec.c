
undefined4 FUN_6000feec(void)

{
  int iVar1;
  undefined4 uVar2;
  uint in_fpscr;
  undefined8 uVar3;
  undefined8 uVar4;
  undefined1 auStack_58 [24];
  undefined1 auStack_40 [24];
  undefined8 local_28;
  undefined8 local_20;
  float local_18;
  
  if ((((cRam2000b13c == '\x02') && (iVar1 = FUN_60166dd0(0x2000b184), iVar1 != 1)) &&
      (iVar1 = FUN_60166dd0(0x2000b18c), iVar1 != 1)) &&
     (iVar1 = FUN_601614a4(uRam2000b194), iVar1 != 0)) {
    local_18 = (float)VectorSignedToFloat(uRam2000b194,(byte)(in_fpscr >> 0x16) & 3);
    local_18 = local_18 / 100.0;
    uVar3 = FUN_6016759c(uRam2000b184);
    uVar4 = FUN_6016759c(uRam2000b188);
    local_28 = FUN_601675d8((int)uVar3,(int)((ulonglong)uVar3 >> 0x20),(int)uVar4,
                            (int)((ulonglong)uVar4 >> 0x20));
    uVar3 = FUN_6016759c(uRam2000b18c);
    uVar4 = FUN_6016759c(uRam2000b190);
    local_20 = FUN_601675d8((int)uVar3,(int)((ulonglong)uVar3 >> 0x20),(int)uVar4,
                            (int)((ulonglong)uVar4 >> 0x20));
    ZeroBytes(auStack_40,0x18);
    ZeroBytes(auStack_58,0x18);
    iVar1 = FUN_6001a7f6(0x2008b528,&local_28,auStack_40);
    if (iVar1 == 0) {
      iVar1 = FUN_6001a884(0x2000b144,auStack_40);
      if (iVar1 != 0) {
        FUN_601667bc(uRam2000b144);
        uRam2000b144 = 0;
        FUN_60163bbe(0x20005dca);
        cRam2000b13c = '\x01';
        goto LAB_6000ffb8;
      }
      iVar1 = FUN_6001a500(0x2000b164,auStack_40,auStack_58);
      if (iVar1 == 0) {
        FUN_6001a6b0(0x2000b174,auStack_58);
        FUN_6001a630(0x2000b158,auStack_58);
        return 0;
      }
    }
    uVar2 = 1;
  }
  else {
LAB_6000ffb8:
    uVar2 = 0xffffffff;
  }
  return uVar2;
}
