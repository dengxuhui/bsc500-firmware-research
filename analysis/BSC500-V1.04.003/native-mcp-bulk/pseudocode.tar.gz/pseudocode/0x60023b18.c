
void FUN_60023b18(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  
  uVar2 = 0;
  while( true ) {
    uVar1 = uVar2;
    uVar2 = uVar1 + 1;
    if (param_3 <= uVar2) {
      return;
    }
    iVar4 = param_1 + uVar1 * 4;
    iVar3 = *(int *)(param_1 + uVar1 * 4);
    iVar5 = *(int *)(iVar4 + 4);
    if (iVar5 < iVar3) break;
    *(int *)(param_1 + uVar1 * 4) = iVar5;
    *(int *)(iVar4 + 4) = iVar3;
    if (param_2 != 0) {
      iVar3 = param_2 + uVar1 * 4;
      uVar6 = *(undefined4 *)(iVar3 + 4);
      *(undefined4 *)(iVar3 + 4) = *(undefined4 *)(param_2 + uVar1 * 4);
      *(undefined4 *)(param_2 + uVar1 * 4) = uVar6;
    }
  }
  return;
}
