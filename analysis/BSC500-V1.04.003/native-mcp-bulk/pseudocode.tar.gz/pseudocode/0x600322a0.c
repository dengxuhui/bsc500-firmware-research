
void FUN_600322a0(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined1 auStack_a0 [16];
  undefined1 local_90;
  undefined1 local_8f;
  undefined *local_8c;
  char cStack_84;
  undefined2 uStack_6c;
  undefined2 uStack_64;
  undefined1 auStack_60 [12];
  uint uStack_54;
  undefined2 uStack_4c;
  undefined *puStack_48;
  undefined4 uStack_44;
  undefined1 uStack_40;
  undefined1 uStack_3c;
  int iStack_38;
  undefined1 uStack_34;
  undefined4 uStack_30;
  undefined1 uStack_2c;
  undefined1 uStack_24;
  undefined2 *puStack_1c;
  undefined4 uStack_18;
  
  ZeroBytes(&local_90,0x30);
  local_8c = &UNK_600400bd;
  FUN_60161d4c(auStack_a0,param_1,param_2);
  iVar1 = FUN_60161d60(auStack_a0,&UNK_603e5cae,&local_90);
  if (iVar1 == 0) {
    return;
  }
  switch(local_8f) {
  case 1:
    iVar4 = 0;
    puStack_1c = (undefined2 *)0x0;
    uStack_18 = 0;
    ZeroBytes(&uStack_4c,0x30);
    iVar1 = FUN_6013a780(&uStack_18,&puStack_1c,0x6e);
    if (iVar1 != 0) {
      return;
    }
    uStack_3c = 1;
    uStack_40 = 1;
    uStack_4c = 0x118;
    FUN_60161fb8(0x20009fc8);
    FUN_6015ee0c(0x20009fc8,0x20005898,&LAB_603fc5a4_1,0,0,0,0);
    piVar2 = (int *)0x20009fd0;
    while (piVar2 = (int *)*piVar2, piVar2 != (int *)0x20009fd0) {
      iVar4 = iVar4 + 1;
    }
    FUN_601607f4(0x20009fc8);
    uStack_24 = 0;
    uStack_2c = 0;
    uStack_30 = 10;
    uStack_34 = 1;
    iStack_38 = iVar4;
    break;
  case 2:
    if (cStack_84 == '\0') {
      local_8f = 2;
      goto LAB_60032438;
    }
    puStack_1c = (undefined2 *)0x0;
    uStack_18 = 0;
    uRam20009fc2 = uStack_6c;
    uRam20009fc4 = uStack_64;
    ZeroBytes(&uStack_4c,0x30);
    iVar1 = FUN_6013a780(&uStack_18,&puStack_1c,0x6e);
    if (iVar1 != 0) {
      return;
    }
    uStack_44 = 0;
    uStack_4c = 0x218;
    puStack_48 = &UNK_6003ff11;
    break;
  case 3:
    local_8f = 3;
    goto code_r0x600323b0;
  case 4:
    if (cRam20009fc1 == '\x01') {
      FUN_60163840(0x20009fd8);
    }
    func_0x6003e278();
code_r0x600323b0:
    FUN_60127660(local_90,0,local_8f,0);
    return;
  case 5:
    FUN_60127660(local_90,0,5,0);
    func_0x600400fc();
    return;
  default:
LAB_60032438:
    FUN_60129ec8(local_90,0,local_8f,0);
    return;
  }
  FUN_601648d4(auStack_60,uStack_18,0x640);
  FUN_60164868(auStack_60,&UNK_603e5cae,&uStack_4c);
  *puStack_1c = (short)uStack_54;
  FUN_60122c60();
  uVar3 = FUN_6015f2e8(uStack_18,*puStack_1c);
  FUN_6013a800((undefined1)uStack_4c,0,uStack_4c._1_1_,0,uStack_54 & 0xffff,uVar3);
  return;
}
