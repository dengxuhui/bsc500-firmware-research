
void FUN_600154ec(undefined4 *param_1,uint param_2,int *param_3)

{
  bool bVar1;
  int iVar2;
  int *piVar3;
  uint *puVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  bool bVar9;
  bool bVar10;
  uint uStack_30;
  int local_2c;
  int *local_28;
  
  local_28 = (int *)0x0;
  if (DAT_2000bb04 != '\0') {
    local_28 = (int *)0x200032c8;
  }
  local_2c = 0;
  if (DAT_2000bb08 != '\0') {
    local_2c = 0x1000;
  }
  uStack_30 = param_2;
  if (DAT_2000bb12 == '\x01') {
    bVar1 = false;
    if (DAT_2000bb13 == '\0') {
      *param_1 = 0;
      uVar8 = 1;
      iVar2 = 0;
      if (DAT_2000bb0c != '\0') {
        iVar2 = 0x60000000;
      }
      if (DAT_2000bb10 != '\0') {
        iVar2 = iVar2 + 0x43ef68;
      }
      if ((1 < param_2) && (iVar2 == -4)) {
        bVar1 = true;
        uVar8 = 2;
        param_1[1] = 0xfffffffc;
      }
    }
    else {
      uVar8 = 0;
    }
    if (DAT_2000bb14 != '\0') {
      FUN_6015a194(&local_28,&local_2c);
    }
  }
  else {
    puVar4 = (uint *)getProcessStackPointer();
    if (&uStack_30 == puVar4) {
      FUN_6015a194(&local_28,&local_2c);
    }
    uVar8 = 0;
    bVar1 = false;
  }
  piVar3 = param_3;
  if (((DAT_2000bb13 == '\x01') && (piVar3 = local_28, local_28 <= param_3)) &&
     (piVar3 = param_3, (int *)(local_2c + (int)local_28) < param_3)) {
    piVar3 = (int *)(local_2c + (int)local_28);
  }
  uVar5 = 0;
  if (DAT_2000bb0c != '\0') {
    uVar5 = 0x60000000;
  }
  uVar6 = uVar5;
  if (DAT_2000bb10 != '\0') {
    uVar6 = uVar5 + 0x43ef68;
  }
  for (; piVar3 < (int *)((int)local_28 + local_2c); piVar3 = piVar3 + 1) {
    uVar7 = *piVar3 - 4;
    if ((((uVar7 & 1) != 0) && (uVar5 <= uVar7)) && (uVar8 < param_2)) {
      bVar10 = 0xe < uVar8;
      bVar9 = uVar8 == 0xf;
      if (uVar8 < 0x10) {
        bVar10 = uVar6 <= uVar7;
        bVar9 = uVar7 == uVar6;
      }
      if (!bVar10 || bVar9) {
        if ((uVar8 == 2 && bVar1) && (uVar7 == param_1[1])) {
          uVar8 = 2;
        }
        else {
          param_1[uVar8] = uVar7;
          uVar8 = uVar8 + 1;
        }
      }
    }
  }
  return;
}
