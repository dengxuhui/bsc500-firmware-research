
void FUN_6001da48(int param_1)

{
  if (param_1 != 0) {
    if ((*(char *)(param_1 + 0x1d84) != '\0') && (*(int *)(param_1 + 0x1d70) != 0)) {
      FUN_601667bc();
      *(undefined1 *)(param_1 + 0x1d84) = 0;
      *(int *)(param_1 + 0x1d70) = 0;
    }
    *(undefined1 *)(param_1 + 0x1d8c) = 1;
    *(undefined1 *)(param_1 + 0x1d85) = 0;
  }
  return;
}
