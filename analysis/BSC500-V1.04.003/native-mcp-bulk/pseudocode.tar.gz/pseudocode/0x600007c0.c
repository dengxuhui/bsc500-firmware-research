
undefined8 ResetTarget_600007c0(void)

{
  undefined8 uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  FUN_6006cb00();
  uVar1 = FUN_6026859c();
  FUN_60000aa0();
  FUN_60062fae();
  iVar2 = FUN_60140d54();
  iVar3 = FUN_6004fe60(0,0);
  *(int *)(iVar2 + 4) = iVar3 + 1;
  uVar4 = FUN_6004fe8c(0,0);
  *(undefined4 *)(iVar2 + 0xc) = uVar4;
  uVar4 = FUN_60268358(0,0);
  *(undefined4 *)(iVar2 + 0x10) = uVar4;
  FUN_6006d138();
  FUN_6006d02c();
  return uVar1;
}
