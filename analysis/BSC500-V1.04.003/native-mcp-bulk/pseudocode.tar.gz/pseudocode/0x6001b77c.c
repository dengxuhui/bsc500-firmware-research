
void FUN_6001b77c(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  uRam2000a6d0 = 1;
  FUN_6013bb40(&DAT_602ad5a0,0x2000bed0,param_3,param_4,param_4);
  FUN_6013bb40(&DAT_602ad512,0x2000a6e4);
  FUN_6013bb40(&DAT_602ad26e,0x2000befc);
  uRam2000bed0 = param_1[1];
  uRam2000bed4 = *param_1;
  uRam2000bf00 = param_1[1];
  uRam2000bf04 = *param_1;
  uRam2000bef4 = 0x1f50073;
  uRam2000bf20 = 0x1f50073;
  uRam2000bf27 = 0;
  uRam2000bf28 = *(undefined1 *)(param_1 + 3);
  uRam2000a6e6 = *(undefined1 *)(param_1 + 3);
  uRam2000bf24 = (undefined2)((uint)param_1[4] / 1000);
  uRam2000a6e4 = uRam2000bf24;
  return;
}
