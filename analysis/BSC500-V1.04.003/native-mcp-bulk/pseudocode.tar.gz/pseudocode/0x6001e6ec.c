
void FUN_6001e6ec(undefined4 param_1,int param_2)

{
  FUN_6002c258();
  FUN_6007db44(param_2 + 0x54,param_2,0x54);
  *(undefined4 *)(param_2 + 0x30) = 0x6003f371;
  *(undefined4 *)(param_2 + 0x18) = 0x60031e75;
  *(undefined1 **)(param_2 + 0x50) = &LAB_60031ca4_1;
  return;
}
