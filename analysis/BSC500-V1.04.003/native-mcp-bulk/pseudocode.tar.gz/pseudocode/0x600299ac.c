
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600299ac(void)

{
  FUN_6013810c(_DAT_2000b300);
  FUN_60133ef6(_DAT_2000b304);
  _DAT_2000b300 = 0;
  _DAT_2000b304 = 0;
  return 0;
}
