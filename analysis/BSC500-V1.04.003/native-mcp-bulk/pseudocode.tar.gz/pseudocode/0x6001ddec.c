
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined2 FUN_6001ddec(void)

{
  return _DAT_2000bca8;
}
