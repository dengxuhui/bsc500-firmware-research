
void FUN_6001b8e8(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  
  uVar1 = (uint)*(ushort *)(param_1 + 0x80);
  if (uVar1 < 0x10) {
    *(ushort *)(param_1 + 0x80) = *(ushort *)(param_1 + 0x80) + 1;
    *(undefined4 *)(param_1 + uVar1 * 8) = param_2;
    *(undefined4 *)(param_1 + uVar1 * 8 + 4) = param_3;
    return;
  }
                    /* WARNING: Subroutine does not return */
  thunk_FUN_6016804c("_size < capacity && \"Vector capacity exceeded\"",
                     "../../../../qwos/module/touchx/touchgfx/include\\touchgfx/hal/Types.hpp",0x21a
                    );
}
