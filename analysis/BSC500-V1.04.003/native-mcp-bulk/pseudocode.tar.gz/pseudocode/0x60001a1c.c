
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001a1c(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  iVar2 = _DAT_20009590;
  uVar3 = FUN_60167d0c();
  FUN_6013a164(iVar2);
  *(undefined1 *)(iVar2 + 0x3c) = 4;
  FUN_60136698(iVar2 + 0x58);
  iVar4 = FUN_601635b0(iVar2);
  if ((iVar4 == 1) && (*(int *)(iVar2 + 0x90) == 0)) {
    FUN_60162d10(iVar2);
  }
  else {
    piVar1 = (int *)(iVar2 + 0x1c);
    *piVar1 = (int)_DAT_20009598;
    _DAT_20009598[1] = (int)piVar1;
    _DAT_20009598 = piVar1;
    *(undefined1 **)(iVar2 + 0x20) = &DAT_20009598;
  }
  FUN_60167d14(uVar3);
  FUN_60163a08();
  return;
}
