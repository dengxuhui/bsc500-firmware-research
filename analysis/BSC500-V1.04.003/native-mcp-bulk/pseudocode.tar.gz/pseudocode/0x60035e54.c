
void FUN_60035e54(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 auStack_a0 [12];
  uint local_94;
  undefined2 *local_8c;
  undefined4 local_88;
  undefined2 local_84;
  undefined1 local_82;
  undefined1 local_20;
  undefined1 local_1c;
  undefined4 local_18;
  
  ZeroBytes(&local_84,0x7c);
  local_8c = (undefined2 *)0x0;
  local_88 = 0;
  iVar1 = FUN_6013a780(&local_88,&local_8c,0x3e);
  if (iVar1 == 0) {
    local_1c = 1;
    local_20 = 1;
    local_82 = 1;
    local_84 = 0x56e;
    local_18 = param_1;
    FUN_601648d4(auStack_a0,local_88,0x4b0);
    FUN_60164868(auStack_a0,&UNK_603df56a,&local_84);
    *local_8c = (short)local_94;
    FUN_6012d1e4();
    uVar2 = FUN_6015f2e8(local_88,*local_8c);
    FUN_6013a800((undefined1)local_84,local_84._1_1_,local_82,0,local_94 & 0xffff,uVar2);
    FUN_6015de78();
  }
  return;
}
