
int FUN_600339dc(int param_1,undefined4 param_2,uint param_3,int param_4)

{
  longlong lVar1;
  longlong lVar2;
  uint uVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  
  uVar3 = param_3 & 0x3ff;
  iVar11 = *(int *)(param_1 + 0x70);
  uVar10 = *(undefined4 *)(param_1 + 0xc);
  iVar12 = iVar11 + uVar3 * 8;
  iVar9 = iVar11 + uVar3 * 0x28;
  puVar4 = (undefined4 *)(iVar9 + 0x1000);
  for (iVar6 = 0; iVar6 != 2; iVar6 = iVar6 + 1) {
    if (*(uint *)(iVar12 + 0xb000 + iVar6 * 4) == param_3) goto LAB_60033a82;
    puVar4 = puVar4 + 5;
  }
  iVar6 = *(int *)(iVar11 + uVar3 * 4);
  *(int *)(iVar11 + uVar3 * 4) = (iVar6 + 1) % 2;
  lVar1 = (ulonglong)param_3 * 0x14 + 0xc;
  lVar2 = FUN_60131f54(uVar10,param_2,(int)lVar1,(int)((ulonglong)lVar1 >> 0x20),0);
  puVar4 = (undefined4 *)(iVar9 + iVar6 * 0x14 + 0x1000);
  if (lVar1 == lVar2) {
    FUN_60131f30(uVar10,puVar4,0x14);
  }
  *(uint *)(iVar12 + iVar6 * 4 + 0xb000) = param_3;
LAB_60033a82:
  uVar8 = puVar4[1];
  uVar10 = puVar4[2];
  uVar7 = puVar4[3];
  uVar5 = puVar4[4];
  *(undefined4 *)(param_1 + 0x10) = *puVar4;
  *(undefined4 *)(param_1 + 0x14) = uVar8;
  *(undefined4 *)(param_1 + 0x18) = uVar10;
  *(undefined4 *)(param_1 + 0x1c) = uVar7;
  *(undefined4 *)(param_1 + 0x20) = uVar5;
  *(uint *)(param_1 + 0x60) = param_3;
  iVar6 = param_4 * 0x50;
  *(undefined4 *)(iVar6 + 0x200496fc) = param_2;
  *(undefined4 *)(iVar6 + 0x20049700) = param_2;
  *(undefined4 *)(iVar6 + 0x2004970c) = 0;
  *(undefined4 *)(iVar6 + 0x20049708) = *(undefined4 *)(param_1 + 0x1c);
  return param_4 * 4 + -0x10002;
}
