
void FUN_6002eb20(undefined4 param_1)

{
  FUN_601608ac(param_1,0x30);
  return;
}
