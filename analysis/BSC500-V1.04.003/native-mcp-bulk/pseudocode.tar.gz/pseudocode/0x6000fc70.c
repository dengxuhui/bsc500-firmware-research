
void FUN_6000fc70(int param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  
  if (param_1 < (int)(uint)bRam2000a000) {
    puVar1 = (undefined8 *)(iRam2000a004 + param_1 * 0x18);
    *param_2 = *puVar1;
    *param_3 = puVar1[1];
  }
  return;
}
