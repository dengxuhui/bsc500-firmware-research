
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000cc8(void)

{
  int iVar1;
  undefined4 in_r3;
  
  DAT_200437b4 = 0x12;
  ZeroBytes(0x200437bc,0x14,0x50000000,in_r3,in_r3);
  _DAT_20043870 = &PTR_LAB_6025bb10_1_602a59b0;
  _DAT_200437d0 = &LAB_60001860_1;
  _DAT_200437d4 = &LAB_6000189c_1;
  _DAT_200437d8 = &LAB_600017f0_1;
  _DAT_200437ec = 0x50000000;
  for (iVar1 = 0; iVar1 != 0x20; iVar1 = iVar1 + 1) {
    *(undefined2 *)(iVar1 * 4 + 0x200437f0) = 0xffff;
  }
  FUN_601637f8(0x20043798,&DAT_603eab45,3);
  return 0;
}
