
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6002eb90(void)

{
  if (_DAT_2000b830 != 0) {
    return;
  }
  _DAT_2000b830 = FUN_6015c074(0x200581cc,0x20000);
  return;
}
