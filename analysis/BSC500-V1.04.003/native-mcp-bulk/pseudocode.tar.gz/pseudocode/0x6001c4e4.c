
bool FUN_6001c4e4(int param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint in_fpscr;
  float fVar5;
  
  uVar1 = FUN_60165170();
  if (param_1 != 0) {
    uVar3 = 0;
    param_1 = param_1 + (uint)DAT_2000b278 * 0x18;
    uVar4 = 0xffffffff;
    uVar2 = 0;
    switch(*(undefined1 *)(param_1 + 1)) {
    case 6:
    case 9:
      fVar5 = (float)VectorUnsignedToFloat
                               (*(uint *)(param_1 + 4) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar2 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (0xfa < uVar2) {
        uVar2 = *(uint *)(param_1 + 4);
      }
      fVar5 = (float)VectorUnsignedToFloat
                               (*(int *)(param_1 + 8) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar3 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (0xf9 < uVar3) {
        uVar3 = 0xfa;
      }
      uVar4 = (uint)*(byte *)(param_2 + 1);
      break;
    case 7:
    case 10:
      fVar5 = (float)VectorUnsignedToFloat
                               (*(uint *)(param_1 + 4) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar2 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (2000 < uVar2) {
        uVar2 = *(uint *)(param_1 + 4);
      }
      fVar5 = (float)VectorUnsignedToFloat
                               (*(int *)(param_1 + 8) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar3 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (1999 < uVar3) {
        uVar3 = 2000;
      }
      uVar4 = (uint)*(ushort *)(param_2 + 6);
      break;
    case 8:
      break;
    case 0xb:
      fVar5 = (float)VectorUnsignedToFloat
                               (*(uint *)(param_1 + 4) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar2 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (0xa2c2 < uVar2) {
        uVar2 = *(uint *)(param_1 + 4);
      }
      fVar5 = (float)VectorUnsignedToFloat
                               (*(int *)(param_1 + 8) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar3 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (0xa2c2 < uVar3) {
        uVar3 = 0xa3d8;
      }
      uVar4 = (uint)*(ushort *)(param_2 + 4);
      break;
    case 0xc:
      fVar5 = (float)VectorUnsignedToFloat
                               (*(uint *)(param_1 + 4) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar2 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (0xfa < uVar2) {
        uVar2 = *(uint *)(param_1 + 4);
      }
      fVar5 = (float)VectorUnsignedToFloat
                               (*(int *)(param_1 + 8) * (uVar1 & 0xffff),
                                (byte)(in_fpscr >> 0x16) & 3);
      uVar3 = VectorFloatToUnsigned(fVar5 / 100.0,3);
      if (0xf9 < uVar3) {
        uVar3 = 0xfa;
      }
      uVar4 = (uint)*(byte *)(param_2 + 2);
      break;
    default:
      uVar2 = 0;
    }
    return uVar4 <= uVar3 && uVar2 <= uVar4;
  }
  return false;
}
