
void FUN_60001b40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c;
  char *local_18;
  
  local_1c = param_3;
  local_18 = (char *)param_4;
  FUN_60001b7c();
  local_18 = "sys_queue";
  local_1c = 0x20;
  FUN_60001c04(&local_1c,0x2008d284);
  return;
}
