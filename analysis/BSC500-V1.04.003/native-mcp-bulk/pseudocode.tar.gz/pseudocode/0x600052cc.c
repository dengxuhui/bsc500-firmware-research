
undefined4 FUN_600052cc(void)

{
  undefined1 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  int *piVar7;
  
  iVar2 = FUN_60164eb0(3);
  piVar7 = (int *)(iVar2 + 4);
  uVar3 = FUN_6015de24("mutex",piVar7);
  FUN_60168578("%-*.s   owner  hold suspend thread\n",uVar3,"mutex");
  FUN_6015de60(uVar3);
  FUN_60168578(" -------- ---- --------------\n");
  piVar5 = piVar7;
  while (piVar5 = (int *)*piVar5, piVar5 != piVar7) {
    uVar6 = piVar5[5];
    uVar1 = *(undefined1 *)((int)piVar5 + 0x13);
    uVar4 = FUN_6015dd58(piVar5 + 2);
    FUN_60168578("%-*.*s %-8.*s %04d %d\n",uVar3,0x10,piVar5 + -5,0x10,uVar6,uVar1,uVar4);
  }
  return 0;
}
