
void FUN_60028548(undefined4 param_1,undefined4 param_2)

{
  ushort uVar1;
  uint *puVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  undefined1 auStack_2fc [16];
  uint uStack_2ec;
  int aiStack_2e8 [60];
  undefined1 local_1f8;
  undefined1 local_1f7 [204];
  undefined1 local_12b;
  undefined *local_11c;
  uint *puStack_118;
  undefined1 auStack_110 [4];
  int aiStack_10c [60];
  
  ZeroBytes(&local_1f8,0xe8);
  local_12b = 1;
  puVar2 = (uint *)FUN_6015d6d8();
  FUN_6007db44(&uStack_2ec,puVar2,0xf4);
  FUN_60161d4c(auStack_2fc,param_1,param_2);
  puRam20047e7c = local_1f7;
  local_11c = &UNK_6003cd5d;
  puStack_118 = &uStack_2ec;
  iVar3 = FUN_60161d60(auStack_2fc,&UNK_602ad1d4,&local_1f8);
  if (iVar3 == 0) {
LAB_600285be:
    FUN_60129ec8(local_1f8,0,local_1f7[0],0);
  }
  else {
    switch(local_1f7[0]) {
    case 1:
      func_0x600389d4();
      return;
    default:
      goto LAB_600285be;
    case 3:
      if (0x13 < *puVar2) {
        FUN_6011f5ec(local_1f8,0,3,0,4);
        return;
      }
      uStack_2ec = uStack_2ec + 1;
    case 5:
      break;
    case 4:
      ZeroBytes(auStack_110,0xf4);
      uVar7 = 0;
      for (uVar1 = 0; uVar4 = (uint)uVar1, uVar4 < uStack_2ec; uVar1 = uVar1 + 1) {
        iVar3 = aiStack_2e8[uVar4 * 3 + 2];
        if (iVar3 != -1) {
          iVar5 = aiStack_2e8[uVar4 * 3 + 1];
          iVar6 = (uVar7 & 0xffff) * 2 + (uVar7 & 0xffff);
          uVar7 = uVar7 + 1;
          aiStack_10c[iVar6] = aiStack_2e8[uVar4 * 3];
          aiStack_10c[iVar6 + 1] = iVar5;
          aiStack_10c[iVar6 + 2] = iVar3;
        }
      }
      FUN_6007db44(&uStack_2ec,auStack_110,0xf4);
      uStack_2ec = uVar7 & 0xffff;
    }
    FUN_6007db44(puVar2,&uStack_2ec,0xf4);
    FUN_60159b58();
    FUN_60159bbc();
    FUN_60127660(local_1f8,0,local_1f7[0],0);
    iVar3 = FUN_6015a144("NaviLocation");
    if (iVar3 != 0) {
      FUN_60164914(0x800005,0);
    }
  }
  return;
}
