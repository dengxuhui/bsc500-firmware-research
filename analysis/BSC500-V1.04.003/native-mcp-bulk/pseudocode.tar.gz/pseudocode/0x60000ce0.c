
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000ce0(void)

{
  DAT_2008d75c = 1;
  DAT_2008d8e8 = 1;
  DAT_2008da74 = 1;
  _DAT_20004398 = 0x2000435c;
  _DAT_200043ac = 0x2000436c;
  _DAT_200043c0 = 0x2000437c;
  FUN_60000ff4(0x2008d640,0x2000438c,3,1000000);
  return 0;
}
