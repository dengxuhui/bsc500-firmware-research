
void FUN_6001be40(undefined4 param_1,undefined4 param_2)

{
  FUN_60139d78(3,param_1,param_2);
  FUN_6015de78();
  return;
}
