
undefined4 FUN_60016d3c(void)

{
  int iVar1;
  
  if (((byte)uRam20009eb8 == '\0') && (iVar1 = FUN_601176c4(0x7e), iVar1 != 0)) {
    iVar1 = FUN_6001e400((byte)uRam20009eb8 ^ 1);
    if (iVar1 == 0) {
      uRam20009eb8 = 0;
      return 1;
    }
    uRam20009eb8 = CONCAT11(uRam20009eb8._1_1_,1);
  }
  else {
    if ((cRam20009eba != '\x01') ||
       ((iVar1 = FUN_601176c4(0x7e), iVar1 == 0 || (uRam20009eb8._1_1_ != '\0')))) {
      return 0;
    }
    iVar1 = FUN_6001e400((byte)uRam20009eb8 ^ 1);
    if (iVar1 == 0) {
      uRam20009eb8 = 0;
      return 1;
    }
  }
  if (uRam20009eb8._1_1_ == '\x01') {
    uRam20009eb8 = 0;
    return 1;
  }
  return 0;
}
