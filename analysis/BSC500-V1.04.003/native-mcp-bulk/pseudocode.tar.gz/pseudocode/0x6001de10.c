
void FUN_6001de10(void)

{
  if (iRam20049700 != 0) {
    iRam20049700 = FUN_6016717c();
    iRam20049700 = iRam20049700 + 10000;
  }
  FUN_6015917c();
  return;
}
