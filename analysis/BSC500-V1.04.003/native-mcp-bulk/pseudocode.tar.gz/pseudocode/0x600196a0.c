
int FUN_600196a0(void)

{
  int iVar1;
  
  iVar1 = FUN_60023390(&UNK_6002347d);
  if (iVar1 != 0) {
    return iVar1;
  }
  thunk_FUN_600263c6();
  (*(code *)&UNK_6002338d)(0x32);
  thunk_FUN_600263ce();
  (*(code *)&UNK_6002338d)(0x32);
  thunk_FUN_600263c6();
  FUN_60133d38(&UNK_6043e938);
  FUN_60133d38(&UNK_6043e910);
  FUN_60133d38(&UNK_6043e924);
  (*(code *)&UNK_6002338d)(0x32);
  thunk_FUN_600263ce();
  (*(code *)&UNK_6002338d)(300);
  iVar1 = FUN_600233b0(&UNK_6002342d,&UNK_600233e1,&UNK_600233ad,&UNK_6001fd87,0);
  thunk_FUN_600263c4();
  return iVar1;
}
