
undefined4 FUN_6002b14c(int param_1)

{
  int iVar1;
  uint local_7c;
  undefined1 auStack_78 [100];
  
  local_7c = 1;
  ZeroBytes(auStack_78,100);
  if ((iRam20009ec0 == 0) && (iRam20009ec0 = thunk_FUN_60162e34(0x260), iRam20009ec0 == 0)) {
    uRam20009eb9 = CONCAT11(uRam20009eb9._1_1_,1);
    return 0;
  }
  if (uRam20009eb9._1_1_ == '\0') {
    FUN_601681f4(auStack_78,"%s/%s",0x20005cae,0x20009ed4);
    iVar1 = FUN_60166758(0x20009ec0,auStack_78,1);
    if (iVar1 != 0) {
      uRam20009eb9 = CONCAT11(uRam20009eb9._1_1_,1);
      return 0;
    }
    uRam20009eb9 = CONCAT11(1,(undefined1)uRam20009eb9);
    iRam20009ed0 = 0;
  }
  iVar1 = FUN_6015d9d4(iRam20009ec0);
  if (iVar1 == 0) {
    FUN_60161ef4(iRam20009ec0,iRam20009ec4 + param_1,0x600,&local_7c);
    iRam20009ed0 = iRam20009ed0 + local_7c;
    iRam20009ec4 = iRam20009ec4 + local_7c;
    if ((0x5ff < local_7c) && (*(int *)(iRam20009ec0 + 0xc) != iRam20009ed0)) {
      FUN_60161ef4(iRam20009ec0,iRam20009ec4 + param_1,0x1a0,&local_7c);
      iRam20009ec4 = iRam20009ec4 + local_7c;
      iRam20009ed0 = iRam20009ed0 + local_7c;
      if ((0x19f < local_7c) && (*(int *)(iRam20009ec0 + 0xc) != iRam20009ed0)) {
        return 1;
      }
    }
    FUN_601667bc();
    iRam20009ec0 = 0;
    uRam20009eb9 = 1;
    FUN_601681f4(auStack_78,"%s/%s",0x20005cae,0x20009ed4);
    FUN_60163bbe(auStack_78);
  }
  else {
    FUN_601667bc();
    iRam20009ec0 = 0;
    uRam20009eb9 = 1;
    FUN_601681f4(auStack_78,"%s/%s",0x20005cae,0x20009ed4);
    FUN_60163bbe(auStack_78);
    iRam20009ed0 = 0;
  }
  return 1;
}
