
int FUN_60018cf8(float param_1)

{
  char cVar1;
  
  if (0.0 <= param_1) {
    if (150.0 <= param_1) {
      cVar1 = '\x04';
      goto LAB_60018d94;
    }
    if (120.0 <= param_1) {
      cVar1 = '\x03';
      goto LAB_60018d94;
    }
    if (60.0 <= param_1) {
      cVar1 = '\x02';
      goto LAB_60018d94;
    }
    if (30.0 <= param_1) {
      cVar1 = '\x01';
      goto LAB_60018d94;
    }
  }
  else {
    if (param_1 <= -150.0) {
      cVar1 = -4;
      goto LAB_60018d94;
    }
    if (param_1 <= -120.0) {
      cVar1 = -3;
      goto LAB_60018d94;
    }
    if (param_1 <= -60.0) {
      cVar1 = -2;
      goto LAB_60018d94;
    }
    if (param_1 <= -30.0) {
      cVar1 = -1;
      goto LAB_60018d94;
    }
  }
  cVar1 = '\0';
LAB_60018d94:
  return (int)cVar1;
}
