
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60022068 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4
FUN_60021fec(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            )

{
  int iVar1;
  undefined4 uVar2;
  float local_a8;
  float local_a4;
  float local_a0;
  float local_9c;
  undefined1 auStack_98 [32];
  undefined1 auStack_78 [32];
  undefined4 local_58 [2];
  undefined4 local_50;
  float local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_38;
  float local_30;
  undefined4 local_2c;
  float local_28;
  
  if (param_5 == 0) {
    return 0xffffffff;
  }
  iVar1 = FUN_60030c34();
  if (iVar1 != 0) {
    return 0xffffffff;
  }
  ZeroBytes(local_58,0x38);
  ZeroBytes(&local_a8,0x50);
  iVar1 = FUN_60135c80(0x200895f0,local_58);
  if ((iVar1 == 0) && (30.0 <= ABS(local_28))) {
    local_a0 = local_28;
    local_a8 = local_48;
    local_a4 = local_30;
    local_9c = local_30 - local_48;
    FUN_60135f50(local_40,param_2,local_38,param_4,local_2c,auStack_98);
    uVar2 = FUN_60135e30(local_44);
    FUN_60135f50(local_58[0],param_2,local_50,param_4,uVar2,auStack_78);
    iVar1 = FUN_60135f20(&uRam2000b0ac,&local_a8);
    if (iVar1 != 0) {
      FUN_6015b87c();
      goto LAB_600220f8;
    }
    iRam2000b0ec = iRam2000b0ec + 1;
    FUN_60135d20(0x2000b0c0,&local_a8);
  }
  FUN_6015b87c();
  FUN_60135ccc(*(undefined4 *)(param_5 + 0x14),0x2000b0c0);
  FUN_60135cb6(0x2000b0c0,0x2000b0b0);
  iVar1 = FUN_60136026(&uRam2000b0ac,0x2000b0b0);
  if (((iVar1 == 0) && (iVar1 = FUN_60135fe0(&uRam2000b0ac,iRam2000b0ec), iVar1 == 0)) &&
     (iVar1 = FUN_60135eb8(&uRam2000b0ac), iVar1 == 0)) {
    FUN_601667bc(uRam2000b0ac);
    uRam2000b0ac = 0;
    iVar1 = FUN_60166758(&uRam2000b0a8,0x2008b0e4,1);
    if (iVar1 != 0) {
      uRam2000b0a8 = 0;
      return 0xffffffff;
    }
    uRam2000b0dc = &uRam2000b0a8;
    return 0;
  }
LAB_600220f8:
  FUN_601667bc(uRam2000b0ac);
  uRam2000b0ac = 0;
  FUN_60163bbe(0x2008b0e4);
  return 0xffffffff;
}
