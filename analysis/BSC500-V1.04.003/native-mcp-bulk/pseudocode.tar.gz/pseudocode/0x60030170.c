
undefined4 FUN_60030170(undefined4 *param_1)

{
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0xffffffff;
    return 0;
  }
  return 0x16;
}
