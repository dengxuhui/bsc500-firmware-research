
void FUN_60023a7c(int param_1,int param_2,uint param_3)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  
  for (uVar1 = 0; uVar2 = uVar1, uVar1 != param_3; uVar1 = uVar1 + 1) {
    for (; uVar2 < param_3; uVar2 = uVar2 + 1) {
      iVar5 = *(int *)(param_1 + uVar2 * 4);
      iVar3 = *(int *)(param_1 + uVar1 * 4);
      if (iVar3 < iVar5) {
        *(int *)(param_1 + uVar1 * 4) = iVar5;
        *(int *)(param_1 + uVar2 * 4) = iVar3;
        if (param_2 != 0) {
          uVar4 = *(undefined4 *)(param_2 + uVar1 * 4);
          *(undefined4 *)(param_2 + uVar1 * 4) = *(undefined4 *)(param_2 + uVar2 * 4);
          *(undefined4 *)(param_2 + uVar2 * 4) = uVar4;
        }
      }
    }
  }
  return;
}
