
undefined4 FUN_60031e74(undefined4 *param_1,short *param_2,short *param_3,undefined4 param_4)

{
  ushort uVar1;
  short sVar2;
  short sVar3;
  ushort uVar4;
  ushort uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  uint *puVar9;
  ushort *puVar10;
  uint *puVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  int iVar15;
  uint uVar16;
  undefined1 auStack_7c [8];
  short local_74;
  short local_72;
  short local_70;
  short local_6e;
  undefined4 local_6c;
  undefined4 local_68;
  short local_64;
  short local_62;
  undefined4 local_60;
  short local_5c;
  short local_5a;
  int local_58;
  int local_54;
  undefined4 local_50;
  uint local_4c;
  int local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 uStack_3c;
  undefined1 auStack_38 [4];
  char local_34;
  undefined4 local_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  
  if (*(byte *)((int)param_2 + 0xb) < 3) {
LAB_60031e82:
    uVar6 = 1;
  }
  else {
    if (param_2[4] == 0) {
      iVar7 = FUN_6015cb64();
      iVar8 = FUN_6015bd44();
      if (iVar7 != iVar8) {
                    /* WARNING: Subroutine does not return */
        FUN_6016804c("osThreadGetId() == gui_task_thread_get()","sifli_gpu_img_decode_and_draw",
                     0x6aa);
      }
      iVar7 = FUN_60041974(param_4,param_2[4],*(undefined4 *)(param_2 + 8));
      if ((iVar7 != 0) && ((*(uint *)(iVar7 + 0x14) & 0x1f) < 7)) {
        if ((*(int *)(iVar7 + 0x20) == 0) && (*(int *)(iVar7 + 0x18) != 0)) {
          local_74 = *param_3;
          local_72 = param_3[1];
          local_70 = param_3[2];
          local_6e = param_3[3];
          if ((*param_2 != 0) || (param_2[1] != 0x100)) {
            FUN_6014d984(&local_74,(int)(short)((local_70 - local_74) + 1),
                         (int)(short)((local_6e - local_72) + 1),(int)*param_2,param_2[1],
                         param_2 + 2);
            local_74 = local_74 + *param_3;
            local_72 = local_72 + param_3[1];
            local_70 = *param_3 + local_70;
            local_6e = local_6e + param_3[1];
          }
          iVar8 = FUN_6014f950(auStack_7c,param_1[2],&local_74);
          if (iVar8 != 0) {
            uVar13 = *(uint *)(iVar7 + 0x14);
            iVar8 = FUN_6003b314(param_1[1],auStack_38);
            if (iVar8 == 0) {
              uStack_28 = 0;
            }
            else {
              if (local_34 != '\x04') {
                FUN_6015e5e0(3,"./../../../../Application/App/touchx_gui/touchx_embed/lv_gpu.c",
                             0x486,"draw_img","Asserted at expression: %s",
                             "LV_DRAW_MASK_TYPE_MAP == mask_param.dsc.type");
                    /* WARNING: Subroutine does not return */
                FUN_6016804c(&DAT_60434315,"draw_img",0x486);
              }
              local_40 = local_30;
              uStack_3c = uStack_2c;
            }
            uVar13 = uVar13 & 0x1f;
            if ((uVar13 < 7) && ((char)param_2[5] == '\0')) {
              uVar16 = *(uint *)(iVar7 + 0x14);
              local_44 = *(undefined4 *)(iVar7 + 0x18);
              local_50 = *param_1;
              puVar10 = (ushort *)param_1[1];
              local_48 = (uVar16 >> 0x15) * ((uVar16 & 0x1fffff) >> 10) * 2;
              uVar14 = ((uint)puVar10[2] - (uint)*puVar10) + 1 & 0x7ff;
              uVar12 = ((uint)puVar10[3] - (uint)puVar10[1]) + 1;
              local_54 = uVar14 * (uVar12 & 0x7ff) * 2;
              local_58 = (uVar14 << 10 | uVar12 * 0x200000) + 4;
              local_4c = uVar16;
              if ((ushort)param_2[1] < 0x21) {
                if (uVar13 - 1 < 2) {
                  uVar6 = 5;
                  if (uVar13 == 1) {
                    uVar6 = 4;
                  }
                  uVar13 = (short)((param_3[2] - *param_3) + 1) * 0x21;
                  uVar12 = (short)((param_3[3] - param_3[1]) + 1) * 0x21;
                  puVar9 = (uint *)FUN_6003c294((int)(uVar13 + (uVar13 >> 0x18)) >> 8,
                                                (int)(uVar12 + (uVar12 >> 0x18)) >> 8,uVar6);
                  if (puVar9 != (uint *)0x0) {
                    local_5a = (ushort)(uVar16 >> 0x15) - 1;
                    uVar1 = param_2[1];
                    uVar13 = 0x100;
                    local_60 = 0;
                    local_5c = ((ushort)(uVar16 >> 10) & 0x7ff) - 1;
                    uVar4 = (ushort)((*puVar9 << 0xb) >> 0x15);
                    local_6c = 0;
                    uVar5 = (ushort)(*puVar9 >> 0x15);
                    puVar11 = &local_4c;
                    for (; local_68 = local_60, local_62 = uVar5 - 1, local_64 = uVar4 - 1,
                        uVar1 < 0x21; uVar1 = (ushort)(((ulonglong)uVar1 << 8) / 0x21)) {
                      FUN_6010399e(puVar9,puVar11,0,0x21,&local_60,&local_68,&local_68,&local_6c,
                                   0xff,0x7e0,0,0,0,0,0);
                      FUN_6003f370(param_1);
                      local_60 = local_68;
                      local_5c = local_64;
                      local_5a = local_62;
                      uVar12 = (short)((local_64 - (short)local_68) + 1) * 0x21;
                      uVar4 = (ushort)(uVar12 + (uVar12 >> 0x18) >> 8);
                      uVar12 = (short)((local_62 - local_68._2_2_) + 1) * 0x21;
                      uVar5 = (ushort)(uVar12 + (uVar12 >> 0x18) >> 8);
                      uVar13 = uVar13 * 0x21 >> 8;
                      puVar11 = puVar9;
                    }
                    iVar15 = (0x100 - uVar13) * (int)param_2[3];
                    iVar8 = (int)param_2[2] * (0x100 - uVar13);
                    iVar7 = uVar13 * (int)param_2[2];
                    sVar2 = param_3[1] + (short)(iVar15 + ((uint)(iVar15 >> 0x1f) >> 0x18) >> 8);
                    sVar3 = *param_3 + (short)(iVar8 + ((uint)(iVar8 >> 0x1f) >> 0x18) >> 8);
                    local_60 = CONCAT22(sVar2,sVar3);
                    iVar8 = uVar13 * (int)param_2[3];
                    local_6c = CONCAT22((short)(iVar8 + ((uint)(iVar8 >> 0x1f) >> 0x18) >> 8),
                                        (short)(iVar7 + ((uint)(iVar7 >> 0x1f) >> 0x18) >> 8));
                    _local_5c = CONCAT22(sVar2 + (ushort)(*puVar9 >> 0x15) + -1,
                                         sVar3 + (ushort)((*puVar9 << 0xb) >> 0x15) + -1);
                    FUN_6010399e(&local_58,puVar9,(int)*param_2,uVar1,&local_60,param_1[1],
                                 param_1[2],&local_6c,*(undefined1 *)((int)param_2 + 0xb),0x7e0,0,0,
                                 0,uStack_28,&local_40);
                    FUN_6003f370(param_1);
                    FUN_6003c2f4(puVar9);
                  }
                }
              }
              else {
                FUN_6010399e(&local_58,&local_4c,(int)*param_2,param_2[1],param_3,puVar10,param_1[2]
                             ,param_2 + 2,*(undefined1 *)((int)param_2 + 0xb),0x7e0,0,0,0,uStack_28,
                             &local_40);
              }
            }
          }
        }
        goto LAB_60031e82;
      }
    }
    uVar6 = 0;
  }
  return uVar6;
}
