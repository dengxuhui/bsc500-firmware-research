
void FUN_6001b988(int param_1)

{
  char cVar1;
  uint uVar2;
  char cVar3;
  short sVar4;
  int iVar5;
  ushort *puVar6;
  uint uVar7;
  short sVar8;
  uint uVar9;
  
  *(undefined4 *)(param_1 + 0xd0) = 0xffffffff;
  *(undefined4 *)(param_1 + 0xd4) = 0xffffffff;
  *(undefined2 *)(param_1 + 0xd9) = 0xffff;
  for (iVar5 = 0; iVar5 != 8; iVar5 = iVar5 + 1) {
    switch(*(undefined1 *)(param_1 + 0x74 + iVar5)) {
    case 1:
      if (*(ushort *)(param_1 + 0xe8) != 0xffff) {
        uVar2 = (uint)*(ushort *)(param_1 + 0xe8) * 1000;
        uVar7 = (uint)*(ushort *)(param_1 + 0x1c);
code_r0x6001ba2e:
        uVar2 = uVar2 / uVar7;
        *(short *)(param_1 + 0xd0) = (short)uVar2;
        uVar7 = (uRam2000adac + uVar2 & 0xffff) / 1000;
        uRam2000adac = (short)uVar7 * -1000 + (short)(uRam2000adac + uVar2);
        *(short *)(param_1 + 0xd2) = (short)uVar7;
        uVar9 = uVar2 & 0xffff;
joined_r0x6001ba20:
        if ((uVar9 != 0xffff) && ((uVar7 == 0 || ((uVar2 & 0xffff) == 0)))) {
          if (uRam2000adae < 0xf) {
            uRam2000adae = uRam2000adae + 1;
            goto LAB_6001ba6a;
          }
          iVar5 = 0;
          goto code_r0x6001bb50;
        }
        goto LAB_6001ba60;
      }
      break;
    case 2:
      uVar2 = (uint)*(ushort *)(param_1 + 0xe4);
      if (uVar2 != 0xffff) {
        *(ushort *)(param_1 + 0xd0) = *(ushort *)(param_1 + 0xe4);
        puVar6 = (ushort *)(param_1 + 0xe6);
code_r0x6001ba18:
        uVar7 = (uint)*puVar6;
        *(ushort *)(param_1 + 0xd2) = *puVar6;
        uVar9 = uVar7;
        goto joined_r0x6001ba20;
      }
      break;
    case 3:
      uVar2 = (uint)*(ushort *)(param_1 + 0xdc);
      if (uVar2 != 0xffff) {
        *(ushort *)(param_1 + 0xd0) = *(ushort *)(param_1 + 0xdc);
        puVar6 = (ushort *)(param_1 + 0xde);
        goto code_r0x6001ba18;
      }
      break;
    case 4:
      uVar2 = (uint)*(ushort *)(param_1 + 0xe0);
      if (uVar2 != 0xffff) {
        puVar6 = (ushort *)(param_1 + 0xe2);
        *(ushort *)(param_1 + 0xd0) = *(ushort *)(param_1 + 0xe0);
        goto code_r0x6001ba18;
      }
      break;
    case 7:
      if ((*(ushort *)(param_1 + 0xea) != 0xffff) && (*(ushort *)(param_1 + 0x112) != 0)) {
        uVar2 = (uint)*(ushort *)(param_1 + 0xea) * 1000000;
        uVar7 = (uint)*(ushort *)(param_1 + 0x112) * 0x24;
        goto code_r0x6001ba2e;
      }
    }
  }
LAB_6001ba60:
  if (uRam2000adae != 0) {
    uRam2000adae = 0;
  }
LAB_6001ba6a:
  for (iVar5 = 0; iVar5 != 8; iVar5 = iVar5 + 1) {
    switch(*(undefined1 *)(param_1 + 0x7c + iVar5)) {
    case 1:
      cVar3 = *(char *)(param_1 + 0xf0);
      cVar1 = cVar3;
      if (cVar3 != -1 && cVar3 != '\0') goto LAB_6001bae8;
      break;
    case 2:
      cVar3 = *(char *)(param_1 + 0xef);
      goto code_r0x6001ba9e;
    case 4:
      cVar3 = *(char *)(param_1 + 0xee);
code_r0x6001ba9e:
      if ((cVar3 != '\0') && (cVar1 = cVar3, cVar3 != -1)) goto LAB_6001bae8;
      break;
    case 5:
      cVar3 = *(char *)(param_1 + 0xed);
      if ((cVar3 != '\0') && (cVar3 != -1)) {
        cVar1 = *(char *)(param_1 + 0xec);
        goto LAB_6001bae8;
      }
    }
  }
  if ((((*(char *)(param_1 + 0xef) == '\0') || (*(char *)(param_1 + 0xed) == '\0')) ||
      (*(char *)(param_1 + 0xee) == '\0')) || (*(char *)(param_1 + 0xf0) == '\0')) {
    cVar3 = '\0';
    cVar1 = '\0';
LAB_6001bae8:
    *(char *)(param_1 + 0xd9) = cVar3;
    *(char *)(param_1 + 0xda) = cVar1;
  }
  iVar5 = 0;
  do {
    if (iVar5 == 8) {
      if ((*(short *)(param_1 + 0xf4) != 0) && (*(short *)(param_1 + 0xf6) != 0)) {
        return;
      }
      sVar8 = 0;
      sVar4 = 0;
LAB_6001bb40:
      *(short *)(param_1 + 0xd4) = sVar8;
      *(short *)(param_1 + 0xd6) = sVar4;
      return;
    }
    cVar3 = *(char *)(param_1 + 0x84 + iVar5);
    if (cVar3 == '\x01') {
      sVar8 = *(short *)(param_1 + 0xf6);
      sVar4 = sVar8;
      if (sVar8 != -1 && sVar8 != 0) goto LAB_6001bb40;
    }
    else if (((cVar3 == '\x02') && (sVar8 = *(short *)(param_1 + 0xf4), sVar8 != 0)) &&
            (sVar8 != -1)) {
      sVar4 = *(short *)(param_1 + 0xf2);
      goto LAB_6001bb40;
    }
    iVar5 = iVar5 + 1;
  } while( true );
code_r0x6001bb50:
  if (iVar5 == 8) goto code_r0x6001bc3a;
  switch(*(undefined1 *)(param_1 + 0x74 + iVar5)) {
  case 1:
    uVar2 = (uint)*(ushort *)(param_1 + 0xe8);
    if ((uVar2 != 0) && (uVar2 != 0xffff)) {
      uVar2 = (uVar2 * 1000) / (uint)*(ushort *)(param_1 + 0x1c);
      uVar9 = uRam2000adac + uVar2;
      sVar8 = (short)uVar2;
      *(short *)(param_1 + 0xd0) = sVar8;
      uVar7 = (uVar9 & 0xffff) / 1000;
      uRam2000adac = (short)uVar7 * -1000 + (short)uVar9;
code_r0x6001bc12:
      *(short *)(param_1 + 0xd2) = (short)uVar7;
code_r0x6001bc18:
      if ((((*(char *)(param_1 + 0xcc) == '\0') || (*(int *)(param_1 + 0xc4) == 0)) || (sVar8 == -1)
          ) || (uVar7 != 0)) goto LAB_6001ba6a;
      goto code_r0x6001bc3a;
    }
    break;
  case 2:
    sVar8 = *(short *)(param_1 + 0xe4);
    if ((sVar8 != 0) && (sVar8 != -1)) {
      uVar7 = (uint)*(ushort *)(param_1 + 0xe6);
code_r0x6001bba4:
      if ((uVar7 != 0) && (uVar7 != 0xffff)) {
        *(short *)(param_1 + 0xd2) = (short)uVar7;
        *(short *)(param_1 + 0xd0) = sVar8;
        goto code_r0x6001bc18;
      }
    }
    break;
  case 3:
    sVar8 = *(short *)(param_1 + 0xdc);
    if ((sVar8 != 0) && (sVar8 != -1)) {
      uVar7 = (uint)*(ushort *)(param_1 + 0xde);
      goto code_r0x6001bba4;
    }
    break;
  case 4:
    sVar8 = *(short *)(param_1 + 0xe0);
    if ((sVar8 != 0) && (sVar8 != -1)) {
      uVar7 = (uint)*(ushort *)(param_1 + 0xe2);
      goto code_r0x6001bba4;
    }
    break;
  case 7:
    uVar2 = (uint)*(ushort *)(param_1 + 0xea);
    if (((uVar2 != 0) && (uVar2 != 0xffff)) && (*(ushort *)(param_1 + 0x112) != 0)) {
      uVar7 = (uVar2 * 1000000) / ((uint)*(ushort *)(param_1 + 0x112) * 0x24);
      uVar2 = uRam2000adac + uVar7;
      sVar8 = (short)uVar7;
      *(short *)(param_1 + 0xd0) = sVar8;
      uVar7 = (uVar2 & 0xffff) / 1000;
      uRam2000adac = (short)uVar7 * -1000 + (short)uVar2;
      goto code_r0x6001bc12;
    }
  }
  iVar5 = iVar5 + 1;
  goto code_r0x6001bb50;
code_r0x6001bc3a:
  *(undefined2 *)(param_1 + 0xd2) = 0xffff;
  *(undefined2 *)(param_1 + 0xd0) = 0xffff;
  *(undefined1 *)(param_1 + 0x8c) = 0;
  goto LAB_6001ba6a;
}
