
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_600193c8(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  if (_DAT_20009590 != 0) {
    FUN_60166b98();
  }
  iVar1 = FUN_60164eb0(1);
  if (iVar1 != 0) {
    piVar3 = (int *)(iVar1 + 4);
    do {
      piVar3 = (int *)*piVar3;
      if (piVar3 == (int *)(iVar1 + 4)) {
        if (_DAT_20009590 != 0) {
          FUN_60166b64();
        }
        return 0;
      }
      iVar2 = FUN_601343dc(piVar3 + -5,param_1,0x10);
    } while (iVar2 != 0);
    if (_DAT_20009590 != 0) {
      FUN_60166b64();
    }
    return (int)(piVar3 + -5);
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("information != RT_NULL","rt_thread_find",0x30c);
}
