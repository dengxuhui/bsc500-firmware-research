
void FUN_6001b644(undefined4 *param_1)

{
  *param_1 = 0;
  FUN_60163288();
  return;
}
