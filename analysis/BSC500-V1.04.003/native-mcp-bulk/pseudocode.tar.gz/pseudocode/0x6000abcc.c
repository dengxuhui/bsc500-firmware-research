
void FUN_6000abcc(undefined4 *param_1,int param_2,undefined4 *param_3)

{
  char *pcVar1;
  int iVar2;
  undefined4 *puVar3;
  
  puVar3 = param_3;
  if (DAT_2000bb13 == '\x01') {
    FUN_60161424("stack_is_overflow\n");
    FUN_60161424(&DAT_603f7cc3);
    if (DAT_2000bb14 == '\0') {
      pcVar1 = "Error: Main stack(%08x) was overflow";
    }
    else {
      FUN_60161424("on_thread_before_fault\n");
      FUN_60161424(&DAT_603f7cc3);
      pcVar1 = "Error: Thread stack(%08x) was overflow";
    }
    FUN_60161424(pcVar1,param_3);
    FUN_60161424(&DAT_603f7cc3);
    puVar3 = param_1;
    if ((param_1 <= param_3) && (puVar3 = param_3, (undefined4 *)(param_2 + (int)param_1) < param_3)
       ) {
      puVar3 = (undefined4 *)(param_2 + (int)param_1);
    }
  }
  FUN_60161424("===== Thread stack information =====");
  FUN_60161424(&DAT_603f7cc3);
  for (; puVar3 < (undefined4 *)((int)param_1 + param_2); puVar3 = puVar3 + 1) {
    iVar2 = FUN_601597bc(*puVar3);
    if (iVar2 != 0) {
      FUN_60161424("0x%08x",*puVar3);
      FUN_60161424(&DAT_603f7cc3);
    }
  }
  FUN_60161424("====================================");
  FUN_60161424(&DAT_603f7cc3);
  return;
}
