
undefined4 FUN_6001c894(int param_1,float *param_2)

{
  undefined4 uVar1;
  float fVar2;
  
  uVar1 = 0xffffffff;
  if ((param_1 != 0) && (param_2 != (float *)0x0)) {
    fVar2 = *param_2;
    if (-273.15 <= fVar2) {
      if (*(int *)(param_1 + 0x14) == 0) {
        *(float *)(param_1 + 0x10) = fVar2;
        *(float *)(param_1 + 8) = fVar2;
        *(undefined4 *)(param_1 + 0x14) = 1;
      }
      else {
        *(int *)(param_1 + 0x14) = *(int *)(param_1 + 0x14) + 1;
        if (fVar2 < *(float *)(param_1 + 8)) {
          *(float *)(param_1 + 8) = fVar2;
        }
      }
      uVar1 = FUN_6011cfa8(param_1);
      *(undefined4 *)(param_1 + 0xc) = uVar1;
      if (*(float *)(param_1 + 0x10) < *param_2) {
        *(float *)(param_1 + 0x10) = *param_2;
      }
    }
    uVar1 = 0;
  }
  return uVar1;
}
