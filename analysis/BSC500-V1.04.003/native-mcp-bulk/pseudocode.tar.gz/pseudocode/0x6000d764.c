
void FUN_6000d764(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 local_5c [16];
  
  ZeroBytes(local_5c,0x40);
  iVar1 = FUN_600154ec(local_5c,0x10,param_1);
  iVar3 = 0x20045b64;
  for (iVar2 = 0; iVar1 != iVar2; iVar2 = iVar2 + 1) {
    FUN_601681f4(iVar3,&DAT_6000d7d8,local_5c[iVar2]);
    *(undefined1 *)(iVar3 + 8) = 0x20;
    iVar3 = iVar3 + 9;
  }
  if (iVar1 == 0) {
    FUN_60161424("Dump call stack has an error");
  }
  else {
    FUN_60161424("Show more call stack info by run: addr2line -e %s%s -a -f %-*.s",0x2000bb15,
                 &DAT_6000d824,iVar1 * 9,0x20045b64);
  }
  FUN_60161424(&DAT_603f7cc3);
  return;
}
