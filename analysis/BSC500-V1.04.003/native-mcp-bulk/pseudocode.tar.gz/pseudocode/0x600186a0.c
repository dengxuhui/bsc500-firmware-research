
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600186a0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_14;
  
  local_14 = param_4;
  if (_DAT_2000ba84 == 0) {
    _DAT_2000ba84 = FUN_60165098("qwos_mem",1,0,param_4,param_3);
    if (_DAT_2000ba84 == 0) goto LAB_600186c2;
  }
  FUN_601668f8(_DAT_2000ba84,0xffffffff);
LAB_600186c2:
  FUN_600239c0(_DAT_2000ba88,&local_14);
  if (_DAT_2000ba84 != 0) {
    FUN_60166af4();
  }
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0x40000;
  }
  if (param_2 != (undefined4 *)0x0) {
    *param_2 = local_14;
  }
  return;
}
