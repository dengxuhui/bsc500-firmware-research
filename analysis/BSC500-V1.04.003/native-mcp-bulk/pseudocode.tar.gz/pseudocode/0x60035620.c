
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60035620(undefined4 param_1)

{
  _DAT_20049b40 = param_1;
  return;
}
