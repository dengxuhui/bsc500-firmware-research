
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x6002492a */
/* WARNING: Restarted to delay deadcode elimination for space: register */

int FUN_600248b8(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4,int param_5,
                undefined4 param_6,int param_7,int param_8,int param_9,int param_10,
                undefined2 param_11,undefined4 param_12)

{
  float *pfVar1;
  bool bVar2;
  bool bVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int *piVar9;
  int *piVar10;
  int *piVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  int iVar15;
  undefined4 *puVar16;
  undefined4 *puVar17;
  undefined4 *puVar18;
  int *piVar19;
  int iVar20;
  int iVar21;
  undefined4 *puVar22;
  uint uVar23;
  int iVar24;
  uint uVar25;
  int iVar26;
  int iVar27;
  int iVar28;
  int iVar29;
  int iVar30;
  int iVar31;
  uint uVar32;
  int iVar33;
  uint uVar34;
  bool bVar35;
  uint in_fpscr;
  float fVar36;
  float fVar37;
  float fVar38;
  float fVar39;
  undefined4 *local_c8;
  int local_c4;
  int local_a8;
  uint local_84;
  undefined4 *local_74;
  undefined4 local_58;
  undefined4 local_50 [2];
  
  if (param_8 == param_10) {
    iVar4 = FUN_60125e9c(8);
    if (iVar4 != 0) {
      if (param_9 == -1) {
        FUN_60136908(param_3,param_8,0,local_50);
        param_9 = FUN_60033ad0(local_50[0],param_2,local_58,param_3,param_4,param_5,1);
      }
      if (param_9 + 0x10000U < 0xffff) {
        param_9 = FUN_60126490(param_9);
      }
      uVar5 = FUN_600339dc(param_4,param_8,param_9,param_12);
      iVar6 = FUN_60125f94(iVar4,param_8,param_9);
      if ((iVar6 != 0) && (iVar7 = FUN_60125f94(iVar4,param_8,uVar5), iVar7 != 0)) {
        *(int *)(iVar4 + 0x20) = param_8;
        *(int *)(iVar4 + 0x24) = param_9;
        *(int *)(iVar4 + 0x28) = param_8;
        *(undefined4 *)(iVar4 + 0x2c) = uVar5;
        *(int *)(iVar6 + 0xc) = iVar7;
        goto LAB_6002499e;
      }
LAB_60024f02:
      FUN_60127138(iVar4);
    }
LAB_60024f06:
    iVar4 = 0;
  }
  else {
    iVar4 = FUN_60106e40(param_3,param_4,param_5);
    if (iVar4 == 0) {
      if ((param_9 == -1) || (iVar4 = FUN_60106e40(param_3,param_4,param_5,param_6), iVar4 == 0)) {
        FUN_601516f0("Error: Cannot find initial section of route compatible with profile.\n",0x45,1
                     ,0x20008868);
        goto LAB_60024f06;
      }
      if (*(int *)(iVar4 + 0x28) == -1) {
        param_9 = -1;
        goto LAB_600249dc;
      }
    }
    else if (*(int *)(iVar4 + 0x28) == -1) {
LAB_600249dc:
      if (iRam2000af54 == 0) {
        FUN_6011fff0("Finding Finish Route: Nodes checked = 0");
      }
      iVar6 = FUN_60125e9c(2);
      if (iVar6 != 0) {
        iVar7 = FUN_60125e9c(8);
        if (iVar7 != 0) {
          iVar8 = FUN_60125de2(8);
          if (iVar8 != 0) {
            piVar9 = (int *)FUN_60125f94(iVar6,param_10,0xffffffff);
            if ((piVar9 != (int *)0x0) && (FUN_60125f04(0,iVar8), *(int *)(iVar8 + 0xc) != 0)) {
LAB_60024a5e:
              piVar10 = (int *)FUN_60125c90(iVar8);
              if (piVar10 != (int *)0x0) {
                uVar25 = piVar10[1];
                iVar33 = *piVar10;
                local_84 = uVar25;
                if (uVar25 + 0x10000 < 0xffff) {
                  local_84 = FUN_60126490(uVar25);
                }
                if (uVar25 == 0xffffffff) {
                  piVar11 = (int *)0x0;
                  iVar12 = iVar33;
                }
                else {
                  if (uVar25 < 0xffff0000) {
                    piVar11 = (int *)FUN_601264ba(param_4,uVar25,1);
                  }
                  else {
                    piVar11 = (int *)FUN_60034de0();
                  }
                  iVar12 = *piVar11;
                  if (iVar12 == iVar33) {
                    iVar12 = piVar11[1];
                  }
                }
                uVar34 = iVar12 + 0x10000;
                if (0xfffe < uVar34) {
                  local_74 = (undefined4 *)FUN_60125d50(param_3,iVar12,1);
                  if (uVar25 != 0xffffffff) goto code_r0x60024af2;
                  fVar39 = 0.0;
                  bVar2 = true;
                  goto LAB_60024bb0;
                }
                fVar39 = 0.0;
                local_74 = (undefined4 *)0x0;
                bVar2 = false;
                bVar35 = false;
                if (uVar25 != 0xffffffff) goto LAB_60024b04;
                goto LAB_60024ba6;
              }
              FUN_60125a74(iVar8);
              FUN_60127138(iVar6);
              if (*(int *)(iVar7 + 8) == 0) {
                iVar6 = iVar7;
                if (iRam2000af54 != 0) goto LAB_60024ef0;
                goto LAB_60024eec;
              }
              *(int *)(iVar7 + 0x28) = param_10;
              if (iRam2000af54 == 0) {
                FUN_60120034("Found Finish Route: Nodes checked = %d");
              }
              iVar8 = FUN_600341d0(param_3,param_4,param_5,param_6);
              iVar6 = iVar4;
              if ((param_9 == -1) || (iVar8 != 0)) {
LAB_60024fc2:
                if (iVar8 != 0) {
                  if (iRam2000af54 == 0) {
                    FUN_6011fff0("Finding Combined Route: Nodes = 0");
                  }
                  iVar4 = FUN_60125e9c(10);
                  if (iVar4 != 0) {
                    puVar16 = (undefined4 *)
                              FUN_6012726c(iVar8,*(undefined4 *)(iVar8 + 0x20),
                                           *(undefined4 *)(iVar8 + 0x24));
                    piVar9 = (int *)FUN_60125f94(iVar4,*(undefined4 *)(iVar6 + 0x20),
                                                 *(undefined4 *)(iVar6 + 0x24));
                    if (piVar9 != (int *)0x0) {
                      if (1 < *(uint *)(iVar6 + 8)) {
                        puVar18 = puVar16;
                        if ((undefined4 *)puVar16[2] != (undefined4 *)0xffffffff) {
                          puVar18 = (undefined4 *)puVar16[2];
                        }
                        FUN_6012726c(iVar6,*puVar18,puVar18[1]);
                        FUN_6011ffe0();
                        iVar33 = FUN_6012726c(iVar6,*(undefined4 *)(iVar6 + 0x20),
                                              *(undefined4 *)(iVar6 + 0x24));
                        piVar10 = piVar9;
                        puVar18 = *(undefined4 **)(iVar33 + 0xc);
                        do {
                          piVar9 = (int *)FUN_60125f94(iVar4,*puVar18,puVar18[1]);
                          if (piVar9 == (int *)0x0) goto LAB_600255f8;
                          piVar9[2] = (int)piVar10;
                          puVar17 = (undefined4 *)puVar18[3];
                          piVar9[4] = puVar18[4];
                          piVar10 = piVar9;
                          puVar18 = puVar17;
                        } while (puVar17 != (undefined4 *)0x0);
                      }
                      while( true ) {
                        if ((int)puVar16[3] + 1U < 2) break;
                        iVar12 = *piVar9;
                        iVar33 = *(int *)puVar16[3];
                        iVar31 = piVar9[1];
                        if (iVar33 + 0x10000U < 0xffff) {
                          FUN_60133d58(iVar33,local_50);
                        }
                        else {
                          FUN_60136908(param_3,iVar33,0);
                        }
                        iVar15 = FUN_60125e9c(8);
                        if (iVar15 == 0) {
LAB_600255ea:
                          if (iRam2000af54 == 0) {
                            FUN_60120034("Found Combined Route: Nodes = %d - Fail",
                                         *(undefined4 *)(iVar4 + 8));
                          }
                          goto LAB_600255f8;
                        }
                        iVar26 = FUN_60125de2(8);
                        if (iVar26 == 0) {
LAB_600255e4:
                          FUN_60127138(iVar15);
                          goto LAB_600255ea;
                        }
                        puVar18 = (undefined4 *)FUN_60125f94(iVar15,iVar12,iVar31);
                        if ((puVar18 == (undefined4 *)0x0) ||
                           (FUN_60125f04(0,iVar26), *(int *)(iVar26 + 0xc) == 0)) {
                          FUN_60125a74(iVar26);
                          goto LAB_600255e4;
                        }
                        bVar2 = false;
                        if ((iVar31 != -1) && (0xfffe < iVar12 + 0x10000U)) {
                          iVar31 = FUN_60125d50(param_3,iVar12,1);
                          bVar2 = (*(ushort *)(iVar31 + 8) & *(ushort *)(param_7 + 0x78)) == 0;
                        }
                        fVar39 = 1e+30;
                        local_c8 = (undefined4 *)0x0;
                        while ((piVar10 = (int *)FUN_60125c90(iVar26), piVar10 != (int *)0x0 &&
                               (iRam2000af50 == 0))) {
                          uVar25 = in_fpscr & 0xfffffff | (uint)((float)piVar10[4] < fVar39) << 0x1f
                          ;
                          in_fpscr = uVar25 | (uint)(NAN((float)piVar10[4]) || NAN(fVar39)) << 0x1c;
                          if ((byte)(uVar25 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) {
                            iVar27 = *piVar10;
                            iVar31 = piVar10[1];
                            local_84 = iVar31;
                            if (iVar31 + 0x10000U < 0xffff) {
                              local_84 = FUN_60126490(iVar31);
                            }
                            uVar25 = iVar27 + 0x10000;
                            if (uVar25 < 0xffff) {
                              piVar11 = (int *)FUN_6011ffbc(iVar27);
                              local_a8 = -1;
                            }
                            else {
                              puVar17 = (undefined4 *)FUN_60125d50(param_3,iVar27,1);
                              if ((*(int *)(param_7 + 0x70) == 0) ||
                                 (-1 < (int)((uint)*(ushort *)((int)puVar17 + 10) << 0x13))) {
                                local_a8 = -1;
                              }
                              else {
                                local_a8 = FUN_6011fe5c(param_6,iVar27,local_84);
                              }
                              piVar11 = (int *)FUN_601264ba(param_4,*puVar17,1);
                            }
                            while (piVar19 = piVar11, piVar19 != (int *)0x0) {
                              iVar20 = *piVar19;
                              iVar29 = iVar20;
                              if (iVar20 == iVar27) {
                                iVar29 = piVar19[1];
                              }
                              iVar24 = piVar19[4];
                              puVar17 = local_c8;
                              fVar37 = fVar39;
                              if (iVar24 << 4 < 0) {
                                if (*(int *)(param_7 + 0x6c) != 0) {
                                  if (iVar20 == iVar27) {
                                    iVar24 = iVar24 << 2;
                                  }
                                  else {
                                    iVar24 = iVar24 << 1;
                                  }
                                  if ((iVar24 < 0) &&
                                     ((*(short *)(param_7 + 0x78) != 8 ||
                                      (iVar20 = FUN_60125bc4(param_5,piVar19[3],1),
                                      -1 < (int)((uint)*(byte *)(iVar20 + 6) << 0x1b)))))
                                  goto LAB_60025490;
                                }
                                uVar34 = iVar29 + 0x10000;
                                bVar35 = uVar25 == 0xffff;
                                if (0xfffe < uVar25) {
                                  bVar35 = uVar34 == 0xfffe;
                                }
                                if ((0xfffe < uVar25 && 0xfffd < uVar34) && !bVar35) {
                                  iVar24 = *(int *)(param_4 + (((int)piVar19 - (param_4 + 0x10)) /
                                                              0x14) * 4 + 0x60);
                                  iVar20 = iVar24;
                                }
                                else {
                                  iVar24 = FUN_6011ffd0(piVar19);
                                  iVar20 = FUN_60126490();
                                }
                                if ((bool)(iVar27 == iVar12 & bVar2)) {
                                  if (iVar20 == piVar10[1]) {
LAB_600252c6:
                                    if ((local_a8 == -1) ||
                                       (iVar20 = FUN_6011ff10(param_6,local_a8,iVar27,local_84),
                                       iVar20 != 0)) {
                                      if (uVar34 < 0xffff) {
                                        bVar35 = iVar29 != iVar33;
                                        local_c4 = 0;
                                        bVar3 = true;
                                      }
                                      else {
                                        local_c4 = FUN_60125d50(param_3,iVar29,2);
                                        if (iVar29 == iVar33) {
                                          bVar3 = false;
                                          bVar35 = false;
                                        }
                                        else {
                                          if (*(short *)(local_c4 + 10) < 0) goto LAB_60025490;
                                          bVar35 = true;
                                          bVar3 = false;
                                        }
                                      }
                                      iVar20 = FUN_60125bc4(param_5,piVar19[3],1);
                                      if (((((*(ushort *)(param_7 + 0x78) & *(ushort *)(iVar20 + 4))
                                             != 0) &&
                                           ((*(byte *)(iVar20 + 9) == 0 ||
                                            (*(byte *)(param_7 + 0x74) <= *(byte *)(iVar20 + 9)))))
                                          && ((*(byte *)(iVar20 + 10) == 0 ||
                                              (*(byte *)(param_7 + 0x75) <= *(byte *)(iVar20 + 10)))
                                             )) && (((*(byte *)(iVar20 + 0xb) == 0 ||
                                                     (*(byte *)(param_7 + 0x76) <=
                                                      *(byte *)(iVar20 + 0xb))) &&
                                                    ((*(byte *)(iVar20 + 0xc) == 0 ||
                                                     (*(byte *)(param_7 + 0x77) <=
                                                      *(byte *)(iVar20 + 0xc))))))) {
                                        fVar36 = *(float *)(param_7 + (*(byte *)(iVar20 + 6) & 0xf)
                                                                      * 4 + 8);
                                        uVar34 = in_fpscr & 0xfffffff;
                                        in_fpscr = uVar34 | (uint)(fVar36 == 0.0) << 0x1e;
                                        if ((byte)(in_fpscr >> 0x1e) == 0) {
                                          iVar28 = 1;
                                          for (iVar30 = -0x18; iVar30 != 0; iVar30 = iVar30 + 4) {
                                            uVar13 = 1 << (iVar28 - 1U & 0xff);
                                            if ((uVar13 & *(byte *)(param_5 + 8)) != 0) {
                                              iVar21 = 0x98;
                                              if ((uVar13 & *(byte *)(iVar20 + 7)) == 0) {
                                                iVar21 = 0xb4;
                                              }
                                              fVar36 = fVar36 * *(float *)(iVar21 + param_7 + iVar30
                                                                          );
                                            }
                                            iVar28 = iVar28 + 1;
                                          }
                                          in_fpscr = uVar34 | (uint)(fVar36 == 0.0) << 0x1e;
                                          if (((byte)(in_fpscr >> 0x1e) == 0) &&
                                             ((!bVar35 || bVar3 ||
                                              ((*(ushort *)(local_c4 + 8) &
                                               *(ushort *)(param_7 + 0x78)) != 0)))) {
                                            if (iRam2007d268 == 0) {
                                              uVar34 = piVar19[4] & 0x7ffffff;
                                            }
                                            else {
                                              uVar34 = FUN_60120128(piVar19,iVar20,param_7);
                                            }
                                            fVar38 = (float)VectorUnsignedToFloat
                                                                      (uVar34,(byte)(in_fpscr >>
                                                                                    0x16) & 3);
                                            fVar36 = (float)piVar10[4] + fVar38 / fVar36;
                                            uVar34 = in_fpscr & 0xfffffff |
                                                     (uint)(fVar36 < fVar39) << 0x1f;
                                            in_fpscr = uVar34 | (uint)(NAN(fVar36) || NAN(fVar39))
                                                                << 0x1c;
                                            if ((byte)(uVar34 >> 0x1f) !=
                                                ((byte)(in_fpscr >> 0x1c) & 1)) {
                                              puVar22 = (undefined4 *)
                                                        FUN_6012726c(iVar15,iVar29,iVar24);
                                              if (puVar22 == (undefined4 *)0x0) {
                                                puVar22 = (undefined4 *)
                                                          FUN_60125f94(iVar15,iVar29,iVar24);
                                                if (puVar22 != (undefined4 *)0x0) {
                                                  puVar22[4] = fVar36;
                                                  goto LAB_6002547a;
                                                }
LAB_60025666:
                                                FUN_60125a74(iVar26);
                                                goto LAB_600255e4;
                                              }
                                              uVar34 = in_fpscr & 0xfffffff |
                                                       (uint)(fVar36 < (float)puVar22[4]) << 0x1f;
                                              in_fpscr = uVar34 | (uint)(NAN(fVar36) ||
                                                                        NAN((float)puVar22[4])) <<
                                                                  0x1c;
                                              if ((byte)(uVar34 >> 0x1f) !=
                                                  ((byte)(in_fpscr >> 0x1c) & 1)) {
                                                puVar22[4] = fVar36;
                                                puVar22[1] = iVar24;
LAB_6002547a:
                                                puVar22[2] = piVar10;
                                                puVar17 = puVar22;
                                                fVar37 = fVar36;
                                                if ((iVar29 != iVar33) &&
                                                   (FUN_60125f04(fVar36,iVar26), puVar17 = local_c8,
                                                   fVar37 = fVar39, *(int *)(iVar26 + 0xc) == 0))
                                                goto LAB_60025666;
                                              }
                                            }
                                          }
                                        }
                                      }
                                    }
                                  }
                                }
                                else if ((*(int *)(param_7 + 0x70) == 0) ||
                                        (((local_84 != iVar24 &&
                                          (iVar31 != iVar24 && iVar31 != iVar20)) &&
                                         ((local_84 != iVar20 ||
                                          (iVar20 = FUN_6011ff80(iVar31), iVar20 == 0))))))
                                goto LAB_600252c6;
                              }
LAB_60025490:
                              local_c8 = puVar17;
                              fVar39 = fVar37;
                              if (uVar25 < 0xffff) {
                                piVar11 = (int *)FUN_601200ac(piVar19,iVar27);
                              }
                              else {
                                piVar11 = (int *)0x0;
                                if (((0xfffe < iVar29 + 0x10000U) &&
                                    (piVar11 = (int *)FUN_60125c46(param_4,piVar19,iVar27),
                                    iVar33 + 0x10000U < 0xffff)) && (piVar11 == (int *)0x0)) {
                                  piVar11 = (int *)FUN_60041280(iVar27,iVar33);
                                }
                              }
                            }
                          }
                        }
                        FUN_60125a74(iVar26);
                        if (iRam2000af50 != 0) {
                          FUN_60149068("    Aborted.");
                          goto LAB_600255e4;
                        }
                        if (local_c8 == (undefined4 *)0x0) goto LAB_600255e4;
                        FUN_6011ffe0(local_c8);
                        uVar5 = puVar18[1];
                        *(undefined4 *)(iVar15 + 0x20) = *puVar18;
                        *(undefined4 *)(iVar15 + 0x24) = uVar5;
                        uVar5 = local_c8[1];
                        *(undefined4 *)(iVar15 + 0x28) = *local_c8;
                        *(undefined4 *)(iVar15 + 0x2c) = uVar5;
                        iVar33 = FUN_6012726c(iVar15,*puVar16,piVar9[1]);
                        puVar18 = *(undefined4 **)(iVar33 + 0xc);
                        piVar10 = piVar9;
                        do {
                          piVar9 = (int *)FUN_60125f94(iVar4,*puVar18,puVar18[1]);
                          if (piVar9 == (int *)0x0) {
                            FUN_60127138(iVar15);
                            goto LAB_600255f8;
                          }
                          piVar9[2] = (int)piVar10;
                          piVar9[4] = (int)((float)puVar16[4] + (float)puVar18[4]);
                          puVar18 = (undefined4 *)puVar18[3];
                          piVar10 = piVar9;
                        } while (puVar18 != (undefined4 *)0x0);
                        FUN_60127138(iVar15);
                        puVar16 = (undefined4 *)puVar16[3];
                        puVar16[4] = piVar9[4];
                      }
                      if (*(int *)(iVar7 + 8) != 0) {
                        iVar33 = FUN_6012726c(iVar7,*puVar16,puVar16[1]);
                        while (puVar16 = *(undefined4 **)(iVar33 + 0xc),
                              puVar16 != (undefined4 *)0x0) {
                          piVar10 = (int *)FUN_60125f94(iVar4,*puVar16,puVar16[1]);
                          if (piVar10 == (int *)0x0) {
                            FUN_60127138(iVar4);
                            goto LAB_600255fe;
                          }
                          piVar10[2] = (int)piVar9;
                          pfVar1 = (float *)(iVar33 + 0x10);
                          iVar33 = *(int *)(iVar33 + 0xc);
                          piVar10[4] = (int)((float)piVar9[4] +
                                            (*pfVar1 - *(float *)(iVar33 + 0x10)));
                          piVar9 = piVar10;
                        }
                      }
                      FUN_6011ffe0(piVar9);
                      uVar5 = *(undefined4 *)(iVar6 + 0x24);
                      *(undefined4 *)(iVar4 + 0x20) = *(undefined4 *)(iVar6 + 0x20);
                      *(undefined4 *)(iVar4 + 0x24) = uVar5;
                      iVar33 = piVar9[1];
                      *(int *)(iVar4 + 0x28) = *piVar9;
                      *(int *)(iVar4 + 0x2c) = iVar33;
                      if (iRam2000af54 == 0) {
                        FUN_60120034("Found Combined Route: Nodes = %d",*(undefined4 *)(iVar4 + 8),
                                     iVar4);
                      }
                      FUN_60127138(iVar6);
                      FUN_60127138(iVar8);
                      FUN_60127138(iVar7);
                      goto LAB_6002499e;
                    }
LAB_600255f8:
                    FUN_60127138(iVar4);
                  }
LAB_600255fe:
                  FUN_601516f0("Error: Cannot create combined route following super-route.\n",0x3b,1
                               ,0x20008868);
                  FUN_60127138(iVar6);
                  FUN_60127138(iVar8);
                  FUN_60127138(iVar7);
                  goto LAB_60024f06;
                }
              }
              else {
                FUN_60127138(iVar4);
                iVar6 = FUN_60106e40(param_3,param_4,param_5,param_6);
                if (iVar6 != 0) {
                  iVar8 = FUN_600341d0(param_3,param_4,param_5,param_6);
                  goto LAB_60024fc2;
                }
                iVar6 = 0;
              }
              FUN_601516f0("Error: Cannot find super-route compatible with profile.\n",0x38,1,
                           0x20008868);
              FUN_60127138(iVar6);
              iVar4 = iVar7;
              goto LAB_60024f02;
            }
            FUN_60125a74(iVar8);
          }
          FUN_60127138(iVar7);
        }
LAB_60024eec:
        FUN_60127138(iVar6);
      }
LAB_60024ef0:
      FUN_601516f0("Error: Cannot find final section of route compatible with profile.\n",0x43,1,
                   0x20008868);
      goto LAB_60024f02;
    }
LAB_6002499e:
    *(short *)(iVar4 + 0x32) = (short)param_12;
    *(undefined2 *)(iVar4 + 0x30) = param_11;
  }
  return iVar4;
code_r0x60024af2:
  bVar2 = true;
  if ((*(ushort *)(param_7 + 0x78) & *(ushort *)(local_74 + 2)) != 0) {
LAB_60024b04:
    iVar15 = 1;
    iVar33 = FUN_60125bc4(param_5,piVar11[3],1);
    fVar37 = *(float *)(param_7 + (*(byte *)(iVar33 + 6) & 0xf) * 4 + 8);
    for (iVar31 = -0x18; iVar31 != 0; iVar31 = iVar31 + 4) {
      uVar13 = 1 << (iVar15 - 1U & 0xff);
      if ((uVar13 & *(byte *)(param_5 + 8)) != 0) {
        iVar26 = 0x98;
        if ((uVar13 & *(byte *)(iVar33 + 7)) == 0) {
          iVar26 = 0xb4;
        }
        fVar37 = fVar37 * *(float *)(iVar26 + param_7 + iVar31);
      }
      iVar15 = iVar15 + 1;
    }
    if (iRam2007d268 == 0) {
      uVar13 = piVar11[4] & 0x7ffffff;
    }
    else {
      uVar13 = FUN_60120128(piVar11);
    }
    fVar36 = (float)VectorUnsignedToFloat(uVar13,(byte)(in_fpscr >> 0x16) & 3);
    fVar39 = fVar36 / fVar37;
    if (0xfffeffff < uVar25) {
      fVar39 = (fVar36 / fVar37) * 1.01;
    }
    bVar35 = bVar2;
    if (uVar34 < 0xffff) {
LAB_60024ba6:
      bVar2 = bVar35;
      piVar11 = (int *)FUN_6011ffbc(iVar12);
    }
    else {
LAB_60024bb0:
      piVar11 = (int *)FUN_601264ba(param_4,*local_74,1);
    }
    iVar33 = -1;
    while (piVar11 != (int *)0x0) {
      if ((uVar34 < 0xffff) || (-1 < *(short *)((int)local_74 + 10))) {
        uVar13 = piVar11[4];
        if ((int)(uVar13 << 4) < 0) {
          if ((0xfffe < uVar34) && (0x7fffffff < (uint)(int)*(short *)((int)local_74 + 10)))
          goto LAB_60024c0c;
          goto LAB_60024c1e;
        }
        goto LAB_60024be4;
      }
      uVar13 = piVar11[4];
LAB_60024c0c:
      if ((int)(uVar13 << 3) < 0) {
LAB_60024c1e:
        if (*(int *)(param_7 + 0x6c) == 0) {
LAB_60024c50:
          iVar31 = *piVar11;
          if (iVar31 == iVar12) {
            iVar31 = piVar11[1];
          }
          uVar23 = iVar31 + 0x10000;
          bVar35 = uVar34 == 0xffff;
          if (0xfffe < uVar34) {
            uVar13 = 0xfffe;
            bVar35 = uVar23 == 0xfffe;
          }
          if ((0xfffe < uVar34 && uVar13 <= uVar23) && !bVar35) {
            uVar14 = *(uint *)(param_4 + (((int)piVar11 - (param_4 + 0x10)) / 0x14) * 4 + 0x60);
            uVar13 = uVar14;
          }
          else {
            uVar13 = FUN_6011ffd0(piVar11);
            uVar14 = FUN_60126490();
          }
          if (uVar25 != 0xffffffff) {
            if (*(int *)(param_7 + 0x70) != 0) {
              if ((uVar34 < 0xffff) || (-1 < *(short *)((int)local_74 + 10))) {
                if (((local_84 == uVar13) || (uVar25 == uVar13 || uVar25 == uVar14)) ||
                   ((local_84 == uVar14 && (iVar15 = FUN_6011ff80(uVar25,uVar13), iVar15 != 0))))
                goto LAB_60024be4;
              }
              else {
                uVar32 = FUN_6011f7a4(param_3,param_4,param_5);
                if (uVar13 == uVar32) goto LAB_60024c10;
              }
            }
            if ((bVar2 && *(int *)(param_7 + 0x70) != 0) &&
               ((int)((uint)*(ushort *)((int)local_74 + 10) << 0x13) < 0)) {
              iVar33 = FUN_6011fe5c(param_6,iVar12,uVar14);
            }
            if (iVar33 == -1) {
              iVar33 = -1;
            }
            else {
              iVar15 = FUN_6011ff10(param_6,iVar33,iVar12,uVar14);
              if (iVar15 == 0) goto LAB_60024be4;
            }
          }
          iVar15 = FUN_60125bc4(param_5,piVar11[3],1);
          if (((((*(ushort *)(param_7 + 0x78) & *(ushort *)(iVar15 + 4)) != 0) &&
               ((*(byte *)(iVar15 + 9) == 0 || (*(byte *)(param_7 + 0x74) <= *(byte *)(iVar15 + 9)))
               )) && ((*(byte *)(iVar15 + 10) == 0 ||
                      (*(byte *)(param_7 + 0x75) <= *(byte *)(iVar15 + 10))))) &&
             (((*(byte *)(iVar15 + 0xb) == 0 ||
               (*(byte *)(param_7 + 0x76) <= *(byte *)(iVar15 + 0xb))) &&
              ((*(byte *)(iVar15 + 0xc) == 0 ||
               (*(byte *)(param_7 + 0x77) <= *(byte *)(iVar15 + 0xc))))))) {
            fVar37 = *(float *)(param_7 + (*(byte *)(iVar15 + 6) & 0xf) * 4 + 8);
            uVar14 = in_fpscr & 0xfffffff;
            in_fpscr = uVar14 | (uint)(fVar37 == 0.0) << 0x1e;
            if ((byte)(in_fpscr >> 0x1e) == 0) {
              iVar26 = 1;
              for (iVar27 = -0x18; iVar27 != 0; iVar27 = iVar27 + 4) {
                uVar32 = 1 << (iVar26 - 1U & 0xff);
                if ((uVar32 & *(byte *)(param_5 + 8)) != 0) {
                  iVar29 = 0x98;
                  if ((uVar32 & *(byte *)(iVar15 + 7)) == 0) {
                    iVar29 = 0xb4;
                  }
                  fVar37 = fVar37 * *(float *)(iVar29 + param_7 + iVar27);
                }
                iVar26 = iVar26 + 1;
              }
              in_fpscr = uVar14 | (uint)(fVar37 == 0.0) << 0x1e;
              if (((byte)(in_fpscr >> 0x1e) == 0) &&
                 ((uVar23 < 0xffff ||
                  (iVar31 = FUN_60125d50(param_3,iVar31,2),
                  (*(ushort *)(param_7 + 0x78) & *(ushort *)(iVar31 + 8)) != 0)))) {
                fVar37 = (float)piVar10[4];
                iVar31 = FUN_6012726c(iVar7,iVar12,uVar13);
                fVar37 = fVar39 + fVar37;
                if (iVar31 == 0) {
                  iVar31 = FUN_60125f94(iVar7,iVar12,uVar13);
                  if (iVar31 != 0) {
                    if (piVar10 != piVar9) {
                      *(int **)(iVar31 + 0xc) = piVar10;
                    }
                    goto LAB_60024e8c;
                  }
LAB_60024eb6:
                  FUN_60125a74(iVar8);
                  FUN_60127138(iVar7);
                  FUN_60127138(iVar6);
                  goto LAB_60024ef0;
                }
                uVar13 = in_fpscr & 0xfffffff | (uint)(fVar37 < *(float *)(iVar31 + 0x10)) << 0x1f;
                in_fpscr = uVar13 | (uint)(NAN(fVar37) || NAN(*(float *)(iVar31 + 0x10))) << 0x1c;
                if ((byte)(uVar13 >> 0x1f) != ((byte)(in_fpscr >> 0x1c) & 1)) {
                  if (piVar10 != piVar9) {
                    *(int **)(iVar31 + 0xc) = piVar10;
                  }
LAB_60024e8c:
                  *(float *)(iVar31 + 0x10) = fVar37;
                  if ((0xfffe < uVar34) && (*(short *)((int)local_74 + 10) < 0)) goto LAB_60024c10;
                  FUN_60125f04(fVar37,iVar8);
                  if (*(int *)(iVar8 + 0xc) == 0) goto LAB_60024eb6;
                }
              }
            }
          }
        }
        else {
          if (piVar11[1] != iVar12) {
            uVar13 = uVar13 << 1;
            if ((int)uVar13 < 0) goto LAB_60024c34;
            goto LAB_60024c50;
          }
          uVar13 = uVar13 << 2;
          if (-1 < (int)uVar13) goto LAB_60024c50;
LAB_60024c34:
          if (*(short *)(param_7 + 0x78) == 8) {
            iVar31 = FUN_60125bc4(param_5,piVar11[3],1);
            uVar13 = (uint)*(byte *)(iVar31 + 6) << 0x1b;
            if ((int)uVar13 < 0) goto LAB_60024c50;
          }
        }
LAB_60024be4:
        if (0xfffe < uVar34) goto LAB_60024c10;
        piVar11 = (int *)FUN_601200ac(piVar11,iVar12);
      }
      else {
LAB_60024c10:
        piVar11 = (int *)FUN_60125c46(param_4,piVar11,iVar12);
      }
    }
  }
  goto LAB_60024a5e;
}
