
void FUN_600301a6(int *param_1,int *param_2,int *param_3,int param_4,int param_5,int param_6)

{
  int iVar1;
  int iVar2;
  
  if (((param_1 != (int *)0x0) && (param_2 != (int *)0x0)) && (param_3 != (int *)0x0)) {
    if (param_6 == 1) {
      iVar1 = 0;
      iVar2 = param_4;
    }
    else {
      iVar2 = param_4 - *param_2;
      if (param_5 == 1) {
        iVar1 = iVar2;
        iVar2 = iVar2 - *param_3;
      }
      else {
        iVar1 = 0;
      }
    }
    *param_1 = iVar2;
    *param_2 = param_4;
    *param_3 = iVar1;
  }
  return;
}
