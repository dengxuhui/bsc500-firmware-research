
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60011430(int param_1)

{
  _DAT_60e6f714 = 0x1ff8;
  if (param_1 + _DAT_20044734 < 0x1ff8) {
    _DAT_60e6f714 = param_1 + _DAT_20044734;
  }
  _DAT_20044734 = _DAT_60e6f714;
  return;
}
