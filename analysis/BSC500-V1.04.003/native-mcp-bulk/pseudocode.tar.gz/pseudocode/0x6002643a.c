
void FUN_6002643a(undefined1 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 local_18;
  undefined3 uStack_17;
  undefined4 uStack_14;
  
  _local_18 = CONCAT31((int3)((uint)param_3 >> 8),0x31);
  uStack_14 = param_4;
  FUN_600358ae(&uStack_17);
  FUN_60153e3c(*param_1,8,&local_18);
  return;
}
