
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60030cb8 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_60030c34(undefined8 *param_1)

{
  int iVar1;
  undefined8 uVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  undefined4 uVar5;
  float local_c0;
  float local_bc;
  float local_b8;
  float local_b4;
  undefined1 auStack_b0 [32];
  undefined1 auStack_90 [32];
  undefined4 local_70 [2];
  undefined4 local_68;
  float local_60;
  undefined4 local_5c;
  undefined4 local_58;
  undefined4 local_50;
  float local_48;
  undefined4 local_44;
  float local_40;
  undefined8 local_38;
  undefined8 local_30;
  undefined4 local_28;
  undefined4 uStack_24;
  
  if (param_1 == (undefined8 *)0x0) {
    return 0xffffffff;
  }
  uVar2 = *param_1;
  uVar4 = param_1[1];
  local_28 = *(undefined4 *)((int)param_1 + 0x14);
  uStack_24 = *(undefined4 *)(param_1 + 3);
  local_38 = uVar2;
  local_30 = uVar4;
  ZeroBytes(local_70,0x38);
  ZeroBytes(&local_c0,0x50);
  iVar1 = FUN_6012eb6c(0x200895f0,&local_38,local_70);
  if ((iVar1 == 0) && (30.0 <= ABS(local_40))) {
    local_b8 = local_40;
    local_c0 = local_60;
    local_bc = local_48;
    local_b4 = local_48 - local_60;
    uVar3 = (undefined4)((ulonglong)uVar2 >> 0x20);
    uVar5 = (undefined4)((ulonglong)uVar4 >> 0x20);
    FUN_60135f50(local_58,uVar3,local_50,uVar5,local_44,auStack_b0);
    FUN_60135e30(local_5c);
    FUN_60135f50(local_70[0],uVar3,local_68,uVar5,(int)uVar2,auStack_90);
    iVar1 = FUN_60135f20(&uRam2000b0ac,&local_c0);
    if (iVar1 != 0) {
      FUN_6015b87c();
      FUN_601667bc(uRam2000b0ac);
      uRam2000b0ac = 0;
      FUN_60163bbe(0x2008b0e4);
      return 0xffffffff;
    }
    iRam2000b0ec = iRam2000b0ec + 1;
    FUN_60135d20(0x2000b0c0,&local_c0);
  }
  return 0;
}
