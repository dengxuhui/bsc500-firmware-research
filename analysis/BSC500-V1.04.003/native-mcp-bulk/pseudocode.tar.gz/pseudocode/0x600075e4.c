
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600075e4(undefined4 param_1,uint param_2,int param_3)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  undefined *local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 uStack_2c;
  int local_28;
  
  local_28 = 0;
  if (((int)(param_2 << 2) < 0) && (iVar1 = FUN_601169e8(param_1,&local_28), iVar1 != 0)) {
    param_2 = param_2 & 0xdfffffff;
    if (_DAT_2000b3c4 == 0) {
      local_30 = 0;
      uStack_2c = 0;
      local_34 = 1;
      local_38 = &DAT_603fcde5;
      _DAT_2000b3c4 = FUN_60168494(&local_38);
    }
    FUN_6016825e(_DAT_2000b3c4,0xffffffff);
    uVar3 = 0;
    for (; param_2 != 0; param_2 = param_2 >> 1) {
      if ((param_2 & 1) != 0) {
        uVar2 = 1 << (uVar3 & 0xff);
        uVar4 = uVar2 | 0x20000000;
        iVar1 = FUN_60019d88(uVar4,param_1,param_3);
        if (iVar1 != 0) {
          if (param_3 == 0) {
            *(uint *)(local_28 + 0x18) = *(uint *)(local_28 + 0x18) & ~uVar2 | 0x20000000;
          }
          else {
            *(uint *)(local_28 + 0x18) = *(uint *)(local_28 + 0x18) | uVar4;
            FUN_60019ce4(uVar4);
          }
        }
      }
      uVar3 = uVar3 + 1;
    }
    if (_DAT_2000b3c4 != 0) {
      FUN_601682ae();
    }
  }
  return;
}
