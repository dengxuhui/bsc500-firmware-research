
void FUN_60031bc8(uint param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  
  iVar1 = FUN_6015f2c4(DAT_2000b290 + -1);
  if ((((iVar1 != 0) && (DAT_2000b291 == '\0')) && (DAT_2000b290 != '\0')) &&
     (param_1 < *(byte *)(iVar1 + 0x50))) {
    iVar1 = iVar1 + param_1 * 0x14;
    if (*(char *)(iVar1 + 0x5c) == '\r') {
      param_2 = param_3;
    }
    *(undefined4 *)(iVar1 + 0x54) = param_2;
    *(undefined4 *)(iVar1 + 0x58) = param_3;
  }
  return;
}
