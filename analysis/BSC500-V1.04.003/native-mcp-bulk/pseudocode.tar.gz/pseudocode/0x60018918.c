
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018918(void)

{
  uRam20050f18 = uRam2004b3bc;
  uRam20050f10 = _DAT_2004b3ac;
  uRam20050f14 = _DAT_2004b3b0;
  uRam20050f1a = DAT_2004b3f4;
  uRam20050f1b = DAT_2004b3f2;
  uRam20050f1c = _DAT_2004b3c0;
  uRam20050f20 = _DAT_2004b3a8;
  uRam20050f24 = (uint)_DAT_2004b3c4;
  uRam20050f28 = _DAT_2004b3de;
  uRam20050f2a = _DAT_2004b3d6;
  return;
}
