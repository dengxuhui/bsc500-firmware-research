
/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 FUN_6000c568(int param_1,int param_2)

{
  int *piVar1;
  ushort uVar2;
  undefined1 uVar3;
  byte bVar4;
  undefined2 uVar5;
  byte bVar6;
  int iVar7;
  int iVar8;
  undefined4 *puVar9;
  int iVar10;
  uint uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  int iVar20;
  uint uVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  undefined4 uVar27;
  undefined *puVar28;
  uint uVar29;
  uint uVar30;
  bool bVar31;
  undefined8 uVar32;
  undefined8 uVar33;
  undefined1 auStack_1dc [100];
  undefined1 auStack_178 [100];
  int local_114 [4];
  int local_104 [4];
  undefined4 local_f4;
  byte local_f0;
  undefined1 auStack_ef [10];
  undefined3 local_e5;
  undefined3 local_e2;
  undefined2 local_df;
  undefined1 local_dd;
  undefined4 local_90;
  undefined4 local_8c;
  undefined2 local_88;
  undefined1 local_86;
  uint local_84;
  undefined4 uStack_80;
  undefined1 uStack_7d;
  undefined2 local_7c;
  undefined4 local_78 [13];
  undefined4 local_44;
  
  iVar7 = FUN_601639fc();
  uVar5 = local_7c;
  ZeroBytes(auStack_178,100);
  local_7c = uVar5;
  uVar5 = local_7c;
  ZeroBytes(auStack_1dc,100);
  local_7c = uVar5;
  uVar5 = local_7c;
  if (iRam2000a740 == 0) {
    return 0xffffffff;
  }
  iVar8 = FUN_60163a88();
  local_7c = uVar5;
  uVar5 = local_7c;
  if (((iVar8 == 0) ||
      (iVar8 = FUN_60166dd0(iRam2000a740), local_7c = uVar5, bVar6 = local_7c._1_1_, iVar8 != 0)) ||
     (uVar5 = local_7c, local_7c._1_1_ = bVar6, iVar8 = FUN_60166dd0(iRam2000a740 + 8),
     bVar6 = local_7c._1_1_, iVar8 != 0)) {
    *(undefined1 *)(iVar7 + 0x16) = 0;
    return 0;
  }
  bVar31 = param_2 != 0;
  uRam2008596c = 0x60d00d7c;
  uRam20085970 = 0x10000;
  if (!bVar31 || param_1 == 0) {
    param_2 = 0x24000;
  }
  uRam2008590c = 0x60d10d7c;
  iVar8 = 0x60d34d7c;
  if (bVar31 && param_1 != 0) {
    iVar8 = param_1;
  }
  iRam20008304 = param_2;
  iRam20085910 = param_2;
  uVar5 = local_7c;
  local_7c._1_1_ = bVar6;
  puVar9 = (undefined4 *)FUN_60162b78(1);
  uVar5 = local_7c;
  iVar10 = FUN_6015f308(*puVar9,puVar9[2]);
  local_7c = uVar5;
  uVar5 = local_7c;
  if (iVar10 == 0) {
    uVar12 = 0xffffffff;
  }
  else {
    uVar11 = FUN_601668a4();
    local_7c = uVar5;
    uVar5 = local_7c;
    puVar28 = &UNK_602a9f86;
    if (uVar11 < 2) {
      puVar28 = &UNK_602a9f84;
    }
    uVar11 = FUN_601668a4();
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar12 = *puVar9;
    uVar13 = puVar9[1];
    uVar27 = puVar9[3];
    uVar32 = FUN_6016759c(puVar9[2]);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar33 = FUN_6016759c(uVar27);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar32 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),(int)uVar33,
                          (int)((ulonglong)uVar33 >> 0x20));
    local_7c = uVar5;
    uVar5 = local_7c;
    FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar14 = FUN_60167a50();
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar32 = FUN_6016759c();
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar27 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar3 = puVar28[(uVar11 | 2) != 2];
    iVar15 = FUN_60159978(uVar27,uVar3);
    local_7c = uVar5;
    uVar5 = local_7c;
    local_104[0] = iVar15;
    uVar32 = FUN_6016759c(uVar12);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar33 = FUN_6016759c(uVar13);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar32 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),(int)uVar33,
                          (int)((ulonglong)uVar33 >> 0x20));
    local_7c = uVar5;
    uVar5 = local_7c;
    FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar16 = FUN_60167a50();
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar32 = FUN_6016759c();
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar12 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar17 = FUN_60159878(uVar12,uVar3);
    local_7c = uVar5;
    uVar5 = local_7c;
    local_114[0] = iVar17;
    uVar12 = FUN_60159a10(iVar15,uVar3);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar32 = FUN_60166bb4(uVar12);
    local_7c = uVar5;
    uVar5 = local_7c;
    FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar10 = FUN_60167a50();
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar12 = FUN_60159a60(iVar17,uVar3);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar18 = iVar15 + 1;
    uVar13 = FUN_60159a10(iVar18,uVar3);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar27 = FUN_60159a60(iVar17 + 1,uVar3);
    local_7c = uVar5;
    uVar5 = local_7c;
    iRam20085898 = iVar10;
    uVar32 = FUN_60166bb4(uVar12);
    local_7c = uVar5;
    uVar5 = local_7c;
    FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar19 = FUN_60167a50();
    local_7c = uVar5;
    uVar5 = local_7c;
    iRam20085894 = iVar19;
    local_114[1] = iVar17;
    uVar32 = FUN_60166bb4(uVar13);
    local_7c = uVar5;
    uVar5 = local_7c;
    FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar20 = FUN_60167a50();
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar10 = iVar14 - iVar10;
    if (iVar10 < 0) {
      iVar10 = -iVar10;
    }
    iVar20 = iVar20 - iVar14;
    if (iVar20 < 0) {
      iVar20 = -iVar20;
    }
    local_104[2] = iVar15;
    local_104[3] = iVar18;
    if (iVar10 <= iVar20) {
      iVar18 = iVar15 + -1;
      local_104[2] = iVar15 + -1;
      local_104[3] = iVar15;
    }
    local_104[1] = iVar18;
    uVar32 = FUN_60166bb4(uVar27);
    local_7c = uVar5;
    uVar5 = local_7c;
    FUN_601678fc((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),0,0x412e8480);
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar10 = FUN_60167a50();
    local_7c = uVar5;
    uVar5 = local_7c;
    iVar19 = iVar16 - iVar19;
    if (iVar19 < 0) {
      iVar19 = -iVar19;
    }
    iVar10 = iVar10 - iVar16;
    iVar20 = -1;
    if (iVar10 < 0) {
      iVar10 = -iVar10;
    }
    if (iVar10 < iVar19) {
      iVar20 = 1;
    }
    iVar10 = 0;
    local_114[2] = iVar20 + iVar17;
    local_114[3] = iVar20 + iVar17;
    do {
      if (iVar10 == 4) {
        if (iRam2000a744 != param_1) goto LAB_6000c80c;
        uVar12 = 0;
        goto LAB_6000c860;
      }
      iVar20 = iVar10 * 4;
    } while (((*(int *)(iVar20 + 0x2000a790) != 0) || (*(int *)(iVar20 + 0x2000a7a0) != 0)) &&
            ((local_104[iVar10] == *(int *)(iVar20 + 0x2000a790) &&
             (piVar1 = local_114 + iVar10, iVar10 = iVar10 + 1,
             *piVar1 == *(int *)(iVar20 + 0x2000a7a0)))));
    for (iVar10 = 0; iVar10 != 4; iVar10 = iVar10 + 1) {
      *(int *)(iVar10 * 4 + 0x2000a790) = local_104[iVar10];
      *(int *)(iVar10 * 4 + 0x2000a7a0) = local_114[iVar10];
    }
LAB_6000c80c:
    if (*(char *)(iVar7 + 0x1f) != '\0') {
      return 0xffffffff;
    }
    iRam2000a744 = param_1;
    *(undefined1 *)(iVar7 + 0x1f) = 1;
    iVar10 = FUN_60163b60();
    local_7c = uVar5;
    uVar5 = local_7c;
    puVar9 = (undefined4 *)FUN_60162b78(1);
    local_7c = uVar5;
    uVar5 = local_7c;
    uVar12 = 0xffffffff;
    bVar6 = local_7c._1_1_;
    if ((iVar10 != 0) && (puVar9 != (undefined4 *)0x0)) {
      iVar10 = FUN_60166dd0(puVar9);
      local_7c = uVar5;
      uVar5 = local_7c;
      uVar11 = uRam2000a748;
      uVar21 = uRam2000a74c;
      bVar6 = local_7c._1_1_;
      if ((iVar10 == 0) &&
         (iVar10 = FUN_60166dd0(puVar9 + 2), local_7c = uVar5, bVar6 = local_7c._1_1_,
         uVar11 = uRam2000a748, uVar21 = uRam2000a74c, uVar5 = local_7c, iVar10 == 0)) {
        local_7c._1_1_ = bVar6;
        uVar11 = FUN_601668a4();
        uVar5 = local_7c;
        uVar12 = puVar9[3];
        uVar32 = FUN_6016759c(puVar9[2]);
        local_7c = uVar5;
        uVar5 = local_7c;
        uVar33 = FUN_6016759c(uVar12);
        local_7c = uVar5;
        uVar5 = local_7c;
        uVar12 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),(int)uVar33,
                              (int)((ulonglong)uVar33 >> 0x20));
        local_7c = uVar5;
        uVar5 = local_7c;
        uVar13 = 0xd;
        if (uVar11 < 2) {
          uVar13 = 9;
        }
        uVar11 = FUN_60159978(uVar12,uVar13);
        local_7c = uVar5;
        uVar5 = local_7c;
        uVar12 = puVar9[1];
        uVar32 = FUN_6016759c(*puVar9);
        local_7c = uVar5;
        uVar5 = local_7c;
        uVar33 = FUN_6016759c(uVar12);
        local_7c = uVar5;
        uVar5 = local_7c;
        uVar12 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),(int)uVar33,
                              (int)((ulonglong)uVar33 >> 0x20));
        local_7c = uVar5;
        uVar5 = local_7c;
        uVar21 = FUN_60159878(uVar12,uVar13);
        local_7c = uVar5;
        uVar5 = local_7c;
        if ((uRam2000a748 == uVar11) &&
           (uVar22 = uRam2000a748, uVar23 = uRam2000a74c, bVar6 = local_7c._1_1_,
           uRam2000a74c == uVar21)) {
LAB_6000c95c:
          local_7c._1_1_ = bVar6;
          local_7c = uVar5;
          uRam2000a74c = uVar23;
          uRam2000a748 = uVar22;
          bVar6 = local_7c._1_1_;
          *(undefined1 *)(iVar7 + 0x20) = 1;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          FUN_60167214(iVar8,iRam20008304);
          uVar5 = local_7c;
          uRam2008588c = 0;
          uRam20085890 = 0;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          ZeroBytes(0x2008589c,0x70);
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          ZeroBytes(0x20085914,0x58);
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          FUN_601021f4(auStack_178,uRam20085888 * 0x18 + 0x20085770);
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          FUN_6001b248();
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          uVar12 = FUN_600171a8(iVar8,auStack_178,local_104,local_114);
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          uVar11 = FUN_601668a4();
          uVar5 = local_7c;
          if (1 < uVar11) {
            bVar6 = local_7c._1_1_;
            local_7c = uVar5;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            FUN_600158f8(auStack_1dc,auStack_178);
            uVar5 = local_7c;
            bVar6 = local_7c._1_1_;
            local_7c = uVar5;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            uVar12 = FUN_60015618(iVar8,auStack_1dc,local_104,local_114);
            uVar5 = local_7c;
          }
          local_7c = uVar5;
          bVar6 = local_7c._1_1_;
          iVar10 = 0x20085770;
          for (uVar11 = 0; local_7c._1_1_ = bVar6, bVar6 = local_7c._1_1_, uVar5 = local_7c,
              uVar11 < uRam2008576c; uVar11 = uVar11 + 1) {
            if ((uVar11 != uRam20085888) && (*(int *)(uVar11 * 4 + 0x20085860) != 0)) {
              local_7c._1_1_ = bVar6;
              FUN_601021f4(auStack_178,iVar10);
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar12 = FUN_600171a8(iVar8,auStack_178,local_104,local_114);
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar21 = FUN_601668a4();
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              if (1 < uVar21) {
                local_7c = uVar5;
                uVar5 = local_7c;
                local_7c._1_1_ = bVar6;
                FUN_600158f8(auStack_1dc,auStack_178);
                uVar5 = local_7c;
                bVar6 = local_7c._1_1_;
                local_7c = uVar5;
                uVar5 = local_7c;
                local_7c._1_1_ = bVar6;
                uVar12 = FUN_60015618(iVar8,auStack_1dc,local_104,local_114);
                uVar5 = local_7c;
                bVar6 = local_7c._1_1_;
              }
            }
            local_7c._1_1_ = bVar6;
            local_7c = uVar5;
            bVar6 = local_7c._1_1_;
            iVar10 = iVar10 + 0x18;
          }
          goto LAB_6000c858;
        }
        ZeroBytes(&uRam2008576c,0x120);
        iVar10 = FUN_60163b60();
        ZeroBytes(&local_f4,100);
        local_84 = 0;
        uStack_80 = 0;
        local_7c = 0;
        local_7c._1_1_ = 0;
        local_8c = (uint)local_8c._3_1_ << 0x18;
        local_90 = (uint)local_90._3_1_ << 0x18;
        local_88 = 0;
        local_86 = 0;
        uVar22 = FUN_601668a4();
        uVar5 = local_7c;
        if ((iVar10 != 0) && (*(char *)(iVar10 + 0x9d) != '\0')) {
          uRam2008576c = 0;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          iVar10 = FUN_60162384(local_78,(char *)(iVar10 + 0x9d));
          uVar5 = local_7c;
          if (iVar10 == 0) {
            bVar6 = local_7c._1_1_;
LAB_6000caea:
            do {
              local_7c._1_1_ = bVar6;
              local_7c = uVar5;
              bVar6 = local_7c._1_1_;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              iVar10 = FUN_600166ee(local_78,&local_f4,&UNK_603fbef9,0,0,0,0);
              uVar5 = local_7c;
              if (iVar10 == 0) goto LAB_6000cc40;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              iVar10 = FUN_60168220(&local_f4);
              bVar6 = local_7c._1_1_;
              bVar4 = local_f0;
              uVar12 = local_f4;
              uVar5 = local_7c;
            } while (iVar10 != 0x1c);
            local_7c._1_1_ = bVar6;
            CopyBytes(&local_84,auStack_ef,10);
            uVar5 = local_7c;
            local_8c = CONCAT13(local_8c._3_1_,local_e5);
            local_90 = CONCAT13(local_90._3_1_,local_e2);
            local_88 = local_df;
            local_86 = local_dd;
            bVar6 = local_7c._1_1_;
            if (uVar22 < 2) {
              if (bVar4 < 0x3a) goto LAB_6000caea;
            }
            else if (0x39 < bVar4) goto LAB_6000caea;
            local_44._0_2_ = CONCAT21(uVar5,uStack_7d);
            local_44._2_2_ = (ushort)local_7c._1_1_;
            local_7c = uVar5;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            uVar23 = (*(code *)&UNK_60015931)(0x24,&local_44);
            uVar5 = local_7c;
            local_44._0_3_ = (undefined3)local_8c;
            bVar6 = local_7c._1_1_;
            local_7c = uVar5;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            uVar24 = (*(code *)&UNK_60015931)(0x24,&local_44);
            uVar5 = local_7c;
            local_44._0_3_ = (undefined3)local_90;
            bVar6 = local_7c._1_1_;
            local_7c = uVar5;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            iVar10 = (*(code *)&UNK_60015931)(0x24,&local_44);
            uVar5 = local_7c;
            local_44._0_3_ = CONCAT12(local_86,local_88);
            bVar6 = local_7c._1_1_;
            local_7c = uVar5;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            iVar20 = (*(code *)&UNK_60015931)(0x24,&local_44);
            uVar5 = local_7c;
            bVar6 = local_7c._1_1_;
            if ((((uVar21 < uVar24) || (uVar11 < uVar23)) || (iVar10 + uVar23 < uVar11)) ||
               (iVar20 + uVar24 < uVar21)) goto LAB_6000caea;
            iVar10 = uRam2008576c * 0x18;
            *(byte *)(iVar10 + 0x20085774) = bVar4;
            *(undefined4 *)(iVar10 + 0x20085770) = uVar12;
            local_7c = uVar5;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            CopyBytes(iVar10 + 0x20085775,&local_84,10);
            uVar5 = local_7c;
            *(undefined2 *)(iVar10 + 0x2008577f) = (undefined2)local_8c;
            *(undefined1 *)(iVar10 + 0x20085784) = local_90._2_1_;
            *(undefined1 *)(iVar10 + 0x20085781) = local_8c._2_1_;
            *(undefined2 *)(iVar10 + 0x20085785) = local_88;
            *(undefined1 *)(iVar10 + 0x20085787) = local_86;
            *(undefined2 *)(iVar10 + 0x20085782) = (undefined2)local_90;
            uRam2008576c = uRam2008576c + 1;
            bVar6 = local_7c._1_1_;
            if (uRam2008576c < 10) goto LAB_6000caea;
LAB_6000cc40:
            local_7c = uVar5;
            bVar6 = local_7c._1_1_;
            uVar5 = local_7c;
            local_7c._1_1_ = bVar6;
            FUN_6016238c(local_78);
            uVar5 = local_7c;
          }
        }
        local_7c = uVar5;
        bVar6 = local_7c._1_1_;
        uVar5 = local_7c;
        if (uRam2008576c != 0) {
          local_7c._1_1_ = bVar6;
          iVar10 = FUN_60163b60();
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          puVar9 = (undefined4 *)FUN_60162b78(1);
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          local_7c = uVar5;
          uVar5 = local_7c;
          local_7c._1_1_ = bVar6;
          ZeroBytes(&local_f4,100);
          uVar5 = local_7c;
          bVar6 = local_7c._1_1_;
          if ((iVar10 != 0) &&
             (local_7c = uVar5, uVar5 = local_7c, local_7c._1_1_ = bVar6,
             iVar10 = FUN_60168220(iVar10 + 0x9d), uVar5 = local_7c, bVar6 = local_7c._1_1_,
             iVar10 + 0x1cU < 100)) {
            uVar22 = uVar11;
            uVar23 = uVar21;
            if (uRam2008576c < 2) {
              uRam20085888 = 0;
            }
            else {
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar11 = FUN_601668a4();
              uVar5 = local_7c;
              uVar12 = puVar9[3];
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar32 = FUN_6016759c(puVar9[2]);
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar33 = FUN_6016759c(uVar12);
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar12 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),(int)uVar33,
                                    (int)((ulonglong)uVar33 >> 0x20));
              uVar5 = local_7c;
              uVar13 = 0xe;
              if (uVar11 < 2) {
                uVar13 = 0xb;
              }
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar21 = FUN_60159978(uVar12,uVar13);
              uVar5 = local_7c;
              uVar12 = puVar9[1];
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar32 = FUN_6016759c(*puVar9);
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar33 = FUN_6016759c(uVar12);
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar12 = FUN_601675d8((int)uVar32,(int)((ulonglong)uVar32 >> 0x20),(int)uVar33,
                                    (int)((ulonglong)uVar33 >> 0x20));
              uVar5 = local_7c;
              bVar6 = local_7c._1_1_;
              local_7c = uVar5;
              uVar5 = local_7c;
              local_7c._1_1_ = bVar6;
              uVar24 = FUN_60159878(uVar12,uVar13);
              uVar5 = local_7c;
              iVar10 = 0x188;
              uVar11 = 0;
              for (uVar26 = 0; local_7c = uVar5, bVar6 = local_7c._1_1_, uVar5 = local_7c,
                  uVar26 < uRam2008576c; uVar26 = uVar26 + 1) {
                local_7c._1_1_ = bVar6;
                FUN_601021f4(&local_f4,iVar10 + 0x200855e8);
                uVar5 = local_7c;
                bVar6 = local_7c._1_1_;
                local_7c = uVar5;
                uVar5 = local_7c;
                local_7c._1_1_ = bVar6;
                iVar20 = FUN_600206c8(&local_f4);
                uVar5 = local_7c;
                if ((iVar20 == 0) &&
                   (bVar6 = local_7c._1_1_, local_7c = uVar5, uVar5 = local_7c,
                   local_7c._1_1_ = bVar6, iVar19 = FUN_60166758(&local_90,&local_f4,1),
                   uVar5 = local_7c, iVar20 = local_90, iVar19 == 0)) {
                  local_84 = 0;
                  local_78[0] = 0;
                  local_78[1] = 0;
                  local_44 = 0;
                  local_8c = 0;
                  uVar29 = 0;
                  if (local_90 != 0) {
                    bVar6 = local_7c._1_1_;
                    if ((uRam2008575c <= uVar21) && (uVar21 <= uRam20085764)) {
                      uVar29 = 0;
                      if ((uVar24 < uRam20085760) || (uVar29 = 0, uRam20085768 < uVar24))
                      goto LAB_6000cd7a;
                      iVar19 = iRam20085730 +
                               ((uVar24 - uRam20085760) * ((uRam20085764 - uRam2008575c) + 1) +
                               (uVar21 - uRam2008575c)) * 5;
                      if (cRam20085672 < '\0') {
                        iVar19 = iVar19 + 0x10;
                      }
                      local_7c = uVar5;
                      uVar5 = local_7c;
                      local_7c._1_1_ = bVar6;
                      FUN_60163c98(local_90,iVar19);
                      uVar5 = local_7c;
                      bVar6 = local_7c._1_1_;
                      local_7c = uVar5;
                      uVar5 = local_7c;
                      local_7c._1_1_ = bVar6;
                      FUN_60161ef4(iVar20,local_78,5,&local_44);
                      uVar5 = local_7c;
                      bVar6 = local_7c._1_1_;
                      local_7c = uVar5;
                      uVar5 = local_7c;
                      local_7c._1_1_ = bVar6;
                      uVar32 = FUN_6012222c(local_78);
                      uVar5 = local_7c;
                      uVar29 = (uint)((ulonglong)uVar32 >> 0x20);
                      uVar30 = (uVar29 & 0x7fffffff) >> 0x18;
                      uVar25 = (uint)uVar32 >> 0x18 | uVar29 << 8;
                      bVar6 = local_7c._1_1_;
                      if (uVar30 <= uRam2008573c &&
                          (uint)(uRam20085738 <= uVar25) <= uVar30 - uRam2008573c) {
                        local_7c = uVar5;
                        uVar5 = local_7c;
                        local_7c._1_1_ = bVar6;
                        FUN_60161ef4(iVar20,local_78,5,&local_44);
                        bVar6 = local_7c._1_1_;
                        uVar5 = local_7c;
                        local_7c._1_1_ = bVar6;
                        uVar32 = FUN_6012222c(local_78);
                        bVar6 = local_7c._1_1_;
                        uVar30 = (uint)((ulonglong)uVar32 >> 0x20);
                        uVar5 = local_7c;
                        if (((uint)uVar32 >> 0x18 | uVar30 << 8) != uVar25 ||
                            ((uVar30 ^ uVar29) & 0x7fffffff) >> 0x18 != 0) {
                          local_7c._1_1_ = bVar6;
                          FUN_60163c98(iVar20,uVar25 + iRam20085730);
                          uVar5 = local_7c;
                          if (0x7fffffff < (uint)(int)cRam20085672) {
                            bVar6 = local_7c._1_1_;
                            local_7c = uVar5;
                            uVar5 = local_7c;
                            local_7c._1_1_ = bVar6;
                            iVar19 = FUN_6015cbf2(iVar20);
                            uVar5 = local_7c;
                            bVar6 = local_7c._1_1_;
                            local_7c = uVar5;
                            uVar5 = local_7c;
                            local_7c._1_1_ = bVar6;
                            FUN_60163c98(iVar20,iVar19 + 0x20);
                            uVar5 = local_7c;
                          }
                          local_7c = uVar5;
                          bVar6 = local_7c._1_1_;
                          uVar5 = local_7c;
                          local_7c._1_1_ = bVar6;
                          FUN_60161ef4(iVar20,local_78,8,&local_44);
                          uVar5 = local_7c;
                          bVar6 = local_7c._1_1_;
                          local_7c = uVar5;
                          uVar5 = local_7c;
                          local_7c._1_1_ = bVar6;
                          iVar20 = FUN_6015a168(&local_8c,local_78);
                          uVar5 = local_7c;
                          bVar6 = local_7c._1_1_;
                          local_7c = uVar5;
                          uVar5 = local_7c;
                          local_7c._1_1_ = bVar6;
                          FUN_6015a168(&local_84,(int)local_78 + iVar20);
                          uVar5 = local_7c;
                          uVar29 = local_84;
                          goto LAB_6000cd7a;
                        }
                      }
                    }
                    local_7c._1_1_ = bVar6;
                    local_7c = uVar5;
                    bVar6 = local_7c._1_1_;
                    uVar29 = 0;
                    uVar5 = local_7c;
                    local_7c._1_1_ = bVar6;
                  }
LAB_6000cd7a:
                  local_7c = uVar5;
                  bVar6 = local_7c._1_1_;
                  uVar5 = local_7c;
                  local_7c._1_1_ = bVar6;
                  FUN_601667bc(local_90);
                  uVar5 = local_7c;
                  *(uint *)(uVar26 * 4 + 0x20085860) = uVar29;
                  if (uVar11 < uVar29) {
                    uVar11 = uVar29;
                    uRam20085888 = uVar26;
                  }
                }
                local_7c = uVar5;
                bVar6 = local_7c._1_1_;
                iVar10 = iVar10 + 0x18;
                uVar5 = local_7c;
                local_7c._1_1_ = bVar6;
              }
            }
            goto LAB_6000c95c;
          }
        }
      }
      local_7c._1_1_ = bVar6;
      local_7c = uVar5;
      uRam2000a74c = uVar21;
      uRam2000a748 = uVar11;
      bVar6 = local_7c._1_1_;
      uVar12 = 0xffffffff;
      uVar5 = local_7c;
    }
LAB_6000c858:
    local_7c._1_1_ = bVar6;
    local_7c = uVar5;
    bVar6 = local_7c._1_1_;
    *(undefined1 *)(iVar7 + 0x1f) = 0;
    uVar5 = local_7c;
    local_7c._1_1_ = bVar6;
  }
LAB_6000c860:
  local_7c = uVar5;
  bVar6 = local_7c._1_1_;
  uVar2 = *(ushort *)(iVar7 + 0x12);
  local_7c._1_1_ = bVar6;
  if (*(ushort *)(iVar7 + 0x10) == uVar2) {
    if (*(char *)(iVar7 + 0x1d) == '\0') goto LAB_6000c8ba;
    *(undefined1 *)(iVar7 + 0x1d) = 0;
    uVar5 = local_7c;
  }
  else {
    uVar5 = local_7c;
    uVar11 = FUN_601668a4();
    uVar5 = local_7c;
    if ((uVar2 < 2 == 1 < uVar11) ||
       (uVar2 = *(ushort *)(iVar7 + 0x12), bVar6 = local_7c._1_1_, local_7c = uVar5,
       uVar5 = local_7c, local_7c._1_1_ = bVar6, uVar11 = FUN_601668a4(), uVar5 = local_7c,
       ((uVar2 | 2) != 2) != ((uVar11 | 2) != 2))) {
      *(undefined1 *)(iVar7 + 0x1d) = 1;
      *(undefined2 *)(iVar7 + 0x10) = *(undefined2 *)(iVar7 + 0x12);
      return uVar12;
    }
    *(undefined1 *)(iVar7 + 0x1d) = 0;
    *(undefined2 *)(iVar7 + 0x10) = *(undefined2 *)(iVar7 + 0x12);
  }
  local_7c = uVar5;
  bVar6 = local_7c._1_1_;
  *(undefined1 *)(iVar7 + 0x1e) = 1;
LAB_6000c8ba:
  local_7c._1_1_ = bVar6;
  bVar6 = local_7c._1_1_;
  if (*(char *)(iVar7 + 0x1c) == '\0') {
    *(undefined1 *)(iVar7 + 0x16) = 0;
    if (*(char *)(iVar7 + 0x20) != '\0') {
      uVar5 = local_7c;
      local_7c._1_1_ = bVar6;
      FUN_6001b27c();
      uVar12 = 0;
    }
    *(undefined1 *)(iVar7 + 0x17) = 0;
  }
  return uVar12;
}
