
undefined4 FUN_60029a00(undefined4 param_1,undefined4 param_2)

{
  FUN_60159154(param_2);
  FUN_60160aa4(param_2);
  return 0;
}
