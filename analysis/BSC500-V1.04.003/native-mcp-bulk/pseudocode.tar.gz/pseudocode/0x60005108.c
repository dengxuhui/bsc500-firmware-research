
longlong FUN_60005108(undefined4 param_1,uint param_2)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int *piVar4;
  
  iVar1 = FUN_60164eb0(7);
  piVar3 = (int *)(iVar1 + 4);
  uVar2 = FUN_6015de24("memheap",piVar3);
  FUN_60168578("%-*.s  pool size  max used size available size\n",uVar2,"memheap");
  FUN_6015de60(uVar2);
  FUN_60168578(" ---------- ------------- --------------\n");
  piVar4 = piVar3;
  while (piVar4 = (int *)*piVar4, piVar4 != piVar3) {
    param_2 = piVar4[4];
    FUN_60168578("%-*.*s %-010d %-013d %-05d\n",uVar2,0x10,piVar4 + -5,param_2,piVar4[6],piVar4[5]);
  }
  return (ulonglong)param_2 << 0x20;
}
