
undefined4 FUN_6001fac8(int *param_1,int param_2,int param_3,uint *param_4)

{
  bool bVar1;
  int *piVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr8;
  undefined8 in_d3;
  float unaff_s16;
  float fVar8;
  undefined1 auStack_70 [16];
  undefined8 uStack_60;
  
  if (param_1 == (int *)0x0) {
    return 0xffffffff;
  }
  if (param_3 == 0) {
    return 0xffffffff;
  }
  if (param_4 == (uint *)0x0) {
    return 0xffffffff;
  }
  piVar2 = (int *)param_1[1];
  iVar5 = 0;
  uVar6 = 0;
  uVar4 = piVar2[1];
  fVar8 = *(float *)(*piVar2 + uVar4 * 0x10 + -0xc);
  coprocessor_function2(10,0,0,in_cr8,in_cr1,in_cr0);
  uStack_60 = in_d3;
  while( true ) {
    if (uVar4 <= uVar6) {
      return 1;
    }
    iVar3 = FUN_6010e156(*piVar2 + iVar5);
    if (iVar3 == 1) break;
    piVar2 = (int *)param_1[1];
    iVar5 = iVar5 + 0x10;
    uVar6 = uVar6 + 1;
    uVar4 = piVar2[1];
  }
  ZeroBytes(auStack_70,0x38);
  uVar6 = *(uint *)(*(int *)param_1[1] + iVar5 + 8);
  uVar4 = *(uint *)(*(int *)param_1[1] + iVar5 + 0xc);
  if (param_2 != 1) {
    while( true ) {
      if (uVar4 <= uVar6) {
        return 1;
      }
      iVar5 = FUN_600f7576(*param_1,uVar6,auStack_70);
      if ((iVar5 == 0) && (unaff_s16 <= uStack_60._4_4_)) break;
      uVar6 = uVar6 + 1;
    }
    FUN_600fb404(param_3,auStack_70);
    *param_4 = uVar6;
    return 0;
  }
  bVar1 = false;
  uVar7 = 0;
  do {
    if (uVar4 <= uVar6) {
LAB_6001fba0:
      if (bVar1) {
LAB_6001fba6:
        iVar5 = FUN_600f7576(*param_1,uVar7,auStack_70);
        if (iVar5 == 0) {
          FUN_600fb404(param_3,auStack_70);
          *(float *)(param_3 + 0x14) = fVar8 - *(float *)(param_3 + 0x14);
          *param_4 = ~uVar7 + *(int *)(*param_1 + 0x14);
          return 0;
        }
      }
      return 1;
    }
    iVar5 = FUN_600f7576(*param_1,uVar6,auStack_70);
    if ((iVar5 == 0) && (unaff_s16 < uStack_60._4_4_)) {
      if (uVar6 != 0) {
        uVar7 = uVar6 - 1;
        goto LAB_6001fba6;
      }
      goto LAB_6001fba0;
    }
    if (uVar4 - 1 == uVar6) {
      bVar1 = true;
      uVar7 = uVar4 - 1;
    }
    uVar6 = uVar6 + 1;
  } while( true );
}
