
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600330c8(undefined1 param_1)

{
  *(undefined1 *)(_DAT_20005204 + 0x95) = param_1;
  return;
}
