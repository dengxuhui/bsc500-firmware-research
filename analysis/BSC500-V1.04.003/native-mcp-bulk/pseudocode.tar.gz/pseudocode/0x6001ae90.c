
undefined4 FUN_6001ae90(float param_1,int param_2)

{
  bool bVar1;
  undefined4 uVar2;
  int *piVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  undefined8 in_d6;
  undefined8 in_d7;
  undefined8 local_30;
  undefined8 local_28;
  
  if (param_1 == 0.0) {
    uVar2 = 0;
  }
  else {
    local_30 = in_d6;
    local_28 = in_d7;
    if (iRam20009ba4 == 0) {
      local_28 = 0;
      local_30 = 0x1603f895a;
      iRam20009ba4 = FUN_60168494(&local_30);
    }
    FUN_6016825e(iRam20009ba4,0xffffffff);
    for (piVar3 = (int *)0x20009ba8; piVar3 = (int *)*piVar3, piVar3 != (int *)0x0;
        piVar3 = piVar3 + 10) {
      if (*piVar3 == param_2) {
        if ((short)piVar3[9] == 0) {
          piVar3[5] = (int)param_1;
          iVar7 = VectorFloatToUnsigned(1000.0 / param_1,3);
          piVar3[8] = iVar7;
          uVar6 = VectorFloatToUnsigned(1000.0 / param_1,3);
          uVar4 = FUN_600f6ef0(0x20009bac);
          if (uVar6 < uVar4) {
LAB_6001af8a:
            FUN_60163840(0x20009bac);
            FUN_6016507e(0x20009bac,piVar3[8],piVar3);
            bVar1 = true;
          }
          else {
            uVar6 = piVar3[8];
            uVar4 = FUN_600f6ef0(0x20009bac);
            if (uVar6 != (uVar6 / uVar4) * uVar4) goto LAB_6001af8a;
            uVar6 = piVar3[8];
            uVar4 = FUN_600f6ef0(0x20009bac);
            bVar1 = false;
            piVar3[7] = uVar6 / uVar4;
          }
          if ((code *)piVar3[1] != (code *)0x0) {
            (*(code *)piVar3[1])();
          }
          *(undefined2 *)(piVar3 + 9) = 1;
          goto LAB_6001afca;
        }
        if ((float)piVar3[5] == param_1) break;
        piVar3[5] = (int)param_1;
        iVar7 = VectorFloatToUnsigned(1000.0 / param_1,3);
        piVar3[8] = iVar7;
        uVar6 = VectorFloatToUnsigned(1000.0 / param_1,3);
        uVar4 = FUN_600f6ef0(0x20009bac);
        if (uVar4 <= uVar6) {
          uVar6 = piVar3[8];
          uVar4 = FUN_600f6ef0(0x20009bac);
          if (uVar6 == (uVar6 / uVar4) * uVar4) {
            uVar6 = piVar3[8];
            uVar4 = FUN_600f6ef0(0x20009bac);
            piVar3[7] = uVar6 / uVar4;
            break;
          }
        }
        FUN_60163840(0x20009bac);
        FUN_6016507e(0x20009bac,piVar3[8],piVar3);
        bVar1 = true;
        goto LAB_6001afca;
      }
    }
    bVar1 = false;
LAB_6001afca:
    if (iRam20009ba4 != 0) {
      FUN_601682ae();
    }
    if (bVar1) {
      if (iRam20009ba4 == 0) {
        local_28 = 0;
        local_30 = 0x1603f895a;
        iRam20009ba4 = FUN_60168494(&local_30);
      }
      FUN_6016825e(iRam20009ba4,0xffffffff);
      iVar7 = iRam20009ba8;
      while (iVar5 = iVar7, iVar5 != 0) {
        uVar6 = *(uint *)(iVar5 + 0x20);
        iVar7 = *(int *)(iVar5 + 0x28);
        uVar4 = FUN_600f6ef0(0x20009bac);
        if (uVar4 <= uVar6) {
          uVar6 = *(uint *)(iVar5 + 0x20);
          uVar4 = FUN_600f6ef0(0x20009bac);
          if (uVar6 == (uVar6 / uVar4) * uVar4) {
            uVar6 = *(uint *)(iVar5 + 0x20);
            uVar4 = FUN_600f6ef0(0x20009bac);
            uVar6 = uVar6 / uVar4;
            *(uint *)(iVar5 + 0x18) = uVar6 - 1;
            *(uint *)(iVar5 + 0x1c) = uVar6;
          }
        }
      }
      if (iRam20009ba4 != 0) {
        FUN_601682ae();
      }
    }
    uVar2 = 1;
  }
  return uVar2;
}
