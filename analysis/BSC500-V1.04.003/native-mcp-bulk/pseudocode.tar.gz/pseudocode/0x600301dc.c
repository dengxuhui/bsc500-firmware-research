
undefined4 FUN_600301dc(int param_1,uint *param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  undefined4 local_1c;
  
  local_1c = 0;
  if ((((param_1 != 0) && (param_2 != (uint *)0x0)) && (param_3 != 0)) && (2 < *param_2)) {
    FUN_6011ec30(param_1,*param_2,param_3,&local_1c,param_3);
    uVar1 = *param_2;
    piVar4 = (int *)(param_1 + uVar1 * 0xc + -0x18);
    iVar3 = 1 - uVar1;
    while (iVar3 + 1 != 0) {
      if ((*piVar4 == 0) && (piVar4[1] == 0)) {
        FUN_6015d9f4(piVar4,piVar4 + 3,(uVar1 + iVar3) * 0xc);
        iVar2 = param_1 + *param_2 * 0xc;
        *(undefined4 *)(iVar2 + -0xc) = 0;
        *(undefined4 *)(iVar2 + -8) = 0;
        *(undefined4 *)(iVar2 + -4) = 0;
        uVar1 = *param_2 - 1;
        *param_2 = uVar1;
      }
      piVar4 = piVar4 + -3;
      iVar3 = iVar3 + 1;
    }
    return 0;
  }
  return 0xffffffff;
}
