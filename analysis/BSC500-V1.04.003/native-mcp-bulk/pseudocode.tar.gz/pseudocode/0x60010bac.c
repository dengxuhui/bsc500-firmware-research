
undefined4 * FUN_60010bac(undefined4 *param_1)

{
  *param_1 = &UNK_602978b0;
  param_1[1] = 0;
  FUN_600e7fa8(param_1 + 2);
  FUN_600e7fa8(param_1 + 0xe);
  return param_1;
}
