
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x6001a80e */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_6001a7f6(undefined8 *param_1,undefined8 *param_2,int param_3)

{
  int iVar1;
  undefined4 uVar2;
  float fVar3;
  undefined8 uVar4;
  
  uVar2 = 0xffffffff;
  if (((param_1 != (undefined8 *)0x0) && (param_2 != (undefined8 *)0x0)) && (param_3 != 0)) {
    iVar1 = FUN_60137930((int)*param_2,(int)((ulonglong)*param_2 >> 0x20),(int)param_2[1]);
    if (iVar1 == 0) {
      uVar2 = 0xffffffff;
    }
    else {
      if (*(int *)(param_1 + 3) == 0) {
        *(undefined4 *)(param_1 + 2) = 0;
        uVar4 = param_2[1];
        *param_1 = *param_2;
        param_1[1] = uVar4;
        *(undefined4 *)((int)param_1 + 0x14) = *(undefined4 *)(param_2 + 2);
        FUN_60100c64(param_3,param_1);
        iVar1 = *(int *)(param_1 + 3);
      }
      else {
        fVar3 = (float)*param_1;
        FUN_60161ad0(fVar3,(int)((ulonglong)*param_1 >> 0x20),(int)param_1[1],
                     (int)((ulonglong)param_1[1] >> 0x20),(int)*param_2,
                     (int)((ulonglong)*param_2 >> 0x20),(int)param_2[1]);
        if (fVar3 < 1.0) {
          return 1;
        }
        uVar4 = param_2[1];
        *param_1 = *param_2;
        param_1[1] = uVar4;
        *(undefined4 *)((int)param_1 + 0x14) = *(undefined4 *)(param_2 + 2);
        *(float *)(param_1 + 2) = fVar3 + *(float *)(param_1 + 2);
        FUN_60100c64(param_3,param_1);
        iVar1 = *(int *)(param_1 + 3);
      }
      uVar2 = 0;
      *(int *)(param_1 + 3) = iVar1 + 1;
    }
  }
  return uVar2;
}
