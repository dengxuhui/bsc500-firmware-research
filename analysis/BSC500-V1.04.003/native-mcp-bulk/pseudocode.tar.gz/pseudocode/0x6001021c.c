
undefined4 FUN_6001021c(void)

{
  int iVar1;
  
  for (iVar1 = 0; iVar1 != 0x30; iVar1 = iVar1 + 0xc) {
    FUN_6001b060(*(undefined4 *)(&UNK_602bf84c + iVar1));
    FUN_6001ae90(*(undefined4 *)(&UNK_602bf848 + iVar1),*(undefined4 *)(&UNK_602bf844 + iVar1));
  }
  return 1;
}
