
undefined4 FUN_600201f6(ushort *param_1,ushort *param_2,char *param_3)

{
  ushort *puVar1;
  char cVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  ushort *puVar6;
  uint uVar7;
  uint uVar8;
  
  uVar3 = 0xffffffff;
  if (((param_1 != (ushort *)0x0) && (param_2 != (ushort *)0x0)) && (param_3 != (char *)0x0)) {
    uVar4 = (uint)*param_2;
    if (uVar4 == 0xffff) {
      cVar2 = -1;
    }
    else if (uVar4 < *param_1) {
      cVar2 = (char)((uVar4 * 10) / (uint)*param_1);
    }
    else {
      iVar5 = (byte)param_1[8] - 1;
      if (uVar4 < param_1[iVar5]) {
        uVar7 = 1;
        cVar2 = '\0';
        puVar6 = param_1;
        do {
          puVar1 = puVar6;
          puVar6 = puVar1 + 1;
          if ((byte)param_1[8] <= uVar7) goto LAB_60020268;
          uVar8 = (uint)*puVar6;
          cVar2 = cVar2 + '\n';
          uVar7 = uVar7 + 1;
        } while (uVar8 <= uVar4);
        uVar7 = (uint)*puVar1;
        cVar2 = (char)((int)((uVar4 - uVar7) * 10) / (int)(uVar8 - uVar7)) + cVar2;
      }
      else {
        cVar2 = (char)iVar5 * '\n' + '\t';
      }
    }
    *param_3 = cVar2;
LAB_60020268:
    uVar3 = 0;
  }
  return uVar3;
}
