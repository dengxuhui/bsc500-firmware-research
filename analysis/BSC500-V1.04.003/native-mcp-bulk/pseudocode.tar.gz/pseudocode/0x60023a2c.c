
undefined4 FUN_60023a2c(byte *param_1,undefined4 *param_2)

{
  int *piVar1;
  undefined4 uVar2;
  
  piVar1 = (int *)FUN_6015d9e4();
  if (*(char *)(*piVar1 + (uint)*param_1) == ' ') {
    uVar2 = FUN_6016811c(param_1);
    param_2[5] = uVar2;
    uVar2 = FUN_6016811c(param_1 + 5);
    param_2[4] = uVar2;
    uVar2 = FUN_6016811c(param_1 + 8);
    param_2[3] = uVar2;
    uVar2 = FUN_6016811c(param_1 + 0xb);
    param_2[2] = uVar2;
    uVar2 = FUN_6016811c(param_1 + 0xe);
    param_2[1] = uVar2;
    uVar2 = FUN_6016811c(param_1 + 0x11);
    *param_2 = uVar2;
    return 1;
  }
  return 0;
}
