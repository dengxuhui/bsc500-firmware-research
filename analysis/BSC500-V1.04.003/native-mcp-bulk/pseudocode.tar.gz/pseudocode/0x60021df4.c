
undefined4 FUN_60021df4(int param_1)

{
  int iVar1;
  undefined1 auStack_38 [24];
  
  if ((param_1 != 0) && (iVar1 = FUN_60030b8c(), iVar1 == 0)) {
    ZeroBytes(auStack_38,0x18);
    iVar1 = FUN_601356c8(0x2000b070,auStack_38);
    if ((iVar1 == 0) && (iVar1 = FUN_601357f0(0x2000b030,auStack_38), iVar1 == 0)) {
      iRam2000bddc = iRam2000bddc + 1;
      FUN_601354ec(0x2000b090,auStack_38);
      FUN_601354a8(0x2000b090);
      FUN_60135466(0x200895a0,0x2000be00);
      FUN_6013570a(0x2000b060,0x2000b038);
      FUN_60135492(0x2000b090,0x2000b040);
      iVar1 = FUN_60135acc(0x2000b030,0x2000be00);
      if ((((iVar1 == 0) && (iVar1 = FUN_60135b7e(0x2000b030,0x2000b038), iVar1 == 0)) &&
          (iVar1 = FUN_60135bf2(0x2000b030,0x2000b040), iVar1 == 0)) &&
         ((iVar1 = FUN_60135b38(0x2000b030,iRam2000bddc), iVar1 == 0 &&
          (iVar1 = FUN_60135788(0x2000b030), iVar1 == 0)))) {
        FUN_601667bc(uRam2000b030);
        uRam2000b030 = 0;
        iVar1 = FUN_60166758(0x2000b034,0x2008ae28,1);
        if (iVar1 != 0) {
          uRam2000b034 = 0;
          return 0xffffffff;
        }
        uRam2000bdcc = 0x2000b034;
        return 0;
      }
    }
    FUN_601667bc(uRam2000b030);
    uRam2000b030 = 0;
    FUN_60163bbe(0x2008ae28);
  }
  return 0xffffffff;
}
