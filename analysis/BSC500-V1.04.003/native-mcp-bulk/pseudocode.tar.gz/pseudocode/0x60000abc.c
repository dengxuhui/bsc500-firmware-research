
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000abc(undefined1 *param_1,uint *param_2)

{
  uint uVar1;
  undefined4 uVar2;
  
  uVar2 = 1;
  if ((param_1 != (undefined1 *)0x0) && (param_2 != (uint *)0x0)) {
    if ((int)(_DAT_4007a000 << 0x1e) < 0) {
      if ((_DAT_4007a000 & 1) == 0) {
        *param_1 = 2;
        _DAT_4007b00c = _DAT_4007b00c & 0xfffffbff;
      }
      else {
        *param_1 = 1;
      }
      _DAT_4007a00c = _DAT_4007a008;
      _DAT_4007a000 = _DAT_4007a000 & 0xfffffffd;
      uVar1 = _DAT_4007a008 & 1;
      *param_2 = _DAT_4007a008;
      if (uVar1 != 0) {
        _DAT_4007b00c = _DAT_4007b00c & 0xfffffffd;
        _DAT_4007a00c = *param_2;
      }
    }
    else {
      *param_1 = 0;
      *param_2 = 0;
      if (-1 < (int)(_DAT_4007a000 << 0x1d)) {
        return 0;
      }
      *param_2 = _DAT_4007a008;
      *param_1 = 3;
      _DAT_4007a000 = _DAT_4007a000 & 0xfffffffb;
    }
    uVar2 = 0;
  }
  return uVar2;
}
