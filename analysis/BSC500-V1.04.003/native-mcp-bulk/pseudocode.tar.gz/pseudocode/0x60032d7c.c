
void FUN_60032d7c(int param_1)

{
  if ((param_1 != 0) && (cRam2000a478 == '\0')) {
    FUN_6013a8de(uRam2000a480,&stack0xfffffff4,0,0);
  }
  return;
}
