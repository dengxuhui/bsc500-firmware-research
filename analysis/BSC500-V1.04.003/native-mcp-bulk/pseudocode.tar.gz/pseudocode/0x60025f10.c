
uint FUN_60025f10(undefined4 param_1,undefined4 param_2,uint param_3,uint *param_4,int param_5,
                 uint param_6,int param_7)

{
  longlong lVar1;
  uint *puVar2;
  undefined4 uVar3;
  uint *puVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  undefined4 uVar10;
  uint uVar11;
  uint uVar12;
  undefined4 uVar13;
  uint uVar14;
  uint uVar15;
  undefined4 *puVar16;
  int iVar17;
  int iVar18;
  bool bVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  uint local_8c;
  
  uVar15 = param_6 + 0x10000;
  if (uVar15 < 0xffff) {
    puVar2 = (uint *)FUN_6011ffbc(param_6);
  }
  else {
    iVar9 = *(int *)(param_3 + 0x68);
    lVar1 = *(longlong *)(param_3 + 0x18);
    uVar3 = *(undefined4 *)(param_3 + 0x10);
    uVar7 = param_6 & 0x3ff;
    iVar17 = iVar9 + uVar7 * 8;
    iVar18 = iVar9 + uVar7 * 0x18;
    puVar16 = (undefined4 *)(iVar18 + 0x1000);
    uVar11 = param_3;
    for (iVar8 = 0; iVar8 != 2; iVar8 = iVar8 + 1) {
      uVar11 = *(uint *)(iVar17 + 0x7000 + iVar8 * 4);
      if (uVar11 == param_6) goto LAB_60025fc6;
      puVar16 = puVar16 + 3;
    }
    iVar8 = *(int *)(iVar9 + uVar7 * 4);
    *(int *)(iVar9 + uVar7 * 4) = (iVar8 + 1) % 2;
    puVar16 = (undefined4 *)(iVar18 + iVar8 * 0xc + 0x1000);
    FUN_6013233a(uVar3,puVar16,0xc,uVar11,(ulonglong)param_6 * 0xc + lVar1);
    *(uint *)(iVar17 + iVar8 * 4 + 0x7000) = param_6;
LAB_60025fc6:
    uVar6 = *puVar16;
    uVar3 = puVar16[1];
    uVar10 = puVar16[2];
    *(undefined4 *)(param_3 + 0x38) = uVar6;
    *(undefined4 *)(param_3 + 0x3c) = uVar3;
    *(undefined4 *)(param_3 + 0x40) = uVar10;
    puVar2 = (uint *)FUN_600fc2e0(param_4,uVar6,1);
  }
  uVar3 = 0;
  uVar11 = 0x40768000;
  local_8c = 0xffffffff;
  do {
    puVar4 = puVar2;
    if (puVar4 == (uint *)0x0) {
      return local_8c;
    }
    uVar7 = *puVar4;
    if (uVar7 == param_6) {
      uVar7 = puVar4[1];
    }
    uVar5 = (uint)*(byte *)((int)puVar4 + 0x13) << 0x1c;
    if ((int)uVar5 < 0) {
      bVar19 = uVar15 == 0xffff;
      if (0xfffe < uVar15) {
        uVar5 = uVar7 + 0x10000;
        bVar19 = uVar5 == 0xfffe;
      }
      if ((0xfffe < uVar15 && 0xfffd < uVar5) && !bVar19) {
        uVar5 = param_4[((int)puVar4 - (int)(param_4 + 4)) / 0x14 + 0x18];
      }
      else {
        uVar5 = FUN_6011ffd0(puVar4);
      }
      uVar14 = puVar4[3];
      iVar9 = *(int *)(param_5 + 0x54);
      uVar6 = *(undefined4 *)(param_5 + 0xc);
      uVar12 = uVar14 & 0x3ff;
      iVar17 = iVar9 + uVar12 * 8;
      iVar18 = iVar9 + uVar12 * 0x20;
      puVar16 = (undefined4 *)(iVar18 + 0x1000);
      for (iVar8 = 0; iVar8 != 2; iVar8 = iVar8 + 1) {
        if (*(uint *)(iVar17 + 0x9000 + iVar8 * 4) == uVar14) goto LAB_600260d8;
        puVar16 = puVar16 + 4;
      }
      iVar8 = *(int *)(iVar9 + uVar12 * 4);
      *(int *)(iVar9 + uVar12 * 4) = (iVar8 + 1) % 2;
      puVar16 = (undefined4 *)(iVar18 + iVar8 * 0x10 + 0x1000);
      FUN_6013233a(uVar6,puVar16,0x10,uVar12,uVar14 * 0x10 + 0xc);
      *(uint *)(iVar17 + iVar8 * 4 + 0x9000) = uVar14;
LAB_600260d8:
      uVar6 = puVar16[1];
      uVar10 = puVar16[2];
      uVar13 = puVar16[3];
      *(undefined4 *)(param_5 + 0x18) = *puVar16;
      *(undefined4 *)(param_5 + 0x1c) = uVar6;
      *(undefined4 *)(param_5 + 0x20) = uVar10;
      *(undefined4 *)(param_5 + 0x24) = uVar13;
      if ((*(ushort *)(param_7 + 0x78) & *(ushort *)(param_5 + 0x1c)) != 0) {
        if (*(int *)(param_7 + 0x6c) != 0) {
          if (puVar4[1] == param_6) {
            iVar8 = puVar4[4] << 2;
          }
          else {
            iVar8 = puVar4[4] << 1;
          }
          if ((iVar8 < 0) &&
             ((*(ushort *)(param_7 + 0x78) != 8 ||
              (-1 < (int)((uint)*(byte *)(param_5 + 0x1e) << 0x1b))))) goto LAB_600261b6;
        }
        uVar20 = FUN_60058548(param_3,puVar4,param_6);
        uVar21 = FUN_60165558(param_1,param_2,(int)uVar20,(int)((ulonglong)uVar20 >> 0x20));
        uVar6 = (undefined4)((ulonglong)uVar21 >> 0x20);
        uVar20 = FUN_601682c8((int)uVar21,uVar6,0,0x40768000);
        iVar8 = FUN_60167bc4((int)uVar21,uVar6,0,0xc0668000);
        if (iVar8 == 0) {
          uVar20 = uVar21;
        }
        uVar6 = (undefined4)((ulonglong)uVar20 >> 0x20);
        uVar21 = FUN_601682c8((int)uVar20,uVar6,0,0xc0768000);
        iVar8 = FUN_60167b9a((int)uVar20,uVar6,0,0x40668000);
        if (iVar8 == 0) {
          uVar21 = uVar20;
        }
        uVar12 = (uint)((ulonglong)uVar21 >> 0x20) & 0x7fffffff;
        iVar8 = FUN_60167b9a((int)uVar21,uVar12,uVar3,uVar11);
        if (iVar8 == 0) {
          uVar3 = (int)uVar21;
          uVar11 = uVar12;
          local_8c = uVar5;
        }
      }
    }
LAB_600261b6:
    if (uVar15 < 0xffff) {
      puVar2 = (uint *)FUN_601200ac(puVar4,param_6);
    }
    else {
      puVar2 = (uint *)0x0;
      if (0xfffe < uVar7 + 0x10000) {
        iVar8 = ((int)puVar4 - (int)(param_4 + 4)) / 0x14;
        iVar9 = iVar8 + 1;
        if (*puVar4 == param_6) {
          puVar2 = (uint *)0x0;
          if ((param_4[iVar8 + 0x18] + 1 < *param_4) &&
             (puVar2 = (uint *)FUN_600fc2e0(param_4,param_4[iVar8 + 0x18] + 1,iVar9),
             *puVar2 != param_6)) {
            puVar2 = (uint *)0x0;
          }
        }
        else {
          puVar2 = (uint *)0x0;
          if (puVar4[2] != 0xffffffff) {
            puVar2 = (uint *)FUN_600fc2e0(param_4,puVar4[2],iVar9);
          }
        }
      }
    }
  } while( true );
}
