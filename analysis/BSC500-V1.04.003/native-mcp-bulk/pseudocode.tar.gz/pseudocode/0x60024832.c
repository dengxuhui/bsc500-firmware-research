
int FUN_60024832(int param_1)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_6015d9e4();
  if (((int)((uint)*(byte *)(*piVar1 + param_1) << 0x1c) < 0) && (param_1 != 0xdf)) {
    return param_1 + -0x20;
  }
  return param_1;
}
