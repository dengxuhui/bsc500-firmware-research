
undefined4 FUN_6003229a(void)

{
  return 0;
}
