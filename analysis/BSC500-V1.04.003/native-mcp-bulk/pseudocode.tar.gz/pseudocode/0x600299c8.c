
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600299c8(void)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if ((_DAT_2000b300 == 0) && (_DAT_2000b304 == 0)) {
    _DAT_2000b304 = FUN_60133eee();
    if (_DAT_2000b304 != 0) {
      _DAT_2000b300 = FUN_60137fd4();
      if (_DAT_2000b300 != 0) {
        return 0;
      }
      FUN_60133ef6(_DAT_2000b304);
      _DAT_2000b300 = 0;
      _DAT_2000b304 = 0;
    }
    uVar1 = 0xffffffff;
  }
  return uVar1;
}
