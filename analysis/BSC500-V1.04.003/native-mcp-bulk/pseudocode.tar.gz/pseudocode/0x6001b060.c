
undefined4 FUN_6001b060(char *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  char *local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 uStack_14;
  
  if ((param_1 == (char *)0x0) || ((param_1[3] & 0x60U) == 0)) {
    uVar1 = 0;
  }
  else {
    local_20 = param_1;
    local_1c = param_2;
    local_18 = param_3;
    uStack_14 = param_4;
    if (iRam20009ba4 == 0) {
      local_18 = 0;
      uStack_14 = 0;
      local_1c = 1;
      local_20 = "low_prio";
      iRam20009ba4 = FUN_60168494(&local_20);
    }
    FUN_6016825e(iRam20009ba4,0xffffffff);
    *(char **)(param_1 + 0x28) = pcRam20009ba8;
    if (pcRam20009ba8 != (char *)0x0) {
      *(char **)(pcRam20009ba8 + 0x2c) = param_1 + 0x28;
    }
    pcRam20009ba8 = param_1;
    param_1[0x2c] = -0x58;
    param_1[0x2d] = -0x65;
    param_1[0x2e] = '\0';
    param_1[0x2f] = ' ';
    if (cRam20009ba0 == '\0') {
      FUN_6016572c(&UNK_6043585c,1,&UNK_6001e5e1);
      FUN_6016507e(0x20009bac,100,0);
      cRam20009ba0 = '\x01';
    }
    if (iRam20009ba4 != 0) {
      FUN_601682ae();
    }
    uVar1 = 1;
  }
  return uVar1;
}
