
char FUN_600182fc(void)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  char local_25;
  undefined1 auStack_24 [4];
  undefined4 local_20;
  undefined1 auStack_1c [4];
  undefined4 local_18;
  int local_14;
  
  if (cRam2000a0cc == '\0') {
    local_20 = 0;
    local_25 = '\0';
    iVar2 = FUN_6012f44c();
    iVar3 = FUN_60166758(&local_20,"0:/nrf_fw/ble_ver.bin",1);
    cVar1 = cRam2000a0cc;
    if (iVar3 == 0) {
      FUN_60161ef4(local_20,&local_25,1,auStack_24);
      FUN_601667bc(local_20);
      if ((iVar2 == 0x68) || (local_25 != 'h')) {
        FUN_60163bbe("0:/nrf_fw/ble_dat_pack.bin");
        FUN_60163bbe("0:/nrf_fw/ble_bin_pack.bin");
        FUN_60163bbe("0:/nrf_fw/ble_ver.bin");
        FUN_60163bbe(&UNK_603fa992);
        cVar1 = cRam2000a0cc;
      }
      else {
        local_18 = 0;
        local_14 = 0;
        iVar2 = FUN_60166758(&local_14,"0:/nrf_fw/ble_dat_pack.bin",1);
        if (iVar2 == 0) {
          uRam2000a0d4 = FUN_6016506c();
          uRam2000a0d0 = FUN_60162e34();
          uVar4 = FUN_60161ef4(local_14,uRam2000a0d0,uRam2000a0d4,auStack_1c);
          FUN_60168578("qw_f_read %s, ret:%d\n","0:/nrf_fw/ble_dat_pack.bin",uVar4);
          FUN_601667bc(local_14);
          iVar2 = FUN_60166758(&local_18,"0:/nrf_fw/ble_bin_pack.bin",1);
          if (iVar2 == 0) {
            uRam2000a0dc = FUN_6016506c(local_18);
            uRam2000a0d8 = FUN_60162e34();
            uVar4 = FUN_60161ef4(local_18,uRam2000a0d8,uRam2000a0dc,auStack_1c);
            FUN_60168578("qw_f_read %s, ret:%d\n","0:/nrf_fw/ble_bin_pack.bin",uVar4);
            FUN_601667bc(local_18);
            FUN_60168578("nrf_dat_pack_size:%d, nrf_bin_pack_size:%d\n",uRam2000a0d4,uRam2000a0dc);
          }
          cRam2000a0cc = '\x01';
          cVar1 = cRam2000a0cc;
        }
        else {
          cVar1 = cRam2000a0cc;
          if (local_14 != 0) {
            FUN_601667bc();
            cVar1 = cRam2000a0cc;
          }
        }
      }
    }
  }
  else {
    cVar1 = '\x01';
  }
  return cVar1;
}
