
void FUN_6002b290(int param_1,undefined2 *param_2,short *param_3,uint param_4,uint param_5,
                 uint param_6)

{
  ushort uVar1;
  short sVar2;
  short sVar3;
  bool bVar4;
  short sVar5;
  short sVar6;
  short sVar7;
  short sVar8;
  short sVar9;
  short sVar10;
  undefined4 uVar11;
  uint uVar12;
  int iVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  uint uVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  int iVar20;
  int iVar21;
  uint uVar22;
  bool bVar23;
  undefined1 auStack_130 [8];
  short local_128;
  short local_126;
  short local_124;
  short local_122;
  short local_120;
  short local_11e;
  short local_11c;
  short local_11a;
  undefined1 auStack_108 [108];
  undefined1 auStack_9c [24];
  undefined1 auStack_84 [24];
  short local_6c;
  short local_6a;
  short local_68;
  short local_66;
  short local_64;
  short local_62;
  short local_60;
  short local_5e;
  undefined2 local_5c;
  byte local_5a;
  undefined1 local_59;
  undefined2 local_58;
  int local_4c;
  undefined1 local_42;
  
  if (*(byte *)(param_2 + 6) < 3) {
    return;
  }
  uVar1 = param_2[1];
  if (uVar1 == 0) {
    return;
  }
  if (param_5 == param_6) {
    return;
  }
  FUN_6015a96c(&local_5c);
  local_5a = *(byte *)((int)param_2 + 0xd) & 3;
  uVar19 = (uint)uVar1;
  if ((int)param_4 < (int)(short)uVar1) {
    uVar19 = param_4;
  }
  if (*(int *)(param_2 + 4) == 0) {
    local_58 = *param_2;
    local_59 = *(undefined1 *)(param_2 + 6);
  }
  else {
    local_42 = *(undefined1 *)(param_2 + 6);
    local_59 = 0;
    local_4c = *(int *)(param_2 + 4);
  }
  sVar5 = (short)param_4;
  local_6a = param_2[1];
  local_60 = sVar5 + -1 + *param_3;
  local_64 = *param_3 - sVar5;
  local_6c = local_64 + local_6a;
  local_68 = local_60 - local_6a;
  local_62 = param_3[1] - sVar5;
  local_5e = sVar5 + -1 + param_3[1];
  local_66 = local_5e - local_6a;
  local_6a = local_6a + local_62;
  if (((short)((local_68 - local_6c) + 1) < 1) || ((short)((local_66 - local_6a) + 1) < 1)) {
    bVar4 = false;
    sVar6 = -1;
  }
  else {
    bVar4 = true;
    FUN_6015a530(auStack_84,&local_6c,0x7fff,1);
    sVar6 = FUN_6015a500(auStack_84,0);
  }
  FUN_6015a530(auStack_9c,&local_64,0x7fff,0);
  uVar11 = FUN_6015a500(auStack_9c,0);
  uVar12 = param_5 + 0x168;
  bVar23 = uVar12 != param_6;
  if (bVar23) {
    uVar12 = param_6 + 0x168;
  }
  if (!bVar23 || uVar12 == param_5) {
    local_5c = 0x7fff;
    DispatchRectangleFill(param_1,&local_5c,&local_64);
    FUN_6015a4e0(uVar11);
    if (sVar6 != -1) {
      FUN_6015a4e0((int)sVar6);
    }
    FUN_6015a4aa(auStack_9c);
    if (!bVar4) {
      return;
    }
    FUN_6015a4aa(auStack_84);
    return;
  }
  uVar12 = 0x167;
  if (0x2c < param_6 >> 3) {
    uVar12 = param_6;
  }
  param_6 = (uVar12 / 0x168) * -0x168 + param_6;
  sVar3 = (short)param_6;
  iVar13 = (int)sVar3;
  uVar12 = 0x167;
  if (0x2c < param_5 >> 3) {
    uVar12 = param_5;
  }
  param_5 = (uVar12 / 0x168) * -0x168 + param_5;
  sVar2 = (short)param_5;
  iVar18 = (int)sVar2;
  FUN_6003b288(auStack_108,(int)*param_3,(int)param_3[1],iVar18,iVar13);
  param_5 = param_5 & 0xffff;
  uVar12 = param_6 & 0xffff;
  iVar20 = param_5 - uVar12;
  if (param_5 < uVar12) {
    iVar20 = iVar20 + 0x168;
  }
  uVar14 = FUN_6015a500(auStack_108,0);
  uVar15 = *(undefined4 *)(param_1 + 8);
  if ((param_4 < 0xb) || (iVar20 < 0x3d)) {
    DispatchRectangleFill(param_1,&local_5c,&local_64);
    goto LAB_6002bb38;
  }
  uVar17 = uVar12 / 0x5a;
  uVar16 = param_5 / 0x5a & 3;
  sVar10 = (short)uVar19;
  if (uVar16 == 0) {
    if ((0x59 < uVar12) || (uVar12 <= param_5)) {
      local_120 = *param_3;
      sVar9 = param_3[1];
      local_11a = sVar9 + sVar5;
      iVar21 = (int)sVar5 - (int)sVar10;
      iVar20 = FUN_6012536c(iVar18);
      local_11e = sVar9 + (short)((uint)(iVar21 * iVar20) >> 0xf);
      sVar9 = *param_3;
      sVar7 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
      local_11c = sVar9 + (short)((uint)((int)sVar7 * (int)sVar5) >> 0xf);
      iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
      if (iVar20 != 0) {
        *(short **)(param_1 + 8) = &local_120;
        DispatchRectangleFill(param_1,&local_5c,&local_64);
      }
      if (0x59 < uVar12) goto LAB_6002b638;
      goto LAB_6002b5da;
    }
    sVar9 = param_3[1];
    iVar20 = FUN_6012536c(iVar18);
    local_11e = sVar9 + (short)((uint)(((int)sVar5 - (int)sVar10) * iVar20) >> 0xf);
    sVar9 = *param_3;
    sVar7 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
    local_11c = sVar9 + (short)((uint)((int)sVar7 * (int)sVar5) >> 0xf);
    sVar9 = param_3[1];
    sVar8 = FUN_6012536c(iVar13);
    sVar7 = *param_3;
    local_11a = sVar9 + (short)((uint)((int)sVar8 * (int)sVar5) >> 0xf);
    iVar20 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
    local_120 = sVar7 + (short)((uint)(((int)sVar5 - (int)sVar10) * iVar20) >> 0xf);
    iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
LAB_6002b626:
    if (iVar20 != 0) {
LAB_6002b62a:
      *(short **)(param_1 + 8) = &local_120;
      DispatchRectangleFill(param_1,&local_5c,&local_64);
    }
  }
  else {
    if (uVar12 < 0x5a) {
      iVar21 = (int)sVar5 - (int)sVar10;
LAB_6002b5da:
      sVar9 = param_3[1];
      local_11c = *param_3 + sVar5;
      local_11e = sVar9;
      iVar20 = FUN_6012536c(iVar13);
      local_11a = sVar9 + (short)((uint)(sVar5 * iVar20) >> 0xf);
      sVar9 = *param_3;
      iVar20 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
      local_120 = sVar9 + (short)((uint)(iVar21 * iVar20) >> 0xf);
      iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
      goto LAB_6002b626;
    }
    if ((uVar12 < param_5) && (uVar16 == uVar17)) {
LAB_6002b538:
      local_120 = *param_3;
      local_11e = param_3[1];
      local_11a = local_11e + sVar5;
      local_11c = local_120 + sVar5;
      iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
      if (iVar20 == 0) goto LAB_6002b638;
      goto LAB_6002b62a;
    }
    if (uVar16 == 3) {
      if ((uVar17 - 1 & 0xffff) < 2) goto LAB_6002b538;
    }
    else if ((uVar16 == 2) && ((param_6 - 0x5a & 0xffff) < 0x5a)) goto LAB_6002b538;
  }
LAB_6002b638:
  uVar22 = param_6 - 0x5a;
  *(undefined4 *)(param_1 + 8) = uVar15;
  if (uVar16 == 1) {
    if ((param_5 < uVar12) && ((uVar22 & 0xffff) < 0x5a)) {
      sVar9 = param_3[1];
      sVar7 = FUN_6012536c(iVar18);
      local_11a = sVar9 + (short)((uint)((int)sVar7 * (int)sVar5) >> 0xf);
      sVar9 = *param_3;
      iVar20 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
      local_11c = sVar9 + (short)((uint)(((int)sVar5 - (int)sVar10) * iVar20) >> 0xf);
      sVar9 = param_3[1];
      iVar20 = FUN_6012536c(iVar13);
      local_11e = sVar9 + (short)((uint)(((int)sVar5 - (int)sVar10) * iVar20) >> 0xf);
      sVar9 = *param_3;
      sVar7 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
      local_120 = sVar9 + (short)((uint)((int)sVar7 * (int)sVar5) >> 0xf);
LAB_6002b7c2:
      iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
    }
    else {
      sVar9 = param_3[1];
      local_120 = *param_3 - sVar5;
      local_11e = sVar9;
      sVar8 = FUN_6012536c(iVar18);
      sVar7 = *param_3;
      local_11a = sVar9 + (short)((uint)((int)sVar8 * (int)sVar5) >> 0xf);
      iVar20 = (int)sVar5 - (int)sVar10;
      iVar21 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
      local_11c = sVar7 + (short)((uint)(iVar20 * iVar21) >> 0xf);
      iVar21 = FUN_6014f950(&local_120,&local_120,uVar15);
      if (iVar21 != 0) {
        *(short **)(param_1 + 8) = &local_120;
        DispatchRectangleFill(param_1,&local_5c,&local_64);
      }
      if (0x59 < (uVar22 & 0xffff)) goto LAB_6002b7e0;
LAB_6002b744:
      sVar9 = param_3[1];
      local_11c = *param_3 + -1;
      local_11a = sVar9 + sVar5;
      iVar21 = FUN_6012536c(iVar13);
      sVar7 = *param_3;
      local_11e = sVar9 + (short)((uint)(iVar20 * iVar21) >> 0xf);
      iVar20 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
      local_120 = sVar7 + (short)((uint)(sVar5 * iVar20) >> 0xf);
      iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
    }
    if (iVar20 != 0) {
      *(short **)(param_1 + 8) = &local_120;
      DispatchRectangleFill(param_1,&local_5c,&local_64);
    }
  }
  else {
    if ((uVar22 & 0xffff) < 0x5a) {
      iVar20 = (int)sVar5 - (int)sVar10;
      goto LAB_6002b744;
    }
    if ((uVar12 < param_5) && (uVar16 == uVar17)) {
LAB_6002b7a4:
      local_11e = param_3[1];
      local_11a = local_11e + sVar5;
      local_120 = *param_3 - sVar5;
      local_11c = *param_3 + -1;
      goto LAB_6002b7c2;
    }
    if (uVar16 == 3) {
      if ((param_6 - 0xb4 & 0xffff) < 0x5a) goto LAB_6002b7a4;
    }
    else if ((uVar16 == 0) && ((uVar17 & 0xfffffffe) == 2)) goto LAB_6002b7a4;
  }
LAB_6002b7e0:
  *(undefined4 *)(param_1 + 8) = uVar15;
  uVar22 = param_6 - 0xb4;
  if (uVar16 == 2) {
    sVar9 = *param_3;
    if ((param_5 < uVar12) && ((uVar22 & 0xffff) < 0x5a)) {
      sVar7 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
      local_120 = sVar9 + (short)((uint)((int)sVar7 * (int)sVar5) >> 0xf);
      sVar9 = param_3[1];
      iVar20 = FUN_6012536c(iVar18);
      local_11a = sVar9 + (short)((uint)(((int)sVar5 - (int)sVar10) * iVar20) >> 0xf);
      sVar7 = param_3[1];
      sVar8 = FUN_6012536c(iVar13);
      sVar9 = *param_3;
      local_11e = sVar7 + (short)((uint)((int)sVar8 * (int)sVar5) >> 0xf);
      iVar20 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
      local_11c = sVar9 + (short)((uint)(((int)sVar5 - (int)sVar10) * iVar20) >> 0xf);
    }
    else {
      local_11c = sVar9 + -1;
      local_11e = param_3[1] - sVar5;
      sVar8 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
      sVar7 = param_3[1];
      local_120 = sVar9 + (short)((uint)((int)sVar8 * (int)sVar5) >> 0xf);
      iVar20 = (int)sVar5 - (int)sVar10;
      iVar21 = FUN_6012536c(iVar18);
      local_11a = sVar7 + (short)((uint)(iVar20 * iVar21) >> 0xf);
      iVar21 = FUN_6014f950(&local_120,&local_120,uVar15);
      if (iVar21 != 0) {
        *(short **)(param_1 + 8) = &local_120;
        DispatchRectangleFill(param_1,&local_5c,&local_64);
      }
      if (0x59 < (uVar22 & 0xffff)) goto LAB_6002b984;
LAB_6002b8ee:
      sVar9 = *param_3;
      local_120 = sVar9 - sVar5;
      local_11a = param_3[1] + -1;
      iVar21 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
      sVar7 = param_3[1];
      local_11c = sVar9 + (short)((uint)(iVar20 * iVar21) >> 0xf);
      iVar20 = FUN_6012536c(iVar13);
      local_11e = sVar7 + (short)((uint)(sVar5 * iVar20) >> 0xf);
    }
LAB_6002b96e:
    iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
    if (iVar20 != 0) {
      *(short **)(param_1 + 8) = &local_120;
      DispatchRectangleFill(param_1,&local_5c,&local_64);
    }
  }
  else {
    if ((uVar22 & 0xffff) < 0x5a) {
      iVar20 = (int)sVar5 - (int)sVar10;
      goto LAB_6002b8ee;
    }
    if ((uVar12 < param_5) && (uVar16 == uVar17)) {
LAB_6002b946:
      local_120 = *param_3 - sVar5;
      local_11c = *param_3 + -1;
      local_11a = param_3[1] + -1;
      local_11e = param_3[1] - sVar5;
      goto LAB_6002b96e;
    }
    if (uVar16 == 1) {
      if ((uVar17 == 3) || (uVar17 == 0)) goto LAB_6002b946;
    }
    else if ((uVar16 == 0) && ((param_6 - 0x10e & 0xffff) < 0x5a)) goto LAB_6002b946;
  }
LAB_6002b984:
  *(undefined4 *)(param_1 + 8) = uVar15;
  param_6 = param_6 - 0x10e;
  if (uVar16 == 3) {
    sVar9 = *param_3;
    if ((param_5 < uVar12) && ((param_6 & 0xffff) < 0x5a)) {
      iVar20 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
      sVar2 = param_3[1];
      local_120 = sVar9 + (short)((uint)(((int)sVar5 - (int)sVar10) * iVar20) >> 0xf);
      sVar9 = FUN_6012536c(iVar18);
      local_11e = sVar2 + (short)((uint)((int)sVar9 * (int)sVar5) >> 0xf);
      sVar2 = *param_3;
      sVar9 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
      sVar3 = param_3[1];
      local_11c = sVar2 + (short)((uint)((int)sVar9 * (int)sVar5) >> 0xf);
      iVar20 = FUN_6012536c(iVar13);
      uVar12 = ((int)sVar5 - (int)sVar10) * iVar20;
    }
    else {
      local_11c = sVar9 + sVar5;
      local_11a = param_3[1] + -1;
      iVar20 = (int)sVar5 - (int)sVar10;
      iVar21 = FUN_6012536c((int)(short)(sVar2 + 0x5a));
      sVar2 = param_3[1];
      local_120 = sVar9 + (short)((uint)(iVar20 * iVar21) >> 0xf);
      sVar10 = FUN_6012536c(iVar18);
      local_11e = sVar2 + (short)((uint)((int)sVar10 * (int)sVar5) >> 0xf);
      iVar21 = FUN_6014f950(&local_120,&local_120,uVar15);
      if (iVar21 != 0) {
        *(short **)(param_1 + 8) = &local_120;
        DispatchRectangleFill(param_1,&local_5c,&local_64);
      }
      if (0x59 < (param_6 & 0xffff)) goto LAB_6002bb2a;
LAB_6002ba92:
      sVar2 = *param_3;
      local_11e = param_3[1] - sVar5;
      local_120 = sVar2;
      iVar21 = FUN_6012536c((int)(short)(sVar3 + 0x5a));
      local_11c = sVar2 + (short)((uint)(sVar5 * iVar21) >> 0xf);
      sVar3 = param_3[1];
      iVar21 = FUN_6012536c(iVar13);
      uVar12 = iVar20 * iVar21;
    }
    local_11a = sVar3 + (short)(uVar12 >> 0xf);
    iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
LAB_6002bb1a:
    if (iVar20 != 0) {
      *(short **)(param_1 + 8) = &local_120;
      DispatchRectangleFill(param_1,&local_5c,&local_64);
    }
  }
  else {
    if ((param_6 & 0xffff) < 0x5a) {
      iVar20 = (int)sVar5 - (int)sVar10;
      goto LAB_6002ba92;
    }
    if ((uVar12 < param_5) && (uVar16 == uVar17)) {
LAB_6002baee:
      local_120 = *param_3;
      local_11a = param_3[1] + -1;
      local_11c = local_120 + sVar5;
      local_11e = param_3[1] - sVar5;
      iVar20 = FUN_6014f950(&local_120,&local_120,uVar15);
      goto LAB_6002bb1a;
    }
    if (uVar16 == 1) {
      if (uVar12 < 0x5a) goto LAB_6002baee;
    }
    else if ((uVar16 == 2) && (uVar12 < 0xb4)) goto LAB_6002baee;
  }
LAB_6002bb2a:
  *(undefined4 *)(param_1 + 8) = uVar15;
LAB_6002bb38:
  FUN_6015a4aa(auStack_108);
  FUN_6015a4aa(auStack_9c);
  if (bVar4) {
    FUN_6015a4aa(auStack_84);
  }
  FUN_6015a4e0(uVar14);
  FUN_6015a4e0(uVar11);
  if (sVar6 != -1) {
    FUN_6015a4e0((int)sVar6);
  }
  if ((int)((uint)*(byte *)((int)param_2 + 0xd) << 0x1d) < 0) {
    FUN_6003a43c(iVar18,(int)sVar5,uVar19 & 0xff,&local_128);
    local_128 = local_128 + *param_3;
    local_124 = *param_3 + local_124;
    local_126 = local_126 + param_3[1];
    local_122 = param_3[1] + local_122;
    iVar18 = FUN_6014f950(auStack_130,uVar15,&local_128);
    if (iVar18 != 0) {
      FUN_6015a530(&local_120,&local_128,0x7fff,0);
      uVar11 = FUN_6015a500(&local_120,0);
      *(undefined1 **)(param_1 + 8) = auStack_130;
      DispatchRectangleFill(param_1,&local_5c,&local_64);
      FUN_6015a4e0(uVar11);
      FUN_6015a4aa(&local_120);
    }
    FUN_6003a43c(iVar13,(int)sVar5,uVar19 & 0xff,&local_128);
    local_128 = local_128 + *param_3;
    local_124 = *param_3 + local_124;
    local_126 = local_126 + param_3[1];
    local_122 = param_3[1] + local_122;
    iVar13 = FUN_6014f950(auStack_130,uVar15,&local_128);
    if (iVar13 != 0) {
      FUN_6015a530(&local_120,&local_128,0x7fff,0);
      uVar11 = FUN_6015a500(&local_120,0);
      *(undefined1 **)(param_1 + 8) = auStack_130;
      DispatchRectangleFill(param_1,&local_5c,&local_64);
      FUN_6015a4e0(uVar11);
      FUN_6015a4aa(&local_120);
    }
    *(undefined4 *)(param_1 + 8) = uVar15;
  }
  return;
}
