
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d8e4(void)

{
  ushort uVar1;
  short *psVar2;
  int iVar3;
  int iVar4;
  undefined4 *in_r3;
  uint uVar5;
  undefined4 *local_20;
  
  local_20 = in_r3;
  psVar2 = (short *)FUN_60163b40();
  iVar3 = FUN_60161d80(10,2);
  uRam20053034 = uRam2004c628._1_1_ == '\x06';
  DAT_20052faa = FUN_601516c0();
  uRam20052fab = FUN_60156cfc();
  FUN_60011d78(psVar2);
  FUN_60010de4(&DAT_20052fa8,psVar2);
  iVar4 = FUN_601671f0();
  uVar5 = 0;
  local_20 = (undefined4 *)0x0;
  FUN_60166e0c(0x40000008,&local_20);
  _DAT_20052fac = _DAT_200555fc;
  uRam20052fb0 = uRam20055600;
  _DAT_20052fb4 = _DAT_2004c60c;
  uRam20052fc0 = _DAT_2004bc08;
  uRam20052fc2 = uRam2004bc44;
  uRam20053037 = uRam2004bc0b;
  uRam20052fb8 = (undefined4)((ulonglong)uRam2004c640 * 100);
  uRam20053050 = *local_20;
  bRam20053036 = bRam2004bc0c & 1;
  iRam20052fbc = iRam2004c644 * 100 + (int)((ulonglong)uRam2004c640 * 100 >> 0x20);
  bRam2005303b = (byte)(((uint)DAT_2004c73c << 0x1d) >> 0x1f);
  if (0x76b < _DAT_20055618) {
    uVar5 = _DAT_20055618 + 0x94U & 0xff;
  }
  cRam20053038 = (char)uVar5 - bRam2004bc0a;
  if (uVar5 < bRam2004bc0a) {
    cRam20053038 = '\x18';
  }
  sRam20052fc4 = *psVar2;
  if ((iVar3 != 0) && (psVar2[0x217] != 0)) {
    sRam20052fc4 = psVar2[0x217];
  }
  sRam20052fca = psVar2[8];
  uRam20052fc8 = uRam2004bc74;
  cRam20052fc9 = DAT_2004bc72;
  uRam20052fc6 = _DAT_2004bc70 & 0x7fff;
  iVar3 = iVar4 * 0x14;
  uRam20052fd0 = *(undefined4 *)(iVar3 + 0x20050160);
  uRam20052fcc = *(undefined4 *)(iVar3 + 0x2005016c);
  uRam20052fd8 = *(undefined1 *)(iVar3 + 0x20050168);
  bRam2005303a = *(byte *)(iVar3 + 0x20050170) >> 7;
  uRam20052fd4 = *(undefined4 *)(iVar3 + 0x20050164);
  bRam20053039 = (byte)(((uint)*(byte *)(iVar3 + 0x20050170) << 0x19) >> 0x1f);
  iVar3 = iVar4 * 0x38;
  uRam20052fe8 = *(undefined4 *)(iVar3 + 0x20050228);
  uRam20052ff0 = *(undefined4 *)(iVar3 + 0x2005022c);
  uRam20052fec = *(undefined4 *)(iVar3 + 0x20050230);
  uRam20052fdc = *(undefined4 *)(iVar3 + 0x20050234);
  uRam20052fe0 = *(undefined4 *)(iVar3 + 0x20050238);
  uRam20052fe4 = *(undefined4 *)(iVar3 + 0x2005023c);
  uRam20053002 = *(undefined4 *)(iVar3 + 0x20050258);
  uVar1 = *(ushort *)(iVar3 + 0x2005025c);
  uRam20053006 = (uRam20053006 & 0xfc00) + (uVar1 & 1) + (uVar1 & 2) + (uVar1 & 0x40) + (uVar1 & 4)
                 + (uVar1 & 8) + (uVar1 & 0x10) | uVar1 & 0x20 | uVar1 & 0x200 | uVar1 & 0x80 |
                 uVar1 & 0x100;
  uRam20052ffa = *(undefined4 *)(iVar3 + 0x2005024c);
  uRam20052ff4 = *(undefined2 *)(iVar3 + 0x20050240);
  uRam20052ff6 = *(undefined2 *)(iVar3 + 0x20050242);
  uRam20052ffe = (undefined2)*(undefined4 *)(iVar3 + 0x20050250);
  uRam20052ff8 = (undefined2)*(undefined4 *)(iVar3 + 0x20050244);
  uRam20053000 = *(undefined2 *)(iVar3 + 0x20050254);
  if (DAT_2004bc72 != *(char *)(bRam2004bcac + 0x2004bc99)) {
    DAT_2004bc72 = *(char *)(bRam2004bcac + 0x2004bc99);
  }
  bRam20053019 = bRam2004bcac;
  uRam2005300c = 0x2004bc8a;
  uRam20053010 = 0x2004bc9a;
  uRam20053014 = 0x2004bca2;
  uRam20053018 = uRam2004bcab;
  uRam2005301a = uRam2004bcad;
  FUN_600153ac(&DAT_2004bb98);
  uRam2005301c = uRam2004c624;
  uRam20053020 = _uRam2004c628;
  uRam20053024 = uRam2004c62c;
  uRam20053028 = uRam2004c630;
  uRam2005302c = uRam2004c634;
  uRam20053030 = uRam2004c638;
  uRam20053035 = *(undefined1 *)((short)iVar4 * 0x2c + 0x2004c747);
  return;
}
