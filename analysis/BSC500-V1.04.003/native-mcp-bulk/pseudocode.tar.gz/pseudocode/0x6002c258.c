
void FUN_6002c258(undefined4 param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_601608ac(param_2,0x54,param_3,param_4,param_4);
  *(undefined4 *)(param_2 + 0x50) = 0x6003b3c5;
  *(undefined **)(param_2 + 0xc) = &UNK_6002d731;
  *(undefined **)(param_2 + 0x44) = &UNK_6002c4ad;
  *(undefined4 *)(param_2 + 0x10) = 0x6002b291;
  *(undefined **)(param_2 + 0x40) = &UNK_6002c333;
  *(undefined **)(param_2 + 0x3c) = &UNK_6002c2e5;
  *(undefined **)(param_2 + 0x1c) = &UNK_6002c4b5;
  *(undefined **)(param_2 + 0x20) = &UNK_6002cc91;
  *(undefined **)(param_2 + 0x24) = &UNK_6002d46d;
  *(undefined4 *)(param_2 + 0x28) = 0x6002e561;
  *(undefined **)(param_2 + 0x2c) = &UNK_6002bd29;
  *(undefined4 *)(param_2 + 0x30) = 0x6003c16d;
  *(undefined **)(param_2 + 0x34) = &UNK_6002bd43;
  *(undefined4 *)(param_2 + 0x38) = 0x6002c3c5;
  *(undefined **)(param_2 + 0x14) = &UNK_6002bdad;
  *(undefined4 *)(param_2 + 0x48) = 0x2c;
  return;
}
