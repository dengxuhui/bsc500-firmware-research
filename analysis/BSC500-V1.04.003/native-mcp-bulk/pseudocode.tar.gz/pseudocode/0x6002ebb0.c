
void FUN_6002ebb0(int param_1,uint *param_2,uint param_3,undefined4 param_4)

{
  uint *puVar1;
  code *UNRECOVERED_JUMPTABLE;
  uint *puVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  uint *puVar6;
  uint uVar7;
  
  if (param_2 == (uint *)0x0) {
    FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_slab.c",0xcf,
                 "lv_page_free","Asserted at expression: %s","addr != NULL");
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&DAT_60434315,"lv_page_free",0xcf);
  }
  if (((uint)param_2 & 0xfff) != 0) {
    FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_slab.c",0xd0,
                 "lv_page_free","Asserted at expression: %s","(uint32_t)addr % LV_MM_PAGE_SIZE == 0"
                );
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&DAT_60434315,"lv_page_free",0xd0);
  }
  if (param_3 == 0) {
    FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_slab.c",0xd1,
                 "lv_page_free","Asserted at expression: %s","npages != 0");
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&DAT_60434315,"lv_page_free",0xd1);
  }
  puVar6 = param_2;
  uVar7 = param_3;
  if (*(code **)(param_1 + 0x144) != (code *)0x0) {
    (**(code **)(param_1 + 0x144))();
  }
  puVar3 = param_2 + param_3 * 0x400;
  puVar1 = (uint *)(param_1 + 0x140);
  while (puVar2 = puVar1, puVar1 = (uint *)*puVar2, puVar1 != (uint *)0x0) {
    uVar5 = puVar1[1];
    if (uVar5 == 0) {
      FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_slab.c",0xda,
                   "lv_page_free","Asserted at expression: %s","b->page > 0");
                    /* WARNING: Subroutine does not return */
      FUN_6016804c(&DAT_60434315,"lv_page_free",0xda);
    }
    if ((puVar1 <= param_2) && (param_2 < puVar1 + uVar5 * 0x400)) {
      FUN_6015e5e0(3,"./../../../../qwos/module/touchx/lv_engine/src/misc/lv_slab.c",0xdb,
                   "lv_page_free","Asserted at expression: %s","b > n || b + b->page <= n");
                    /* WARNING: Subroutine does not return */
      FUN_6016804c(&DAT_60434315,"lv_page_free",0xdb);
    }
    if (puVar1 + uVar5 * 0x400 == param_2) {
      uVar5 = uVar5 + param_3;
      puVar1[1] = uVar5;
      if (puVar1 + uVar5 * 0x400 == (uint *)*puVar1) {
        uVar4 = (puVar1 + uVar5 * 0x400)[1];
        *puVar1 = *(uint *)*puVar1;
        puVar1[1] = uVar5 + uVar4;
      }
      goto LAB_6002ec20;
    }
    if (puVar1 == puVar3) {
      *param_2 = *puVar3;
      param_2[1] = uVar5 + param_3;
      goto LAB_6002ec1e;
    }
    if (puVar3 <= puVar1) break;
  }
  *param_2 = (uint)puVar1;
  param_2[1] = param_3;
LAB_6002ec1e:
  *puVar2 = (uint)param_2;
LAB_6002ec20:
  UNRECOVERED_JUMPTABLE = *(code **)(param_1 + 0x148);
  if (UNRECOVERED_JUMPTABLE == (code *)0x0) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x6002ec2a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(UNRECOVERED_JUMPTABLE,puVar6,uVar7,param_4);
  return;
}
