
undefined8 FUN_600239c0(int param_1,undefined4 *param_2)

{
  undefined4 local_18;
  undefined4 uStack_14;
  undefined4 local_10;
  undefined4 uStack_c;
  
  local_10 = 0;
  uStack_c = 0;
  local_18 = 0;
  uStack_14 = 0;
  FUN_600239e8(param_1 + 0xd78,&LAB_60032a22_1,&local_18);
  if (param_2 != (undefined4 *)0x0) {
    *param_2 = local_10;
  }
  return CONCAT44(uStack_14,local_18);
}
