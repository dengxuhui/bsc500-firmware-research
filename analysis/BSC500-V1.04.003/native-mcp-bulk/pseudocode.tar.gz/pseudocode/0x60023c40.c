
undefined4 FUN_60023c40(void)

{
  if (DAT_20052fa8 == '\x03') {
    FUN_60167010(4);
    return 0;
  }
  return 0xffffffff;
}
