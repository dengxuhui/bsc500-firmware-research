
void FUN_60021ee4(void)

{
  if (iRam2000b034 != 0) {
    FUN_601667bc();
    iRam2000b034 = 0;
    FUN_60163bbe(0x2008ae28);
    return;
  }
  return;
}
