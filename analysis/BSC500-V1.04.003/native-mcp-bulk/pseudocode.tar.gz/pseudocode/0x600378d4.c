
undefined8 FUN_600378d4(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined1 *puVar2;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  uStack_20 = param_1;
  uStack_1c = param_2;
  uStack_18 = param_3;
  uStack_14 = param_4;
  iVar1 = FUN_6004381a(&uStack_20);
  if (iVar1 != 0) {
    FUN_600436dc(&uStack_20,iVar1,0);
  }
  iVar1 = FUN_600437f4(&uStack_20);
  if (iVar1 != 0) {
    puVar2 = (undefined1 *)thunk_FUN_60162e34(0x14);
    if (puVar2 == (undefined1 *)0x0) {
      FUN_60167f3c(3,&UNK_603ea2a2,1,"Public address generate failed!");
    }
    else {
      *(undefined2 *)(puVar2 + 2) = 0x10ae;
      CopyBytes(puVar2 + 4,&uStack_20,0x10);
      puVar2[1] = (char)iVar1;
      *puVar2 = 0;
      FUN_6015b944(puVar2);
      thunk_FUN_60166c0c(puVar2);
    }
  }
  FUN_60125b4c();
  return CONCAT44(uStack_1c,uStack_20);
}
