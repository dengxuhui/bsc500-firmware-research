
void FUN_60012008(void)

{
  bool bVar1;
  byte bVar2;
  uint uVar3;
  int iVar4;
  byte bVar5;
  byte bVar6;
  uint uVar7;
  uint uVar8;
  uint extraout_r3;
  uint uVar9;
  int iVar10;
  uint uVar11;
  byte bVar12;
  uint unaff_r7;
  uint unaff_r8;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  uint unaff_r11;
  uint extraout_r12;
  uint uVar16;
  bool bVar17;
  uint in_fpscr;
  float fVar18;
  float fVar19;
  undefined8 uVar20;
  undefined8 uVar21;
  uint local_798;
  uint local_794;
  uint local_790 [408];
  byte local_130 [256];
  
  FUN_6013496a();
  uRam500420f4 = uRam500420f4 & 0xfffffffc;
  uRam50042008 = uRam50042008 | 0xf00;
  uRam50042004 = uRam50042004 & 0xffffff0f | 0x801070;
  uRam50042018 = uRam50042018 | 0x4000;
  uRam500440a0 = uRam500440a0 & 0xf03fffff | 0x1c00000;
  uRam50042000 = uRam50042000 & 0xffc07fff | 0x8200001;
  thunk_EXT_FUN_00020458(4);
  uVar3 = 1;
  uVar7 = 0x40;
  local_790[0x118] = extraout_r3;
  while ((uVar3 != 7 && (local_790[0x118] = uRam50042004 << 0x1e, (int)local_790[0x118] < 0))) {
    if ((uRam50042004 & 1) == 0) {
      uVar7 = uVar7 - (0x40U >> (uVar3 & 0xff));
    }
    else if ((uRam50042004 & 1) != 0) {
      uVar7 = uVar7 + (0x40U >> (uVar3 & 0xff));
    }
    uVar3 = uVar3 + 1;
    local_790[0x118] = uRam50042000 & 0xffc07fff | (uVar7 & 0xff) << 0xf;
    uRam50042000 = local_790[0x118];
  }
  uVar15 = 0xffffffff;
  uVar11 = 0x80;
  uVar7 = uRam50042010 & 0xffff;
  uRam50042010 = uVar7 | 0x1e000000;
  uRam500440a4 = uRam500440a4 & 0xfffff800 | 0x10;
  uRam500440a0 = uRam500440a0 & 0xf01fffff | 0x1c00000;
  uRam5004200c = uRam5004200c & 0xffffffbd | 0x802;
  uRam50042008 = uRam50042008 | 0x11000;
  uRam50042014 = uRam50042014 | 0x80000;
  uRam50042000 = uRam50042000 & 0xffc0007f | 1;
  local_794 = 0xffffffff;
  uVar3 = extraout_r12;
  for (uVar8 = 1; uVar8 != 9; uVar8 = uVar8 + 1) {
    uVar13 = 0x40;
    uRam50042000 = uRam50042000 & 0xffc07fff;
    uVar9 = 1;
    while ((uVar9 != 7 && ((int)(uRam50042004 << 0x1e) < 0))) {
      if ((uRam50042004 & 1) == 0) {
        uVar13 = uVar13 - (0x40U >> (uVar9 & 0xff));
      }
      else if ((uRam50042004 & 1) != 0) {
        uVar13 = uVar13 + (0x40U >> (uVar9 & 0xff));
      }
      uVar9 = uVar9 + 1;
      uRam50042000 = uRam50042000 & 0xffc07fff | (uVar13 & 0xff) << 0xf;
    }
    do {
    } while ((uRam5004200c & 1) == 0);
    if (uVar7 < 0x8449) {
      local_794 = 0x8448 - uVar7;
      uVar9 = -(0x80U >> (uVar8 & 0xff));
      unaff_r11 = uVar11;
      uVar3 = uVar7;
      local_798 = uVar13;
    }
    else {
      uVar15 = uVar7 - 0x8448;
      uVar9 = 0x80 >> (uVar8 & 0xff);
      local_790[0x118] = uVar7;
      unaff_r7 = uVar11;
      unaff_r8 = uVar13;
    }
    uVar11 = uVar9 + uVar11;
    uRam5004200c = uRam5004200c & 0xfffffffb;
  }
  local_130[0] = (byte)unaff_r7;
  local_130[0x80] = (byte)unaff_r8;
  if (local_794 < uVar15) {
    local_130[0] = (byte)unaff_r11;
    local_130[0x80] = (byte)local_798;
    local_790[0x118] = uVar3;
    unaff_r8 = local_798;
    unaff_r7 = unaff_r11;
  }
  uVar7 = 0;
  uRam5004200c = uRam5004200c & 0xfffffffb;
  uVar3 = 0;
  iRam50042050 = 0;
  uRam50042004 = uRam50042004 & 0xffffefff | 0x800000;
  do {
    bVar12 = 0;
    unaff_r7 = unaff_r7 + 1;
    iRam50042050 = iRam50042050 + 1;
    iRam5004204c = 0;
    uRam50042000 = uRam50042000 & 0xffff807f | (unaff_r7 & 0xff) << 7;
    uRam50042004 = uRam50042004 | 0x1000;
    uRam50042018 = uRam50042018 | 0x4000;
    uVar7 = (uVar7 & 0xff) + 1;
    bVar2 = 0;
    bVar1 = false;
    bVar6 = 0;
    while( true ) {
      bVar5 = bVar6;
      bVar17 = 2 < bVar5;
      if (bVar5 < 4) {
        bVar17 = 1 < bVar2;
        bVar12 = bVar2;
      }
      if (bVar17) break;
      uVar11 = (unaff_r8 & 0xff) << 0xf;
      iRam5004204c = iRam5004204c + 1;
      uRam50042000 = uRam50042000 & 0xffc07fff | uVar11;
      thunk_EXT_FUN_00020458(4);
      if (-1 < (int)(uRam50042004 << 0x1e)) goto LAB_600123be;
      uVar11 = uRam50042004 & 1;
      if (uVar11 == 0) {
        if ((unaff_r8 & 0xff) == 0) {
          bVar2 = bVar12 + 1;
          unaff_r8 = 0;
        }
        else {
          unaff_r8 = unaff_r8 - 1;
          bVar2 = 0;
        }
      }
      else if ((unaff_r8 & 0xff) < 0x3f) {
        unaff_r8 = unaff_r8 + 1;
        bVar2 = 0;
      }
      else {
        bVar2 = bVar12 + 1;
        unaff_r8 = 0x3f;
      }
      bVar6 = 0;
      if (uVar3 != uVar11) {
        bVar6 = bVar5 + 1;
      }
      bVar17 = !bVar1;
      uVar3 = uVar11;
      bVar1 = true;
      if (bVar17) {
        bVar6 = bVar5;
      }
    }
    uVar11 = (unaff_r8 & 0xff) << 0xf;
LAB_600123be:
    uRam50042004 = uRam50042004 & 0xffffefff;
    uRam50042000 = uRam50042000 & 0xffc07fff | uVar11;
    thunk_EXT_FUN_00020458(4);
    uRam5004200c = uRam5004200c & 0xfffffffd | 6;
    thunk_EXT_FUN_00020458(200);
    do {
    } while ((uRam5004200c & 1) == 0);
    if ((uRam50042010 & 0xffff) < 0x7611) {
      uVar3 = (uint)local_130[0];
      uVar11 = (uint)local_130[0x80];
      for (iVar4 = 0; iVar4 != 0x28; iVar4 = iVar4 + 1) {
        uVar9 = 0;
        uVar8 = 0;
        iRam5004204c = 100;
        uVar15 = 0;
        for (bVar12 = 0; uVar13 = (uint)bVar12, uVar13 < (uVar7 & 0xff); bVar12 = bVar12 + 1) {
          uVar16 = *(uint *)(&UNK_603e0860 + iVar4 * 4);
          iRam5004204c = iRam5004204c + 1;
          uVar14 = local_790[uVar13 + 0x118];
          if (bVar12 == 0) {
            if (uVar14 < uVar16) {
              uVar15 = uVar16 - uVar14;
              uVar9 = *(int *)(&UNK_603e0720 + iVar4 * 4) - uVar14;
              uVar8 = uVar14;
              uVar14 = *(uint *)(&UNK_603e07c0 + iVar4 * 4);
            }
            else {
              uVar8 = *(uint *)(&UNK_603e07c0 + iVar4 * 4);
              uVar15 = uVar14 - uVar16;
              uVar9 = uVar14 - *(int *)(&UNK_603e0720 + iVar4 * 4);
            }
            uVar8 = uVar14 - uVar8;
            local_790[iVar4 + 0xa0] = uVar11;
            local_790[iVar4 + 0xf0] = uVar11;
            local_790[iVar4 + 200] = uVar11;
            local_790[iVar4 + 0x78] = uVar3;
            local_790[iVar4 + 0x28] = uVar3;
            local_790[iVar4 + 0x50] = uVar3;
          }
          else {
            if (uVar14 < uVar16) {
              uVar16 = uVar16 - uVar14;
            }
            else {
              uVar16 = uVar14 - uVar16;
            }
            if (uVar16 < uVar15) {
              local_790[iVar4 + 0xf0] = (uint)local_130[uVar13 + 0x80];
              local_790[iVar4 + 0x78] = (uint)local_130[uVar13];
              uVar15 = uVar16;
            }
            iVar10 = *(int *)(&UNK_603e0720 + iVar4 * 4);
            if (iVar10 - uVar14 < uVar9) {
              local_790[iVar4 + 0xa0] = (uint)local_130[uVar13 + 0x80];
              local_790[iVar4 + 0x28] = (uint)local_130[uVar13];
              uVar9 = iVar10 - uVar14;
            }
            iVar10 = *(int *)(&UNK_603e07c0 + iVar4 * 4);
            if (iVar10 - uVar14 < uVar8) {
              local_790[iVar4 + 200] = (uint)local_130[uVar13 + 0x80];
              local_790[iVar4 + 0x50] = (uint)local_130[uVar13];
              uVar8 = iVar10 - uVar14;
            }
          }
        }
      }
      iRam50042050 = 100;
      uRam50042004 = uRam50042004 & 0xff7fffff | 0x800000;
      uRam50042010 = uRam50042010 & 0xffff | 0x43800000;
      uRam500440a4 = uRam500440a4 & 0xfffff800 | 0x10;
      uRam50042000 = (uRam50042000 & 0xffff807f | local_790[0x81] << 7) & 0xffc07fff |
                     local_790[0xf9] << 0xf;
      uRam500440a0 = uRam500440a0 & 0xf01fffff;
      thunk_EXT_FUN_00020458(0x14);
      uVar3 = uRam50042010;
      do {
      } while ((uRam5004200c & 1) == 0);
      uRam500440a0 = uRam500440a0 & 0xf03fffff | 0xfc00000;
      uRam5004200c = uRam5004200c & 0xfffffffb;
      thunk_EXT_FUN_00020458(0x14);
      do {
      } while ((uRam5004200c & 1) == 0);
      uRam5004200c = uRam5004200c & 0xfffffffb;
      uRam50042004 = uRam50042004 & 0xff7fffff;
      uVar20 = FUN_6016759c(0x6c000 / ((uRam50042010 & 0xffff) - (uVar3 & 0xffff)));
      for (iVar4 = 0; iVar4 != 0x14; iVar4 = iVar4 + 1) {
        iRam50042050 = iRam50042050 + 1;
        fVar18 = (float)VectorSignedToFloat(*(int *)(&UNK_603e0860 + iVar4 * 4) * 3 + -0x16e63,
                                            (byte)(in_fpscr >> 0x16) & 3);
        uVar21 = FUN_60166bb4(fVar18 * -1.0330578e-05);
        uVar21 = FUN_601682c8((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),0,0x3ff00000);
        FUN_601678fc((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),(int)uVar20,
                     (int)((ulonglong)uVar20 >> 0x20));
        uVar3 = FUN_6015e530();
        local_790[iVar4] = uVar3;
      }
      iRam50042050 = 1000;
      uRam50042004 = uRam50042004 | 0x800000;
      uRam50042010 = uRam50042010 & 0xffff | 0x43800000;
      uRam500440a4 = uRam500440a4 & 0xfffff800 | 0x10;
      uRam50042000 = (uRam50042000 & 0xffff807f | local_790[0x95] << 7) & 0xffc07fff |
                     local_790[0x10d] << 0xf;
      uRam500440a0 = uRam500440a0 & 0xf01fffff;
      thunk_EXT_FUN_00020458(0x14);
      uVar3 = uRam50042010;
      do {
      } while ((uRam5004200c & 1) == 0);
      uRam5004200c = uRam5004200c & 0xfffffffb;
      uRam500440a0 = uRam500440a0 & 0xf03fffff | 0xfc00000;
      thunk_EXT_FUN_00020458(0x14);
      do {
      } while ((uRam5004200c & 1) == 0);
      uRam5004200c = uRam5004200c & 0xfffffffb;
      iVar4 = 0;
      fVar18 = (float)VectorSignedToFloat(0x6c000 / ((uRam50042010 & 0xffff) - (uVar3 & 0xffff)),
                                          (byte)(in_fpscr >> 0x16) & 3);
      for (; iVar4 != 0x14; iVar4 = iVar4 + 1) {
        iRam50042050 = iRam50042050 + 1;
        fVar19 = (float)VectorSignedToFloat(*(int *)(&UNK_603e08b0 + iVar4 * 4) * 3 + -0x18123,
                                            (byte)(in_fpscr >> 0x16) & 3);
        uVar3 = VectorFloatToUnsigned((fVar19 * -1.0162602e-05 + 1.0) * fVar18,3);
        local_790[iVar4 + 0x14] = uVar3;
      }
      uRam50042014 = uRam50042014 & 0xfff7ffff;
      for (iVar4 = 0; iVar4 != 0xa0; iVar4 = iVar4 + 4) {
        *(int *)(iVar4 + 0x50042054) =
             *(int *)((int)local_790 + iVar4 + 0x3c0) * 0x100 +
             *(int *)((int)local_790 + iVar4) * 0x10000 + *(int *)((int)local_790 + iVar4 + 0x1e0);
        *(int *)(iVar4 + 0x500422a0) =
             *(int *)((int)local_790 + iVar4 + 800) * 0x1000000 +
             *(int *)((int)local_790 + iVar4 + 0x140) * 0x10000 +
             *(int *)((int)local_790 + iVar4 + 0xa0) +
             *(int *)((int)local_790 + iVar4 + 0x280) * 0x100;
      }
      uRam50042008 = uRam50042008 | 0x10;
      uRam50042024 = uRam50042024 & 0xffe1ffff | 0x5d8000;
      uRam50042028 = uRam50042028 | 0x3f800;
      uRam50042104 = uRam50042104 | 0x300;
      (*(code *)0x20459)(0x14);
      uRam50042024 = uRam50042024 & 0xfffffdff;
      (*(code *)0x20459)(2);
      uRam50042024 = uRam50042024 | 0x200;
      (*(code *)0x20459)(0x14);
      do {
      } while (-1 < (int)((uRam50042104 & 0xfffffffe | 1) << 0x1e));
      uVar3 = uRam50042104 & 0x78;
      uVar7 = uRam50042104 & 4;
      uRam50042104 = uRam50042104 & 0xfffffdfe;
      uRam500420f4 = uRam500420f4 | 3;
      uRam50042018 = uRam50042018 & 0xffffbfff;
      uRam50042004 = uRam50042004 & 0xff7fffff;
      uRam500440a4 = uRam500440a4 | 1;
      uRam50042024 = uRam50042024 & 0xffbf03ff | uVar3 << 7 | uVar7 << 0xc | 1;
      uRam50042028 = uRam50042028 | 0x400;
      uRam50042044 = uRam50042044 | 0x400;
      uRam50042000 = uRam50042000 & 0xf7fffffe;
      uRam5004200c = uRam5004200c & 0xfffff7ff | 2;
      uVar3 = uRam50042100 & 0xfc3fffff;
      do {
      } while (-1 < (int)(uRam50042100 << 0xb));
      uRam50042100 = uRam50042100 & 0xfc1fffff;
      uRam50042040 = uVar3 >> 0x13 & 0xf80 | uRam50042040 & 0xffffe037 | 0x6040 | 0x1000;
      uRam50042030 = uRam50042030 & 0xffffdfff;
      uRam50042034 = uRam50042034 & 0xffff9fff | 0x6000;
      uRam50042008 = uRam50042008 & 0xfffef0ef;
      uRam500440a0 = uRam500440a0 & 0x8fffffff | 0x10200000;
      FUN_6001c044();
      FUN_60156f2c();
      uRam50042044 = uRam50042044 | 0x400;
      uRam5004202c = uRam5004202c & 0xffc3ffff | 0x340000;
      uRam50042038 = uRam50042038 & 0xffffffdf;
      uRam50042008 = uRam50042008 & 0xfd7fffff | 0x800000;
      uRam50044024 = uRam50044024 & 0x80000000 | 0xb008968;
      uRam50044088 = uRam50044088 & 0xff81ffff | 0x1e0000;
      uRam500440ac = uRam500440ac & 0xfffe0000 | 0x1aae1;
      uRam500440b0 = uRam500440b0 & 0xfffe0000 | 0x155c3;
      uRam50044018 = uRam50044018 | 0x900100;
      uRam50044048 = uRam50044048 | 0x8008030;
      uRam5004404c = uRam5004404c | 0x9008000;
      uRam50044010 = 0x800800;
      uRam50044008 = uRam50044008 & 0xf0003fff | 0xc000000;
      uRam50044098 = uRam50044098 & 0xfffc0000 | 0x1feff;
      uRam500440a8 = uRam500440a8 & 0xfffff8ff | 0x600;
      uRam5004401c = uRam5004401c & 0xfff00000 | 0x2a8a6;
      uRam50044014 = uRam50044014 & 0xffffff00 | 0xaa08;
      uRam50042030 = uRam50042030 & 0xfffffffc | 3;
      return;
    }
    uVar11 = uVar7 & 0xff;
    local_130[uVar11] = (byte)unaff_r7;
    local_130[uVar11 + 0x80] = (byte)unaff_r8;
    local_790[uVar11 + 0x118] = uRam50042010 & 0xffff;
  } while( true );
}
