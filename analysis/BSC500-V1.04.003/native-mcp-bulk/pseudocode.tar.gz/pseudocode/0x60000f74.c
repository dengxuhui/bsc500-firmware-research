
void FUN_60000f74(void)

{
  undefined **ppuVar1;
  
  for (ppuVar1 = &PTR_LAB_60250900_1_6043dd90; ppuVar1 < &PTR_LAB_60250908_1_6043dea0;
      ppuVar1 = ppuVar1 + 1) {
    if ((code *)*ppuVar1 != (code *)0x0) {
      (*(code *)*ppuVar1)();
    }
  }
  return;
}
