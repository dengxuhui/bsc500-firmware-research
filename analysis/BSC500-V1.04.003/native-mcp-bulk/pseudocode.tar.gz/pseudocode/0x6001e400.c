
undefined4 FUN_6001e400(int param_1)

{
  ushort uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  uint uVar5;
  ushort *local_1cc;
  undefined1 *local_1c8;
  int local_1c4;
  undefined1 auStack_1c0 [100];
  undefined1 auStack_15c [22];
  char local_146 [258];
  undefined1 auStack_44 [48];
  
  local_1cc = (ushort *)0x0;
  local_1c8 = (undefined1 *)0x0;
  iVar2 = FUN_6013a780(&local_1c8,&local_1cc,0x7e);
  if (iVar2 != 0) {
    return 0;
  }
  uRam20009ec4 = 0;
  if (param_1 == 0) {
    if (cRam20009ebc == '\x01') {
      iVar2 = FUN_6002870c();
    }
    else {
      iVar2 = FUN_6002b14c(local_1c8);
    }
    if (iVar2 != 0) {
      *local_1cc = (ushort)uRam20009ec4;
      FUN_60122c60();
      return 1;
    }
    goto LAB_6001e572;
  }
  ZeroBytes(auStack_1c0,100);
  local_1c4 = 0;
  ZeroBytes(0x20009ed4,0x32);
  FUN_60168578(&UNK_6001e5a8,"log_data_file_size_get",cRam20009ebc);
  if (cRam20009ebc == '\x01') {
    FUN_60167214(0x20009ee2,0x24);
    uRam20009ed4._0_1_ = 'd';
    uRam20009ed4._1_1_ = 'e';
    uRam20009ed4._2_1_ = 'v';
    uRam20009ed4._3_1_ = 'i';
    uRam20009ed8._0_1_ = 'c';
    uRam20009ed8._1_1_ = 'e';
    uRam20009ed8._2_1_ = '_';
    uRam20009ed8._3_1_ = 'l';
    uRam20009edc._0_1_ = 'o';
    uRam20009edc._1_1_ = 'g';
    uRam20009edc._2_1_ = '.';
    uRam20009edc._3_1_ = 't';
    uRam20009ee0._0_1_ = 'x';
    uRam20009ee0._1_1_ = 't';
    uVar4 = 0x20005820;
LAB_6001e466:
    FUN_601681f4(auStack_1c0,"%s/%s",uVar4,0x20009ed4);
    iVar2 = FUN_60166758(&local_1c4,auStack_1c0,1);
    if (iVar2 != 0) goto LAB_6001e4b2;
    uVar5 = *(uint *)(local_1c4 + 0xc);
    FUN_601667bc();
  }
  else {
    uVar4 = 0x20005cae;
    iVar2 = FUN_6015c8a2(auStack_44,0x20005cae);
    if (((iVar2 == 0) && (iVar2 = FUN_6015c834(auStack_44,auStack_15c), iVar2 == 0)) &&
       (local_146[0] != '\0')) {
      uVar3 = FUN_60168220(local_146);
      CopyBytes(0x20009ed4,local_146,uVar3);
      goto LAB_6001e466;
    }
LAB_6001e4b2:
    uVar5 = 0;
  }
  FUN_60168578(&UNK_6001e5d8,uVar5);
  if (uVar5 == 0) {
    if (cRam20009ebc != '\0') {
      FUN_6011f0b8();
      cRam20009ebc = '\0';
LAB_6001e54c:
      FUN_60122c60();
      FUN_6011a29c(0x13,0x55,0,2,0x11,*local_1cc,3,0);
      return 1;
    }
  }
  else {
    if ((cRam20009ebc != '\0') && (iRam20009ec8 = 0, 0x1ffff < uVar5)) {
      iRam20009ec8 = uVar5 - 0x20000;
      uVar5 = 0x20000;
    }
    iVar2 = FUN_6011a208(local_1c8 + 4,0x7fc,uVar5,0,0,0x20009ed4,0,0);
    if (iVar2 != 0) {
      *local_1c8 = 0;
      local_1c8[1] = 0;
      local_1c8[2] = (char)((uint)iVar2 >> 8);
      local_1c8[3] = (char)iVar2;
      uVar1 = (short)iVar2 + 4;
      *local_1cc = uVar1;
      if (cRam20009ebc == '\x01') {
        iVar2 = FUN_6002870c();
      }
      else {
        iVar2 = FUN_6002b14c(local_1c8 + uVar1);
      }
      *local_1cc = (short)uRam20009ec4 + *local_1cc;
      if (iVar2 != 0) goto LAB_6001e54c;
    }
  }
LAB_6001e572:
  FUN_60129ec8(0x13,0,2,0x11);
  return 0;
}
