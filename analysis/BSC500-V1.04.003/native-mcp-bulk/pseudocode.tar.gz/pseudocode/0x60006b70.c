
undefined4
FUN_60006b70(undefined4 *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_8c;
  undefined1 auStack_88 [100];
  undefined4 local_24;
  
  ZeroBytes(auStack_88,100);
  local_8c = 1;
  FUN_6015ad48(0x20005820);
  FUN_6015ad48(0x20005cae);
  FUN_601681f4(auStack_88,"%s/%s_%04d%02d%02d_%02d%02d%02d.txt",0x20005cae,param_2,param_1[5],
               param_1[4],param_1[3],param_1[2],param_1[1],*param_1);
  iVar1 = FUN_60166758(&local_24,auStack_88,0x12);
  if (((iVar1 == 0) && (iVar1 = FUN_60164ed8(local_24,param_3,param_4,&local_8c), iVar1 == 0)) &&
     (iVar1 = FUN_601667bc(local_24), iVar1 == 0)) {
    uVar2 = 0;
  }
  else {
    uVar2 = 0xffffffff;
  }
  return uVar2;
}
