
undefined4 FUN_6001a240(int param_1)

{
  int iVar1;
  
  if (*(char *)(param_1 + 0x55) == '\x01') {
    FUN_60137690(param_1 + 8);
  }
  else if (*(char *)(param_1 + 0x55) == '\x02') {
    FUN_601617d0(param_1);
    FUN_60137690(param_1 + 8);
    if (*(char *)(param_1 + 0x50) != '\0') {
                    /* WARNING: Subroutine does not return */
      thunk_FUN_6016804c("pPager->journalOpen==0","./../../../../qwos/framework/kvdb/fs_kv/pager.c",
                         0x3c6);
    }
  }
  iVar1 = *(int *)(param_1 + 0x6c);
  while (iVar1 != 0) {
    iVar1 = *(int *)(iVar1 + 0x1c);
    FUN_601634dc();
  }
  FUN_60138452(param_1 + 8);
  if (*(char *)(param_1 + 0x50) == '\0') {
    FUN_601634dc(param_1);
    return 0;
  }
                    /* WARNING: Subroutine does not return */
  thunk_FUN_6016804c("pPager->journalOpen==0","./../../../../qwos/framework/kvdb/fs_kv/pager.c",
                     0x3d7);
}
