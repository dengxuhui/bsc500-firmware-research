
void FUN_60035558(code *param_1,uint param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = param_3 - param_2;
  if (param_3 < param_2 || param_3 - param_2 == 0) {
    uVar2 = param_3;
  }
  for (; 0 < (int)uVar2; uVar2 = uVar2 - 0x10) {
    for (iVar1 = 0; iVar1 != 0x10; iVar1 = iVar1 + 1) {
      if (iVar1 < (int)uVar2) {
        (*param_1)(&UNK_600355a0,*(undefined1 *)(param_2 + iVar1));
      }
      if (iVar1 == 7) {
        (*param_1)(&UNK_600355a8);
      }
    }
    (*param_1)(&UNK_600355ac);
    param_2 = param_2 + 0x10;
  }
  return;
}
