
undefined4 FUN_60030b8c(undefined8 *param_1)

{
  int iVar1;
  undefined1 auStack_58 [24];
  undefined8 local_40;
  undefined8 local_38;
  undefined4 local_30;
  undefined4 local_2c;
  undefined8 local_28;
  undefined8 local_20;
  undefined4 local_18;
  undefined4 uStack_14;
  
  if (param_1 == (undefined8 *)0x0) {
    return 0xffffffff;
  }
  local_40 = *param_1;
  local_38 = param_1[1];
  local_18 = *(undefined4 *)(param_1 + 2);
  local_30 = *(undefined4 *)((int)param_1 + 0x14);
  local_2c = *(undefined4 *)(param_1 + 3);
  local_28 = local_40;
  local_20 = local_38;
  uStack_14 = local_30;
  ZeroBytes(auStack_58,0x18);
  FUN_6012e60c(0x200895a0,&local_28);
  FUN_6012e858(0x2000b060,&local_40);
  iVar1 = FUN_6012e6d0(0x2000b070,&local_40,auStack_58);
  if (iVar1 == 0) {
    iVar1 = FUN_601357f0(0x2000b030,auStack_58);
    if (iVar1 != 0) {
      FUN_601667bc(uRam2000b030);
      uRam2000b030 = 0;
      FUN_60163bbe(0x2008ae28);
      return 0xffffffff;
    }
    iRam2000bddc = iRam2000bddc + 1;
    FUN_601354ec(0x2000b090,auStack_58);
  }
  return 0;
}
