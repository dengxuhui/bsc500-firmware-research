
int FUN_600372f8(int param_1,int param_2,undefined2 *param_3,uint *param_4)

{
  int iVar1;
  int local_14;
  
  local_14 = 0;
  if ((param_1 == 0) || (param_4 == (uint *)0x0)) {
    return 0xe;
  }
  if (1 < *param_4) {
    *param_4 = *param_4 - 2;
    *param_3 = 0x54;
    iVar1 = FUN_60152fa4(param_1,param_2,&local_14,param_3 + 2,param_3);
    if (iVar1 != 0) {
      return iVar1;
    }
    if (local_14 == param_2) {
      *param_4 = 2;
      return 0;
    }
  }
  return 9;
}
