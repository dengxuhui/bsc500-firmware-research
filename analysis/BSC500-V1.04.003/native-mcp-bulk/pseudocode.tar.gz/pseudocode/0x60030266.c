
undefined4 FUN_60030266(int *param_1,undefined2 param_2)

{
  undefined4 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  
  if (param_1 == (int *)0x0) {
    uVar1 = 0xffffffff;
  }
  else {
    uVar4 = param_1[2];
    iVar5 = param_1[3];
    uVar2 = param_1[1];
    *(undefined2 *)(*param_1 + iVar5 * 2) = param_2;
    uVar3 = iVar5 + 1;
    if (uVar4 <= uVar3) {
      uVar3 = 0;
    }
    param_1[3] = uVar3;
    if (uVar2 < uVar4) {
      param_1[1] = uVar2 + 1;
    }
    uVar1 = 0;
  }
  return uVar1;
}
