
undefined4 FUN_600339ac(void)

{
  FUN_6004124c("SIGABRT: Abnormal termination",0);
  return 1;
}
