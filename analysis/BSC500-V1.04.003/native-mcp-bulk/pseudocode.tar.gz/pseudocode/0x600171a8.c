
/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_600171a8(int param_1,int param_2,uint *param_3,uint *param_4)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  int iVar12;
  int *piVar13;
  uint uVar14;
  int iVar15;
  uint uVar16;
  int iVar17;
  int iVar18;
  undefined4 uVar19;
  bool bVar20;
  undefined8 uVar21;
  uint local_a8;
  int local_9c;
  uint local_88;
  uint local_78;
  uint local_70;
  undefined4 local_6c;
  undefined4 uStack_68;
  undefined4 local_64;
  int local_60 [4];
  int local_50;
  int local_4c;
  uint local_48;
  uint local_44 [5];
  
  local_64 = 0;
  local_6c = 0;
  uStack_68 = 0;
  if (param_1 == 0 || param_2 == 0) {
    return 0xffffffff;
  }
  if (param_3 == (uint *)0x0) {
    return 0xffffffff;
  }
  if (param_4 == (uint *)0x0) {
    return 0xffffffff;
  }
  iVar2 = FUN_600206c8(param_2);
  if (iVar2 == 0) {
    uVar3 = FUN_601668a4();
    uVar16 = (uint)((uVar3 | 2) != 2);
    iVar2 = uVar16 * 0x10;
    uVar3 = *(uint *)(iVar2 + 0x2008574c);
    if ((uVar3 <= *param_3) && (uVar14 = *(uint *)(iVar2 + 0x20085754), *param_3 <= uVar14)) {
      uVar11 = *(uint *)(iVar2 + 0x20085750);
      if ((uVar11 <= *param_4) && (*param_4 <= *(uint *)(iVar2 + 0x20085758))) {
        for (iVar15 = 0; iVar15 != 4; iVar15 = iVar15 + 1) {
          local_60[iVar15] =
               (param_4[iVar15] - uVar11) * ((uVar14 - uVar3) + 1) + (param_3[iVar15] - uVar3);
        }
        iVar15 = FUN_60166758(0x20085748,0x200855e8,1);
        if (iVar15 == 0) {
          ZeroBytes(0x60d00d7c,0x4000);
          iVar17 = 0;
          iVar15 = uVar16 * 0x18;
          uVar19 = 0;
          piVar4 = (int *)(iVar15 + 0x20085718);
          do {
            if (iVar17 == 4) {
              FUN_601667bc(iRam20085748);
              return uVar19;
            }
            if ((((*(uint *)(iVar2 + 0x2008574c) <= param_3[iVar17]) &&
                 (param_3[iVar17] <= *(uint *)(iVar2 + 0x20085754))) &&
                (*(uint *)(iVar2 + 0x20085750) <= param_4[iVar17])) &&
               (param_4[iVar17] <= *(uint *)(iVar2 + 0x20085758))) {
              iVar12 = *piVar4 + local_60[iVar17] * 5;
              if (cRam20085672 < '\0') {
                iVar12 = iVar12 + 0x10;
              }
              FUN_60163c98(iRam20085748,iVar12);
              uVar19 = FUN_60161ef4(iRam20085748,&uStack_68,5,&local_6c);
              uVar21 = FUN_6012222c(&uStack_68);
              uVar3 = (uint)((ulonglong)uVar21 >> 0x20);
              uVar14 = (uVar3 & 0x7fffffff) >> 0x18;
              uVar16 = (uint)uVar21 >> 0x18 | uVar3 << 8;
              if (uVar14 <= *(uint *)(iVar15 + 0x20085724) &&
                  (uint)(*(uint *)(iVar15 + 0x20085720) <= uVar16) <=
                  uVar14 - *(uint *)(iVar15 + 0x20085724)) {
                uVar19 = FUN_60161ef4(iRam20085748,&uStack_68,5,&local_6c);
                uVar21 = FUN_6012222c(&uStack_68);
                uVar14 = (uint)((ulonglong)uVar21 >> 0x20);
                if (((uint)uVar21 >> 0x18 | uVar14 << 8) != uVar16 ||
                    ((uVar14 ^ uVar3) & 0x7fffffff) >> 0x18 != 0) {
                  FUN_60163c98(iRam20085748,*piVar4 + uVar16);
                  if (0x7fffffff < (uint)(int)cRam20085672) {
                    iVar12 = FUN_6015cbf2(iRam20085748);
                    FUN_60163c98(iRam20085748,iVar12 + 0x20);
                  }
                  uVar19 = FUN_60159a10(param_3[iVar17],*(undefined1 *)(iVar15 + 0x20085710));
                  uVar21 = FUN_60166bb4(uVar19);
                  FUN_601678fc((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),0,0x412e8480);
                  iVar5 = FUN_60167a50();
                  iVar12 = iRam20085898;
                  uVar19 = FUN_60159a60(param_4[iVar17],*(undefined1 *)(iVar15 + 0x20085710));
                  uVar21 = FUN_60166bb4(uVar19);
                  FUN_601678fc((int)uVar21,(int)((ulonglong)uVar21 >> 0x20),0,0x412e8480);
                  iVar6 = FUN_60167a50();
                  iVar6 = iVar6 - iRam20085894;
                  FUN_6001ee88(param_1,iVar5 - iVar12,iVar6,0x200855e8);
                  FUN_60163c98(iRam20085748,uVar16 + *piVar4);
                  if (0x7fffffff < (uint)(int)cRam20085672) {
                    iVar7 = FUN_6015cbf2(iRam20085748);
                    FUN_60163c98(iRam20085748,iVar7 + 0x20);
                  }
                  iVar7 = iRam20085748;
                  local_44[3] = 0;
                  local_44[4] = 0;
                  local_44[1] = 0;
                  local_44[2] = 0;
                  local_48 = 0;
                  local_44[0] = 0;
                  local_50 = 0;
                  local_4c = 0;
                  if (iRam20085748 != 0) {
                    local_78 = 0;
                    for (iVar8 = 0; iVar8 != 0xb; iVar8 = iVar8 + 1) {
                      local_78 = local_78 + *(int *)(iVar8 * 4 + 0x20085914);
                    }
                    uVar3 = FUN_601668a4();
                    local_9c = FUN_6015cbf2(iVar7);
                    FUN_60161ef4(iVar7,0x60c7e740,0x1fa0,local_44 + 4);
                    iVar8 = (uint)((uVar3 | 2) != 2) * 0x18;
                    iVar18 = 0;
                    local_70 = 0;
                    for (uVar3 = 0;
                        uVar3 < ((uint)*(byte *)(iVar8 + 0x20085712) -
                                (uint)*(byte *)(iVar8 + 0x20085711)) + 1; uVar3 = uVar3 + 1) {
                      iVar9 = FUN_6015a168(local_44 + 3,iVar18 + 0x60c7e740);
                      iVar10 = FUN_6015a168(local_44 + 2,iVar18 + iVar9 + 0x60c7e740);
                      iVar18 = iVar18 + iVar9 + iVar10;
                      local_70 = local_70 + local_44[3];
                    }
                    bVar20 = 9999 < local_44[3];
                    if (local_44[3] < 0x2711) {
                      bVar20 = 10000 < local_44[2];
                    }
                    if (!bVar20) {
                      iVar8 = FUN_6015a168(local_44 + 1,iVar18 + 0x60c7e740);
                      uVar16 = iVar18 + iVar8;
                      uVar19 = 0;
                      local_a8 = 0;
                      for (uVar3 = 0; uVar3 != local_70; uVar3 = uVar3 + 1) {
                        if (cRam20085672 < '\0') {
                          uVar16 = uVar16 + 0x20;
                        }
                        iVar8 = FUN_60158ee8(&local_4c,uVar16 + 0x60c7e740);
                        iVar18 = FUN_60158ee8(&local_50,uVar16 + iVar8 + 0x60c7e740);
                        iVar18 = iVar18 + uVar16 + iVar8;
                        iVar8 = iVar18 + 1;
                        uVar16 = 0xff;
                        local_4c = iRam20085894 + iVar6 + local_4c;
                        local_50 = (iVar5 - iVar12) + iRam20085898 + local_50;
                        for (uVar14 = *(byte *)(iVar18 + 0x60c7e740) & 0xf; uVar14 != 0;
                            uVar14 = uVar14 - 1) {
                          iVar18 = FUN_6015a168(&local_48,iVar8 + 0x60c7e740);
                          iVar8 = iVar8 + iVar18;
                          if ((local_48 < 0xd) && (*(char *)(local_48 + 0x20085676) != -1)) {
                            uVar16 = local_48;
                          }
                        }
                        if (((uVar16 & 0xff) < 0xd) &&
                           (local_a8 = FUN_6001ff38(*(undefined1 *)((uVar16 & 0xff) + 0x20085676)),
                           local_a8 < 0xb)) {
                          bVar20 = local_70 < 0x3e9 || local_a8 < 3;
                        }
                        else {
                          bVar20 = false;
                        }
                        iVar18 = iVar8 + 1;
                        cVar1 = *(char *)(iVar8 + 0x60c7e740);
                        if (cVar1 < '\0') {
                          iVar8 = FUN_6015a168(local_44,iVar8 + 0x60c7e741);
                          uVar16 = local_44[0];
                          iVar9 = local_44[0] + 10;
                          local_88 = local_78 + iVar9;
                          if (0x4000 < local_88) break;
                          iVar18 = iVar18 + iVar8;
                          if ((bVar20) && (local_44[0] < 0x100)) {
                            uRam60ca2740 = (undefined1)local_44[0];
                            CopyBytes(0x60ca2741,iVar18 + 0x60c7e740,local_44[0]);
                            uVar14 = 0;
                            *(int *)(uVar16 + 0x60ca2742) = local_4c;
                            *(char *)(uVar16 + 0x60ca2741) = (char)local_a8;
                            *(int *)(uVar16 + 0x60ca2746) = local_50;
                            piVar13 = (int *)0x20085914;
                            for (iVar8 = (local_a8 & 0xff) + 1; iVar8 != 0; iVar8 = iVar8 + -1) {
                              iVar10 = *piVar13;
                              piVar13 = piVar13 + 1;
                              uVar14 = uVar14 + iVar10;
                            }
                            if (uVar14 < local_78) {
                              FUN_6015dda0(iVar9 + uVar14 + 0x60d00d7c,uVar14 + 0x60d00d7c,
                                           local_78 - uVar14);
                            }
                            CopyBytes(uVar14 + 0x60d00d7c,0x60ca2740,iVar9);
                            iVar8 = (local_a8 & 0xff) * 4;
                            *(int *)(iVar8 + 0x20085914) = *(int *)(iVar8 + 0x20085914) + iVar9;
                            *(int *)(iVar8 + 0x20085940) = *(int *)(iVar8 + 0x20085940) + 1;
                          }
                          else {
                            local_88 = local_78;
                          }
                        }
                        else {
                          uVar16 = 0;
                          local_44[0] = 0;
                          local_88 = local_78;
                        }
                        iVar8 = FUN_6001ff6c(uVar16 + iVar18 + 0x60c7e740,cVar1);
                        uVar16 = iVar8 + uVar16 + iVar18;
                        if (0x1e74 < uVar16) {
                          ZeroBytes(0x60c7e740,0x1fa0);
                          FUN_60163c98(iVar7,uVar16 + local_9c);
                          local_9c = FUN_6015cbf2(iVar7);
                          uVar19 = FUN_60161ef4(iVar7,0x60c7e740,0x1fa0,local_44 + 4);
                          uVar16 = 0;
                        }
                        local_78 = local_88;
                      }
                      goto LAB_6001752e;
                    }
                    if (iRam2004970c == 0) {
                      FUN_60168578("map:[pois %d][ways %d]\n");
                      iRam2004970c = 1;
                    }
                  }
                  uVar19 = 0xffffffff;
                }
              }
            }
LAB_6001752e:
            iVar17 = iVar17 + 1;
          } while( true );
        }
        goto LAB_600171ec;
      }
    }
    uVar19 = 0;
  }
  else {
LAB_600171ec:
    uVar19 = 0xffffffff;
  }
  return uVar19;
}
