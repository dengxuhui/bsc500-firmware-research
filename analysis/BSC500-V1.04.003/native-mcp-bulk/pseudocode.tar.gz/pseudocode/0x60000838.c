
undefined4 FUN_60000838(void)

{
  int iVar1;
  
  FUN_60167d0c();
  FUN_600008cc();
  FUN_60000904();
  iVar1 = thunk_EXT_FUN_0002194c();
  if (iVar1 == 0) {
    FUN_60168138();
  }
  FUN_60000a04();
  FUN_6000098c();
  FUN_6000086c();
  FUN_60000a10();
  FUN_60000a5c();
  FUN_600009c8();
  return 0;
}
