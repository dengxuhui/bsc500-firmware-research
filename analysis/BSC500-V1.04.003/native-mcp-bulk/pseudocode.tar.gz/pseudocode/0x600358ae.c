
void FUN_600358ae(undefined4 *param_1,ushort *param_2)

{
  ushort uVar1;
  
  *(undefined1 *)(param_1 + 1) = 0xff;
  *param_1 = 0xffffffff;
  uVar1 = *param_2;
  *(char *)((int)param_1 + 6) = (char)(uVar1 >> 6);
  *(char *)((int)param_1 + 5) = (char)uVar1 << 2;
  return;
}
