
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600272dc(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  char cVar2;
  undefined2 uVar3;
  byte bVar4;
  ushort uVar5;
  int iVar6;
  byte bVar7;
  int iVar8;
  undefined2 *puVar9;
  uint uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  int iVar14;
  int iVar15;
  int iVar16;
  undefined4 uVar17;
  undefined1 auStack_3d0 [16];
  undefined1 auStack_3c0 [48];
  undefined4 local_390;
  undefined4 uStack_38c;
  undefined4 local_384;
  undefined4 uStack_380;
  undefined4 local_37c;
  undefined4 uStack_378;
  undefined4 local_374;
  undefined4 uStack_370;
  undefined4 local_36c;
  undefined4 uStack_368;
  undefined4 local_364;
  undefined1 auStack_360 [32];
  undefined4 local_340;
  undefined4 uStack_33c;
  undefined4 local_338;
  undefined4 uStack_334;
  undefined4 local_330;
  undefined1 auStack_32c [80];
  undefined1 local_2dc;
  char local_2db;
  char local_2da;
  char cStack_2d9;
  char cStack_2d8;
  uint uStack_2d4;
  char cStack_2d0;
  uint uStack_2cc;
  char cStack_2c8;
  int iStack_2c4;
  char cStack_2c0;
  uint uStack_2bc;
  char cStack_2b8;
  int iStack_2b4;
  undefined1 *local_2b0;
  undefined4 local_2ac;
  char cStack_2a0;
  undefined *local_29c;
  undefined4 local_298;
  undefined *local_294;
  undefined4 local_290;
  undefined *local_28c;
  undefined4 local_288;
  char cStack_284;
  uint uStack_280;
  undefined *local_27c;
  undefined4 local_278;
  undefined *local_26c;
  undefined1 *local_268;
  undefined *local_25c;
  undefined4 *local_258;
  char cStack_21c;
  undefined1 auStack_218 [20];
  char local_204;
  char local_200;
  byte local_1fc;
  char local_1f8;
  int local_1f4;
  char local_1f0;
  byte local_1ec;
  char local_1e8;
  undefined2 local_1e4;
  char local_1e0;
  undefined2 local_1dc;
  char local_1d8;
  byte local_1d4;
  undefined *local_1d0;
  undefined1 *local_1cc;
  undefined *local_1c8;
  undefined1 *local_1c4;
  undefined *local_1c0;
  undefined4 *local_1bc;
  undefined *local_1b8;
  undefined4 *local_1b4;
  undefined *local_1b0;
  undefined4 *local_1ac;
  undefined *local_1a8;
  undefined4 *local_1a4;
  undefined *local_1a0;
  undefined4 *local_19c;
  undefined2 *local_198;
  undefined4 uStack_194;
  undefined4 local_190;
  undefined4 uStack_18c;
  undefined1 auStack_184 [12];
  uint local_178;
  undefined2 *local_170;
  undefined2 *local_16c;
  undefined4 local_168;
  undefined1 uStack_164;
  uint uStack_160;
  undefined1 uStack_15c;
  uint uStack_158;
  undefined1 uStack_154;
  int iStack_150;
  undefined1 uStack_14c;
  uint uStack_148;
  undefined1 uStack_144;
  undefined4 uStack_140;
  code *pcStack_13c;
  undefined4 uStack_138;
  undefined1 uStack_134;
  uint uStack_130;
  undefined1 uStack_12c;
  undefined1 *puStack_128;
  undefined4 uStack_124;
  undefined1 *puStack_120;
  undefined4 uStack_11c;
  undefined1 uStack_110;
  uint uStack_10c;
  undefined1 *puStack_108;
  undefined4 uStack_104;
  undefined1 uStack_100;
  undefined4 uStack_fc;
  undefined1 *puStack_e8;
  undefined2 **ppuStack_e4;
  undefined1 uStack_a8;
  int iStack_a4;
  undefined1 local_90;
  undefined1 local_8c;
  uint local_88;
  undefined1 local_84;
  uint local_80;
  undefined1 local_7c;
  uint local_78;
  undefined1 local_74;
  undefined4 local_70;
  undefined1 local_6c;
  undefined4 local_68;
  undefined1 *puStack_54;
  undefined2 **ppuStack_50;
  code *pcStack_4c;
  undefined2 **ppuStack_48;
  code *pcStack_44;
  undefined2 **ppuStack_40;
  undefined1 *puStack_3c;
  undefined2 **ppuStack_38;
  code *local_34;
  undefined2 **local_30;
  undefined4 uStack_2c;
  undefined2 **ppuStack_28;
  
  uStack_164 = 0;
  ZeroBytes(&local_2dc,0x10c);
  ZeroBytes(auStack_32c,0x50);
  local_338 = 0;
  uStack_334 = 0;
  local_330 = 0;
  local_340 = 0;
  uStack_33c = 0;
  ZeroBytes(auStack_360,0x20);
  local_364 = 0;
  local_36c = 0;
  uStack_368 = 0;
  local_37c = 0;
  uStack_378 = 0;
  local_374 = 0;
  uStack_370 = 0;
  local_384 = 0;
  uStack_380 = 0;
  local_390 = 0;
  uStack_38c = 0;
  ZeroBytes(auStack_3c0,0x30);
  uRam20009dc3 = 0;
  local_2ac = 0x20009dd0;
  local_278 = 0x2004bc8a;
  local_298 = 0x2004bc9a;
  local_290 = 0x2004bca2;
  local_288 = 0x2004bc7a;
  local_2b0 = &LAB_600389c8_1;
  local_28c = &UNK_6003d17d;
  local_27c = &UNK_6003d17d;
  local_29c = &UNK_6003d1a1;
  local_294 = &UNK_6003d1a1;
  local_1d0 = &UNK_600386f9;
  local_258 = &local_330;
  local_26c = &UNK_6003c57d;
  local_25c = &UNK_60040e1d;
  local_1bc = &local_340;
  local_1c8 = &UNK_6003562d;
  local_1c0 = &UNK_6003b009;
  local_1b4 = &uStack_370;
  local_1b8 = &UNK_60035a79;
  local_1ac = &local_374;
  local_1b0 = &UNK_6003afd1;
  local_1a4 = &local_384;
  local_1a8 = &UNK_6003fdf5;
  local_19c = &local_390;
  local_1a0 = &UNK_600388dd;
  local_268 = auStack_32c;
  local_1cc = auStack_3c0;
  local_1c4 = auStack_360;
  FUN_60161d4c(auStack_3d0,param_1,param_2);
  local_168._3_1_ = uStack_164;
  iVar8 = FUN_60161d60(auStack_3d0,&UNK_602a8462,&local_2dc);
  bVar7 = bRam20009e01;
  bVar4 = bRam20009dc1;
  if (iVar8 == 0) {
    FUN_60129ec8(local_2dc,local_2db,local_2da,0);
    return;
  }
  if (local_1d8 != '\0') {
    bRam20009dc2 = local_1d4;
  }
  switch(local_2db) {
  case '0':
    if (local_2da != '\x02') {
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '0';
        goto LAB_60027bd6;
      }
      goto LAB_60027e52;
    }
    ZeroBytes(&local_168,0x144);
    local_190 = 0;
    uStack_18c = 0;
    local_198 = (undefined2 *)0x0;
    uStack_194 = 0;
    local_170 = (undefined2 *)0x0;
    local_16c = (undefined2 *)0x0;
    iVar8 = FUN_6013a780(&local_16c,&local_170,0x9e);
    if (iVar8 != 0) {
      return;
    }
    ppuStack_50 = &local_198;
    local_168 = CONCAT22((short)(CONCAT13(local_168._3_1_,0x20000) >> 0x10),0x300c);
    puStack_54 = &LAB_6003565c_1;
    break;
  case '1':
    if (local_2da != '\x02') {
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '1';
        goto LAB_60027bd6;
      }
      goto LAB_60027e52;
    }
    ZeroBytes(&local_168,0x144);
    local_190 = 0;
    uStack_18c = 0;
    local_198 = (undefined2 *)0x0;
    uStack_194 = 0;
    local_170 = (undefined2 *)0x0;
    local_16c = (undefined2 *)0x0;
    iVar8 = FUN_6013a780(&local_16c,&local_170,0x9e);
    if (iVar8 != 0) {
      return;
    }
    ppuStack_48 = &local_198;
    local_168 = CONCAT22((short)(CONCAT13(local_168._3_1_,0x20000) >> 0x10),0x310c);
    pcStack_4c = (code *)0x6003b0f9;
    break;
  case '2':
    if (local_2da != '\x02') {
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '2';
        goto LAB_60027bd6;
      }
      goto LAB_60027e52;
    }
    ZeroBytes(&local_168,0x144);
    local_190 = 0;
    uStack_18c = 0;
    local_198 = (undefined2 *)0x0;
    uStack_194 = 0;
    local_170 = (undefined2 *)0x0;
    local_16c = (undefined2 *)0x0;
    iVar8 = FUN_6013a780(&local_16c,&local_170,0x9e);
    if (iVar8 != 0) {
      return;
    }
    ppuStack_40 = &local_198;
    local_168 = CONCAT22((short)(CONCAT13(local_168._3_1_,0x20000) >> 0x10),0x320c);
    pcStack_44 = (code *)0x60035c51;
    break;
  case '3':
    switch(local_2da) {
    case '\x01':
      uRam20009dff = *(undefined1 *)((short)(ushort)bRam20009dc1 * 0x2c + 0x2004c747);
      CopyBytes((short)(ushort)bRam20009dc1 * 0x2c + 0x2004c740,0x20009df8,0x2c);
      bVar7 = bRam20009dc0;
      if (((int)((uint)bRam20009dfe << 0x1e) < 0) && (bRam20009dc0 != bVar4)) {
        bRam20009dc0 = bVar4;
        (&DAT_2004c746)[(short)(ushort)bVar7 * 0x2c] =
             (&DAT_2004c746)[(short)(ushort)bVar7 * 0x2c] & 0xfd;
      }
      goto code_r0x60027e5a;
    case '\x02':
      func_0x6003c320();
      return;
    default:
      uVar12 = 6;
      local_2db = '3';
      goto LAB_60027bd6;
    case '\x04':
      iVar14 = 0x4690;
      iVar15 = 0x45c8;
      iVar16 = 0xd60;
      for (iVar8 = -0x1b8; iVar8 != 0; iVar8 = iVar8 + 0x2c) {
        if ((*(byte *)(iVar8 + 0x2004c8fe) & 1) == 0) {
          uVar10 = (uint)bRam20009e01;
          uVar5 = (ushort)bRam20009e01;
          iVar6 = (short)uVar5 * 0x2c;
          CopyBytes(iVar8 + 0x2004c8f8,iVar6 + 0x2004c740,0x2c);
          CopyBytes(iVar8 + 0x2004c902,0x20009e02,0x20);
          bVar4 = *(byte *)(iVar8 + 0x2004c8fe);
          *(byte *)(iVar8 + 0x2004c901) = bVar7;
          *(byte *)(iVar8 + 0x2004c8fe) = bVar4 | 1;
          if ((int)((uint)(byte)(&DAT_2004c746)[iVar6] << 0x1e) < 0) {
            *(byte *)(iVar8 + 0x2004c8fe) = bVar4 & 0xfd | 1;
          }
          *(undefined4 *)(iVar8 + 0x2004c8f8) = uRam20009df8;
          FUN_6007db44(&DAT_2004bb98 + iVar16,(short)uVar5 * 0x5a4 + 0x2004c8f8,0x5a4);
          iVar8 = uVar10 * 0x14;
          uVar13 = *(undefined4 *)(iVar8 + 0x20050164);
          uVar17 = *(undefined4 *)(iVar8 + 0x20050168);
          uVar12 = *(undefined4 *)(iVar8 + 0x2005016c);
          uVar11 = *(undefined4 *)(iVar8 + 0x20050170);
          *(undefined4 *)(&DAT_2004bb98 + iVar15) = *(undefined4 *)(iVar8 + 0x20050160);
          *(undefined4 *)(iVar15 + 0x2004bb9c) = uVar13;
          *(undefined4 *)(iVar15 + 0x2004bba0) = uVar17;
          *(undefined4 *)(iVar15 + 0x2004bba4) = uVar12;
          *(undefined4 *)(iVar15 + 0x2004bba8) = uVar11;
          CopyBytes(&DAT_2004bb98 + iVar14,uVar10 * 0x38 + 0x20050228,0x38);
          uVar12 = 4;
          goto code_r0x60027d3e;
        }
        iVar16 = iVar16 + 0x5a4;
        iVar15 = iVar15 + 0x14;
        iVar14 = iVar14 + 0x38;
      }
      uVar12 = 4;
      uVar11 = 4;
      break;
    case '\x05':
      uVar10 = (uint)bRam20009dc1;
      if ((1 < uVar10) && (uVar10 - 2 < 8)) {
        bVar4 = (&DAT_2004c746)[(short)(ushort)bRam20009dc1 * 0x2c];
        iVar8 = (short)(ushort)bRam20009dc1 * 0x2c + 0x2004c740;
        for (; uVar10 < 9; uVar10 = uVar10 + 1) {
          CopyBytes(iVar8,iVar8 + 0x2c,0x2c);
          iVar8 = iVar8 + 0x2c;
        }
        *(byte *)(iVar8 + 6) = *(byte *)(iVar8 + 6) & 0xfc;
        if ((int)((uint)bVar4 << 0x1e) < 0) {
          DAT_2004c746 = DAT_2004c746 | 2;
        }
        uVar12 = 5;
code_r0x60027d3e:
        FUN_60127660(local_2dc,0x33,uVar12,0);
        goto code_r0x60027d44;
      }
      uVar12 = 1;
      uVar11 = 5;
    }
    FUN_6011f5ec(local_2dc,local_2dc,uVar11,0,uVar12);
code_r0x60027d44:
    FUN_60164914(0x800005,0);
    return;
  case '4':
    if (local_2da != '\x02') {
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '4';
        goto LAB_60027bd6;
      }
      if (cStack_21c == '\0') {
        local_2db = '4';
        local_2da = '\x01';
      }
      else {
        FUN_600356a4(0x40000004,auStack_218);
      }
      goto code_r0x60027e6e;
    }
    ZeroBytes(&local_168,0x144);
    local_198 = (undefined2 *)0x0;
    local_16c = (undefined2 *)0x0;
    iVar14 = *(int *)(_DAT_200078a8 + 0x9c);
    iVar8 = FUN_6013a780(&local_198,&local_16c,0x9e);
    if (iVar8 != 0) {
      return;
    }
    uStack_a8 = 1;
    local_168 = CONCAT22((short)(CONCAT13(local_168._3_1_,0x20000) >> 0x10),0x340c);
    iStack_a4 = iVar14;
    if (iVar14 == 0x7fffffff) {
      iStack_a4 = FUN_600316b8();
    }
code_r0x60027ad8:
    FUN_601648d4(auStack_184,local_198,0x4b0);
    FUN_60164868(auStack_184,&UNK_602a8462,&local_168);
    *local_16c = (short)local_178;
    FUN_6012374c();
    uVar3 = *local_16c;
    puVar9 = local_198;
    goto LAB_60027b7a;
  case '5':
    if (local_2da != '\x02') {
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '5';
        goto LAB_60027bd6;
      }
      local_2db = '5';
code_r0x600276fe:
      local_2da = '\x01';
      goto code_r0x60027e6e;
    }
    ZeroBytes(&local_168,0x144);
    local_198 = (undefined2 *)0x0;
    uStack_194 = 0;
    local_170 = (undefined2 *)0x0;
    local_16c = (undefined2 *)0x0;
    iVar8 = FUN_6013a780(&local_16c,&local_170,0x9e);
    if (iVar8 != 0) {
      return;
    }
    ppuStack_28 = &local_198;
    local_168 = CONCAT22((short)(CONCAT13(local_168._3_1_,0x20000) >> 0x10),0x350c);
    uStack_2c = 0x60038959;
    break;
  default:
    switch(local_2db) {
    case '\x01':
      if (local_2da == '\x02') {
        ZeroBytes(&local_168,0x144);
        local_198 = (undefined2 *)0x0;
        local_16c = (undefined2 *)0x0;
        iVar8 = FUN_6013a780(&local_198,&local_16c,0x9e);
        if (iVar8 == 0) {
          uStack_104 = 0x2004bc8a;
          uStack_124 = 0x2004bc9a;
          uStack_11c = 0x2004bca2;
          local_168 = 0x103010c;
          uStack_154 = 1;
          uStack_14c = 1;
          uStack_164 = 1;
          uStack_15c = 1;
          uStack_144 = 1;
          uStack_110 = 1;
          uStack_12c = 1;
          uStack_148 = (uint)bRam2004bc0b;
          uStack_158 = (uint)_DAT_2004bc08;
          uStack_140 = _DAT_2004c60c;
          uStack_138 = 0x2004bc10;
          uStack_160 = bRam2004bc0c & 1;
          iStack_150 = (_DAT_2005563c - (uint)bRam2004bc0a) + -0x76c;
          pcStack_13c = (code *)0x6004b1cb;
          puStack_108 = &LAB_6003ce80_1;
          puStack_128 = &LAB_6003ae34_1;
          puStack_120 = &LAB_60037b58_1;
          uStack_130 = (bRam2004bc0c & 7) >> 2;
          uStack_100 = 1;
          uStack_134 = 1;
          uStack_fc = uRam2004bc38;
          uStack_10c = _DAT_2004bc70 & 0x7fff;
          FUN_601648d4(auStack_184,local_198,0x4b0);
          FUN_60164868(auStack_184,&UNK_602a8462,&local_168);
          *local_16c = (short)local_178;
          FUN_6012374c();
          uVar12 = FUN_6015f2e8(local_198,*local_16c);
          FUN_6013a800(local_168 & 0xff,local_168._1_1_,local_168._2_1_,0,local_178 & 0xffff,uVar12)
          ;
        }
        bRam2004bc0c = bRam2004bc0c & 0xfb;
        return;
      }
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '\x01';
        goto LAB_60027bd6;
      }
      if (cStack_2d9 != '\0') {
        if (((cStack_2c8 != '\0') && (iStack_2c4 - 1U < 99)) &&
           (uVar10 = (uint)bRam2004bc0a, bRam2004bc0a = (char)(_DAT_2005563c - iStack_2c4) + 0x94,
           (_DAT_2005563c - iStack_2c4) - 0x76cU != uVar10)) {
          cRam20009dc6 = '\x01';
        }
        if (cStack_2d0 != '\0') {
          if (uStack_2cc < 0x9c4) {
            if (uStack_2cc < 0x65) {
              uStack_2cc = 100;
            }
          }
          else {
            uStack_2cc = 0x9c4;
          }
          if (uStack_2cc != _DAT_2004bc08) {
            cRam20009dc6 = '\x01';
          }
          _DAT_2004bc08 = (ushort)uStack_2cc;
        }
        if (((cStack_2d8 != '\0') && (uStack_2d4 < 2)) &&
           (uVar10 = (uint)bRam2004bc0c, bRam2004bc0c = (byte)uStack_2d4 | bRam2004bc0c & 0xfe,
           uStack_2d4 != (uVar10 & 1))) {
          cRam20009dc6 = '\x01';
        }
        if (cStack_2c0 != '\0') {
          if (uStack_2bc < 0xfa) {
            if (uStack_2bc < 0x33) {
              uStack_2bc = 0x32;
            }
          }
          else {
            uStack_2bc = 0xfa;
          }
          if (uStack_2bc != bRam2004bc0b) {
            cRam20009dc6 = '\x01';
          }
          bRam2004bc0b = (byte)uStack_2bc;
        }
        if ((cStack_2b8 != '\0') && (iStack_2b4 + 0xa8c0U < 0x16da1)) {
          FUN_6015e10c(0);
        }
      }
      if (cStack_2a0 != '\0') {
        if ((DAT_2004bc72 != cRam2004bc9f) || (cRam2004c67a != cRam2004bc9f)) {
          cRam2004c67a = cRam2004bc9f;
          cRam20009dc6 = '\x01';
        }
        if (cStack_284 != '\0') {
          if (uStack_280 != (_DAT_2004bc70 & 0x7fff)) {
            cRam20009dc6 = '\x01';
          }
          _DAT_2004bc70 = (_DAT_2004bc70 & 0x8000) + ((ushort)uStack_280 & 0x7fff);
        }
      }
      CopyBytes(0x2004bc10,0x20009dd0,0x28);
      bRam2004bc0c = bRam2004bc0c & 0xfb;
      if (cRam20009dc6 == '\x01') {
        uRam2004bc38 = func_0x60040fd8();
        cRam20009dc6 = '\0';
      }
      break;
    case '\x02':
      if (local_2da == '\b') {
        InitializePageDefaults(&DAT_2004bb98);
      }
      else {
        if (local_2da == '\x02') {
          FUN_6007db44(0x20057b20,(short)(ushort)bRam20009dc2 * 0x5a4 + 0x2004c8f8,0x5a4);
          func_0x6003c4d4();
          return;
        }
        if (local_2da != '\x01') {
          uVar12 = 6;
          local_2db = '\x02';
          goto LAB_60027bd6;
        }
      }
      goto code_r0x60027e5a;
    case '\x03':
    case '\x05':
LAB_6002760a:
      uVar12 = 6;
LAB_60027bd6:
      FUN_6011f5ec(local_2dc,local_2db,local_2da,0,uVar12);
      return;
    case '\x04':
      if (local_2da == '\x02') {
        ZeroBytes(&local_168,0x144);
        uRam20009dc8 = 0;
        uRam20009dcc = 0;
        local_198 = (undefined2 *)0x0;
        local_170 = (undefined2 *)0x0;
        local_16c = (undefined2 *)0x0;
        iVar8 = FUN_6013a780(&local_16c,&local_170,0x9e);
        if (iVar8 != 0) {
          return;
        }
        ppuStack_e4 = &local_198;
        local_168 = 0x3040c;
        puStack_e8 = &LAB_60040e6c_1;
        goto code_r0x60027b50;
      }
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '\x04';
        goto LAB_60027bd6;
      }
      for (iVar8 = 0; iVar8 != 4; iVar8 = iVar8 + 1) {
        cVar1 = *(char *)(iVar8 * 2 + 0x20009dc8);
        if ((cVar1 != '\0') && (cVar2 = *(char *)(iVar8 * 2 + 0x20009dc9), cVar2 != '\0')) {
          switch(cVar1) {
          case '\x01':
            if (cVar2 == '\x01') {
              _DAT_2004c620 = _DAT_2004c620 | 1;
            }
            else {
              _DAT_2004c620 = _DAT_2004c620 & 0xfffffffe;
            }
            break;
          case '\x02':
            if (cVar2 == '\x01') {
              _DAT_2004c620 = _DAT_2004c620 | 2;
            }
            else {
              _DAT_2004c620 = _DAT_2004c620 & 0xfffffffd;
            }
            break;
          case '\x03':
            if (cVar2 == '\x01') {
              _DAT_2004c620 = _DAT_2004c620 | 4;
            }
            else {
              _DAT_2004c620 = _DAT_2004c620 & 0xfffffffb;
            }
            break;
          case '\x04':
            if (cVar2 == '\x01') {
              _DAT_2004c620 = _DAT_2004c620 | 8;
            }
            else {
              _DAT_2004c620 = _DAT_2004c620 & 0xfffffff7;
            }
          }
        }
      }
      if (pcRam20044a84 != (code *)0x0) {
        (*pcRam20044a84)(8,0,0);
      }
      break;
    case '\x06':
      if (local_2da != '\x02') {
        if (local_2da != '\x01') {
          uVar12 = 6;
          local_2db = '\x06';
          goto LAB_60027bd6;
        }
        local_2db = '\x06';
        goto code_r0x600276fe;
      }
      ZeroBytes(&local_168,0x144);
      local_198 = (undefined2 *)0x0;
      local_170 = (undefined2 *)0x0;
      local_16c = (undefined2 *)0x0;
      iVar8 = FUN_6013a780(&local_16c,&local_170,0x9e);
      if (iVar8 != 0) {
        return;
      }
      ppuStack_38 = &local_198;
      local_168 = CONCAT22((short)(CONCAT13(local_168._3_1_,0x20000) >> 0x10),0x60c);
      puStack_3c = &LAB_6003afe0_1;
      goto code_r0x60027b50;
    default:
      if (local_2db != '\x11') {
        if (local_2db == '\x14') {
          if (local_2da == '\x02') {
            ZeroBytes(&local_168,0x144);
            local_198 = (undefined2 *)0x0;
            local_16c = (undefined2 *)0x0;
            iVar8 = FUN_6013a780(&local_198,&local_16c,0x9e);
            if (iVar8 != 0) {
              return;
            }
            local_8c = 1;
            local_90 = 1;
            local_84 = 1;
            local_74 = 1;
            local_7c = 1;
            local_88 = (bRam2004c5b5 & 3) >> 1;
            local_78 = (bRam2004c5b5 & 0x7f) >> 6;
            local_80 = (uint)uRam2004c5b0;
            if (local_80 == 0xffff) {
              local_80 = 0xffffffff;
            }
            local_168 = CONCAT13(local_168._3_1_,0x2140c);
            local_70 = FUN_60148c30(2);
            local_6c = 1;
            local_68 = FUN_60148c30(3);
            goto code_r0x60027ad8;
          }
          if (local_2da != '\x01') {
            uVar12 = 6;
            local_2db = '\x14';
            goto LAB_60027bd6;
          }
          iVar8 = FUN_6015a144("WebGrid");
          if (iVar8 == 0) {
            FUN_60164914(0x800005,0);
          }
          if (local_204 == '\0') {
            uVar12 = 7;
            goto LAB_60027bd6;
          }
          if (local_200 != '\0') {
            bRam2004c5b5 = bRam2004c5b5 & 0xfd | (local_1fc & 1) << 1;
          }
          if (local_1f8 != '\0') {
            if (local_1f4 == -1) {
              local_1f4 = -1;
            }
            else if (((local_1f4 != 5 && local_1f4 != 0xf) &&
                     (local_1f4 != 0x1e && local_1f4 != 0x78)) && (local_1f4 != 0x3c))
            goto LAB_60027e84;
            uRam2004c5b0 = (ushort)local_1f4;
          }
LAB_60027e84:
          if (local_1f0 != '\0') {
            bRam2004c5b5 = bRam2004c5b5 & 0xbf | (local_1ec & 1) << 6;
          }
          if (local_1e8 != '\0') {
            FUN_6015f488(2,local_1e4);
          }
          if (local_1e0 != '\0') {
            FUN_6015f488(3,local_1dc);
          }
          FUN_60159334(0);
          goto code_r0x60027e6e;
        }
        goto LAB_6002760a;
      }
      if (local_2da == '\x02') {
        ZeroBytes(&local_168,0x144);
        local_190 = 0;
        uStack_18c = 0;
        local_198 = (undefined2 *)0x0;
        uStack_194 = 0;
        local_170 = (undefined2 *)0x0;
        local_16c = (undefined2 *)0x0;
        iVar8 = FUN_6013a780(&local_16c,&local_170,0x9e);
        if (iVar8 != 0) {
          return;
        }
        local_30 = &local_198;
        local_168 = CONCAT22((short)(CONCAT13(local_168._3_1_,0x20000) >> 0x10),0x110c);
        local_34 = (code *)0x6003fe6d;
        goto code_r0x60027b50;
      }
      if (local_2da != '\x01') {
        uVar12 = 6;
        local_2db = '\x11';
        goto LAB_60027bd6;
      }
    }
LAB_60027e52:
    iVar8 = FUN_6015a144("WebGrid");
    if (iVar8 != 0) goto code_r0x60027e6e;
code_r0x60027e5a:
    FUN_60164914(0x800005,0);
code_r0x60027e6e:
    FUN_60127660(local_2dc,local_2db,local_2da,0);
    return;
  }
code_r0x60027b50:
  FUN_601648d4(auStack_184,local_16c,0x4b0);
  FUN_60164868(auStack_184,&UNK_602a8462,&local_168);
  *local_170 = (short)local_178;
  FUN_6012374c();
  uVar3 = *local_170;
  puVar9 = local_16c;
LAB_60027b7a:
  uVar12 = FUN_6015f2e8(puVar9,uVar3);
  FUN_6013a800(local_168 & 0xff,local_168._1_1_,local_168._2_1_,0,local_178 & 0xffff,uVar12);
  return;
}
