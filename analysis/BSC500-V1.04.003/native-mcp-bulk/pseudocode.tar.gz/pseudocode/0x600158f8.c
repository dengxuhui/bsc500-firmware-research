
void FUN_600158f8(int param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = FUN_60168220(param_2);
  if (iVar1 - 0x16U < 0x4e) {
    FUN_60167370(param_1,param_2);
    *(undefined1 *)(param_1 + (iVar1 - 0x16U)) = 0;
    iVar1 = FUN_60168220(param_1);
    *(undefined4 *)(param_1 + iVar1) = 0x616d2e43;
    *(undefined2 *)(iVar1 + param_1 + 4) = 0x70;
  }
  return;
}
