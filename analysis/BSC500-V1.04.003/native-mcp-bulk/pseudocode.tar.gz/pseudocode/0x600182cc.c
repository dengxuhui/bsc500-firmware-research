
void FUN_600182cc(void)

{
  if (iRam2000ab7c != 0) {
    FUN_601667bc();
    iRam2000ab7c = 0;
  }
  return;
}
