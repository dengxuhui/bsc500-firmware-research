
void FUN_600378a0(undefined4 param_1,undefined4 *param_2)

{
  int iVar1;
  
  iVar1 = FUN_60152ec0();
  if ((param_2 != (undefined4 *)0x0) && (iVar1 != 0)) {
    *(undefined1 *)(iVar1 + 0xc) = *(undefined1 *)(param_2 + 1);
    *(undefined4 *)(iVar1 + 8) = *param_2;
  }
  return;
}
