
void FUN_600379b8(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = FUN_601548bc();
  FUN_60168578("[ble_watch_battery_update] mac:");
  for (iVar2 = 0; iVar2 != 6; iVar2 = iVar2 + 1) {
    FUN_60168578(&UNK_60037a1c,*(undefined1 *)(param_1 + iVar2));
  }
  FUN_60168578(&UNK_60037a24);
  if (iVar1 != 0) {
    *(char *)(iVar1 + 0x37) = (char)param_2;
    FUN_60168578("[ble_watch_battery_update] %d%%\n",param_2);
    return;
  }
  return;
}
