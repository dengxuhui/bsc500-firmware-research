
int FUN_60018214(float param_1)

{
  char cVar1;
  
  if (0.0 <= param_1) {
    if (150.0 <= param_1) {
      cVar1 = '\x04';
      goto LAB_600182b0;
    }
    if (120.0 <= param_1) {
      cVar1 = '\x03';
      goto LAB_600182b0;
    }
    if (60.0 <= param_1) {
      cVar1 = '\x02';
      goto LAB_600182b0;
    }
    if (30.0 <= param_1) {
      cVar1 = '\x01';
      goto LAB_600182b0;
    }
  }
  else {
    if (param_1 <= -150.0) {
      cVar1 = -4;
      goto LAB_600182b0;
    }
    if (param_1 <= -120.0) {
      cVar1 = -3;
      goto LAB_600182b0;
    }
    if (param_1 <= -60.0) {
      cVar1 = -2;
      goto LAB_600182b0;
    }
    if (param_1 <= -30.0) {
      cVar1 = -1;
      goto LAB_600182b0;
    }
  }
  cVar1 = '\0';
LAB_600182b0:
  return (int)cVar1;
}
