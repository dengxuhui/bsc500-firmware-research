
undefined4 FUN_60008d58(int param_1,undefined4 param_2,undefined1 *param_3)

{
  char *pcVar1;
  
  if (param_1 == 1) {
    pcVar1 = "ADV stopped reason %d, mode %d\r\n";
    if (cRam200073c5 != '\0') {
      cRam200073c5 = '\0';
    }
  }
  else {
    if (param_1 != 0) {
      return 0;
    }
    pcVar1 = "ADV start result %d, mode %d\r\n";
    if (cRam200073c5 == '\0') {
      cRam200073c5 = '\x01';
    }
  }
  FUN_60168578(pcVar1,*param_3,param_3[1]);
  return 0;
}
