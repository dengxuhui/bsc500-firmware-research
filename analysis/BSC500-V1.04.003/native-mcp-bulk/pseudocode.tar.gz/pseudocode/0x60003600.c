
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 *
FUN_60003600(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *puVar2;
  
  if (_DAT_2000b5e4 != 0) {
    iVar1 = FUN_6016825e(_DAT_2000b5e4,0xffffffff,param_3,param_4,param_1,param_2,param_3);
    if (iVar1 == 0) {
      puVar2 = (undefined4 *)FUN_60161f90(8,10);
      *puVar2 = 0;
      puVar2[1] = 0;
      FUN_601682ae(_DAT_2000b5e4);
    }
    else {
      FUN_60167f3c(3,"MSG_SVC",1,"acquire mutex failed %s",uRam60003664,param_2,param_3,param_4);
      puVar2 = (undefined4 *)0x0;
    }
    return puVar2;
  }
  FUN_60167f3c(0,"MessageManger",1,"(%s) has assert failed at %s:%ld.",
               "mMessageMutex && \"message not init \"","message_creatListenerManager",0xcb,param_4)
  ;
  FUN_6013dd48();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}
