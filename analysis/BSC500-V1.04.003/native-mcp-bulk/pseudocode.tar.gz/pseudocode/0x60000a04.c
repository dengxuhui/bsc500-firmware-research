
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000a04(void)

{
  _DAT_200095d0 = &DAT_200095d0;
  _DAT_200095d4 = &DAT_200095d0;
  return;
}
