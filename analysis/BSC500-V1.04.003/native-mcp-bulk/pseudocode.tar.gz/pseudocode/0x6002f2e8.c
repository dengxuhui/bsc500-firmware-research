
void FUN_6002f2e8(int param_1)

{
  ushort uVar1;
  byte bVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  char *pcVar6;
  uint uVar7;
  int local_7c;
  undefined1 auStack_74 [31];
  undefined1 local_55;
  undefined1 auStack_54 [39];
  undefined1 local_2d;
  undefined4 local_2c;
  byte local_25;
  
  uVar1 = *(ushort *)(param_1 + 0x9c);
  uVar3 = *(undefined4 *)(param_1 + 0x160);
  local_25 = 0;
  local_2c = 0;
  ZeroBytes(auStack_54,0x28);
  ZeroBytes(auStack_74,0x20);
  if (uVar1 != 0) {
    local_7c = 0;
    for (uVar7 = 0; uVar7 != uVar1; uVar7 = uVar7 + 1) {
      iVar4 = FUN_60161ef4(uVar3,&local_25,1,&local_2c);
      bVar2 = local_25;
      if ((iVar4 != 0) || (0x27 < local_25)) {
        FUN_60168578("Error: read map way tags = %d\n",local_25);
        return;
      }
      ZeroBytes(auStack_54,0x28);
      ZeroBytes(auStack_74,0x20);
      iVar4 = FUN_60161ef4(uVar3,auStack_54,bVar2,&local_2c);
      if (iVar4 != 0) {
        FUN_60168578("Error: read map way tags\n");
        return;
      }
      local_2d = 0;
      iVar4 = FUN_6015e2dc(auStack_54,&UNK_603fbefe,auStack_74);
      if (iVar4 == 1) {
        pcVar6 = "trunk";
        local_55 = 0;
        for (iVar4 = 0; iVar4 != 0x85; iVar4 = iVar4 + 1) {
          iVar5 = FUN_60168418(auStack_74,pcVar6);
          if (iVar5 == 0) goto LAB_6002f3a0;
          pcVar6 = pcVar6 + 0x20;
        }
        iVar4 = 0xff;
LAB_6002f3a0:
        *(char *)(param_1 + local_7c + 0x9e) = (char)iVar4;
        if (local_7c < 0x85) {
          local_7c = local_7c + 1;
        }
      }
    }
  }
  return;
}
