
uint FUN_60037fd8(int *param_1,int param_2,uint param_3,int *param_4)

{
  uint uVar1;
  undefined4 uVar2;
  int iVar3;
  uint uVar4;
  
  if (param_1 != (int *)0x0) {
    uVar1 = FUN_601551ec();
    if (uVar1 == 0) {
      param_3 = 0;
    }
    else {
      uVar4 = param_1[2];
      if (uVar1 < param_3) {
        param_3 = uVar1;
      }
      param_3 = param_3 & 0xffff;
      iVar3 = *param_1 + (uVar4 >> 0x10);
      uVar1 = uVar4 >> 0x10;
      if (param_3 < (int)(short)param_1[4] - (uVar4 >> 0x10)) {
        CopyBytes(param_2,iVar3,param_3);
        uVar2 = FUN_60167d0c();
        if (param_4 != (int *)0x0) {
          iVar3 = FUN_601551ec(param_1);
          *param_4 = iVar3 - param_3;
        }
        uVar1 = uVar4 & 0xffff | (uVar1 + param_3) * 0x10000;
      }
      else {
        CopyBytes(param_2,iVar3);
        iVar3 = (int)(short)param_1[4] - uVar1;
        CopyBytes(param_2 + iVar3,*param_1,param_3 - iVar3);
        uVar2 = FUN_60167d0c();
        if (param_4 != (int *)0x0) {
          iVar3 = FUN_601551ec(param_1);
          *param_4 = iVar3 - param_3;
        }
        uVar1 = (uVar4 & 0xffff | ((uVar1 + param_3) - (uint)*(ushort *)(param_1 + 4)) * 0x10000) ^
                0xffff;
      }
      param_1[2] = uVar1;
      FUN_60167d14(uVar2);
    }
    return param_3;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("cb != NULL","circular_buf_get_and_update_len",0x13e,param_4,param_4);
}
