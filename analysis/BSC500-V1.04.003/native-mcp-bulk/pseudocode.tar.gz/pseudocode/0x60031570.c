
undefined4 FUN_60031570(int param_1,byte *param_2)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  ushort uVar7;
  undefined4 local_ac;
  undefined1 auStack_a8 [8];
  int local_a0 [2];
  undefined4 local_98;
  undefined1 auStack_94 [112];
  
  uVar2 = 0xffffffff;
  if ((param_1 != 0) && (param_2 != (byte *)0x0)) {
    ZeroBytes(auStack_94,0x70);
    local_98 = 0;
    iVar3 = FUN_60168220(param_1);
    FUN_60161fb8(auStack_a8);
    iVar4 = FUN_6015ee0c(auStack_a8,param_1,&UNK_600316b0,0,0,0,0);
    *param_2 = 0;
    if (iVar4 != 0) {
      CopyBytes(auStack_94,param_1,iVar3);
      uVar7 = 0;
      auStack_94[iVar3] = 0x2f;
      piVar6 = local_a0;
      do {
        do {
          piVar6 = (int *)*piVar6;
          if (local_a0 == piVar6) goto LAB_600316a0;
        } while (0x53 < (uint)piVar6[-1]);
        FUN_60167214(auStack_94 + iVar3 + 1,0x6e - iVar3);
        CopyBytes(auStack_94 + iVar3 + 1,piVar6[-2],piVar6[-1]);
        ZeroBytes(param_2 + (short)(uVar7 & 0xff) * 0x1ec + 4,0x1ec);
        iVar4 = FUN_60168220(auStack_94);
        auStack_94[iVar4 + -1] = 0x62;
        iVar5 = FUN_60166758(&local_98,auStack_94,1);
        if (iVar5 == 0) {
          FUN_601667bc(local_98);
          iVar4 = FUN_6003e074(auStack_94,param_2 + (short)(ushort)*param_2 * 0x1ec + 4);
          if (iVar4 != 0) goto LAB_60031686;
          uVar7 = *param_2 + 1;
          *param_2 = (byte)uVar7;
        }
        else {
          auStack_94[iVar4 + -1] = 0x78;
          iVar4 = FUN_6003e288(auStack_94,param_2 + (short)(ushort)*param_2 * 0x1ec + 4);
          if (iVar4 == 0) {
            local_ac = 0;
            FUN_6003ced2(auStack_94,&local_ac);
            bVar1 = *param_2;
            uVar7 = bVar1 + 1;
            *param_2 = (byte)uVar7;
            *(undefined4 *)(param_2 + (short)(ushort)bVar1 * 0x1ec + 0x1e8) = local_ac;
          }
          else {
LAB_60031686:
            uVar7 = (ushort)*param_2;
          }
        }
      } while ((byte)uVar7 < 0x32);
    }
LAB_600316a0:
    FUN_601607f4(auStack_a8);
    uVar2 = 0;
  }
  return uVar2;
}
