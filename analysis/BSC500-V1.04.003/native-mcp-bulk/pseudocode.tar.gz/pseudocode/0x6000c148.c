
void FUN_6000c148(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_600182e4();
  FUN_60161424("current_roadbook: %s\n",uVar1);
  return;
}
