
void InitializePageDefaults(int param_1)

{
  byte *pbVar1;
  int iVar2;
  int iVar3;
  undefined1 *puVar4;
  int iVar5;
  undefined *puVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  
  iVar7 = param_1 + 0xd60;
  ZeroBytes(iVar7,0x3868);
  puVar6 = &RidePageTemplateFields_12;
  iVar9 = param_1 + 0xd7c;
  for (iVar3 = 0; iVar3 != 2; iVar3 = iVar3 + 1) {
    iVar2 = iVar9;
    for (iVar5 = 0; iVar5 != 0x78; iVar5 = iVar5 + 0x18) {
      CopyBytes(iVar2,puVar6 + iVar5,0x18);
      iVar2 = iVar2 + 0x38;
    }
    iVar9 = iVar9 + 0x5a4;
    puVar6 = puVar6 + 0x78;
  }
  iVar9 = param_1 + 0x18c4;
  for (iVar3 = 2; iVar3 != 10; iVar3 = iVar3 + 1) {
    iVar2 = iVar9;
    for (iVar5 = 0; iVar5 != 0x78; iVar5 = iVar5 + 0x18) {
      CopyBytes(iVar2,&DAT_602a6f90 + iVar5,0x18);
      iVar2 = iVar2 + 0x38;
    }
    iVar9 = iVar9 + 0x5a4;
  }
  iVar9 = param_1 + 0xe94;
  for (iVar3 = 0; iVar3 != 10; iVar3 = iVar3 + 1) {
    iVar2 = iVar9;
    for (iVar5 = 0; iVar5 != 0x1ce; iVar5 = iVar5 + 0x16) {
      CopyBytes(iVar2,&RidePageTemplateFields_11 + iVar5,0x16);
      iVar2 = iVar2 + 0x36;
    }
    iVar9 = iVar9 + 0x5a4;
  }
  puVar4 = &DAT_602a75c0;
  for (iVar3 = 0; iVar3 != 2; iVar3 = iVar3 + 1) {
    iVar9 = iVar7;
    for (iVar2 = 0; iVar2 != 5; iVar2 = iVar2 + 1) {
      CopyBytes(iVar9,&UNK_602a75e4 + (uint)(byte)puVar4[iVar2] * 0x1c,0x1c);
      iVar9 = iVar9 + 0x38;
    }
    iVar7 = iVar7 + 0x5a4;
    puVar4 = puVar4 + 5;
  }
  iVar3 = param_1 + 0x18a8;
  for (iVar7 = 2; iVar7 != 10; iVar7 = iVar7 + 1) {
    iVar9 = iVar3;
    for (iVar2 = 0; iVar2 != 5; iVar2 = iVar2 + 1) {
      CopyBytes(iVar9,&UNK_602a75e4 + (uint)(byte)(&DAT_602a75ca)[iVar2] * 0x1c,0x1c);
      iVar9 = iVar9 + 0x38;
    }
    iVar3 = iVar3 + 0x5a4;
  }
  iVar7 = param_1 + 0xe78;
  iVar3 = 0;
LAB_60037d28:
  if (iVar3 == 10) {
    iVar3 = param_1 + 0xeaa;
    iVar7 = param_1 + 0xd94;
    for (iVar9 = 0; iVar9 != 10; iVar9 = iVar9 + 1) {
      for (iVar2 = 0; iVar2 != 0x118; iVar2 = iVar2 + 0x38) {
        *(byte *)(iVar7 + iVar2) = *(byte *)(iVar7 + iVar2) & 0xfe;
      }
      for (iVar2 = -0x46e; iVar2 != 0; iVar2 = iVar2 + 0x36) {
        *(byte *)(iVar3 + iVar2 + 0x46e) = *(byte *)(iVar3 + iVar2 + 0x46e) & 0xfe;
      }
      iVar3 = iVar3 + 0x5a4;
      iVar7 = iVar7 + 0x5a4;
    }
    *(byte *)(param_1 + 0xd94) = *(byte *)(param_1 + 0xd94) | 1;
    *(byte *)(param_1 + 0xdcc) = *(byte *)(param_1 + 0xdcc) | 1;
    *(byte *)(param_1 + 0xe04) = *(byte *)(param_1 + 0xe04) | 1;
    *(byte *)(param_1 + 0xe3c) = *(byte *)(param_1 + 0xe3c) | 1;
    *(byte *)(param_1 + 0xeaa) = *(byte *)(param_1 + 0xeaa) | 1;
    *(byte *)(param_1 + 0x1168) = *(byte *)(param_1 + 0x1168) | 1;
    *(byte *)(param_1 + 0xf16) = *(byte *)(param_1 + 0xf16) | 1;
    *(byte *)(param_1 + 0xfb8) = *(byte *)(param_1 + 0xfb8) | 1;
    *(byte *)(param_1 + 0x1090) = *(byte *)(param_1 + 0x1090) | 1;
    *(byte *)(param_1 + 0x1338) = *(byte *)(param_1 + 0x1338) | 1;
    *(byte *)(param_1 + 0x13a8) = *(byte *)(param_1 + 0x13a8) | 1;
    *(byte *)(param_1 + 0x13e0) = *(byte *)(param_1 + 0x13e0) | 1;
    *(byte *)(param_1 + 0x155c) = *(byte *)(param_1 + 0x155c) | 1;
    *(byte *)(param_1 + 0x170c) = *(byte *)(param_1 + 0x170c) | 1;
    *(byte *)(param_1 + 0x1634) = *(byte *)(param_1 + 0x1634) | 1;
    pbVar1 = (byte *)(param_1 + 0x18dc);
    for (iVar3 = 8; iVar3 != 0; iVar3 = iVar3 + -1) {
      *pbVar1 = *pbVar1 | 1;
      pbVar1[0x38] = pbVar1[0x38] | 1;
      pbVar1[0x70] = pbVar1[0x70] | 1;
      pbVar1[0xa8] = pbVar1[0xa8] | 1;
      pbVar1[0x116] = pbVar1[0x116] | 1;
      pbVar1[0x182] = pbVar1[0x182] | 1;
      pbVar1[0x224] = pbVar1[0x224] | 1;
      pbVar1[0x3d4] = pbVar1[0x3d4] | 1;
      pbVar1[0x2fc] = pbVar1[0x2fc] | 1;
      pbVar1 = pbVar1 + 0x5a4;
    }
    iVar3 = param_1 + 0x12e6;
    for (iVar7 = 0; iVar7 != 10; iVar7 = iVar7 + 1) {
      for (iVar9 = 0; iVar9 != 0x1a; iVar9 = iVar9 + 1) {
        *(char *)(iVar3 + iVar9) = (char)iVar9;
      }
      iVar3 = iVar3 + 0x5a4;
      *(undefined2 *)(iVar7 * 0x5a4 + param_1 + 0x1300) = 0;
    }
    return;
  }
  uVar8 = 0;
  iVar2 = iVar3 * 0x5a4 + param_1;
  iVar9 = iVar7;
  do {
    switch(uVar8) {
    case 0:
      puVar6 = &DAT_602a73ce;
      iVar5 = iVar2 + 0xe78;
      break;
    case 1:
    case 2:
    case 5:
    case 9:
    case 10:
    case 0xb:
    case 0xc:
      goto switchD_60037d66_caseD_1;
    case 3:
      puVar6 = &DAT_602a71d6;
      iVar5 = iVar2 + 0xf1a;
      break;
    case 4:
      puVar6 = &DAT_602a7884;
      iVar5 = iVar2 + 0xf50;
      break;
    case 6:
      puVar6 = &DAT_602a6e4c;
      iVar5 = iVar2 + 0xfbc;
      break;
    case 7:
      iVar5 = iVar2 + 0xff2;
      puVar6 = &DAT_602a6e4c;
      break;
    case 8:
      iVar5 = iVar2 + 0x1028;
      puVar6 = &DAT_602a72b6;
      break;
    case 0xd:
      iVar5 = iVar2 + 0x1136;
      puVar6 = &UNK_602a784c;
      break;
    default:
      if (uVar8 == 0x15) goto LAB_60037de4;
switchD_60037d66_caseD_1:
      if ((uVar8 < 0xb) && ((1 << (uVar8 & 0xff) & 0x602U) != 0)) {
        puVar6 = &DAT_602a75a4;
      }
      else {
        puVar6 = &DAT_602a7262;
      }
      iVar5 = iVar9;
      puVar6 = puVar6 + (uint)(byte)(&DAT_602a75cf)[uVar8] * 0x1c;
    }
    CopyBytes(iVar5,puVar6,0x1c);
    iVar9 = iVar9 + 0x36;
    uVar8 = uVar8 + 1;
  } while( true );
LAB_60037de4:
  iVar7 = iVar7 + 0x5a4;
  iVar3 = iVar3 + 1;
  goto LAB_60037d28;
}
