
void FUN_60022138(void)

{
  if (iRam2000b0a8 != 0) {
    FUN_601667bc();
    iRam2000b0a8 = 0;
    FUN_60163bbe(0x2008b0e4);
    return;
  }
  return;
}
