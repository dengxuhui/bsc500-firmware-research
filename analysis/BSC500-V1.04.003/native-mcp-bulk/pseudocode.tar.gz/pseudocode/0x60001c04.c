
undefined4 FUN_60001c04(undefined4 *param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_34 [5];
  undefined4 local_20;
  undefined4 uStack_1c;
  
  ZeroBytes(local_34,0x24);
  if ((param_1 == (undefined4 *)0x0) || (param_2 == (int *)0x0)) {
    FUN_60167f3c(3,"MSG_SVC",1,"%s invalid parameter\r\n","msgSrv_create");
    uVar2 = 0;
  }
  else {
    iVar1 = FUN_6011e4a8(*param_1,0xc,0);
    param_2[1] = iVar1;
    if (iVar1 == 0) {
      FUN_60167f3c(3,"MSG_SVC",1,"%s queue creat failed\r\n","msgSrv_create");
      FUN_60167f3c(0,"NO_TAG",1,"(%s) has assert failed at %s:%ld.",&DAT_60434315,"msgSrv_create",
                   0x2d);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    iVar1 = FUN_60003600();
    param_2[2] = iVar1;
    if (iVar1 == 0) {
      FUN_60167f3c(3,"MSG_SVC",1,"%s listener_manager creat failed\r\n","msgSrv_create");
      FUN_60167f3c(0,"NO_TAG",1,"(%s) has assert failed at %s:%ld.",&DAT_60434315,"msgSrv_create",
                   0x35);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    local_34[0] = param_1[1];
    local_20 = param_1[2];
    uStack_1c = param_1[3];
    param_2[3] = param_1[4];
    iVar1 = FUN_601566b4(&UNK_600036c9,param_2,local_34);
    *param_2 = iVar1;
    FUN_60156808();
    if (*param_2 == 0) {
      FUN_60167f3c(3,"MSG_SVC",1,"%s thread creat failed\r\n","msgSrv_create");
      FUN_60167f3c(0,"NO_TAG",1,"(%s) has assert failed at %s:%ld.",&DAT_60434315,"msgSrv_create",
                   0x49);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    uVar2 = 1;
  }
  return uVar2;
}
