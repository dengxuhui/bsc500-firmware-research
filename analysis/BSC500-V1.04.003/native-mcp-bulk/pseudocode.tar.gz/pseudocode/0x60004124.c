
void InitializeBacklight(void)

{
  undefined2 uVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  undefined4 uVar5;
  byte bVar6;
  uint uVar7;
  char local_7c [67];
  char local_39;
  int local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  
  FUN_60168578("[BL_CSV] Initializing backlight CSV config...\n");
  local_28 = 0;
  FUN_60168578("[BL_CSV] Trying to open Slider file: %s\n","0:level.txt");
  iVar2 = FUN_60166758(&local_28,"0:level.txt",1);
  if (iVar2 == 0) {
    FUN_60168578("[BL_CSV] Slider file opened successfully\n");
    DAT_20009a4f = 0;
    ZeroBytes(local_7c,0x40);
    iVar2 = 0;
    bVar6 = 0;
    while (bVar6 < 0x14) {
      iVar4 = FUN_60161ef4(local_28,&local_39,1,&local_38);
      if ((iVar4 != 0) || (local_38 == 0)) {
        if ((0 < iVar2) && (DAT_20009a4f < 0x14)) {
          local_7c[iVar2] = '\0';
          iVar2 = SplitCsvFields(local_7c,&local_34,2);
          if (iVar2 == 2) {
            uVar1 = FUN_6016811c(local_34);
            bVar6 = DAT_20009a4f;
            uVar7 = (uint)DAT_20009a4f;
            *(undefined2 *)(uVar7 * 4 + 0x20009a52) = uVar1;
            uVar1 = FUN_6016811c(local_30);
            *(undefined2 *)(uVar7 * 4 + 0x20009a54) = uVar1;
            DAT_20009a4f = bVar6 + 1;
          }
        }
        break;
      }
      bVar6 = DAT_20009a4f;
      if (local_39 == '\r' || local_39 == '\n') {
        if (0 < iVar2) {
          local_7c[iVar2] = '\0';
          iVar4 = SplitCsvFields(local_7c,&local_34,2);
          iVar2 = 0;
          bVar6 = DAT_20009a4f;
          if (iVar4 == 2) {
            uVar1 = FUN_6016811c(local_34);
            bVar6 = DAT_20009a4f;
            uVar7 = (uint)DAT_20009a4f;
            *(undefined2 *)(uVar7 * 4 + 0x20009a52) = uVar1;
            uVar1 = FUN_6016811c(local_30);
            *(undefined2 *)(uVar7 * 4 + 0x20009a54) = uVar1;
            DAT_20009a4f = bVar6 + 1;
            iVar2 = 0;
            bVar6 = DAT_20009a4f;
          }
        }
      }
      else if (iVar2 < 0x3f) {
        local_7c[iVar2] = local_39;
        iVar2 = iVar2 + 1;
      }
    }
    FUN_601667bc(local_28);
    if (DAT_20009a4f == 0) {
      pcVar3 = "[BL_CSV] Slider CSV load failed or empty\n";
      goto LAB_6000414c;
    }
    DAT_20009a4c = '\x01';
    FUN_60168578("[BL_CSV] Slider CSV loaded, %d levels:\n");
    for (uVar7 = 0; uVar7 < DAT_20009a4f; uVar7 = uVar7 + 1) {
      FUN_60168578("  [%d] pos=%d, brightness=%d\n",uVar7,*(undefined2 *)(uVar7 * 4 + 0x20009a52),
                   *(undefined2 *)(uVar7 * 4 + 0x20009a54));
    }
  }
  else {
    pcVar3 = "[BL_CSV] Failed to open Slider file\n";
LAB_6000414c:
    FUN_60168578(pcVar3);
  }
  local_28 = 0;
  FUN_60168578("[BL_CSV] Trying to open ALS file: %s\n","0:light.txt");
  iVar2 = FUN_60166758(&local_28,"0:light.txt",1);
  if (iVar2 == 0) {
    FUN_60168578("[BL_CSV] ALS file opened successfully\n");
    DAT_20009a50 = 0;
    ZeroBytes(local_7c,0x40);
    iVar2 = 0;
    bVar6 = 0;
    while (bVar6 < 0x32) {
      iVar4 = FUN_60161ef4(local_28,&local_39,1,&local_38);
      if ((iVar4 != 0) || (local_38 == 0)) {
        if ((0 < iVar2) && (DAT_20009a50 < 0x32)) {
          local_7c[iVar2] = '\0';
          iVar2 = SplitCsvFields(local_7c,&local_34,3);
          if (iVar2 == 3) {
            uVar5 = FUN_6016811c(local_34);
            bVar6 = DAT_20009a50;
            uVar7 = (uint)DAT_20009a50;
            *(undefined4 *)(uVar7 * 8 + 0x2007e984) = uVar5;
            iVar2 = uVar7 * 8;
            uVar1 = FUN_6016811c(local_30);
            *(undefined2 *)(iVar2 + 0x2007e988) = uVar1;
            uVar1 = FUN_6016811c(local_2c);
            *(undefined2 *)(iVar2 + 0x2007e98a) = uVar1;
            DAT_20009a50 = bVar6 + 1;
          }
        }
        break;
      }
      bVar6 = DAT_20009a50;
      if (local_39 == '\r' || local_39 == '\n') {
        if (0 < iVar2) {
          local_7c[iVar2] = '\0';
          iVar4 = SplitCsvFields(local_7c,&local_34,3);
          iVar2 = 0;
          bVar6 = DAT_20009a50;
          if (iVar4 == 3) {
            uVar5 = FUN_6016811c(local_34);
            bVar6 = DAT_20009a50;
            uVar7 = (uint)DAT_20009a50;
            *(undefined4 *)(uVar7 * 8 + 0x2007e984) = uVar5;
            iVar2 = uVar7 * 8;
            uVar1 = FUN_6016811c(local_30);
            *(undefined2 *)(iVar2 + 0x2007e988) = uVar1;
            uVar1 = FUN_6016811c(local_2c);
            *(undefined2 *)(iVar2 + 0x2007e98a) = uVar1;
            DAT_20009a50 = bVar6 + 1;
            iVar2 = 0;
            bVar6 = DAT_20009a50;
          }
        }
      }
      else if (iVar2 < 0x3f) {
        local_7c[iVar2] = local_39;
        iVar2 = iVar2 + 1;
      }
    }
    FUN_601667bc(local_28);
    if (DAT_20009a50 != 0) {
      DAT_20009a4d = '\x01';
      FUN_60168578("[BL_CSV] ALS CSV loaded, %d levels:\n");
      for (uVar7 = 0; uVar7 < DAT_20009a50; uVar7 = uVar7 + 1) {
        FUN_60168578("  [%d] lux=%d, day=%d, night=%d\n",uVar7,
                     *(undefined4 *)(uVar7 * 8 + 0x2007e984),*(undefined2 *)(uVar7 * 8 + 0x2007e988)
                     ,*(undefined2 *)(uVar7 * 8 + 0x2007e98a));
      }
      goto LAB_60004176;
    }
    pcVar3 = "[BL_CSV] ALS CSV load failed or empty\n";
  }
  else {
    pcVar3 = "[BL_CSV] Failed to open ALS file\n";
  }
  FUN_60168578(pcVar3);
LAB_60004176:
  if ((DAT_20009a4c == '\0') && (DAT_20009a4d != '\x01')) {
    pcVar3 = "[BL_CSV] CSV mode DISABLED (no CSV files found)\n";
  }
  else {
    DAT_20009a4e = 1;
    pcVar3 = "[BL_CSV] CSV mode ENABLED\n";
  }
  FUN_60168578(pcVar3);
  return;
}
