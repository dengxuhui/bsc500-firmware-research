
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600106d4(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  
  iVar1 = _DAT_2000bc64;
  if ((DAT_2000bc60 == '\x01') &&
     (iVar2 = FUN_6001b6a0(param_1,_DAT_2000bc64,param_3,param_4,param_4),
     _DAT_2000bc68 != _DAT_2000bc6c)) {
    uVar3 = param_1 + iVar1 + 0x259d4c00;
    if (((uint)(_DAT_2000bc68 + iVar2 + _DAT_2000bc64 + param_2) < uVar3) &&
       (uVar3 < (uint)(((iVar2 + _DAT_2000bc64) - param_2) + _DAT_2000bc6c))) {
      return 1;
    }
  }
  return 0;
}
