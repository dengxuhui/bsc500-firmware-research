
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60033eb8 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4
FUN_60033ad0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5
            ,int param_6,undefined4 param_7,uint param_8,undefined4 param_9,undefined4 *param_10,
            uint *param_11,uint *param_12,undefined4 *param_13,undefined4 *param_14)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  ushort uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  uint uVar15;
  uint uVar16;
  undefined4 *puVar17;
  uint uVar18;
  uint *puVar19;
  int iVar20;
  int iVar21;
  int iVar22;
  int iVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  uint uVar26;
  int iVar27;
  uint uVar28;
  int iVar29;
  uint uVar30;
  undefined4 uVar31;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  undefined4 extraout_s1_05;
  undefined4 extraout_s1_06;
  undefined4 extraout_s1_07;
  undefined4 uVar32;
  undefined4 uVar33;
  undefined4 uVar34;
  undefined4 uVar35;
  undefined8 uVar36;
  undefined8 uVar37;
  undefined8 uVar38;
  undefined8 uVar39;
  undefined8 uVar40;
  undefined8 uVar41;
  undefined8 uVar42;
  undefined8 uVar43;
  int local_fc;
  uint local_ac;
  uint local_a8;
  undefined4 local_a4;
  undefined4 local_a0;
  undefined4 local_9c;
  undefined4 local_7c;
  undefined8 local_78;
  undefined1 local_70 [8];
  
  uVar36 = FUN_601678fc();
  uVar6 = FUN_601682c8((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x3fe00000);
  uVar6 = FUN_60137818(uVar6);
  uVar7 = FUN_60167a50(uVar6,extraout_s1);
  uVar36 = FUN_601678fc(param_3,param_4,0,0x41900000);
  uVar6 = FUN_601682c8((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x3fe00000);
  uVar6 = FUN_60137818(uVar6);
  uVar8 = FUN_60167a50(uVar6,extraout_s1_00);
  uVar2 = *(ushort *)(param_5 + 0xc);
  uVar3 = *(ushort *)(param_5 + 0xe);
  uVar6 = FUN_60133450(param_3,param_8);
  uVar31 = FUN_60133498(param_8);
  uVar36 = FUN_60165558();
  uVar37 = FUN_601682c8(uVar6,extraout_s1_01);
  uVar38 = FUN_60165558(param_3,param_4);
  uVar36 = FUN_601678fc((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x41900000);
  uVar6 = FUN_601682c8((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x3fe00000);
  uVar6 = FUN_60137818(uVar6);
  uVar9 = FUN_60167a50(uVar6,extraout_s1_03);
  uVar36 = FUN_601678fc((int)uVar37,(int)((ulonglong)uVar37 >> 0x20),0,0x41900000);
  uVar6 = FUN_601682c8((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x3fe00000);
  uVar6 = FUN_60137818(uVar6);
  uVar10 = FUN_60167a50(uVar6,extraout_s1_04);
  uVar4 = (short)(uVar10 >> 0x10) - *(short *)(param_5 + 0xc);
  uVar5 = (short)(uVar9 >> 0x10) - *(short *)(param_5 + 0xc);
  iVar11 = (uVar8 >> 0x10) - (uint)uVar3;
  uVar36 = FUN_601682c8(uVar31,extraout_s1_02,param_3,param_4);
  uVar37 = FUN_601678fc((int)uVar38,(int)((ulonglong)uVar38 >> 0x20),0,0x41900000);
  uVar6 = FUN_601682c8((int)uVar37,(int)((ulonglong)uVar37 >> 0x20),0,0x3fe00000);
  uVar6 = FUN_60137818(uVar6);
  uVar8 = FUN_60167a50(uVar6,extraout_s1_05);
  uVar36 = FUN_601678fc((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x41900000);
  uVar6 = FUN_601682c8((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x3fe00000);
  uVar6 = FUN_60137818(uVar6);
  uVar12 = FUN_60167a50(uVar6,extraout_s1_06);
  iVar20 = (int)(short)iVar11;
  iVar21 = (uVar7 >> 0x10) - (uint)uVar2;
  iVar22 = (int)(short)iVar21;
  uVar2 = (short)(uVar12 >> 0x10) - *(short *)(param_5 + 0xe);
  uVar3 = (short)(uVar8 >> 0x10) - *(short *)(param_5 + 0xe);
  iVar23 = 0;
  local_a0 = 0x7ffffff;
  local_9c = 0xffffffff;
  local_a4 = 0x7ffffff;
  local_7c = 0x7ffffff;
  local_a8 = 0xffffffff;
  local_ac = 0xffffffff;
  uVar6 = extraout_s1_06;
  do {
    uVar7 = iVar11 - iVar23;
    local_fc = 0;
    for (uVar30 = iVar21 - iVar23; iVar27 = (int)(short)uVar30, iVar27 <= iVar22 + iVar23;
        uVar30 = uVar30 + 1) {
      if ((((-1 < iVar27) && (iVar27 <= (short)uVar4)) && ((short)uVar5 <= iVar27)) &&
         (iVar27 < *(short *)(param_5 + 8))) {
        iVar13 = iVar27 - iVar22;
        uVar28 = uVar7;
        if (iVar13 < 0) {
          iVar13 = -iVar13;
        }
        while( true ) {
          iVar29 = (int)(short)uVar28;
          if (iVar23 + iVar20 < iVar29) break;
          if (((-1 < iVar29) && (iVar29 <= (short)uVar2)) &&
             (((short)uVar3 <= iVar29 && (iVar29 < *(short *)(param_5 + 10))))) {
            if (iVar13 < iVar23) {
              iVar14 = iVar29 - iVar20;
              if (iVar14 < 0) {
                iVar14 = -iVar14;
              }
              if (iVar14 < iVar23) goto LAB_60034182;
            }
            iVar14 = (int)*(short *)(param_5 + 8) * (int)(short)uVar28 + iVar27;
            uVar15 = FUN_60133560(param_5,iVar14);
            uVar16 = FUN_60133560(param_5,iVar14 + 1);
            for (; uVar15 < uVar16; uVar15 = uVar15 + 1) {
              puVar17 = (undefined4 *)FUN_6012ece8(param_5,uVar15,3);
              if (((((uVar30 & 0xffff) != (uint)uVar5) ||
                   ((uVar9 & 0xffff) <= (uint)*(ushort *)(puVar17 + 1))) &&
                  ((((uVar30 & 0xffff) != (uint)uVar4 ||
                    ((uint)*(ushort *)(puVar17 + 1) <= (uVar10 & 0xffff))) &&
                   (((uVar28 & 0xffff) != (uint)uVar3 ||
                    ((uVar8 & 0xffff) <= (uint)*(ushort *)((int)puVar17 + 6))))))) &&
                 ((uVar1 = *(ushort *)((int)puVar17 + 6), (uVar28 & 0xffff) != (uint)uVar2 ||
                  ((uint)uVar1 <= (uVar12 & 0xffff))))) {
                uVar36 = FUN_6016759c((uint)*(ushort *)(puVar17 + 1) |
                                      ((uint)*(ushort *)(param_5 + 0xc) + iVar27) * 0x10000);
                uVar31 = FUN_601678fc((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x3e500000);
                uVar36 = FUN_6016759c((uint)uVar1 |
                                      ((uint)*(ushort *)(param_5 + 0xe) + iVar29) * 0x10000);
                uVar36 = FUN_601678fc((int)uVar36,(int)((ulonglong)uVar36 >> 0x20),0,0x3e500000);
                uVar24 = (undefined4)((ulonglong)uVar36 >> 0x20);
                uVar18 = FUN_601335f0(uVar31,uVar6,(int)uVar36,uVar24);
                if (uVar18 < param_8) {
                  puVar19 = (uint *)FUN_6011fdbe(param_6,*puVar17,1);
                  uVar37 = FUN_601673c4(uVar18);
                  uVar25 = (undefined4)((ulonglong)uVar37 >> 0x20);
                  uVar38 = FUN_601678fc((int)uVar37,uVar25,(int)uVar37,uVar25);
                  uVar25 = (undefined4)((ulonglong)uVar38 >> 0x20);
                  do {
                    if ((int)((uint)*(byte *)((int)puVar19 + 0x13) << 0x1c) < 0) {
                      uVar26 = *puVar19;
                      if (uVar26 == uVar15) {
                        uVar26 = puVar19[1];
                      }
                      FUN_60136908(param_5,uVar26,0,local_70);
                      uVar34 = local_70._0_4_;
                      uVar32 = (undefined4)local_78;
                      uVar35 = local_70._4_4_;
                      uVar33 = (undefined4)((ulonglong)local_78 >> 0x20);
                      iVar14 = FUN_601335f0(uVar34,uVar6,uVar32,uVar33);
                      uVar26 = FUN_601335f0(uVar31,uVar6,(int)uVar36,uVar24,uVar34,uVar35,uVar32,
                                            uVar33);
                      uVar40 = uVar37;
                      if (uVar26 == 0) {
                        uVar42 = FUN_601673c4(iVar14);
                        uVar41 = uVar37;
                      }
                      else {
                        uVar39 = FUN_601673c4(iVar14);
                        uVar32 = (undefined4)((ulonglong)uVar39 >> 0x20);
                        uVar42 = uVar39;
                        uVar41 = 0;
                        if (uVar26 <= iVar14 + uVar18) {
                          uVar40 = FUN_601678fc((int)uVar39,uVar32,(int)uVar39,uVar32);
                          uVar41 = FUN_60165558((int)uVar38,uVar25,(int)uVar40,
                                                (int)((ulonglong)uVar40 >> 0x20));
                          uVar40 = FUN_601673c4(uVar26);
                          uVar34 = (undefined4)((ulonglong)uVar40 >> 0x20);
                          uVar32 = (undefined4)uVar40;
                          uVar42 = FUN_601678fc(uVar32,uVar34,uVar32,uVar34);
                          uVar41 = FUN_601682c8((int)uVar41,(int)((ulonglong)uVar41 >> 0x20),
                                                (int)uVar42,(int)((ulonglong)uVar42 >> 0x20));
                          uVar42 = FUN_601682c8(uVar32,uVar34,uVar32,uVar34);
                          uVar43 = FUN_601675d8((int)uVar41,(int)((ulonglong)uVar41 >> 0x20),
                                                (int)uVar42,(int)((ulonglong)uVar42 >> 0x20));
                          uVar35 = (undefined4)((ulonglong)uVar43 >> 0x20);
                          uVar33 = (undefined4)uVar43;
                          uVar42 = FUN_60165558(uVar32,uVar34,uVar33,uVar35);
                          iVar14 = FUN_60167bc4(uVar33,uVar35,0,0);
                          if ((iVar14 == 0) &&
                             (iVar14 = FUN_60167bc4((int)uVar42,(int)((ulonglong)uVar42 >> 0x20),0,0
                                                   ), iVar14 == 0)) {
                            uVar40 = FUN_601678fc(uVar33,uVar35,uVar33,uVar35);
                            uVar6 = FUN_60165558((int)uVar38,uVar25,(int)uVar40,
                                                 (int)((ulonglong)uVar40 >> 0x20));
                            uVar6 = FUN_6015d550(uVar6);
                            uVar41 = CONCAT44(extraout_s1_07,uVar6);
                            uVar40 = uVar43;
                            uVar6 = extraout_s1_07;
                          }
                          else {
                            iVar14 = FUN_60167b9a(uVar33,uVar35,0,0);
                            uVar41 = uVar39;
                            if (iVar14 == 0) {
                              uVar41 = uVar37;
                            }
                            iVar14 = FUN_60167b9a(uVar33,uVar35,0,0);
                            uVar42 = 0;
                            if (iVar14 == 0) {
                              uVar42 = uVar40;
                            }
                            iVar14 = FUN_60167b9a(uVar33,uVar35,0,0);
                            if (iVar14 == 0) {
                              uVar40 = 0;
                            }
                          }
                        }
                      }
                      uVar32 = (undefined4)((ulonglong)uVar41 >> 0x20);
                      uVar39 = FUN_601673c4(local_7c);
                      iVar14 = FUN_60167ba8((int)uVar41,uVar32,(int)uVar39,
                                            (int)((ulonglong)uVar39 >> 0x20));
                      if (iVar14 == 0) {
                        local_ac = *puVar19;
                        local_9c = *(undefined4 *)
                                    (param_6 + (((int)puVar19 - (param_6 + 0x10)) / 0x14) * 4 + 0x60
                                    );
                        uVar39 = uVar40;
                        local_a8 = uVar15;
                        if (local_ac == uVar15) {
                          uVar39 = uVar42;
                          uVar42 = uVar40;
                          local_ac = uVar15;
                          local_a8 = puVar19[1];
                        }
                        local_a4 = FUN_6015e530((int)uVar42,(int)((ulonglong)uVar42 >> 0x20));
                        local_a0 = FUN_6015e530((int)uVar39,(int)((ulonglong)uVar39 >> 0x20));
                        local_7c = FUN_6015e530((int)uVar41,uVar32);
                      }
                    }
                    puVar19 = (uint *)FUN_600354ec(param_6,puVar19,uVar15);
                  } while (puVar19 != (uint *)0x0);
                }
              }
            }
            local_fc = local_fc + 1;
          }
LAB_60034182:
          uVar28 = uVar28 + 1;
        }
      }
    }
    iVar23 = iVar23 + 1;
    if (local_fc == 0) {
      *param_10 = local_7c;
      *param_11 = local_ac;
      *param_12 = local_a8;
      *param_13 = local_a4;
      *param_14 = local_a0;
      return local_9c;
    }
  } while( true );
}
