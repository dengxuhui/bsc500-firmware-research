
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000fba4(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_60019e10();
  FUN_60161424("ble_adapter[%d][%d:%d][%d:%d]\n",uVar1,_DAT_20008f90,_DAT_20008f94,_DAT_20008f88,
               _DAT_20008f8c);
  return;
}
