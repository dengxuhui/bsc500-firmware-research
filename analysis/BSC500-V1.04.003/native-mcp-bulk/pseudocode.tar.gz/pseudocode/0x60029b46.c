
undefined4
FUN_60029b46(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_60156a08(param_2,param_3,param_4,param_5);
  uVar2 = 0;
  if (iVar1 != 0) {
    uVar2 = 0xc;
  }
  return uVar2;
}
