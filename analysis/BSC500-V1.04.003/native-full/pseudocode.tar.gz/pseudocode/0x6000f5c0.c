
void FUN_6000f5c0(void)

{
  ushort uVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  
  iVar3 = DAT_6000f648;
  thunk_EXT_FUN_000219ea(DAT_6000f648,0,0x9ee0);
  FUN_60019b24(iVar3);
  FUN_60019720(iVar3 + 0x6e74);
  iVar4 = DAT_6000f64c;
  uVar1 = *(ushort *)(DAT_6000f64c + 0x48c0);
  uVar5 = *(undefined4 *)(DAT_6000f64c + 0x48c4);
  bVar2 = (byte)uVar1;
  *(byte *)(iVar3 + 0x6e68) = bVar2 & 1;
  *(undefined4 *)(iVar3 + 0x6e6c) = uVar5;
  *(byte *)(iVar3 + 0x6e6b) = *(byte *)(iVar4 + 0x74) & 1;
  *(byte *)(iVar3 + 0x6e70) = (byte)(((uint)uVar1 << 0x17) >> 0x1f);
  *(byte *)(iVar3 + 0x6e6a) = bVar2 >> 4;
  *(byte *)(iVar3 + 0x6e69) = (byte)(((uint)bVar2 << 0x1c) >> 0x1d);
  if (*(code **)(iVar3 + 0x6e4c) != (code *)0x0) {
    (**(code **)(iVar3 + 0x6e4c))(DAT_6000f648,*DAT_6000f650);
  }
  if (*(code **)(iVar3 + 0x6e50) != (code *)0x0) {
    (**(code **)(iVar3 + 0x6e50))(iVar3,iVar3 + 0x6e68);
  }
  FUN_601614d0();
  *(undefined1 *)(iVar3 + 0x9d7c) = 0;
  return;
}

