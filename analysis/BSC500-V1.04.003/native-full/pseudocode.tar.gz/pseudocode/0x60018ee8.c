
undefined4 FUN_60018ee8(int param_1)

{
  int iVar1;
  float fVar2;
  undefined4 uVar3;
  int iVar4;
  char cVar5;
  int iVar6;
  code *pcVar7;
  uint in_fpscr;
  undefined8 uVar8;
  undefined8 uVar9;
  undefined1 auStack_88 [32];
  undefined8 local_68;
  undefined8 local_60;
  float local_58;
  undefined4 local_50;
  undefined4 local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_34;
  
  iVar1 = DAT_600191a0;
  cVar5 = *(char *)(DAT_600191a0 + 0x40);
  *(undefined1 *)(DAT_600191a0 + 0x68) = 1;
  if (cVar5 == '\x03') {
    FUN_6014a9b0();
    cVar5 = *(char *)(iVar1 + 0x40);
  }
  uVar3 = 0xffffffff;
  if ((cVar5 == '\x01') && (param_1 != 0)) {
    iVar4 = FUN_60168220(param_1);
    if (iVar4 - 5U < 0x5a) {
      iVar6 = iVar4 + param_1 + -4;
      *(undefined1 *)(iVar1 + 0x40) = 2;
      iVar4 = FUN_60168418(iVar6,&DAT_600191a4);
      pcVar7 = DAT_600191ac;
      if ((((iVar4 == 0) ||
           (iVar4 = FUN_60168418(iVar6,&DAT_600191b0), pcVar7 = DAT_600191b8, iVar4 == 0)) ||
          (iVar4 = FUN_60168418(iVar6,&DAT_600191bc), pcVar7 = DAT_600191c4, iVar4 == 0)) &&
         (iVar4 = FUN_60021f00(param_1), iVar4 == 0)) {
        iVar4 = FUN_60022154(param_1);
        if (iVar4 == 0) {
          iVar4 = FUN_60021bf8(param_1);
          if (iVar4 == 0) {
            local_34 = 0;
            iVar4 = FUN_60166758(&local_34,param_1,1);
            if (iVar4 == 0) {
              local_3c = 1;
              local_44 = 1;
              local_40 = 0x7fffffff;
              local_4c = 0x7fffffff;
              local_48 = 0x7fffffff;
              local_50 = 0xffffffff;
              iVar4 = DAT_600191c8 + 8;
              FUN_60132d1c();
              ZeroBytes(&local_68,0x18);
              ZeroBytes(auStack_88,0x20);
              fVar2 = DAT_600191d4;
              do {
                do {
                  do {
                    iVar6 = FUN_6015d9d4(local_34);
                    if (iVar6 != 0) {
                      FUN_601667bc(local_34);
                      iVar4 = FUN_60132d28(iVar4,auStack_88);
                      if (iVar4 != 0) goto LAB_600190ca;
                      iVar4 = FUN_60021df4(auStack_88);
                      if (iVar4 != 0) goto LAB_600190ce;
                      iVar4 = FUN_60021fec(auStack_88);
                      if (iVar4 != 0) {
                        FUN_60021ee4();
                        goto LAB_600190d2;
                      }
                      iVar4 = FUN_6002183c(auStack_88);
                      if (iVar4 != 0) {
                        FUN_60021ee4();
                        FUN_60022138();
                        goto LAB_600190d6;
                      }
                      cVar5 = '\0';
                      *(undefined4 *)(iVar1 + 100) = 0;
                      *(undefined2 *)(iVar1 + 0x40) = 0x103;
                      iVar4 = FUN_6015e0d0();
                      if (iVar4 != 0) {
                        *(undefined4 *)(iVar1 + 0x50) = *(undefined4 *)(iVar4 + 0x20);
                      }
                      iVar4 = DAT_600191cc;
                      *(undefined1 *)(DAT_600191cc + 0x21) = 4;
                      uVar3 = DAT_600191d0;
                      *(undefined1 *)(iVar4 + 0x74) = 0;
                      *(undefined1 *)(iVar4 + 0x51) = 0;
                      *(undefined4 *)(iVar4 + 0x70) = uVar3;
                      uVar3 = *(undefined4 *)(iVar1 + 0x50);
                      *(undefined4 *)(iVar4 + 0xa4) = 0;
                      *(undefined4 *)(iVar4 + 0xa8) = uVar3;
                      if (*(byte *)(iVar1 + 0x42) < 3) {
                        cVar5 = *(byte *)(iVar1 + 0x42) + 1;
                      }
                      *(char *)(iVar4 + 0x20) = cVar5;
                      iVar6 = FUN_601623fc();
                      if (iVar6 != 0) {
                        *(undefined4 *)(iVar4 + 0x54) = 0xffffffff;
                        *(undefined4 *)(iVar4 + 0x58) = 0xffffffff;
                        *(undefined4 *)(iVar4 + 0x5c) = 0xffffffff;
                        uVar3 = *(undefined4 *)(iVar6 + 4);
                        *(undefined4 *)(iVar4 + 0x68) = *(undefined4 *)(iVar6 + 8);
                        *(undefined4 *)(iVar4 + 0x6c) = uVar3;
                      }
                      if (*(code **)(iVar1 + 0x44) != (code *)0x0) {
                        (**(code **)(iVar1 + 0x44))(*(undefined1 *)(iVar1 + 0x42));
                      }
                      uVar3 = 0;
                      goto LAB_600190e2;
                    }
                    iVar6 = (*pcVar7)(local_34,&local_40,&local_48,&local_50,&local_4c,0);
                  } while (((iVar6 == -1) || (iVar6 = FUN_60166dd0(&local_40), iVar6 == 1)) ||
                          (iVar6 = FUN_60166dd0(&local_48), uVar3 = local_44, iVar6 == 1));
                  local_58 = (float)VectorSignedToFloat(local_4c,(byte)(in_fpscr >> 0x16) & 3);
                  local_58 = local_58 / fVar2;
                  uVar8 = FUN_6016759c(local_48);
                  uVar9 = FUN_6016759c(uVar3);
                  local_68 = FUN_601675d8((int)uVar8,(int)((ulonglong)uVar8 >> 0x20),(int)uVar9,
                                          (int)((ulonglong)uVar9 >> 0x20));
                  uVar3 = local_3c;
                  uVar8 = FUN_6016759c(local_40);
                  uVar9 = FUN_6016759c(uVar3);
                  local_60 = FUN_601675d8((int)uVar8,(int)((ulonglong)uVar8 >> 0x20),(int)uVar9,
                                          (int)((ulonglong)uVar9 >> 0x20));
                  iVar6 = FUN_60132c70(iVar4,&local_68,auStack_88);
                } while (iVar6 != 0);
                iVar6 = FUN_60030b8c(auStack_88);
                if (iVar6 != 0) {
                  FUN_6011c6ec();
LAB_60019116:
                  FUN_6011c710();
                  goto LAB_6001911a;
                }
                iVar6 = FUN_60030c34(auStack_88);
                if (iVar6 != 0) {
                  FUN_6011c750();
                  goto LAB_60019116;
                }
                iVar6 = FUN_60030a78(auStack_88);
              } while (iVar6 == 0);
              FUN_6011c750();
              FUN_6011c6ec();
LAB_6001911a:
              FUN_601667bc(local_34);
            }
            else {
LAB_600190ca:
              FUN_6011c750();
LAB_600190ce:
              FUN_6011c6ec();
LAB_600190d2:
              FUN_6011c710();
            }
          }
          else {
            FUN_6011c750();
            FUN_6011c6ec();
          }
        }
        else {
          FUN_6011c750();
        }
      }
LAB_600190d6:
      *(undefined2 *)(iVar1 + 0x40) = 0x201;
    }
    uVar3 = 0xffffffff;
  }
LAB_600190e2:
  *(undefined1 *)(iVar1 + 0x68) = 0;
  return uVar3;
}

