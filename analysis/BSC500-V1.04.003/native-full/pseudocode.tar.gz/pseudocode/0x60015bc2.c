
undefined4 FUN_60015bc2(undefined4 param_1,uint *param_2,uint *param_3)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  
  iVar2 = FUN_6015e0e8(param_2);
  if ((iVar2 == 0) && ((*param_2 & 0x1f) - 1 < 2)) {
    uVar4 = *param_3;
    uVar1 = (*param_2 >> 10 & 0x7ff) << 10;
    *param_3 = uVar4 & 0xffe003ff | uVar1;
    uVar3 = *param_2;
    *param_3 = uVar4 & 0x3ff | uVar1 | uVar3 & 0xffe00000;
    *param_3 = uVar4 & 0x3e0 | uVar1 | uVar3 & 0xffe00000 | *param_2 & 0x1f;
    return 1;
  }
  return 0;
}

