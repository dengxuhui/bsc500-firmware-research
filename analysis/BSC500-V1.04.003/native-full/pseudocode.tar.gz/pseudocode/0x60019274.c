
void FUN_60019274(void)

{
  int *piVar1;
  
  piVar1 = DAT_60019288;
  if (*DAT_60019288 != 0) {
    FUN_601667bc();
    *piVar1 = 0;
  }
  return;
}

