
void FUN_60011514(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uStack_14;
  
  iVar1 = DAT_600116f0;
  iVar2 = DAT_600115b0;
  uStack_14 = param_4 & 0xffff;
  if (param_1 == 0) {
    uVar5 = (uint)*(ushort *)(DAT_600116f0 + 0x16);
    if (uVar5 == 0) {
      if (*(char *)(DAT_600116f0 + 9) == '\0') {
        if (*(char *)(DAT_600116f0 + 1) == '\0') {
          uVar5 = 0x14;
          *(undefined2 *)(DAT_600116f0 + 0x16) = 0x14;
        }
        else {
          uVar5 = 0;
          iVar4 = DAT_600116f0 + 0x32;
          *(undefined1 *)(DAT_600116f0 + 1) = 0;
          CopyBytes(iVar2,iVar4,0x14,param_4,param_3);
        }
        *(short *)(iVar1 + 0x10) = *(short *)(iVar1 + 0x10) + 0x14;
        *(undefined1 *)(iVar1 + 9) = 1;
      }
      else {
        uVar5 = 0;
      }
    }
    if (uVar5 < *(ushort *)(iVar1 + 0x10)) {
      uVar3 = *(ushort *)(iVar1 + 0x10) - uVar5;
      if ((int)(uint)*DAT_600116f8 < (int)uVar3) {
        uVar3 = (uint)*DAT_600116f8;
      }
      uStack_14 = CONCAT22((short)uVar3,(undefined2)uStack_14);
      iVar2 = FUN_6012ea18(DAT_600115b0 + uVar5,(int)&uStack_14 + 2,0x7e);
      if (iVar2 == 0) {
        uVar5 = (uint)*(ushort *)(iVar1 + 0x16) + (uStack_14 >> 0x10);
        *(short *)(iVar1 + 0x16) = (short)uVar5;
      }
      else {
        uVar5 = (uint)*(ushort *)(iVar1 + 0x16);
      }
    }
    uVar3 = (uint)*(ushort *)(iVar1 + 0x10);
    if ((uVar5 & 0xffff) < uVar3) {
      return;
    }
    *(undefined1 *)(iVar1 + 9) = 0;
    *(undefined2 *)(iVar1 + 0x16) = 0;
    *(undefined1 *)(iVar1 + 6) = 0;
  }
  else {
    *(undefined1 *)(DAT_600116f0 + 9) = 0;
    *(undefined2 *)(iVar1 + 0x16) = 0;
    *(undefined1 *)(iVar1 + 6) = 0;
    uVar3 = (uint)*(ushort *)(iVar1 + 0x10);
  }
  ZeroBytes(DAT_600115b0,uVar3);
  *(undefined2 *)(DAT_600116f0 + 0x10) = 0;
  return;
}

