
undefined4 FUN_600164d0(int param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined2 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int unaff_r6;
  undefined4 uVar11;
  
  if (param_1 != 0) {
    unaff_r6 = param_2;
  }
  if ((param_1 != 0 && param_2 != 0) && (param_3 != (undefined4 *)0x0)) {
    uVar5 = *(undefined4 *)(unaff_r6 + 0x18c);
    *param_3 = *(undefined4 *)(unaff_r6 + 0x188);
    param_3[1] = uVar5;
    FUN_60118c40(unaff_r6 + 400,unaff_r6 + 0x198,param_3 + 2,param_3 + 3);
    uVar5 = *(undefined4 *)(unaff_r6 + 0x1b8);
    iVar3 = *(int *)(unaff_r6 + 0x188);
    iVar6 = *(int *)(unaff_r6 + 0x18c);
    param_3[6] = *(undefined4 *)(unaff_r6 + 0x1b4);
    param_3[7] = uVar5;
    uVar7 = *(uint *)(unaff_r6 + 0x1c8);
    param_3[8] = *(undefined4 *)(unaff_r6 + 0x1bc);
    uVar5 = *(undefined4 *)(unaff_r6 + 0x1c0);
    uVar4 = (iVar3 - iVar6) * 1000 + 1000;
    param_3[4] = uVar4;
    param_3[9] = uVar5;
    param_3[10] = *(undefined4 *)(unaff_r6 + 0x1c4);
    *(undefined2 *)(param_3 + 0x20) = *(undefined2 *)(unaff_r6 + 0x228);
    if (uVar4 < uVar7) {
      uVar7 = uVar4;
    }
    param_3[0xb] = uVar7;
    param_3[5] = uVar7;
    uVar2 = *(undefined2 *)(unaff_r6 + 0x22a);
    uVar5 = *(undefined4 *)(unaff_r6 + 0x230);
    uVar9 = *(undefined4 *)(unaff_r6 + 0x23a);
    param_3[0x21] = *(undefined4 *)(unaff_r6 + 0x22c);
    param_3[0x22] = uVar5;
    param_3[0x23] = uVar9;
    *(undefined2 *)((int)param_3 + 0x82) = uVar2;
    uVar8 = 0xffff;
    *(undefined2 *)((int)param_3 + 0x96) = *(undefined2 *)(unaff_r6 + 0x242);
    uVar5 = *(undefined4 *)(unaff_r6 + 0x218);
    param_3[0x1e] = *(undefined4 *)(unaff_r6 + 0x214);
    param_3[0x1f] = uVar5;
    iVar3 = *(int *)(unaff_r6 + 0x21c);
    *(undefined2 *)(param_3 + 0x27) = *(undefined2 *)(unaff_r6 + 0x248);
    uVar2 = 0xffff;
    if (iVar3 != 0x7fffffff) {
      uVar8 = (undefined2)((iVar3 + 50000) / 0x14);
    }
    iVar3 = *(int *)(unaff_r6 + 0x220);
    *(undefined2 *)((int)param_3 + 0x9e) = uVar8;
    uVar8 = 0xffff;
    if (iVar3 != 0x7fffffff) {
      uVar8 = (undefined2)((iVar3 + 50000) / 0x14);
    }
    uVar10 = *(undefined4 *)(unaff_r6 + 600);
    uVar5 = *(undefined4 *)(unaff_r6 + 0x24c);
    uVar9 = *(undefined4 *)(unaff_r6 + 0x250);
    uVar11 = *(undefined4 *)(unaff_r6 + 0x254);
    *(undefined2 *)(param_3 + 0x28) = uVar8;
    param_3[0x2c] = uVar10;
    *(undefined2 *)((int)param_3 + 0xa2) = *(undefined2 *)(unaff_r6 + 0x24a);
    param_3[0x29] = uVar5;
    param_3[0x2a] = uVar9;
    param_3[0x2b] = uVar11;
    if (*(int *)(unaff_r6 + 0x224) != 0x7fffffff) {
      uVar2 = (undefined2)((*(int *)(unaff_r6 + 0x224) + 50000) / 0x14);
    }
    *(undefined4 *)((int)param_3 + 0xc5) = *(undefined4 *)(unaff_r6 + 0x263);
    *(undefined2 *)((int)param_3 + 0xc9) = *(undefined2 *)(unaff_r6 + 0x267);
    uVar5 = *(undefined4 *)(unaff_r6 + 0x25f);
    *(undefined2 *)(param_3 + 0x2d) = uVar2;
    *(undefined4 *)((int)param_3 + 0xc1) = uVar5;
    *(undefined1 *)(param_3 + 0x30) = *(undefined1 *)(unaff_r6 + 0x25e);
    *(undefined2 *)((int)param_3 + 0xb6) = *(undefined2 *)(unaff_r6 + 0x234);
    *(undefined2 *)((int)param_3 + 0xba) = *(undefined2 *)(unaff_r6 + 0x236);
    *(undefined2 *)(param_3 + 0x2e) = *(undefined2 *)(unaff_r6 + 0x238);
    for (iVar3 = 0; iVar3 != 5; iVar3 = iVar3 + 1) {
      param_3[iVar3 + 0xc] = *(undefined4 *)(unaff_r6 + 0x1cc + iVar3 * 4);
    }
    for (iVar3 = 0; iVar3 != 6; iVar3 = iVar3 + 1) {
      param_3[iVar3 + 0x11] = *(undefined4 *)(unaff_r6 + 0x1e0 + iVar3 * 4);
    }
    for (iVar3 = 0; iVar3 != 7; iVar3 = iVar3 + 1) {
      param_3[iVar3 + 0x17] = *(undefined4 *)(unaff_r6 + 0x1f8 + iVar3 * 4);
    }
    *(undefined1 *)((int)param_3 + 0xbe) = 2;
    uVar5 = *(undefined4 *)(unaff_r6 + 0x244);
    *(undefined4 *)((int)param_3 + 0x92) = *(undefined4 *)(unaff_r6 + 0x23e);
    param_3[0x26] = uVar5;
    cVar1 = *(char *)(param_1 + 0x8d);
    if (cVar1 != '\x06') {
      cVar1 = '\a';
    }
    *(char *)((int)param_3 + 0xbf) = cVar1;
    return 0;
  }
  return 0xffffffff;
}

