
undefined4 FUN_60016d3c(void)

{
  byte *pbVar1;
  int iVar2;
  
  pbVar1 = DAT_60016db0;
  if ((*DAT_60016db0 == 0) && (iVar2 = FUN_601176c4(0x7e), iVar2 != 0)) {
    iVar2 = FUN_6001e400(*pbVar1 ^ 1);
    if (iVar2 == 0) goto LAB_60016d8c;
    *pbVar1 = 1;
  }
  else {
    if ((pbVar1[2] != 1) || ((iVar2 = FUN_601176c4(0x7e), iVar2 == 0 || (pbVar1[1] != 0)))) {
      return 0;
    }
    iVar2 = FUN_6001e400(*pbVar1 ^ 1);
    if (iVar2 == 0) goto LAB_60016d8c;
  }
  if (pbVar1[1] != 1) {
    return 0;
  }
LAB_60016d8c:
  pbVar1[0] = 0;
  pbVar1[1] = 0;
  return 1;
}

