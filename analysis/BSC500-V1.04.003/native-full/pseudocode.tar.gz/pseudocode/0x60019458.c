
void FUN_60019458(void)

{
  int iVar1;
  undefined1 auStack_a0 [12];
  uint local_94;
  undefined1 auStack_90 [63];
  undefined1 local_51;
  undefined1 auStack_50 [64];
  
  iVar1 = DAT_60019554;
  FUN_601608ac(DAT_60019554,0x3bc);
  FUN_60129756(iVar1 + 4,0x3b8);
  local_94 = 0;
  FUN_601681f4(auStack_50,DAT_60019558,DAT_6001955c,DAT_60019560);
  iVar1 = FUN_601609d0(auStack_a0,auStack_50,2);
  if (iVar1 == 0) {
    FUN_60160948(auStack_a0,0,0);
    FUN_6015c2f4(auStack_a0,auStack_90,0x40,&local_94);
    FUN_60160a64(auStack_a0);
    if (6 < local_94) {
      local_51 = 0;
      iVar1 = FUN_6016228c(auStack_90,0x3d);
      if ((iVar1 != 0) && (iVar1 = FUN_6016811c(iVar1 + 1), iVar1 == 0x6e)) {
        FUN_601681f4(auStack_50,DAT_60019558,DAT_6001955c,DAT_60019560);
        iVar1 = FUN_601609d0(auStack_a0,auStack_50,2);
        if (iVar1 != 0) {
          return;
        }
        FUN_60160948(auStack_a0,0,0);
        FUN_6015c2f4(auStack_a0,DAT_60019554,0x3bc,&local_94);
        goto LAB_6001954a;
      }
    }
  }
  for (iVar1 = 4; iVar1 != 0; iVar1 = iVar1 + -1) {
    FUN_6013f78c();
  }
  iVar1 = FUN_601609d0(auStack_a0,auStack_50,1);
  if (iVar1 != 0) {
    return;
  }
  FUN_601681f4(auStack_90,DAT_60019564,0x6e);
  FUN_60160948(auStack_a0,0,0);
  iVar1 = FUN_60168220(auStack_90);
  FUN_60160774(auStack_a0,auStack_90,iVar1 + 1,&local_94);
LAB_6001954a:
  FUN_60160a64(auStack_a0);
  return;
}

