
undefined4 FUN_6000867c(char *param_1,int param_2,int param_3)

{
  int *piVar1;
  short sVar2;
  char *pcVar3;
  char *pcVar4;
  undefined1 uVar5;
  int iVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  bool bVar10;
  int local_30;
  int iStack_2c;
  int local_28;
  int iStack_24;
  float local_20;
  
  pcVar4 = DAT_6000891c;
  iVar6 = *(int *)(DAT_6000891c + 8);
  piVar1 = (int *)(DAT_6000891c + 0xc);
  *(int *)(DAT_6000891c + 8) = iVar6 + -1;
  *(uint *)(pcVar4 + 0xc) = *piVar1 - (uint)(iVar6 == 0);
  iVar6 = FUN_601499b0();
  pcVar3 = DAT_60008920;
  if (iVar6 == 0) {
LAB_6000871e:
    if (((param_3 == 1) && ((int)*(short *)(param_1 + 0x24) != 0x7fff)) &&
       ((*(char *)(param_2 + 0x32b) != '\x01' || (*param_1 == '\0')))) {
      if (((*(char *)(param_2 + 0x329) == '\0') ||
          (*(uint *)(param_2 + 4) < (uint)(int)*(short *)(param_1 + 0x24))) || (*param_1 != '\0')) {
LAB_6000874e:
        cVar7 = '\x06';
      }
      else {
        local_20 = 0.0;
        iVar6 = FUN_6011679c(*(undefined2 *)(param_1 + 0xd0),param_1[0xd9],param_1[0xd8],
                             *(undefined2 *)(param_1 + 0xd4));
        if (iVar6 == 0) {
          local_30 = *(int *)(param_1 + 0xbc);
          iStack_2c = *(int *)(param_1 + 0xc0);
          local_28 = *(int *)(param_1 + 0xb4);
          iStack_24 = *(int *)(param_1 + 0xb8);
          if (((iStack_2c != 0) && (iStack_24 != 0)) &&
             (local_28 != 0x7fffffff && local_30 != 0x7fffffff)) {
            sVar2 = *(short *)(param_1 + 200);
            if (sVar2 != 0x7fff) {
              cVar7 = *DAT_60008920;
              if (cVar7 == '\x06') {
                iVar6 = 0;
                bVar10 = true;
              }
              else {
                FUN_60118418(&local_20,&local_28,&local_30,pcVar4 + 0x10,pcVar4 + 0x18);
                iVar6 = (int)local_20;
                bVar10 = false;
                uVar9 = (((int)sVar2 - (int)*(short *)(pcVar4 + 4)) + 0x168) % 0x168 - 0x17;
                if (cVar7 != '\x05') {
                  if (uVar9 < 0x13b) goto LAB_600088fa;
                  uVar9 = ((iVar6 - *(short *)(pcVar4 + 2)) + 0x168) % 0x168 - 0x17;
                }
                if (0x13a < uVar9) {
                  bVar10 = true;
                }
              }
LAB_600088fa:
              *(int *)(pcVar4 + 0x10) = local_28;
              *(int *)(pcVar4 + 0x14) = iStack_24;
              *(int *)(pcVar4 + 0x18) = local_30;
              *(short *)(pcVar4 + 4) = sVar2;
              *(short *)(pcVar4 + 2) = (short)iVar6;
              *(int *)(pcVar4 + 0x1c) = iStack_2c;
              if (bVar10) goto LAB_60008824;
            }
          }
          goto LAB_6000874e;
        }
LAB_60008824:
        if (*DAT_60008920 == '\0') {
          *(undefined1 *)(param_2 + 0x328) = 3;
          *(undefined1 *)(param_2 + 0x32b) = 1;
          return 0;
        }
        cVar7 = *DAT_60008920 + -1;
      }
      *DAT_60008920 = cVar7;
    }
  }
  else {
    if (param_3 != 0) {
      if (((*param_1 == '\x03') || (*param_1 == '\0' && *(short *)(param_1 + 0x24) == 0x7fff)) &&
         (*(char *)(param_2 + 0x329) != '\0')) {
        uVar9 = *(uint *)(pcVar4 + 0xc);
        iVar6 = *(int *)(DAT_60008920 + 8);
        iVar8 = *(int *)(DAT_60008920 + 0xc);
        if (((int)(uint)(iVar6 == 0) <= iVar8) && (0x7fffffff < uVar9)) {
          bVar10 = iVar6 == 0;
          iVar6 = iVar6 + -1;
          iVar8 = iVar8 - (uint)bVar10;
          *(int *)(DAT_60008920 + 8) = iVar6;
          *(int *)(pcVar3 + 0xc) = iVar8;
        }
        if (((0x7fffffff < uVar9) && (iVar6 == 0 && iVar8 == 0)) && (*pcVar4 == '\0')) {
          pcVar3[8] = '\x1e';
          pcVar3[9] = '\0';
          pcVar3[10] = '\0';
          pcVar3[0xb] = '\0';
          pcVar3[0xc] = '\0';
          pcVar3[0xd] = '\0';
          pcVar3[0xe] = '\0';
          pcVar3[0xf] = '\0';
          pcVar4[8] = '\0';
          pcVar4[9] = '\0';
          pcVar4[10] = '\0';
          pcVar4[0xb] = '\0';
          pcVar4[0xc] = '\0';
          pcVar4[0xd] = '\0';
          pcVar4[0xe] = '\0';
          pcVar4[0xf] = '\0';
          *pcVar4 = '\x01';
          FUN_60019b80();
          FUN_60163e70(DAT_60008924,0,DAT_60008928);
        }
      }
      else {
        pcVar3[8] = '\x1e';
        pcVar3[9] = '\0';
        pcVar3[10] = '\0';
        pcVar3[0xb] = '\0';
        pcVar3[0xc] = '\0';
        pcVar3[0xd] = '\0';
        pcVar3[0xe] = '\0';
        pcVar3[0xf] = '\0';
      }
      goto LAB_6000871e;
    }
    if ((*param_1 == '\x03' || *param_1 == '\0') && (*(char *)(param_2 + 0x329) != '\0')) {
      uVar9 = *(uint *)(pcVar4 + 0xc);
      iVar6 = *(int *)(DAT_60008920 + 8);
      iVar8 = *(int *)(DAT_60008920 + 0xc);
      if (((int)(uint)(iVar6 == 0) <= iVar8) && (0x7fffffff < uVar9)) {
        bVar10 = iVar6 == 0;
        iVar6 = iVar6 + -1;
        iVar8 = iVar8 - (uint)bVar10;
        *(int *)(DAT_60008920 + 8) = iVar6;
        *(int *)(pcVar3 + 0xc) = iVar8;
      }
      if (((0x7fffffff < uVar9) && (iVar6 == 0 && iVar8 == 0)) && (*pcVar4 == '\0')) {
        pcVar3[8] = '\x1e';
        pcVar3[9] = '\0';
        pcVar3[10] = '\0';
        pcVar3[0xb] = '\0';
        pcVar3[0xc] = '\0';
        pcVar3[0xd] = '\0';
        pcVar3[0xe] = '\0';
        pcVar3[0xf] = '\0';
        pcVar4[8] = '\0';
        pcVar4[9] = '\0';
        pcVar4[10] = '\0';
        pcVar4[0xb] = '\0';
        pcVar4[0xc] = '\0';
        pcVar4[0xd] = '\0';
        pcVar4[0xe] = '\0';
        pcVar4[0xf] = '\0';
        *pcVar4 = '\x01';
        FUN_60019b80();
        FUN_60163e70(DAT_60008924,0,DAT_60008928);
      }
    }
    else {
      pcVar3[8] = '\x1e';
      pcVar3[9] = '\0';
      pcVar3[10] = '\0';
      pcVar3[0xb] = '\0';
      pcVar3[0xc] = '\0';
      pcVar3[0xd] = '\0';
      pcVar3[0xe] = '\0';
      pcVar3[0xf] = '\0';
    }
  }
  if ((*(short *)(param_1 + 0x26) == 0x7fff) || (*param_1 != '\x01')) {
    if ((*param_1 == '\x02') && (*(char *)(param_2 + 0x329) != '\0')) {
      uVar5 = 4;
      goto LAB_600087fe;
    }
  }
  else if (*(char *)(param_2 + 0x329) == '\0') {
    uVar5 = 10;
    goto LAB_600087fe;
  }
  iVar6 = FUN_6001107c(param_1,param_2);
  if ((iVar6 == 0) || (iVar6 = FUN_601673b8(), iVar6 != 0)) {
    return 0xffffffff;
  }
  uVar5 = 0xc;
LAB_600087fe:
  *(undefined1 *)(param_2 + 0x328) = uVar5;
  return 0;
}

