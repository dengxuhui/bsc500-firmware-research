
void FUN_600040cc(void)

{
  int iVar1;
  char cVar2;
  char cVar3;
  int iVar4;
  
  iVar1 = DAT_60004120;
  cVar2 = *(char *)(DAT_60004120 + 6);
  if (0x7fffffff < (uint)(int)cVar2) {
    iVar4 = DAT_60004120 + 0x38;
    *(undefined1 *)(DAT_60004120 + 6) = 0;
    FUN_60163840(iVar4);
    FUN_6016507e(iVar4,1000,0);
    cVar2 = *(char *)(iVar1 + 6);
  }
  iVar4 = *(int *)(iVar1 + 0xc) - *(int *)(iVar1 + 0x10);
  if (iVar4 < 0) {
    iVar4 = -iVar4;
  }
  cVar3 = '\0';
  if (100 < iVar4) {
    cVar3 = cVar2 + '\x01';
  }
  *(char *)(iVar1 + 6) = cVar3;
  if ('\x04' < cVar3) {
    FUN_60163840(iVar1 + 0x38);
    *(undefined1 *)(iVar1 + 3) = 0;
  }
  return;
}

