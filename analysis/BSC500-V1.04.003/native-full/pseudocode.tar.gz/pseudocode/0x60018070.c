
void FUN_60018070(void)

{
  int iVar1;
  
  iVar1 = DAT_60018094;
  if (*(int *)(DAT_60018094 + 4) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 4) = 0;
  }
  return;
}

