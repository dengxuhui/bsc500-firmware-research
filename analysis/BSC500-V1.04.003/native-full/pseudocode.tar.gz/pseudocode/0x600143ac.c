
undefined4 FUN_600143ac(void)

{
  undefined4 uVar1;
  
  if (*DAT_600143c0 == '\x02') {
    *DAT_600143c0 = '\x01';
    uVar1 = 0;
  }
  else {
    uVar1 = 0xffffffff;
  }
  return uVar1;
}

