
void FUN_60019b24(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  uVar6 = DAT_60019b64;
  uVar5 = DAT_60019b60;
  uVar4 = DAT_60019b5c;
  uVar3 = DAT_60019b58;
  uVar2 = DAT_60019b54;
  uVar1 = DAT_60019b50;
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 0x6e4c) = DAT_60019b68;
    *(undefined4 *)(param_1 + 0x6e50) = uVar6;
    *(undefined4 *)(param_1 + 0x6e54) = uVar5;
    *(undefined4 *)(param_1 + 0x6e58) = uVar4;
    *(undefined4 *)(param_1 + 0x6e5c) = uVar3;
    *(undefined4 *)(param_1 + 0x6e60) = uVar2;
    *(undefined4 *)(param_1 + 0x6e64) = uVar1;
  }
  return;
}

