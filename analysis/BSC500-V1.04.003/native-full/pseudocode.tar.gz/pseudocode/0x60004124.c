
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void InitializeBacklight(void)

{
  char *pcVar1;
  code *pcVar2;
  undefined2 uVar3;
  int iVar4;
  char *pcVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  byte bVar9;
  int iVar10;
  char local_7c [67];
  char local_39;
  int local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  
  FUN_60168578("[BL_CSV] Initializing backlight CSV config...\n");
  uVar7 = _DAT_60004430;
  bVar9 = 0;
  local_28 = 0;
  FUN_60168578("[BL_CSV] Trying to open Slider file: %s\n",_DAT_60004430);
  iVar4 = FUN_60166758(&local_28,uVar7,1);
  if (iVar4 == 0) {
    FUN_60168578(DAT_6000445c);
    pcVar1 = DAT_60004460;
    DAT_60004460[3] = '\0';
    ZeroBytes(local_7c,0x40);
    iVar4 = 0;
    while (bVar9 < 0x14) {
      iVar10 = FUN_60161ef4(local_28,&local_39,1,&local_38);
      if ((iVar10 != 0) || (local_38 == 0)) {
        if ((0 < iVar4) && ((byte)pcVar1[3] < 0x14)) {
          local_7c[iVar4] = '\0';
          iVar4 = SplitCsvFields(local_7c,&local_34,2);
          if (iVar4 == 2) {
            uVar3 = FUN_6016811c(local_34);
            bVar9 = pcVar1[3];
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 6) = uVar3;
            uVar3 = FUN_6016811c(local_30);
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 8) = uVar3;
            pcVar1[3] = bVar9 + 1;
          }
        }
        break;
      }
      if (local_39 == '\r' || local_39 == '\n') {
        if (0 < iVar4) {
          local_7c[iVar4] = '\0';
          iVar10 = SplitCsvFields(local_7c,&local_34,2);
          iVar4 = 0;
          if (iVar10 == 2) {
            uVar3 = FUN_6016811c(local_34);
            bVar9 = pcVar1[3];
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 6) = uVar3;
            uVar3 = FUN_6016811c(local_30);
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 8) = uVar3;
            iVar4 = 0;
            pcVar1[3] = bVar9 + 1;
          }
        }
      }
      else if (iVar4 < 0x3f) {
        local_7c[iVar4] = local_39;
        iVar4 = iVar4 + 1;
      }
      bVar9 = pcVar1[3];
    }
    FUN_601667bc(local_28);
    pcVar5 = DAT_60004464;
    if (pcVar1[3] == '\0') goto LAB_6000414c;
    *pcVar1 = '\x01';
    FUN_60168578(DAT_60004468);
    uVar7 = DAT_6000446c;
    for (uVar8 = 0; uVar8 < (byte)pcVar1[3]; uVar8 = uVar8 + 1) {
      FUN_60168578(uVar7,uVar8,*(undefined2 *)(pcVar1 + uVar8 * 4 + 6),
                   *(undefined2 *)(pcVar1 + uVar8 * 4 + 8));
    }
  }
  else {
    pcVar5 = "[BL_CSV] Failed to open Slider file\n";
LAB_6000414c:
    FUN_60168578(pcVar5);
  }
  uVar7 = DAT_60004474;
  bVar9 = 0;
  local_28 = 0;
  FUN_60168578(DAT_60004470,DAT_60004474);
  iVar4 = FUN_60166758(&local_28,uVar7,1);
  uVar7 = DAT_60004478;
  if (iVar4 == 0) {
    FUN_60168578(DAT_6000447c);
    pcVar1 = DAT_60004460;
    DAT_60004460[4] = '\0';
    ZeroBytes(local_7c,0x40);
    iVar4 = DAT_60004484;
    iVar10 = 0;
    while (bVar9 < 0x32) {
      iVar6 = FUN_60161ef4(local_28,&local_39,1,&local_38);
      if ((iVar6 != 0) || (local_38 == 0)) {
        if ((0 < iVar10) && ((byte)pcVar1[4] < 0x32)) {
          local_7c[iVar10] = '\0';
          iVar10 = SplitCsvFields(local_7c,&local_34,3);
          pcVar2 = DAT_60004480;
          if (iVar10 == 3) {
            uVar7 = (*DAT_60004480)(local_34);
            bVar9 = pcVar1[4];
            *(undefined4 *)(iVar4 + (uint)bVar9 * 8) = uVar7;
            iVar10 = iVar4 + (uint)bVar9 * 8;
            uVar3 = (*pcVar2)(local_30);
            *(undefined2 *)(iVar10 + 4) = uVar3;
            uVar3 = (*pcVar2)(local_2c);
            *(undefined2 *)(iVar10 + 6) = uVar3;
            pcVar1[4] = bVar9 + 1;
          }
        }
        break;
      }
      if (local_39 == '\r' || local_39 == '\n') {
        if (0 < iVar10) {
          local_7c[iVar10] = '\0';
          iVar6 = SplitCsvFields(local_7c,&local_34,3);
          iVar10 = 0;
          if (iVar6 == 3) {
            uVar7 = (*DAT_60004480)(local_34);
            pcVar2 = DAT_60004480;
            bVar9 = pcVar1[4];
            *(undefined4 *)(iVar4 + (uint)bVar9 * 8) = uVar7;
            iVar10 = iVar4 + (uint)bVar9 * 8;
            uVar3 = (*pcVar2)(local_30);
            *(undefined2 *)(iVar10 + 4) = uVar3;
            uVar3 = (*DAT_60004480)(local_2c);
            *(undefined2 *)(iVar10 + 6) = uVar3;
            iVar10 = 0;
            pcVar1[4] = bVar9 + 1;
          }
        }
      }
      else if (iVar10 < 0x3f) {
        local_7c[iVar10] = local_39;
        iVar10 = iVar10 + 1;
      }
      bVar9 = pcVar1[4];
    }
    FUN_601667bc(local_28);
    uVar7 = DAT_60004488;
    if (pcVar1[4] != '\0') {
      pcVar1[1] = '\x01';
      FUN_60168578(DAT_6000448c);
      uVar7 = DAT_60004490;
      for (uVar8 = 0; uVar8 < (byte)pcVar1[4]; uVar8 = uVar8 + 1) {
        iVar10 = iVar4 + uVar8 * 8;
        FUN_60168578(uVar7,uVar8,*(undefined4 *)(iVar4 + uVar8 * 8),*(undefined2 *)(iVar10 + 4),
                     *(undefined2 *)(iVar10 + 6));
      }
      goto LAB_60004176;
    }
  }
  FUN_60168578(uVar7);
LAB_60004176:
  if ((*DAT_60004460 != '\0') || (uVar7 = DAT_60004494, DAT_60004460[1] == '\x01')) {
    DAT_60004460[2] = '\x01';
    uVar7 = DAT_60004498;
  }
  FUN_60168578(uVar7);
  return;
}

