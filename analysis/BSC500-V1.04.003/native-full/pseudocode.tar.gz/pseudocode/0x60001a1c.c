
void FUN_60001a1c(void)

{
  int *piVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  
  iVar5 = *DAT_60001a70;
  uVar3 = FUN_60167d0c();
  FUN_6013a164(iVar5);
  *(undefined1 *)(iVar5 + 0x3c) = 4;
  FUN_60136698(iVar5 + 0x58);
  iVar4 = FUN_601635b0(iVar5);
  piVar2 = DAT_60001a74;
  if ((iVar4 == 1) && (*(int *)(iVar5 + 0x90) == 0)) {
    FUN_60162d10(iVar5);
  }
  else {
    iVar4 = *DAT_60001a74;
    piVar1 = (int *)(iVar5 + 0x1c);
    *piVar1 = iVar4;
    *(int **)(iVar4 + 4) = piVar1;
    *piVar2 = (int)piVar1;
    *(int **)(iVar5 + 0x20) = piVar2;
  }
  FUN_60167d14(uVar3);
  FUN_60163a08();
  return;
}

