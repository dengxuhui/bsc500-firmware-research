
void FUN_6000b6dc(void)

{
  int iVar1;
  
  iVar1 = DAT_6000b700;
  FUN_6007db44(DAT_6000b6fc,DAT_6000b700,0x4000);
  FUN_6007db44(DAT_6000b704,iVar1 + 0x4000,0x8860);
  return;
}

