
void FUN_6000dbb8(void)

{
  undefined1 *puVar1;
  
  puVar1 = DAT_6000dbc8;
  *(undefined4 *)(DAT_6000dbc8 + 4) = 0;
  *(undefined4 *)(puVar1 + 8) = 0;
  *(undefined4 *)(puVar1 + 0xc) = 0;
  *puVar1 = 0;
  return;
}

