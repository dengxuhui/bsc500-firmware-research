
uint FUN_600069e0(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 *puVar8;
  uint uVar9;
  bool bVar10;
  undefined4 local_2c;
  undefined4 *local_28;
  undefined4 local_24;
  
  if (param_1 == 2) {
    uVar6 = DAT_60006a14;
    puVar8 = DAT_60006a0c + 2;
  }
  else if (param_1 == 1) {
    uVar6 = DAT_60006a18;
    puVar8 = DAT_60006a0c + 1;
  }
  else {
    uVar6 = DAT_60006a1c;
    puVar8 = DAT_60006a0c;
    if (param_1 != 0) {
      return param_1;
    }
  }
  local_2c = uVar6;
  local_28 = puVar8;
  local_24 = param_4;
  iVar3 = FUN_60010b70(DAT_60006a10,&local_28,puVar8,param_4,DAT_60006a10);
  puVar2 = local_28;
  iVar1 = DAT_6000fa58;
  if (local_28 != (undefined4 *)0x0) {
    iVar4 = DAT_6000fa58 + 0xc;
    for (iVar7 = 0; iVar7 != 4; iVar7 = iVar7 + 1) {
      if (*(undefined4 **)(DAT_6000fa58 + iVar7 * 0x1c) == local_28) {
        for (uVar9 = 0; uVar9 != 3; uVar9 = uVar9 + 1) {
          if (*(int *)(iVar4 + uVar9 * 4) == 0) {
            if ((uVar9 & 0xff) == 3) {
              return 0;
            }
            iVar4 = *(int *)(DAT_6000fa58 + iVar3 * 0x1c + 8);
            if (iVar4 == 0) {
              return 0;
            }
            FUN_6016825e(iVar4,0xffffffff);
            FUN_6016350c(puVar2);
            iVar7 = FUN_6001a148(puVar2,uVar6,&local_24);
            FUN_601634e4(puVar2);
            iVar5 = FUN_601633f8(puVar2,local_24,1,&local_2c);
            bVar10 = iVar5 == 0 && iVar7 == 0;
            if (bVar10) {
              *(undefined4 *)(iVar1 + iVar3 * 0x1c + uVar9 * 4 + 0xc) = local_2c;
              *puVar8 = local_2c;
            }
            FUN_601682ae(iVar4);
            return (uint)bVar10;
          }
        }
      }
      iVar4 = iVar4 + 0x1c;
    }
  }
  return 0;
}

