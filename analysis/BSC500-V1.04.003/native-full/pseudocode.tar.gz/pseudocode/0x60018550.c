
void FUN_60018550(void)

{
  int iVar1;
  undefined4 unaff_r6;
  
  FUN_601608ac(DAT_60018578,0x24);
  iVar1 = FUN_60166758(&stack0xfffffff4,DAT_6001857c,1);
  if (iVar1 != 0) {
    return;
  }
  FUN_601667bc(unaff_r6);
  FUN_6001e398(0);
  return;
}

