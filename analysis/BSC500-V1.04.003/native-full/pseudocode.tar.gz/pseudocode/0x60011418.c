
int FUN_60011418(int *param_1)

{
  int iVar1;
  
  iVar1 = *DAT_60011448;
  if (param_1 != (int *)0x0) {
    *param_1 = DAT_6001144c + iVar1 + 8;
  }
  return 0x1ff8 - iVar1;
}

