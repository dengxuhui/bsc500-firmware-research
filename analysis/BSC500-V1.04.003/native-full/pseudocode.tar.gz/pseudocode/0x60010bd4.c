
void FUN_60010bd4(undefined4 *param_1)

{
  if (*(char *)(param_1 + 2) != '\0') {
    (**(code **)*param_1)(param_1);
    *(undefined1 *)(param_1 + 2) = 0;
  }
  return;
}

