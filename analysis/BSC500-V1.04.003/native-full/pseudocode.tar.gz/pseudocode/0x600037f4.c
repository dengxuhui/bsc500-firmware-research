
void FUN_600037f4(void)

{
  *DAT_600037fc = 1;
  return;
}

