
undefined1 FUN_6000af84(void)

{
  return *(undefined1 *)(DAT_6000af8c + 2);
}

