
void FUN_60016c40(void)

{
  undefined1 *puVar1;
  int iVar2;
  
  iVar2 = FUN_60164940();
  puVar1 = DAT_60016c64;
  *(undefined4 *)(DAT_60016c64 + 0x10) = *(undefined4 *)(iVar2 + 0x10);
  FUN_6001e1be();
  FUN_6004c70c();
  FUN_6004c688();
  *puVar1 = 1;
  FUN_6014bc0c();
  puVar1[2] = 1;
  return;
}

