
void FUN_60009cc0(void)

{
  undefined4 *puVar1;
  uint uVar2;
  
  puVar1 = (undefined4 *)(DAT_60009e64 + 0x14);
  for (uVar2 = 0; uVar2 != 3; uVar2 = uVar2 + 1) {
    FUN_60133d38(*puVar1);
    FUN_60163840(puVar1[1]);
    FUN_60133d0c(uVar2 & 0xff);
    puVar1 = puVar1 + 10;
  }
  return;
}

