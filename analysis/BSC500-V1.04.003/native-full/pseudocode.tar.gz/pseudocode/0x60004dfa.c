
undefined8 FUN_60004dfa(int *param_1,int *param_2,uint param_3,uint param_4)

{
  byte local_20;
  byte local_1f;
  byte local_1e;
  byte local_1d;
  byte local_1c;
  byte local_1b;
  byte local_1a;
  byte local_19;
  uint local_18;
  uint local_14;
  
  local_1c = (byte)param_2;
  local_1b = (byte)((uint)param_2 >> 8);
  local_1a = (byte)((uint)param_2 >> 0x10);
  local_19 = (byte)((uint)param_2 >> 0x18);
  local_20 = (byte)param_1;
  local_1f = (byte)((uint)param_1 >> 8);
  local_1e = (byte)((uint)param_1 >> 0x10);
  local_1d = (byte)((uint)param_1 >> 0x18);
  local_18 = param_3;
  local_14 = param_4;
  FUN_6000ea30(0x10000000,&local_20,0x10);
  *param_1 = ((uint)local_1d + (uint)local_1e) * 0x10000 +
             ((uint)local_20 + (uint)local_1f) * 0x1000000 + (uint)local_1a +
             ((uint)local_1c + (uint)local_1b) * 0x100 + (uint)local_19;
  *param_2 = ((local_18 >> 0x10 & 0xff) + (local_18 >> 0x18)) * 0x10000 +
             ((local_18 & 0xff) + (local_18 >> 8 & 0xff)) * 0x1000000 + (local_14 >> 0x10 & 0xff) +
             ((local_14 & 0xff) + (local_14 >> 8 & 0xff)) * 0x100 + (local_14 >> 0x18);
  return CONCAT17(local_19,CONCAT16(local_1a,CONCAT15(local_1b,CONCAT14(local_1c,CONCAT13(local_1d,
                                                  CONCAT12(local_1e,CONCAT11(local_1f,local_20))))))
                 );
}

