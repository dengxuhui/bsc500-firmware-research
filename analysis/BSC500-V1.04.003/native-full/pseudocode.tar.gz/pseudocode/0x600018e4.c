
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600018e4(int param_1,uint param_2)

{
  undefined1 uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  if (param_1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(_DAT_60001930,"_pm_select_sleep_mode",0xab);
  }
  if (*(code **)(param_1 + 0x6c) == (code *)0x0) {
    uVar2 = (uint)*(byte *)(param_1 + 0x70);
    do {
      if ((int)uVar2 < 1) {
        uVar1 = 1;
        goto LAB_60001920;
      }
      uVar4 = uVar2 - 1;
      uVar3 = FUN_60167b58(*(undefined4 *)(*(int *)(param_1 + 0x74) + uVar2 * 8 + -8));
      uVar2 = uVar4;
    } while (param_2 < uVar3);
    uVar1 = *(undefined1 *)(*(int *)(param_1 + 0x74) + uVar4 * 8 + 4);
  }
  else {
    uVar1 = (**(code **)(param_1 + 0x6c))(param_2);
  }
LAB_60001920:
  *(undefined1 *)(param_1 + 0x5e) = uVar1;
  return;
}

