
void thunk_FUN_600054bc(void)

{
  undefined1 uVar1;
  int iVar2;
  
  iVar2 = FUN_6015f808();
  if (iVar2 != 0) {
    FUN_6016713c(iVar2,0xb3,DAT_600054dc);
  }
  iVar2 = FUN_6000d578();
  if (iVar2 != 0) {
    uVar1 = FUN_6013846c();
    *DAT_600054e0 = uVar1;
  }
  return;
}

