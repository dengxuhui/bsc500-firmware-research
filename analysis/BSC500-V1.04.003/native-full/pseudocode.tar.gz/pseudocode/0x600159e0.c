
void FUN_600159e0(void)

{
  undefined8 uVar1;
  
  FUN_6001fc18();
  uVar1 = FUN_60167f4a("dfu_nrf_thread",DAT_60015a18,0,0x2800);
  if ((int)uVar1 != 0) {
    FUN_60167f8c((int)uVar1,(int)((ulonglong)uVar1 >> 0x20),10,5);
    return;
  }
  return;
}

