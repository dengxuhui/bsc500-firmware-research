
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60017910(int *param_1,int param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  
  iVar1 = DAT_60017a18;
  if (*(int *)(DAT_60017a18 + 4) == 0) {
    FUN_60167f3c(0,DAT_60017a2c,1,_DAT_60017a30,DAT_60017be4,DAT_60017a1c,0xdb,param_4);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  if (param_1 == (int *)0x0) {
    FUN_60167f3c(0,DAT_60017a2c,1,_DAT_60017a30,"manager && \"messagelistener should be init\"",
                 DAT_60017a1c,0xdc,param_4);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar8 = param_2;
  iVar9 = param_3;
  iVar10 = param_4;
  piVar2 = (int *)FUN_60161f90(0x14,10,param_3,param_4,param_1,param_2,param_3);
  *piVar2 = param_3;
  piVar2[1] = param_2;
  piVar2[2] = param_4;
  piVar2[3] = param_5;
  piVar2[4] = 0;
  iVar3 = FUN_6016825e(*(undefined4 *)(iVar1 + 4),5000);
  if (iVar3 == 0) {
    piVar5 = param_1 + 1;
    piVar6 = (int *)*piVar5;
    for (piVar7 = (int *)*piVar5; piVar7 != (int *)0x0; piVar7 = (int *)piVar7[4]) {
      if (piVar7[1] == param_2) {
        if ((piVar7[2] == param_4) && (*piVar7 == param_3)) {
          FUN_6015e008(piVar2);
          goto LAB_600179da;
        }
      }
      else if (piVar7[2] == param_4) {
        FUN_6015e008(piVar2);
        FUN_60167f3c(0,DAT_60017a2c,1,_DAT_60017a30,DAT_60017a28,DAT_60017a1c,0x115,iVar10);
        FUN_6013dd48();
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      piVar6 = piVar7;
    }
    if (piVar6 != (int *)0x0) {
      piVar5 = piVar6 + 4;
    }
    *piVar5 = (int)piVar2;
    *param_1 = *param_1 + 1;
LAB_600179da:
    FUN_601682ae(*(undefined4 *)(iVar1 + 4));
    uVar4 = 1;
  }
  else {
    FUN_60167f3c(3,DAT_60017a20,1,DAT_60017a24,DAT_60017a1c,iVar8,iVar9,iVar10);
    uVar4 = 0;
  }
  return uVar4;
}

