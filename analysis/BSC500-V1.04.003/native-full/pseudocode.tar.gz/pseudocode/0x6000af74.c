
uint FUN_6000af74(void)

{
  return (*(uint *)(DAT_6000af80 + 0x14) & 0x3f) >> 5;
}

