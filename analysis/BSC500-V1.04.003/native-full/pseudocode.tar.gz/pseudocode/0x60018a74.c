
void FUN_60018a74(void)

{
  undefined1 *puVar1;
  
  FUN_6001da48(DAT_60018a8c);
  puVar1 = DAT_60018a90;
  ZeroBytes(DAT_60018a90 + 4,0x1c);
  *puVar1 = 0;
  return;
}

