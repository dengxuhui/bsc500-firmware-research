
void FUN_6000e35c(void)

{
  FUN_6001a04c();
  if (*DAT_6000e378 != '\0') {
    FUN_60018918();
  }
  *DAT_6000e37c = *DAT_6000e37c + 1;
  return;
}

