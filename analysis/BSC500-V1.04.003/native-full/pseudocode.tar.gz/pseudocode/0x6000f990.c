
undefined4 FUN_6000f990(undefined4 *param_1)

{
  FUN_6001a3c0(*param_1);
  return 0;
}

