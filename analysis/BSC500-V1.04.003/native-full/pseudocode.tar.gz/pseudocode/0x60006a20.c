
undefined4 FUN_60006a20(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int local_18;
  
  local_18 = param_4;
  FUN_60010b70(param_1,&local_18);
  if (local_18 == 0) {
    piVar4 = DAT_60006a8c;
    for (uVar1 = 0; uVar1 != 4; uVar1 = uVar1 + 1) {
      if (*piVar4 == 0) {
        if ((uVar1 & 0xff) != 4) {
          iVar2 = FUN_6000f914(param_1,param_2,&local_18);
          if (iVar2 != 0) {
            return 0;
          }
          FUN_6000f990(local_18,param_3);
          *piVar4 = local_18;
          uVar3 = FUN_60168220(param_1);
          iVar2 = FUN_6001a114(param_1,uVar3);
          piVar4[1] = iVar2;
          iVar2 = FUN_60168494(0);
          piVar4[6] = 0;
          piVar4[2] = iVar2;
          goto LAB_60006a32;
        }
        break;
      }
      piVar4 = piVar4 + 7;
    }
    uVar3 = 0;
  }
  else {
LAB_60006a32:
    uVar3 = 1;
  }
  return uVar3;
}

