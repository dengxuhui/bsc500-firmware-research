
undefined1 FUN_60016998(void)

{
  return *DAT_600169a0;
}

