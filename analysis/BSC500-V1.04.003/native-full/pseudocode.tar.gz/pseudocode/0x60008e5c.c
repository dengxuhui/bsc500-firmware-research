
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60008e5c(undefined4 param_1,char *param_2)

{
  char cVar1;
  
  thunk_FUN_6001bd1c();
  if (*param_2 == '\x05') {
    cVar1 = **(char **)(param_2 + 8);
    *(char *)(_DAT_60009010 + 0x28) = cVar1;
    if (cVar1 == '\0') {
      thunk_FUN_6001bdd0(1);
    }
    else {
      thunk_FUN_6001bd58();
      thunk_FUN_6001bde4(1);
    }
  }
  else if (*param_2 == '\x02') {
    thunk_FUN_6001bd58();
    thunk_FUN_6001be04(*(undefined4 *)(param_2 + 8),*(undefined2 *)(param_2 + 2));
  }
  return 0;
}

