
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_60008aac(uint param_1,int param_2,int param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  char *pcVar3;
  int iVar4;
  ushort *puVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  int iVar10;
  
  if (((*(char *)(DAT_60008b7c + 2) == '\0') || (*(char *)(DAT_60008b7c + 1) != '\x01')) ||
     (uVar1 = (uint)*(byte *)(DAT_60008b7c + 4), uVar1 == 0)) {
    uVar1 = 0;
  }
  else {
    iVar8 = param_2;
    if (param_1 == 0) {
      puVar5 = (ushort *)(_DAT_60008b80 + 6);
      if (param_2 == 0) {
        puVar5 = (ushort *)(_DAT_60008b80 + 4);
      }
      uVar1 = (uint)*puVar5;
      param_1 = 0;
      pcVar3 = DAT_60008bf4;
    }
    else {
      iVar7 = uVar1 - 1;
      if (param_1 < *(uint *)(_DAT_60008b80 + iVar7 * 8)) {
        iVar2 = 0;
        for (iVar10 = 0; uVar1 * 8 + -8 != iVar10; iVar10 = iVar10 + 8) {
          iVar4 = _DAT_60008b80 + iVar10;
          uVar9 = *(uint *)(iVar4 + 8);
          if (param_1 < uVar9) {
            iVar8 = 4;
            if (param_2 != 0) {
              iVar8 = 6;
            }
            uVar6 = *(uint *)(_DAT_60008b80 + iVar10);
            uVar1 = (uint)*(ushort *)(iVar4 + iVar8);
            pcVar3 = DAT_60008bec;
            iVar8 = iVar2 + 1;
            if (uVar9 != uVar6) {
              iVar8 = 0xc;
              if (param_2 != 0) {
                iVar8 = 0xe;
              }
              uVar1 = uVar1 + ((param_1 - uVar6) * (*(ushort *)(iVar4 + iVar8) - uVar1)) /
                              (uVar9 - uVar6);
              pcVar3 = "[BL_ALS] lux=%d, dark=%d, bright=%d (interp[%d-%d])\n";
              iVar8 = iVar2;
              param_3 = iVar2 + 1;
            }
            goto LAB_60008b70;
          }
          iVar2 = iVar2 + 1;
        }
        iVar7 = _DAT_60008b80 + iVar7 * 8;
        puVar5 = (ushort *)(iVar7 + 6);
        if (param_2 == 0) {
          puVar5 = (ushort *)(iVar7 + 4);
        }
        uVar1 = (uint)*puVar5;
        pcVar3 = DAT_60008bf0;
      }
      else {
        iVar7 = _DAT_60008b80 + iVar7 * 8;
        puVar5 = (ushort *)(iVar7 + 6);
        if (param_2 == 0) {
          puVar5 = (ushort *)(iVar7 + 4);
        }
        uVar1 = (uint)*puVar5;
        pcVar3 = "[BL_ALS] lux=%d, dark=%d, bright=%d (last row)\n";
      }
    }
LAB_60008b70:
    FUN_60168578(pcVar3,param_1,param_2,uVar1,iVar8,param_3,param_4);
    param_2 = iVar8;
  }
  return CONCAT44(param_2,uVar1);
}

