
void FUN_60018580(void)

{
  uint uVar1;
  
  uVar1 = *(uint *)(DAT_600185cc + 0x10);
  if (((*(char *)(DAT_600185cc + 4) == '\x01') &&
      (uVar1 <= *(int *)(DAT_600185cc + 0x14) + 900U ||
       (uVar1 - *(int *)(DAT_600185cc + 0x14) & 0xfffffffc) == 900)) &&
     ((*(uint *)(DAT_600185c0 + 0xa64) & 0x600) != 0)) {
    return;
  }
  *(uint *)(DAT_600185cc + 0x14) = uVar1;
  return;
}

