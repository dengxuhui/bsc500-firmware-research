
void FUN_6000b268(void)

{
  int iVar1;
  int iVar2;
  
  iVar1 = DAT_6000b2b4;
  if (*(char *)(DAT_6000b2b4 + 1) == '\0' && *(char *)(DAT_6000b2b0 + 0xcc) == '\0') {
    *(undefined1 *)(DAT_6000b2b4 + 1) = 1;
    iVar2 = FUN_6012d794();
    if ((iVar2 == 0) && (*(char *)(iVar1 + 4) == '\0')) {
      FUN_601489b8(DAT_6000b2b8);
      *(undefined1 *)(iVar1 + 4) = 1;
      return;
    }
  }
  else if ((*(char *)(DAT_6000b2b0 + 0xcc) != '\0') && (*(char *)(DAT_6000b2b4 + 1) != '\0')) {
    *(undefined1 *)(DAT_6000b2b4 + 1) = 0;
    iVar1 = FUN_6012d794();
    if (iVar1 == 0) {
      thunk_FUN_60059aa8(DAT_6000b2b8 + 1);
      return;
    }
  }
  return;
}

