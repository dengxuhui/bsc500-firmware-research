
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60003800(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  ushort uVar1;
  uint uVar2;
  int *piVar3;
  int iVar4;
  undefined4 *puVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  ushort uVar12;
  bool bVar13;
  
  if (param_1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(DAT_60003a08,DAT_600039e8,0x244,param_4,param_4);
  }
  uVar2 = param_2 & 0x200;
  if (((((uVar2 != 0) && (-1 < (int)((uint)*(ushort *)(param_1 + 0x1e) << 0x16))) ||
       ((uVar11 = param_2 & 0x800, uVar11 != 0 &&
        (-1 < (int)((uint)*(ushort *)(param_1 + 0x1e) << 0x14))))) ||
      ((uVar7 = param_2 & 0x100, uVar7 != 0 &&
       (-1 < (int)((uint)*(ushort *)(param_1 + 0x1e) << 0x17))))) ||
     ((uVar10 = param_2 & 0x400, uVar10 != 0 &&
      (-1 < (int)((uint)*(ushort *)(param_1 + 0x1e) << 0x15))))) {
    return 0xfffffff8;
  }
  uVar9 = param_2 << 0x19;
  bVar13 = -1 < (int)uVar9;
  if (bVar13) {
    uVar9 = (uint)*(ushort *)(param_1 + 0x20);
  }
  if (bVar13 && -1 < (int)(uVar9 << 0x19)) {
    uVar12 = 0;
  }
  else {
    uVar12 = 0x40;
  }
  uVar1 = (ushort)param_2 & 0xff;
  *(ushort *)(param_1 + 0x20) = uVar1;
  if (*(int *)(param_1 + 100) == 0) {
    if (uVar7 == 0) {
      if (uVar2 != 0) {
        uVar2 = (*(uint *)(param_1 + 0x60) & 0x3ffffff) >> 10;
        if (uVar2 == 0) {
          puVar5 = (undefined4 *)FUN_60162e34(4);
          if (puVar5 == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_6016804c(DAT_600039ec,DAT_600039e8,0x277);
          }
          *(undefined4 **)(param_1 + 100) = puVar5;
          *puVar5 = 0;
        }
        else {
          piVar3 = (int *)FUN_60162e34(uVar2 + 0xc);
          if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
            FUN_6016804c(DAT_600039e4,DAT_600039e8,0x282);
          }
          *piVar3 = (int)(piVar3 + 3);
          thunk_EXT_FUN_000219ea(piVar3 + 3,0,(*(uint *)(param_1 + 0x60) & 0x3ffffff) >> 10);
          piVar3[1] = 0;
          piVar3[2] = 0;
          *(int **)(param_1 + 100) = piVar3;
          (**(code **)(*(int *)(param_1 + 0x58) + 4))(param_1,3,0x200);
        }
        uVar1 = *(ushort *)(param_1 + 0x20) | 0x200;
        goto LAB_60003918;
      }
      *(undefined4 *)(param_1 + 100) = 0;
    }
    else {
      piVar3 = (int *)FUN_60162e34((*(uint *)(param_1 + 0x60) >> 10 & 0xffff) + 0xc);
      if (piVar3 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_6016804c(DAT_600039e4,DAT_600039e8,0x263);
      }
      *piVar3 = (int)(piVar3 + 3);
      thunk_EXT_FUN_000219ea(piVar3 + 3,0,(*(uint *)(param_1 + 0x60) & 0x3ffffff) >> 10);
      piVar3[1] = 0;
      piVar3[2] = 0;
      *(int **)(param_1 + 100) = piVar3;
      *(ushort *)(param_1 + 0x20) = *(ushort *)(param_1 + 0x20) | 0x100;
      (**(code **)(*(int *)(param_1 + 0x58) + 4))(param_1,0x10,0x100);
    }
  }
  else {
    if (uVar7 == 0) {
      if (uVar2 == 0) goto LAB_6000391a;
      uVar1 = uVar1 + 0x200;
    }
    else {
      uVar1 = uVar1 + 0x100;
    }
LAB_60003918:
    *(ushort *)(param_1 + 0x20) = uVar1;
  }
LAB_6000391a:
  if (*(int *)(param_1 + 0x68) == 0) {
    if (uVar10 == 0) {
      if (uVar11 == 0) {
        *(undefined4 *)(param_1 + 0x68) = 0;
        goto LAB_6000398e;
      }
      puVar5 = (undefined4 *)FUN_60162e34(0x28);
      if (puVar5 == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_6016804c(_DAT_600039f0,DAT_600039e8,0x2b4);
      }
      *puVar5 = 0;
      FUN_60155e1c(puVar5 + 1,8,4,0);
      uVar6 = 3;
      uVar8 = 0x800;
      *(undefined4 **)(param_1 + 0x68) = puVar5;
      uVar1 = *(ushort *)(param_1 + 0x20) | 0x800;
    }
    else {
      iVar4 = FUN_60162e34(0xc);
      if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
        FUN_6016804c("tx_fifo != RT_NULL",DAT_600039e8,0x2a5);
      }
      FUN_60137768();
      uVar6 = 0x10;
      uVar8 = 0x400;
      *(int *)(param_1 + 0x68) = iVar4;
      uVar1 = *(ushort *)(param_1 + 0x20) | 0x400;
    }
    *(ushort *)(param_1 + 0x20) = uVar1;
    (**(code **)(*(int *)(param_1 + 0x58) + 4))(param_1,uVar6,uVar8);
  }
  else {
    if (uVar10 == 0) {
      if (uVar11 == 0) goto LAB_6000398e;
      uVar1 = *(ushort *)(param_1 + 0x20) | 0x800;
    }
    else {
      uVar1 = *(ushort *)(param_1 + 0x20) | 0x400;
    }
    *(ushort *)(param_1 + 0x20) = uVar1;
  }
LAB_6000398e:
  *(ushort *)(param_1 + 0x20) = *(ushort *)(param_1 + 0x20) | uVar12;
  return 0;
}

