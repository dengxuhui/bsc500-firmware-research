
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001b7c(void)

{
  int iVar1;
  char *local_18;
  undefined4 local_14;
  undefined4 uStack_10;
  undefined4 local_c;
  
  local_c = 0;
  local_14 = 0;
  uStack_10 = 0;
  local_18 = "m_msssage";
  iVar1 = FUN_60168494(&local_18);
  *(int *)(_DAT_60001bc8 + 4) = iVar1;
  if (iVar1 != 0) {
    return;
  }
  FUN_60167f3c(0,DAT_60001c00,1,_DAT_60001d20,"mMessageMutex && \"require faied\"","message_Init",
               0x33);
  FUN_6013dd48();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

