
/* WARNING: Type propagation algorithm not settling */

undefined4 FUN_60015da0(int param_1,undefined4 *param_2,int *param_3)

{
  undefined4 *puVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  short local_3a;
  int local_38 [2];
  undefined4 auStack_30 [3];
  
  auStack_30[1] = 0;
  local_38[1] = 0;
  auStack_30[0] = 0;
  if ((param_1 == 0) || (iVar2 = FUN_6016506c(param_1), puVar1 = DAT_60015e48, iVar2 == 0)) {
LAB_60015e3c:
    uVar4 = 0xffffffff;
  }
  else {
    do {
      iVar2 = FUN_6015d9d4(param_1);
      if (iVar2 != 0) goto LAB_60015e3c;
      iVar2 = 0;
      while ((iVar2 != 8 && (iVar3 = FUN_6015d9d4(param_1), iVar3 == 0))) {
        FUN_60161ef4(param_1,(int)auStack_30 + iVar2,1,local_38 + 1);
        iVar2 = iVar2 + 1;
      }
      FUN_60138740(*puVar1,puVar1[1],auStack_30,iVar2,local_38,&local_3a);
      iVar2 = DAT_60015e4c;
    } while ((local_3a != 0x14) || (local_38[0] == 0));
    *param_2 = *(undefined4 *)(local_38[0] + 0xc);
    iVar2 = iVar2 + (uint)*(ushort *)(local_38[0] + 0x14) * 0x14;
    if (*(ushort *)(local_38[0] + 0x14) == 0xffff) {
      iVar2 = 0x7fffffff;
    }
    *param_3 = iVar2;
    uVar4 = 0;
  }
  return uVar4;
}

