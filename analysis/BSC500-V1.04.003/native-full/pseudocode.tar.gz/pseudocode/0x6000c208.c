
undefined4 FUN_6000c208(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  uVar2 = DAT_6000c250;
  iVar1 = DAT_6000c24c;
  uVar4 = 0;
  *(undefined1 *)(DAT_6000c24c + 0x6c) = 0;
  *(undefined1 *)(iVar1 + 0x68) = 0;
  *(undefined4 *)(iVar1 + 0x34) = uVar2;
  *(undefined2 *)(iVar1 + 0x30) = 0;
  FUN_60017f5c();
  FUN_6001818c();
  FUN_60017c18();
  FUN_600180ac();
  if (param_1 == (undefined4 *)0x0) {
    *(undefined4 *)(iVar1 + 0x54) = 0;
    *(undefined4 *)(iVar1 + 0x58) = 0;
    *(undefined4 *)(iVar1 + 0x5c) = 0;
  }
  else {
    uVar2 = param_1[1];
    uVar3 = param_1[2];
    uVar4 = param_1[3];
    *(undefined4 *)(iVar1 + 0x54) = *param_1;
    *(undefined4 *)(iVar1 + 0x58) = uVar2;
    *(undefined4 *)(iVar1 + 0x5c) = uVar3;
  }
  *(undefined4 *)(iVar1 + 0x60) = uVar4;
  *(undefined1 *)(iVar1 + 0x30) = 1;
  return 0;
}

