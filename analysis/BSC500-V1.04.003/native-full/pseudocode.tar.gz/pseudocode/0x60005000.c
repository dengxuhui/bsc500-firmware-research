
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60005000(undefined4 param_1,uint param_2)

{
  int *piVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  
  iVar3 = FUN_60164eb0(5);
  uVar5 = _DAT_60005090;
  piVar8 = (int *)(iVar3 + 4);
  uVar4 = FUN_6015de24(_DAT_60005090,piVar8);
  FUN_60168578("%-*.s entry size suspend thread\n",uVar4,uVar5);
  FUN_6015de60(uVar4);
  FUN_60168578(" ----  ---- --------------\n");
  piVar6 = piVar8;
  while (piVar6 = (int *)*piVar6, piVar6 != piVar8) {
    piVar1 = piVar6 + 2;
    piVar7 = (int *)*piVar1;
    uVar2 = *(undefined2 *)(piVar6 + 5);
    param_2 = (uint)*(ushort *)((int)piVar6 + 0x16);
    uVar5 = FUN_6015dd58(piVar1);
    if (piVar7 == piVar1) {
      FUN_60168578("%-*.*s %04d  %04d %d\n",uVar4,0x10,piVar6 + -5,param_2,uVar2,uVar5);
    }
    else {
      FUN_60168578("%-*.*s %04d  %04d %d:",uVar4,0x10,piVar6 + -5,param_2,uVar2,uVar5);
      FUN_6015dd6c(piVar1);
      FUN_60168578(_DAT_600050ec);
    }
  }
  return (ulonglong)param_2 << 0x20;
}

