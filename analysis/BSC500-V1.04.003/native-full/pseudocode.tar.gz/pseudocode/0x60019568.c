
void FUN_60019568(undefined4 param_1)

{
  undefined2 local_24;
  undefined1 local_22;
  undefined1 uStack_21;
  undefined2 local_20;
  undefined1 local_1d;
  undefined1 local_17;
  undefined1 local_16;
  undefined1 local_15;
  undefined1 local_14;
  undefined1 local_11;
  
  FUN_60166858(&uStack_21,0x11,0xff);
  local_17 = (undefined1)param_1;
  local_1d = 0;
  local_22 = 0;
  local_20 = 5;
  local_24 = 0x1903;
  local_14 = (undefined1)((uint)param_1 >> 0x18);
  local_15 = (undefined1)((uint)param_1 >> 0x10);
  local_16 = (undefined1)((uint)param_1 >> 8);
  local_11 = FUN_60160db4(&local_24,0x13);
  FUN_6015e018(&local_24);
  return;
}

