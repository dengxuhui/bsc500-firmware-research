
void FUN_60019b94(void)

{
  *DAT_60019bd4 = 0;
  return;
}

