
undefined8 FUN_6000af0c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 local_14;
  undefined4 uStack_10;
  undefined4 local_c;
  
  local_c = 0;
  local_14 = 0;
  uStack_10 = 0;
  FUN_600521dc(&local_c,&uStack_10,&local_14,param_4,param_1);
  uVar1 = 0;
  FUN_6015b134(DAT_6000af30,local_14,local_c,uStack_10);
  return CONCAT44(local_14,uVar1);
}

