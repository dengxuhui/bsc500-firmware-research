
int FUN_60019bd8(void)

{
  int iVar1;
  
  iVar1 = FUN_6016572c(DAT_60019bf8,0,DAT_60019bfc);
  if (iVar1 != 0) {
    FUN_6016713c(iVar1,0xe8,DAT_60019c00);
  }
  return iVar1;
}

