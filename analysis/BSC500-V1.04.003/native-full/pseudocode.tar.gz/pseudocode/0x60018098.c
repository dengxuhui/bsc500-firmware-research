
int FUN_60018098(void)

{
  int iVar1;
  
  if (*(char *)(DAT_600182ec + 0x30) == '\x04') {
    iVar1 = DAT_6001f8d8 + 0x18;
    FUN_6015d1e4(DAT_6001f8d4 + 0x18,iVar1);
    return iVar1;
  }
  return 0;
}

