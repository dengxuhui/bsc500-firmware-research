
void FUN_60017770(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  byte bVar6;
  uint uVar7;
  undefined1 auStack_160 [12];
  uint local_154;
  undefined1 auStack_150 [63];
  undefined1 local_111;
  undefined1 auStack_110 [64];
  undefined1 auStack_d0 [164];
  int local_2c;
  int local_28 [3];
  
  iVar1 = DAT_600178f4;
  FUN_601608ac(DAT_600178f4,0xdd0);
  for (iVar4 = 0x44; iVar4 != 0xaa0; iVar4 = iVar4 + 0x374) {
    FUN_60129756(iVar1 + iVar4,0x330);
  }
  local_154 = 0;
  FUN_601681f4(auStack_110,DAT_600178f8,DAT_600178fc,DAT_60017900);
  iVar4 = FUN_601609d0(auStack_160,auStack_110,2);
  if (iVar4 == 0) {
    FUN_60160948(auStack_160,0,0);
    FUN_6015c2f4(auStack_160,auStack_150,0x40,&local_154);
    FUN_60160a64(auStack_160);
    if (local_154 < 7) goto LAB_60017832;
    local_111 = 0;
    iVar4 = FUN_6016228c(auStack_150,0x3d);
    if ((iVar4 == 0) || (iVar4 = FUN_6016811c(iVar4 + 1), iVar4 != 0x6f)) goto LAB_60017832;
    FUN_601681f4(auStack_110,DAT_600178f8,DAT_600178fc,DAT_60017904);
    iVar4 = FUN_601609d0(auStack_160,auStack_110,2);
    if (iVar4 != 0) goto LAB_6001787e;
    FUN_60160948(auStack_160,0,0);
    FUN_6015c2f4(auStack_160,DAT_600178f4,0xdd0,&local_154);
  }
  else {
LAB_60017832:
    for (uVar7 = 0; uVar7 != 4; uVar7 = uVar7 + 1) {
      FUN_6015f7b0(uVar7 & 0xff);
    }
    iVar4 = FUN_601609d0(auStack_160,auStack_110,1);
    if (iVar4 != 0) goto LAB_6001787e;
    FUN_601681f4(auStack_150,DAT_60017908,0x6f);
    FUN_60160948(auStack_160,0,0);
    iVar4 = FUN_60168220(auStack_150);
    FUN_60160774(auStack_160,auStack_150,iVar4 + 1,&local_154);
  }
  FUN_60160a64(auStack_160);
LAB_6001787e:
  uVar7 = 0;
  local_28[2] = 0;
  local_28[0] = 0;
  local_28[1] = 0;
  while( true ) {
    uVar2 = (uint)*(ushort *)(iVar1 + 0x6e8);
    uVar5 = uVar7 & 0xff;
    if (uVar2 <= uVar5) break;
    ZeroBytes(auStack_d0,0xa8);
    FUN_60160650(auStack_d0,iVar1 + uVar5 * 0x110 + 0x73c,0xa8);
    uVar7 = uVar7 + 1;
    local_28[uVar5] = local_2c;
  }
  for (bVar6 = 0; bVar6 < uVar2; bVar6 = bVar6 + 1) {
    iVar4 = local_28[bVar6];
    if ((iVar4 != 0) && (iVar3 = thunk_FUN_60039fa0(iVar4), iVar3 == 0xffff)) {
      FUN_60162d68(iVar4,0);
    }
    uVar2 = (uint)*(ushort *)(iVar1 + 0x6e8);
  }
  FUN_60119dec();
  return;
}

