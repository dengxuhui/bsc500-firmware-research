
undefined1 FUN_600102b4(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined1 uVar2;
  int *piVar3;
  char cVar4;
  undefined4 local_30;
  int *local_2c;
  char local_21;
  
  piVar1 = DAT_60010368;
  piVar3 = (int *)*DAT_60010368;
  if ((code *)piVar3[1] != (code *)0x0) {
    (*(code *)piVar3[1])();
    piVar3 = (int *)*piVar1;
  }
  (**(code **)(*piVar3 + 8))(&local_30,piVar3,0);
  if (local_2c == (int *)0x0) {
    cVar4 = '\r';
  }
  else {
    (**(code **)(*local_2c + 0x10))(local_2c,0,2,3,local_30);
    (**(code **)(*(int *)*piVar1 + 0xc))((int *)*piVar1,&local_30);
    (**(code **)(*local_2c + 0x70))(local_2c,param_1);
    (**(code **)(*local_2c + 0x70))(local_2c,param_2);
    (**(code **)(*local_2c + 0x70))(local_2c,param_3);
    (**(code **)(*local_2c + 0x70))(local_2c,param_4);
    (**(code **)(*local_2c + 100))(local_2c,&local_21);
    cVar4 = (char)local_2c[5];
  }
  (**(code **)(*(int *)*piVar1 + 0x10))((int *)*piVar1,&local_30);
  FUN_601675ca(*piVar1,cVar4,3);
  if (*(code **)(*piVar1 + 8) != (code *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  if (cVar4 == '\0') {
    uVar2 = 0;
    if (local_21 != '\0') {
      uVar2 = 1;
    }
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

