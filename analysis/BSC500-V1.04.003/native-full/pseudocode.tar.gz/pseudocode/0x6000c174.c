
void FUN_6000c174(void)

{
  char cVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 in_r3;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  undefined4 *puVar10;
  
  iVar2 = DAT_6000c1fc;
  if (*(char *)(DAT_6000c1fc + 0x7a) != '\0') {
    puVar10 = (undefined4 *)(DAT_6000c1fc + 0x38);
    uVar4 = *(undefined4 *)(DAT_6000c1fc + 0x3c);
    uVar5 = *(undefined4 *)(DAT_6000c1fc + 0x40);
    uVar6 = *(undefined4 *)(DAT_6000c1fc + 0x44);
    uVar8 = *(undefined4 *)(DAT_6000c1fc + 0x48);
    *(undefined4 *)(DAT_6000c1fc + 0x1c) = *(undefined4 *)(DAT_6000c1fc + 0x34);
    *(undefined4 *)(iVar2 + 0x20) = *puVar10;
    *(undefined4 *)(iVar2 + 0x24) = uVar4;
    *(undefined4 *)(iVar2 + 0x28) = uVar5;
    *(undefined4 *)(iVar2 + 0x2c) = uVar6;
    *(undefined4 *)(iVar2 + 0x30) = uVar8;
    return;
  }
  iVar9 = DAT_6000c200[6];
  iVar7 = DAT_6000c200[7];
  cVar1 = *(char *)(DAT_6000c200 + 5);
  *(char *)(DAT_6000c1fc + 0x30) = cVar1;
  puVar10 = DAT_6000c200;
  if (((cVar1 != '\0') && (iVar3 = FUN_60166dd0(DAT_6000c200), iVar3 == 0)) &&
     (iVar3 = FUN_60166dd0(puVar10 + 2), iVar3 == 0)) {
    uVar4 = *puVar10;
    uVar5 = puVar10[1];
    uVar6 = puVar10[2];
    uVar8 = puVar10[3];
    iVar9 = puVar10[4];
    *(undefined4 *)(iVar2 + 0x1c) = uVar4;
    *(undefined4 *)(iVar2 + 0x20) = uVar5;
    *(undefined4 *)(iVar2 + 0x24) = uVar6;
    *(undefined4 *)(iVar2 + 0x28) = uVar8;
    iVar7 = DAT_6000c4b8;
    *(undefined4 *)(DAT_6000c4b8 + 0xb38) = uVar4;
    *(undefined4 *)(iVar7 + 0xb3c) = uVar6;
    iVar7 = *(int *)(iVar2 + 0x2c);
    if (iVar9 != 0x7fff) {
      iVar7 = iVar9;
    }
    *(int *)(iVar2 + 0x2c) = iVar7;
    return;
  }
  uVar4 = DAT_6000c204;
  if (iVar9 == 0x7fffffff || iVar7 == 0x7fffffff) {
    return;
  }
  FUN_60162cb0(iVar2 + 0x1c,iVar9,DAT_6000c204);
  FUN_60162cb0(iVar2 + 0x24,iVar7,uVar4,in_r3);
  return;
}

