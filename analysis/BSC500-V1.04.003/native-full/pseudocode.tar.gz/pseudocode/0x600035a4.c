
void FUN_600035a4(void)

{
  *DAT_600035ac = 1;
  return;
}

