
void FUN_6000a5e8(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_6015982e();
  FUN_60159828(uVar1,6,0,0);
  uVar2 = FUN_6015bd44();
  FUN_60159838(uVar2,DAT_6000a63c,uVar1);
  if (*(char *)(DAT_6000a614 + 1) != '\0') {
    *(undefined1 *)(DAT_6000a614 + 1) = 0;
  }
  return;
}

