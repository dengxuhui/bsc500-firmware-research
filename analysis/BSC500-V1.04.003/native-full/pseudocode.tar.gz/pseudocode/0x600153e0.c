
void FUN_600153e0(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int *piVar3;
  int iVar4;
  
  iVar4 = DAT_60015468;
  iVar1 = DAT_60015464;
  switch(param_1) {
  case 1:
    piVar3 = *(int **)(*(int *)(DAT_60015464 + 8) + 0xd8);
    if (piVar3 == (int *)0x0) {
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x6001b938. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar3 + 0xe0))();
    return;
  case 2:
    FUN_600ee0f0(*(undefined4 *)(DAT_60015464 + 8),DAT_60015468 + 1);
    uVar2 = *(undefined4 *)(iVar1 + 8);
    goto LAB_60015442;
  case 3:
    iVar4 = DAT_60015468 + 0xc;
    break;
  case 4:
    FUN_600ee0f0(*(undefined4 *)(DAT_60015464 + 8),DAT_60015468 + 0x19);
    uVar2 = *(undefined4 *)(iVar1 + 8);
    iVar4 = iVar4 + 0x1a;
    goto LAB_60015442;
  case 5:
    iVar4 = DAT_60015468 + 0xe;
    break;
  case 6:
    iVar4 = DAT_60015468 + 0x15;
    break;
  case 7:
    piVar3 = *(int **)(*(int *)(DAT_60015464 + 8) + 0xd8);
    if ((piVar3 != (int *)0x0) && (piVar3[0x11] == 3)) {
                    /* WARNING: Could not recover jumptable at 0x6001b94e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar3 + 0xe0))();
      return;
    }
    return;
  case 8:
    piVar3 = *(int **)(*(int *)(DAT_60015464 + 0x10) + 0x524);
    if (piVar3 == (int *)0x0) {
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x6001b818. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar3 + 0xe0))();
    return;
  default:
    return;
  }
  uVar2 = *(undefined4 *)(DAT_60015464 + 8);
LAB_60015442:
  FUN_600ee0f0(uVar2,iVar4);
  return;
}

