
void FUN_600168ec(undefined4 *param_1,char *param_2,char *param_3,char *param_4)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  char *local_1c;
  char *local_18;
  
  cVar1 = *param_2;
  *(char *)(param_1 + 6) = cVar1;
  local_1c = param_3;
  local_18 = param_4;
  if (cVar1 == '\0') {
    *(undefined2 *)((int)param_1 + 0x16) = 0xffff;
    uVar4 = *(undefined4 *)(param_2 + 8);
    uVar5 = *(undefined4 *)(param_2 + 0xc);
    uVar6 = *(undefined4 *)(param_2 + 0x10);
    *param_1 = *(undefined4 *)(param_2 + 4);
    param_1[1] = uVar4;
    param_1[2] = uVar5;
    param_1[3] = uVar6;
    param_1[4] = (*(int *)(param_2 + 0x1c) * 0x202) / *(int *)(param_2 + 0x20);
  }
  else {
    *(undefined2 *)((int)param_1 + 0x16) = *(undefined2 *)(param_2 + 2);
    if ((*(int *)(param_2 + 0x18) == 0) || (param_1[4] == 0)) {
      uVar2 = 0x7fff;
    }
    else {
      uVar2 = (undefined2)(*(int *)(param_2 + 0x14) / *(int *)(param_2 + 0x18));
    }
    *(undefined2 *)(param_1 + 5) = uVar2;
    iVar3 = DAT_60016994;
    if (*(int *)(param_2 + 0x20) != 0) {
      local_18 = (char *)0x0;
      FUN_60166e0c(DAT_60016994,&local_18,param_3,param_4,param_2);
      local_1c = (char *)0x0;
      FUN_60166e0c(iVar3 + 0x10,&local_1c);
      if (((local_18 == (char *)0x0) || (local_1c == (char *)0x0)) ||
         ((*local_18 == '\0' && (*local_1c != '\0')))) {
        param_1[4] = 0;
        iVar3 = FUN_60166dd0(param_1);
        if ((iVar3 == 0) && (iVar3 = FUN_60166dd0(param_1 + 2), iVar3 == 0)) goto LAB_6001698c;
      }
      else {
        param_1[4] = (*(int *)(param_2 + 0x1c) * 0x202) / *(int *)(param_2 + 0x20);
      }
      uVar4 = *(undefined4 *)(param_2 + 8);
      uVar5 = *(undefined4 *)(param_2 + 0xc);
      uVar6 = *(undefined4 *)(param_2 + 0x10);
      *param_1 = *(undefined4 *)(param_2 + 4);
      param_1[1] = uVar4;
      param_1[2] = uVar5;
      param_1[3] = uVar6;
    }
  }
LAB_6001698c:
  FUN_60021788();
  return;
}

