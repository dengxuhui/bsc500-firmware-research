
void FUN_600159b8(void)

{
  undefined4 *puVar1;
  undefined1 *puVar2;
  
  puVar2 = DAT_600159dc;
  if (DAT_600159dc[2] == '\x01') {
    puVar1 = (undefined4 *)(DAT_600159dc + 0x14);
    DAT_600159dc[3] = 0;
    FUN_601667bc(*puVar1);
    *(undefined4 *)(puVar2 + 0x14) = 0;
    *(undefined2 *)(puVar2 + 4) = 0;
    puVar2[2] = 0;
    *(undefined4 *)(puVar2 + 0xc) = 0;
    *puVar2 = 1;
  }
  return;
}

