
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 thunk_FUN_60005480(void)

{
  int iVar1;
  
  iVar1 = FUN_6000a514(1);
  if (iVar1 != 0) {
    return 0;
  }
  FUN_60168578("ant_version = %d\n",*_DAT_600054a4);
  FUN_6005136c();
  FUN_60009c30();
  return 1;
}

