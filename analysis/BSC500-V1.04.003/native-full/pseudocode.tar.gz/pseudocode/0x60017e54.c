
void FUN_60017e54(void)

{
  int iVar1;
  
  iVar1 = DAT_60017e68;
  if (*(int *)(DAT_60017e68 + 0x48) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 0x48) = 0;
  }
  return;
}

