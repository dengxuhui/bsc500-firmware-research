
undefined4 FUN_60013394(int param_1)

{
  int iVar1;
  char *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined2 local_44 [8];
  byte local_34;
  undefined2 local_32;
  undefined4 local_30;
  undefined4 uStack_2c;
  byte local_28;
  undefined4 local_20;
  undefined4 uStack_1c;
  byte local_18;
  
  pcVar2 = DAT_60013484;
  iVar1 = DAT_6001346c;
  uVar3 = 0xffffffff;
  if (param_1 != 0) {
    if (*DAT_60013484 == '\x01') {
      FUN_60133efe(DAT_6001346c);
      local_20 = 0;
      uStack_1c = 0;
      local_18 = *(byte *)(param_1 + 0x72);
      uVar5 = (uint)local_18;
      for (uVar4 = 0; uVar5 != uVar4; uVar4 = uVar4 + 1) {
        *(undefined1 *)((int)&local_20 + uVar4) = *(undefined1 *)(*(int *)(param_1 + 0x6c) + uVar4);
      }
      FUN_60133f20(iVar1 + 0x48,&local_20);
      FUN_60133f88(iVar1 + 0x88);
      FUN_60133f90(iVar1 + 0x8c);
      local_30 = 0;
      uStack_2c = 0;
      local_28 = *(byte *)(param_1 + 0x71);
      uVar5 = (uint)local_28;
      for (uVar4 = 0; uVar5 != uVar4; uVar4 = uVar4 + 1) {
        *(undefined1 *)((int)&local_30 + uVar4) = *(undefined1 *)(*(int *)(param_1 + 0x68) + uVar4);
      }
      FUN_60133fa0(iVar1 + 0xac,&local_30);
      ZeroBytes(local_44,0x14);
      local_34 = *(byte *)(param_1 + 0x70);
      uVar4 = (uint)local_34;
      for (uVar5 = 0; uVar4 != uVar5; uVar5 = uVar5 + 1) {
        local_44[uVar5] = *(undefined2 *)(*(int *)(param_1 + 100) + uVar5 * 2);
      }
      local_32 = *(undefined2 *)(param_1 + 0x1e);
      FUN_60134004(iVar1 + 0xe8,local_44);
      FUN_601340a4(iVar1 + 0x150);
      FUN_601340ac(iVar1 + 0x154);
      FUN_601340c6(iVar1 + 0x16c);
      *pcVar2 = '\x02';
      uVar3 = 0;
    }
  }
  return uVar3;
}

