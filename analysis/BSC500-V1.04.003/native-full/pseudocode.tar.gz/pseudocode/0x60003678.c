
bool FUN_60003678(void)

{
  int *piVar1;
  int iVar2;
  char *local_2c;
  undefined1 auStack_28 [16];
  undefined4 local_18;
  undefined4 local_14;
  
  ZeroBytes(auStack_28,0x20);
  local_14 = 0xf;
  local_2c = "navi_task";
  local_18 = 0x1000;
  iVar2 = FUN_601566b4(DAT_600036c0,0,&local_2c);
  piVar1 = DAT_600036c4;
  *DAT_600036c4 = iVar2;
  FUN_60156808();
  return *piVar1 != 0;
}

