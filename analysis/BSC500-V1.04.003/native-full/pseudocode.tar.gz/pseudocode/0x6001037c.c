
void FUN_6001037c(void)

{
  char *pcVar1;
  char cVar2;
  short sVar3;
  undefined1 *puVar4;
  ushort uVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  undefined4 uVar13;
  uint uVar14;
  code *UNRECOVERED_JUMPTABLE;
  uint in_fpscr;
  float fVar15;
  
  iVar6 = FUN_6016518c();
  puVar4 = DAT_60010524;
  sVar3 = *(short *)(DAT_60010524 + 4);
  if (DAT_60010524[1] != '\0') {
    FUN_60016c40();
  }
  *puVar4 = 1;
  FUN_6014bc0c();
  if (*(short *)(iVar6 + 0xc) == sVar3) {
    FUN_60016098();
  }
  else if ((*(short *)(iVar6 + 10) == sVar3) || (*(short *)(iVar6 + 0x10) == sVar3)) {
    if (*DAT_60010528 == '\x01') {
      *DAT_60010528 = '\0';
      FUN_600166a4();
    }
    iVar6 = FUN_60015a1c();
    if (iVar6 != 0) {
      FUN_6001ac14();
    }
  }
  iVar6 = FUN_6016518c();
  iVar7 = FUN_60164e24();
  iVar8 = FUN_601232d4(0);
  iVar9 = FUN_60164fe8();
  iVar10 = FUN_60164fe0();
  iVar11 = FUN_60165170();
  if ((*(code **)(iVar7 + 0x14) == (code *)0x0) ||
     (iVar12 = (**(code **)(iVar7 + 0x14))(3,0), iVar12 != 0)) {
    return;
  }
  if ((*(short *)(iVar6 + 2) == sVar3) || (*(short *)(iVar6 + 8) == sVar3)) {
    UNRECOVERED_JUMPTABLE = *(code **)(iVar7 + 0x14);
    iVar6 = FUN_60164fb8(3);
    uVar14 = iVar6 + 2000U & 0xffff;
    uVar13 = 0;
    goto LAB_60010420;
  }
  if (*(short *)(iVar6 + 4) == sVar3) {
    UNRECOVERED_JUMPTABLE = *(code **)(iVar7 + 0x14);
    uVar5 = FUN_60164fb8(1);
    uVar14 = (uint)uVar5;
    uVar13 = 1;
    goto LAB_60010420;
  }
  if (*(short *)(iVar6 + 6) == sVar3) {
    UNRECOVERED_JUMPTABLE = *(code **)(iVar7 + 0x14);
    uVar5 = FUN_60164fb8(2);
    uVar14 = (uint)uVar5;
    uVar13 = 2;
    goto LAB_60010420;
  }
  if ((iVar10 != 0) && (*(short *)(iVar6 + 0xc) == sVar3)) {
    iVar10 = iVar10 + (uint)*(ushort *)(iVar10 + 0x8ae) * 8;
    UNRECOVERED_JUMPTABLE = *(code **)(iVar7 + 0x14);
    uVar14 = ((*(int *)(iVar10 + 0x58c) - *(int *)(iVar10 + 0x584)) * 1000) /
             (*(int *)(iVar10 + 0x588) - *(int *)(iVar10 + 0x580)) + 2000U & 0xffff;
    uVar13 = 0;
    goto LAB_60010420;
  }
  if (*(short *)(iVar6 + 10) == sVar3) {
    cVar2 = *(char *)(iVar8 + iVar9 * 0x18 + 1);
    if (cVar2 != '\n' && cVar2 != '\a') {
LAB_60010518:
      UNRECOVERED_JUMPTABLE = *(code **)(iVar7 + 0x14);
      uVar13 = 0;
      uVar14 = 2000;
      goto LAB_60010420;
    }
    iVar8 = iVar8 + iVar9 * 0x18;
    uVar14 = (*(int *)(iVar8 + 8) + *(int *)(iVar8 + 4) & 0x1ffffU) >> 1;
  }
  else {
    if (*(short *)(iVar6 + 0x10) != sVar3) {
      return;
    }
    pcVar1 = (char *)(iVar8 + iVar9 * 0x18 + 1);
    cVar2 = *pcVar1;
    if (cVar2 != '\n' && cVar2 != '\a') {
      iVar6 = FUN_6001b5b8(0);
      if ((iVar6 != 0) && (*pcVar1 == '\r')) {
        UNRECOVERED_JUMPTABLE = *(code **)(iVar7 + 0x14);
        uVar13 = 0;
        uVar14 = 0x7ee;
        goto LAB_60010420;
      }
      goto LAB_60010518;
    }
    iVar8 = iVar8 + iVar9 * 0x18;
    fVar15 = (float)VectorUnsignedToFloat
                              ((*(int *)(iVar8 + 8) + *(int *)(iVar8 + 4)) * iVar11,
                               (byte)(in_fpscr >> 0x16) & 3);
    uVar14 = (uint)((fVar15 / DAT_6001052c) * 0.5);
  }
  UNRECOVERED_JUMPTABLE = *(code **)(iVar7 + 0x14);
  uVar13 = 2;
LAB_60010420:
                    /* WARNING: Could not recover jumptable at 0x60010424. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(uVar13,uVar14);
  return;
}

