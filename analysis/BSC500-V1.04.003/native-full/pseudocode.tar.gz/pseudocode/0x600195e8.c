
undefined4 FUN_600195e8(void)

{
  byte *pbVar1;
  int iVar2;
  
  pbVar1 = DAT_60019640;
  if ((*DAT_60019640 == 0) && (iVar2 = FUN_601176c4(0x6e), iVar2 != 0)) {
    iVar2 = FUN_60022370(*pbVar1 ^ 1);
    if (iVar2 == 0) goto LAB_60019638;
    *pbVar1 = 1;
  }
  else {
    if ((pbVar1[2] != 1) || ((iVar2 = FUN_601176c4(0x6e), iVar2 == 0 || (pbVar1[1] != 0)))) {
      return 0;
    }
    iVar2 = FUN_60022370(*pbVar1 ^ 1);
    if (iVar2 == 0) goto LAB_60019638;
  }
  if (pbVar1[1] != 1) {
    return 0;
  }
LAB_60019638:
  pbVar1[0] = 0;
  pbVar1[1] = 0;
  return 1;
}

