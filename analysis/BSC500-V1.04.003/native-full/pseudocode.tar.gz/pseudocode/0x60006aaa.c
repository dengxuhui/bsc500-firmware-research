
void FUN_60006aaa(int param_1)

{
  uint uVar1;
  byte *pbVar2;
  
  pbVar2 = *(byte **)(param_1 + 0x94);
  *(undefined4 *)(param_1 + 0x90) = 0;
  uVar1 = (uint)*pbVar2;
  if ((*pbVar2 & 1) != 0) {
    FUN_60166af4(*(undefined4 *)(pbVar2 + 0x9c));
    return;
  }
  if ((int)(uVar1 << 0x1d) < 0) {
    FUN_60166c0c(*(undefined4 *)(pbVar2 + 0x34));
    uVar1 = (uint)*pbVar2;
  }
  if (-1 < (int)(uVar1 << 0x1b)) {
    return;
  }
  FUN_60166c0c(pbVar2);
  return;
}

