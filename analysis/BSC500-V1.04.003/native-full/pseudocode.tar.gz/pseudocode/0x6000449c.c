
undefined4 FUN_6000449c(void)

{
  int iVar1;
  
  FUN_60159334(0);
  iVar1 = DAT_60008c2c;
  if (*(char *)(DAT_60008c2c + 1) == '\0') {
    FUN_60122458(0,0);
    *(undefined1 *)(iVar1 + 1) = 1;
  }
  else if (*(char *)(DAT_60008c2c + 2) != '\0') {
    *(undefined1 *)(DAT_60008c2c + 2) = 0;
    FUN_60122688();
  }
  return 1;
}

