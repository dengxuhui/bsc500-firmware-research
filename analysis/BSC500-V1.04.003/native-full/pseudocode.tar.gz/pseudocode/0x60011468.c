
void FUN_60011468(undefined4 param_1)

{
  FUN_6015af42(DAT_60011470,param_1);
  return;
}

