
void FUN_60019b80(void)

{
  int iVar1;
  undefined4 local_90;
  undefined1 local_8c;
  undefined1 local_8b;
  undefined1 local_8a;
  undefined1 local_89;
  undefined1 local_88;
  undefined1 local_87;
  
  iVar1 = FUN_6014893c();
  if (iVar1 != 0) {
    ZeroBytes(&local_90,0x7c);
    local_87 = 0;
    local_89 = 0;
    local_8b = 1;
    local_88 = 1;
    local_8a = 1;
    local_8c = 1;
    local_90 = DAT_60026d44;
    FUN_60156dac(&local_90);
    return;
  }
  return;
}

