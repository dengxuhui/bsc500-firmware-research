
void FUN_600034e4(void)

{
  int iVar1;
  
  iVar1 = FUN_60004e7c();
  *(bool *)(DAT_60003560 + 3) = iVar1 != 0;
  return;
}

