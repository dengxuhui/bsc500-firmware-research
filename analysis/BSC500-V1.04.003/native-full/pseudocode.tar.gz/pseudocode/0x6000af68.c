
uint FUN_6000af68(void)

{
  return (*(uint *)(DAT_6000af80 + 0x14) & 0x1ff) >> 8;
}

