
undefined4 FUN_600093dc(ushort *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined1 *puVar2;
  ushort uVar3;
  
  if (param_1 == (ushort *)0x0) {
    uVar1 = 0x40;
  }
  else {
    uVar3 = *param_1;
    if (0x11 < uVar3) {
      uVar3 = 0x12;
    }
    uVar1 = FUN_60163ca0();
    puVar2 = (undefined1 *)FUN_60163ce0(0xe0c,0xf,uVar1,uVar3 + 10,param_4);
    uVar1 = 0;
    *(ushort *)(puVar2 + 2) = uVar3;
    *puVar2 = 0;
    CopyBytes(puVar2 + 4,param_1 + 1,uVar3);
    CopyBytes(DAT_60009434,param_1 + 1,uVar3);
    *DAT_60009438 = (char)uVar3;
    FUN_60163ca4(puVar2);
  }
  return uVar1;
}

