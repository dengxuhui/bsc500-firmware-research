
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

char FUN_600182fc(void)

{
  char *pcVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  char local_25;
  undefined1 auStack_24 [4];
  undefined4 local_20;
  undefined1 auStack_1c [4];
  undefined4 local_18;
  int local_14;
  
  pcVar1 = DAT_600183ec;
  if (*DAT_600183ec == '\0') {
    local_20 = 0;
    local_25 = '\0';
    iVar4 = FUN_6012f44c();
    iVar5 = FUN_60166758(&local_20,DAT_600183f0,1);
    if (iVar5 == 0) {
      FUN_60161ef4(local_20,&local_25,1,auStack_24);
      FUN_601667bc(local_20);
      pcVar2 = DAT_6001842c;
      if ((iVar4 == 0x68) || (local_25 != 'h')) {
        (*DAT_6001842c)(DAT_600183f4);
        (*pcVar2)(_DAT_600183fc);
        (*pcVar2)(DAT_600183f0);
        (*pcVar2)(DAT_60018430);
      }
      else {
        local_18 = 0;
        local_14 = 0;
        iVar4 = FUN_60166758(&local_14,DAT_600183f4,1);
        if (iVar4 == 0) {
          uVar6 = FUN_6016506c();
          *(undefined4 *)(pcVar1 + 8) = uVar6;
          uVar6 = FUN_60162e34();
          *(undefined4 *)(pcVar1 + 4) = uVar6;
          uVar6 = FUN_60161ef4(local_14,uVar6,*(undefined4 *)(pcVar1 + 8),auStack_1c);
          FUN_60168578(DAT_600183f8,DAT_600183f4,uVar6);
          FUN_601667bc(local_14);
          iVar4 = FUN_60166758(&local_18,_DAT_600183fc,1);
          if (iVar4 == 0) {
            uVar6 = FUN_6016506c(local_18);
            *(undefined4 *)(pcVar1 + 0x10) = uVar6;
            uVar6 = FUN_60162e34();
            *(undefined4 *)(pcVar1 + 0xc) = uVar6;
            uVar6 = FUN_60161ef4(local_18,uVar6,*(undefined4 *)(pcVar1 + 0x10),auStack_1c);
            FUN_60168578(DAT_600183f8,_DAT_600183fc,uVar6);
            FUN_601667bc(local_18);
            FUN_60168578("nrf_dat_pack_size:%d, nrf_bin_pack_size:%d\n",*(undefined4 *)(pcVar1 + 8),
                         *(undefined4 *)(pcVar1 + 0x10));
          }
          *pcVar1 = '\x01';
        }
        else if (local_14 != 0) {
          FUN_601667bc();
        }
      }
    }
    cVar3 = *pcVar1;
  }
  else {
    cVar3 = '\x01';
  }
  return cVar3;
}

