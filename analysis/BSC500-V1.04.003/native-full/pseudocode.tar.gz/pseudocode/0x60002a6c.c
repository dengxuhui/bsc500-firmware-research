
undefined4 FUN_60002a6c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 *puVar1;
  int iVar2;
  undefined4 local_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  puVar1 = DAT_60002aa8;
  local_14 = param_2;
  uStack_10 = param_3;
  uStack_c = param_4;
  FUN_601678a8(DAT_60002aa8 + 4);
  FUN_60006bf8();
  FUN_60160bc0(DAT_60002ab0,DAT_60002aac);
  FUN_60006980(&local_14);
  *puVar1 = (char)local_14;
  iVar2 = DAT_60002ab4;
  *(short *)(DAT_60002ab4 + 2) = (short)uStack_10;
  FUN_60162c50(0x84,0);
  *(undefined1 *)(iVar2 + 1) = 1;
  return 0;
}

