
void FUN_6000b1c8(int param_1)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  
  cVar2 = FUN_6001682c();
  pcVar1 = DAT_6000b204;
  *DAT_6000b204 = cVar2;
  if ((param_1 != 0) && (iVar3 = FUN_6011d9b4(), iVar3 == 0)) {
    FUN_600168ec(DAT_6000b2b0 + 0xb4,param_1);
  }
  if ((((*(int *)(pcVar1 + 8) != 0) && (*pcVar1 != '\0')) && (*(int *)(pcVar1 + 0xc) != 0)) &&
     (iVar3 = FUN_60162268(), iVar3 == 0)) {
    FUN_601649f0(*(undefined4 *)(pcVar1 + 8));
    return;
  }
  return;
}

