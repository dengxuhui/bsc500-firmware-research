
undefined4 FUN_60016258(int param_1,int param_2,undefined4 *param_3)

{
  char cVar1;
  undefined2 uVar2;
  int iVar3;
  uint uVar4;
  undefined4 uVar5;
  int iVar6;
  undefined2 uVar7;
  uint uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int unaff_r6;
  undefined4 uVar11;
  
  if (param_1 != 0) {
    unaff_r6 = param_2;
  }
  if ((param_1 != 0 && param_2 != 0) && (param_3 != (undefined4 *)0x0)) {
    uVar5 = *(undefined4 *)(unaff_r6 + 0x1c);
    *param_3 = *(undefined4 *)(unaff_r6 + 0x18);
    param_3[1] = uVar5;
    FUN_60118c40(unaff_r6 + 0x20,unaff_r6 + 0x28,param_3 + 2,param_3 + 3);
    FUN_60118c40(unaff_r6 + 0x30,unaff_r6 + 0x38,param_3 + 4,param_3 + 5);
    param_3[0xd] = *(undefined4 *)(unaff_r6 + 0x54);
    param_3[0xc] = *(undefined4 *)(unaff_r6 + 0x50);
    iVar3 = *(int *)(unaff_r6 + 0x18);
    iVar6 = *(int *)(unaff_r6 + 0x1c);
    uVar8 = *(uint *)(unaff_r6 + 0x44);
    param_3[8] = *(undefined4 *)(unaff_r6 + 0x40);
    param_3[10] = *(undefined4 *)(unaff_r6 + 0x48);
    param_3[0xb] = *(undefined4 *)(unaff_r6 + 0x4c);
    uVar4 = (iVar3 - iVar6) * 1000 + 1000;
    *(undefined2 *)(param_3 + 0xe) = *(undefined2 *)(unaff_r6 + 0x58);
    param_3[6] = uVar4;
    if (uVar4 < uVar8) {
      uVar8 = uVar4;
    }
    uVar2 = *(undefined2 *)(unaff_r6 + 0x5a);
    iVar3 = *(int *)(unaff_r6 + 100);
    param_3[9] = uVar8;
    param_3[7] = uVar8;
    uVar7 = 0xffff;
    *(undefined2 *)((int)param_3 + 0x3a) = uVar2;
    *(undefined2 *)(param_3 + 0xf) = *(undefined2 *)(unaff_r6 + 0x5c);
    *(undefined2 *)((int)param_3 + 0x3e) = *(undefined2 *)(unaff_r6 + 0x5e);
    *(undefined2 *)(param_3 + 0x10) = *(undefined2 *)(unaff_r6 + 0x60);
    *(undefined2 *)((int)param_3 + 0x42) = *(undefined2 *)(unaff_r6 + 0x62);
    uVar2 = 0xffff;
    if (iVar3 != 0x7fffffff) {
      uVar7 = (undefined2)((iVar3 + 50000) / 0x14);
    }
    iVar3 = *(int *)(unaff_r6 + 0x68);
    *(undefined2 *)(param_3 + 0x11) = uVar7;
    uVar7 = 0xffff;
    if (iVar3 != 0x7fffffff) {
      uVar7 = (undefined2)((iVar3 + 50000) / 0x14);
    }
    uVar10 = *(undefined4 *)(unaff_r6 + 0x7a);
    uVar5 = *(undefined4 *)(unaff_r6 + 0x6e);
    uVar9 = *(undefined4 *)(unaff_r6 + 0x72);
    uVar11 = *(undefined4 *)(unaff_r6 + 0x76);
    *(undefined2 *)((int)param_3 + 0x46) = uVar7;
    *(undefined4 *)((int)param_3 + 0x56) = uVar10;
    uVar7 = *(undefined2 *)(unaff_r6 + 0x6c);
    *(undefined4 *)((int)param_3 + 0x4a) = uVar5;
    *(undefined4 *)((int)param_3 + 0x4e) = uVar9;
    *(undefined4 *)((int)param_3 + 0x52) = uVar11;
    *(undefined2 *)(param_3 + 0x12) = uVar7;
    if (*(int *)(unaff_r6 + 0x80) != 0x7fffffff) {
      uVar2 = (undefined2)((*(int *)(unaff_r6 + 0x80) + 50000) / 0x14);
    }
    param_3[0x19] = *(undefined4 *)(unaff_r6 + 0x8a);
    *(undefined2 *)((int)param_3 + 0x6b) = *(undefined2 *)(unaff_r6 + 0x8e);
    uVar7 = *(undefined2 *)(unaff_r6 + 0x91);
    *(undefined2 *)((int)param_3 + 0x5a) = uVar2;
    *(undefined2 *)((int)param_3 + 0x6e) = uVar7;
    *(undefined2 *)(param_3 + 0x17) = *(undefined2 *)(unaff_r6 + 0x84);
    *(undefined2 *)(param_3 + 0x18) = *(undefined2 *)(unaff_r6 + 0x86);
    *(undefined2 *)((int)param_3 + 0x5e) = *(undefined2 *)(unaff_r6 + 0x88);
    *(undefined1 *)((int)param_3 + 0x6d) = *(undefined1 *)(unaff_r6 + 0x90);
    *(undefined1 *)(param_3 + 0x1c) = *(undefined1 *)(unaff_r6 + 0x93);
    *(undefined1 *)((int)param_3 + 0x71) = *(undefined1 *)(unaff_r6 + 0x94);
    *(undefined1 *)((int)param_3 + 0x72) = *(undefined1 *)(unaff_r6 + 0x95);
    *(undefined1 *)((int)param_3 + 0x69) = 2;
    cVar1 = *(char *)(param_1 + 0x8d);
    if (cVar1 != '\x06') {
      cVar1 = '\a';
    }
    *(char *)((int)param_3 + 0x6a) = cVar1;
    return 0;
  }
  return 0xffffffff;
}

