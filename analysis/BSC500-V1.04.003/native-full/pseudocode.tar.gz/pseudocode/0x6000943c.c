
void FUN_6000943c(uint param_1,undefined4 *param_2,undefined1 param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  if ((param_1 < 8) && (param_2 != (undefined4 *)0x0)) {
    *(undefined1 *)((int)param_2 + 0x1b) = 0xff;
    *(undefined2 *)(param_2 + 6) = 0xffff;
    *(undefined4 **)(DAT_6000947c + param_1 * 4 + 4) = param_2;
    uVar2 = FUN_60137ef0(0x1c);
    uVar1 = DAT_60009480;
    *(undefined1 *)((int)param_2 + 0x1a) = param_3;
    param_2[5] = uVar2;
    FUN_6016572c(param_2 + 5,1,uVar1);
    *param_2 = 0;
    param_2[1] = param_2;
  }
  return;
}

