
void FUN_60013314(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  int iVar2;
  undefined2 local_90;
  undefined1 local_8e;
  undefined1 local_86;
  undefined1 local_76;
  undefined1 local_75;
  undefined1 local_74;
  undefined4 local_70;
  undefined1 local_6c;
  undefined4 local_68;
  
  iVar2 = FUN_6014893c();
  if (iVar2 != 0) {
    uVar1 = 2;
    if (param_1 != 0) {
      uVar1 = 1;
    }
    ZeroBytes(&local_90,0x7c);
    local_6c = 1;
    local_74 = 1;
    local_76 = 1;
    local_86 = 1;
    local_8e = 1;
    local_90 = 0x36e;
    local_75 = uVar1;
    local_70 = param_2;
    local_68 = param_3;
    FUN_60156dac(&local_90);
    return;
  }
  return;
}

