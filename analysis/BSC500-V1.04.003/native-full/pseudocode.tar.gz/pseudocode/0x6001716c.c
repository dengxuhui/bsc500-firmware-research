
undefined4 FUN_6001716c(void)

{
  int iVar1;
  
  iVar1 = DAT_60017184;
  *(undefined1 *)(DAT_60017184 + 0x36) = 0;
  *(undefined2 *)(iVar1 + 0x34) = 0x50;
  FUN_60160d64(4);
  return 0;
}

