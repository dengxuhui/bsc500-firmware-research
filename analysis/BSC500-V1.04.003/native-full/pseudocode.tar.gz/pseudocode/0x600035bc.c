
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600035bc(void)

{
  int iVar1;
  
  iVar1 = FUN_60004d18(_DAT_600035d4);
  if (iVar1 != 0) {
    FUN_60168578("map_route_patch_exist\n");
    *DAT_600035f0 = 1;
  }
  return;
}

