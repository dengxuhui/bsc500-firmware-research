
void FUN_60018148(void)

{
  int iVar1;
  
  iVar1 = DAT_6001817c;
  if (*(int *)(DAT_6001817c + 4) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 4) = 0;
    FUN_60163bbe(DAT_60018164);
    return;
  }
  return;
}

