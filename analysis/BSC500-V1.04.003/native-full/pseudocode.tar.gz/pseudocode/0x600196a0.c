
int FUN_600196a0(void)

{
  code *pcVar1;
  code *pcVar2;
  int iVar3;
  
  iVar3 = FUN_60023390(DAT_600196f8);
  if (iVar3 != 0) {
    return iVar3;
  }
  thunk_FUN_600263c6();
  pcVar1 = DAT_600196fc;
  (*DAT_600196fc)(0x32);
  thunk_FUN_600263ce();
  (*pcVar1)(0x32);
  thunk_FUN_600263c6();
  pcVar2 = DAT_60019704;
  (*DAT_60019704)(DAT_60019700);
  (*pcVar2)(DAT_60019708);
  (*pcVar2)(DAT_6001970c);
  (*pcVar1)(0x32);
  thunk_FUN_600263ce();
  (*pcVar1)(300);
  iVar3 = FUN_600233b0(DAT_60019710,DAT_60019714,DAT_60019718,DAT_6001971c,0);
  thunk_FUN_600263c4();
  return iVar3;
}

