
void FUN_6000b2bc(void)

{
  byte bVar1;
  int iVar2;
  float fVar3;
  int *piVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  char *pcVar8;
  uint uVar9;
  int iVar10;
  uint in_fpscr;
  float fVar11;
  undefined8 uVar12;
  
  iVar5 = FUN_60016998();
  iVar2 = DAT_6000b55c;
  if (iVar5 == 1) {
    ZeroBytes(DAT_6000b55c + 0xc,0x50);
    iVar5 = DAT_6000b560;
    bVar1 = *(byte *)(DAT_6000b560 + 1);
    *(byte *)(iVar2 + 0x2a) = bVar1;
    uVar6 = s_GPS_No_Fix_6000b580._4_4_;
    if (bVar1 < 2) {
      *(undefined4 *)(iVar2 + 0xc) = s_GPS_No_Fix_6000b580._0_4_;
      *(undefined4 *)(iVar2 + 0x10) = uVar6;
      *(undefined2 *)(iVar2 + 0x14) = s_GPS_No_Fix_6000b580._8_2_;
      *(char *)(iVar2 + 0x16) = s_GPS_No_Fix_6000b580[10];
    }
    else {
      uVar6 = DAT_6000b564;
      if ((bVar1 == 3) || (uVar6 = DAT_6000b56c, bVar1 == 2)) {
        *(undefined4 *)(iVar2 + 0xf) = uVar6;
        *(undefined4 *)(iVar2 + 0xc) = DAT_6000b568;
      }
      iVar10 = FUN_60166dd0(iVar5 + 4);
      fVar3 = DAT_6000b574;
      if (iVar10 == 0) {
        fVar11 = (float)VectorUnsignedToFloat
                                  ((uint)*(ushort *)(iVar5 + 2),(byte)(in_fpscr >> 0x16) & 3);
        uVar12 = FUN_60166bb4(fVar11 / DAT_6000b574);
        FUN_601681f4(iVar2 + 0x1b,"%.2fm",(int)uVar12,(int)((ulonglong)uVar12 >> 0x20));
        fVar11 = (float)VectorUnsignedToFloat
                                  ((uint)*(ushort *)(iVar5 + 2),(byte)(in_fpscr >> 0x16) & 3);
        *(float *)(iVar2 + 0x2c) = fVar11 / fVar3;
      }
      else {
        *(undefined1 *)(iVar2 + 0x1d) = 0;
        *(undefined2 *)(iVar2 + 0x1b) = 0x6d2d;
        *(undefined4 *)(iVar2 + 0x2c) = DAT_6000b570;
      }
    }
    piVar4 = DAT_6000b58c;
    for (uVar9 = 0; uVar9 != 0x46; uVar9 = uVar9 + 1) {
      iVar5 = uVar9 * 3 + *piVar4;
      if (*(char *)(iVar5 + 0xd) == '\x01') {
        bVar1 = *(byte *)(iVar5 + 0xe);
        if (bVar1 < 0x2d) {
          if (bVar1 < 0x28) {
            if (bVar1 < 0x23) {
              *(char *)(iVar2 + 0x33) = *(char *)(iVar2 + 0x33) + '\x01';
            }
            else {
              *(char *)(iVar2 + 0x32) = *(char *)(iVar2 + 0x32) + '\x01';
            }
          }
          else {
            *(char *)(iVar2 + 0x31) = *(char *)(iVar2 + 0x31) + '\x01';
          }
        }
        else {
          *(char *)(iVar2 + 0x30) = *(char *)(iVar2 + 0x30) + '\x01';
        }
        *(char *)(iVar2 + 0x34) = *(char *)(iVar2 + 0x34) + '\x01';
        if (uVar9 < 5) {
          *(undefined1 *)(iVar2 + uVar9 + 0x44) = *(undefined1 *)(iVar5 + 0xe);
        }
        else {
          *(undefined1 *)(iVar2 + 0x49) = *(undefined1 *)(iVar5 + 0xe);
          FUN_600f84e4(iVar2 + 0x44,6);
        }
      }
    }
    for (uVar9 = 0; uVar9 != 0x46; uVar9 = uVar9 + 1) {
      iVar5 = uVar9 * 3 + *piVar4;
      if (*(char *)(iVar5 + 0xdf) == '\x03') {
        bVar1 = *(byte *)(iVar5 + 0xe0);
        pcVar8 = (char *)(iVar2 + 0x35);
        if (((bVar1 < 0x2d) && (pcVar8 = (char *)(iVar2 + 0x36), bVar1 < 0x28)) &&
           (pcVar8 = (char *)(iVar2 + 0x38), 0x22 < bVar1)) {
          pcVar8 = (char *)(iVar2 + 0x37);
        }
        *pcVar8 = *pcVar8 + '\x01';
        *(char *)(iVar2 + 0x39) = *(char *)(iVar2 + 0x39) + '\x01';
        if (uVar9 < 5) {
          *(undefined1 *)(iVar2 + uVar9 + 0x4a) = *(undefined1 *)(iVar5 + 0xe0);
        }
        else {
          *(undefined1 *)(iVar2 + 0x4f) = *(undefined1 *)(iVar5 + 0xe0);
          FUN_600f84e4(iVar2 + 0x4a,6);
        }
      }
    }
    for (uVar9 = 0; uVar9 != 100; uVar9 = uVar9 + 1) {
      iVar5 = uVar9 * 3 + *piVar4;
      if (*(char *)(iVar5 + 0x1b1) == '\x02') {
        bVar1 = *(byte *)(iVar5 + 0x1b2);
        if (bVar1 < 0x2d) {
          if (bVar1 < 0x28) {
            if (bVar1 < 0x23) {
              *(char *)(iVar2 + 0x3d) = *(char *)(iVar2 + 0x3d) + '\x01';
            }
            else {
              *(char *)(iVar2 + 0x3c) = *(char *)(iVar2 + 0x3c) + '\x01';
            }
          }
          else {
            *(char *)(iVar2 + 0x3b) = *(char *)(iVar2 + 0x3b) + '\x01';
          }
        }
        else {
          *(char *)(iVar2 + 0x3a) = *(char *)(iVar2 + 0x3a) + '\x01';
        }
        *(char *)(iVar2 + 0x3e) = *(char *)(iVar2 + 0x3e) + '\x01';
        if (uVar9 < 5) {
          *(undefined1 *)(iVar2 + uVar9 + 0x50) = *(undefined1 *)(iVar5 + 0x1b2);
        }
        else {
          *(undefined1 *)(iVar2 + 0x55) = *(undefined1 *)(iVar5 + 0x1b2);
          FUN_600f84e4(iVar2 + 0x50,6);
        }
      }
    }
    iVar5 = 0x56;
    for (iVar10 = 0x2de; iVar10 != 0x3b0; iVar10 = iVar10 + 3) {
      iVar7 = *piVar4;
      if (*(char *)(iVar7 + iVar10 + -1) == '\x04') {
        bVar1 = *(byte *)(iVar7 + iVar10);
        pcVar8 = (char *)(iVar2 + 0x3f);
        if (((bVar1 < 0x2d) && (pcVar8 = (char *)(iVar2 + 0x40), bVar1 < 0x28)) &&
           (pcVar8 = (char *)(iVar2 + 0x42), 0x22 < bVar1)) {
          pcVar8 = (char *)(iVar2 + 0x41);
        }
        *pcVar8 = *pcVar8 + '\x01';
        *(char *)(iVar2 + 0x43) = *(char *)(iVar2 + 0x43) + '\x01';
        if (iVar5 - 0x56U < 5) {
          *(undefined1 *)(iVar2 + iVar5) = *(undefined1 *)(iVar7 + iVar10);
        }
        else {
          *(undefined1 *)(iVar2 + 0x5b) = *(undefined1 *)(iVar7 + iVar10);
          FUN_600f84e4(iVar2 + 0x56,6);
        }
      }
      iVar5 = iVar5 + 1;
    }
  }
  return;
}

