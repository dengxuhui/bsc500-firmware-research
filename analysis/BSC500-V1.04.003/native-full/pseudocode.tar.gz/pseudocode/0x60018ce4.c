
void FUN_60018ce4(int param_1)

{
  if (param_1 != 0) {
    CopyBytes(DAT_60018cf4 + 0x30,param_1,0x30);
    return;
  }
  return;
}

