
void FUN_600074e4(void)

{
  *DAT_600074ec = 0;
  return;
}

