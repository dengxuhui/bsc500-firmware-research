
void FUN_60008c30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  char cVar2;
  int *piVar3;
  undefined1 *puVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined1 uVar9;
  int iVar10;
  bool bVar11;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  
  piVar3 = DAT_60008d2c;
  bVar5 = *(byte *)(*DAT_60008d2c + 2);
  cVar2 = *(char *)(*DAT_60008d2c + 3);
  uStack_20 = param_2;
  uStack_1c = param_3;
  uStack_18 = param_4;
  iVar6 = thunk_FUN_60149780();
  puVar4 = DAT_60008d30;
  pcVar1 = DAT_60008d30 + 3;
  *DAT_60008d30 = (char)iVar6;
  if ((*pcVar1 == '\0') && (iVar6 != 0)) {
    if (cVar2 == '\x01') {
      if (bVar5 < 3) {
        uVar9 = 0xf;
      }
      else {
        if (bVar5 < 6) goto LAB_60008c66;
        if (10 < bVar5) {
          bVar11 = 0xf < bVar5;
          goto LAB_60008c76;
        }
LAB_60008c6e:
        uVar9 = 3;
      }
    }
    else if (bVar5 < 3) {
LAB_60008c66:
      uVar9 = 7;
    }
    else {
      if (bVar5 < 6) goto LAB_60008c6e;
      bVar11 = 10 < bVar5;
LAB_60008c76:
      uVar9 = 0;
      if (!bVar11) {
        uVar9 = 1;
      }
    }
    puVar4[2] = uVar9;
    puVar4[3] = 1;
  }
  if (0xf < bVar5) {
    bVar5 = 0;
    goto LAB_60008c86;
  }
  if (iVar6 == 0) {
    puVar4[2] = 0;
    if (bVar5 != 0) {
      return;
    }
    if (cVar2 == '\x01') {
      return;
    }
    FUN_60167194(0x18,0,0,0);
    return;
  }
  if (cVar2 == '\x01') {
    if (bVar5 < 0xb) {
      if (bVar5 < 6) {
        if (bVar5 < 3) {
          bVar5 = 0xf;
        }
        else {
          bVar5 = 7;
        }
      }
      else {
        bVar5 = 3;
      }
    }
    else {
      bVar5 = 1;
    }
    goto LAB_60008c86;
  }
  if (bVar5 < 3) {
    uVar7 = 3;
  }
  else if (bVar5 < 6) {
    uVar7 = 2;
  }
  else {
    uVar7 = 0;
    if (bVar5 < 0xb) {
      uVar7 = 1;
    }
  }
  if (((uint)(byte)puVar4[2] & 1 << uVar7) >> uVar7 != 0) {
    return;
  }
  if ((uVar7 | 2) == 2) {
    if (*(char *)(*piVar3 + 0x93) == '\0') {
      iVar10 = 0;
      iVar6 = DAT_60008d34 + 1;
      uVar8 = DAT_60008d38;
      goto LAB_60008d20;
    }
  }
  else {
    uVar8 = FUN_6015240c();
    iVar10 = (int)&uStack_20 + 2;
    FUN_601681f4(iVar10,&LAB_60008d3c,uVar8);
    uVar8 = 0;
    iVar6 = DAT_60008d34;
LAB_60008d20:
    FUN_60163e70(iVar6,iVar10,uVar8);
  }
  bVar5 = puVar4[2] | (byte)(1 << uVar7);
LAB_60008c86:
  puVar4[2] = bVar5;
  return;
}

