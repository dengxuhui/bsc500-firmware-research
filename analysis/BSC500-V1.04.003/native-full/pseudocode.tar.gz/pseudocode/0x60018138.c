
void FUN_60018138(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_6001fac8(DAT_6001817c + 0x10,param_1,param_2,param_3);
  return;
}

