
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000a514(int param_1)

{
  int iVar1;
  char *pcVar2;
  
  iVar1 = FUN_600182f0();
  if (iVar1 != 0) {
    *_DAT_6000a564 = (char)param_1;
    if (param_1 == 0) {
      pcVar2 = "Please Set the start flag\n";
    }
    else {
      iVar1 = FUN_6012f44c();
      FUN_60168578("current_nrf528xx_version:%d\n",iVar1);
      if ((iVar1 != 0x68) && (iVar1 = FUN_600182fc(), iVar1 != 0)) {
        FUN_60139e58(1);
        FUN_6012f458();
        thunk_FUN_6005345c();
        FUN_600159e0();
        return 1;
      }
      pcVar2 = "The version is consistent and no upgrade is required\n";
    }
    FUN_60168578(pcVar2);
  }
  return 0;
}

