
/* WARNING: Restarted to delay deadcode elimination for space: stack */

undefined4 FUN_6000c568(int param_1,int param_2)

{
  int *piVar1;
  ushort uVar2;
  undefined1 uVar3;
  int *piVar4;
  code *pcVar5;
  byte bVar6;
  undefined2 uVar7;
  byte bVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  undefined4 *puVar12;
  uint uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  int iVar16;
  int iVar17;
  int iVar18;
  int iVar19;
  int iVar20;
  int iVar21;
  uint uVar22;
  uint uVar23;
  uint uVar24;
  uint uVar25;
  uint uVar26;
  int iVar27;
  uint uVar28;
  undefined4 uVar29;
  uint uVar30;
  uint uVar31;
  undefined4 uVar32;
  bool bVar33;
  undefined4 uVar34;
  undefined8 uVar35;
  undefined8 uVar36;
  undefined1 auStack_1dc [100];
  undefined1 auStack_178 [100];
  int local_114 [4];
  int local_104 [4];
  undefined4 local_f4;
  byte local_f0;
  undefined1 auStack_ef [10];
  undefined3 local_e5;
  undefined3 local_e2;
  undefined2 local_df;
  undefined1 local_dd;
  undefined4 local_90;
  undefined4 local_8c;
  undefined2 local_88;
  undefined1 local_86;
  uint local_84;
  undefined4 uStack_80;
  undefined1 uStack_7d;
  undefined2 local_7c;
  undefined4 local_78 [13];
  undefined4 local_44;
  
  iVar9 = FUN_601639fc();
  uVar7 = local_7c;
  ZeroBytes(auStack_178,100);
  local_7c = uVar7;
  uVar7 = local_7c;
  ZeroBytes(auStack_1dc,100);
  local_7c = uVar7;
  uVar7 = local_7c;
  piVar4 = DAT_6000ce88;
  if (*DAT_6000ce88 == 0) {
    return 0xffffffff;
  }
  iVar10 = FUN_60163a88();
  local_7c = uVar7;
  uVar7 = local_7c;
  if (((iVar10 == 0) ||
      (iVar10 = FUN_60166dd0(*piVar4), local_7c = uVar7, bVar8 = local_7c._1_1_, iVar10 != 0)) ||
     (uVar7 = local_7c, local_7c._1_1_ = bVar8, iVar11 = FUN_60166dd0(*piVar4 + 8),
     bVar8 = local_7c._1_1_, iVar27 = DAT_6000ce9c, iVar10 = DAT_6000ce8c, iVar11 != 0)) {
    *(undefined1 *)(iVar9 + 0x16) = 0;
    return 0;
  }
  bVar33 = param_2 != 0;
  *(undefined4 *)(DAT_6000ce8c + 900) = DAT_6000ce90;
  *(undefined4 *)(iVar10 + 0x388) = 0x10000;
  if (!bVar33 || param_1 == 0) {
    param_2 = 0x24000;
  }
  *(undefined4 *)(iVar10 + 0x324) = DAT_6000ce94;
  *(int *)(iVar10 + 0x328) = param_2;
  *DAT_6000ce98 = param_2;
  if (bVar33 && param_1 != 0) {
    iVar27 = param_1;
  }
  uVar7 = local_7c;
  local_7c._1_1_ = bVar8;
  puVar12 = (undefined4 *)FUN_60162b78(1);
  uVar7 = local_7c;
  iVar10 = FUN_6015f308(*puVar12,puVar12[2]);
  local_7c = uVar7;
  uVar7 = local_7c;
  if (iVar10 == 0) {
    uVar14 = 0xffffffff;
  }
  else {
    uVar13 = FUN_601668a4();
    local_7c = uVar7;
    bVar8 = local_7c._1_1_;
    iVar10 = DAT_6000cea4;
    if (uVar13 < 2) {
      iVar10 = DAT_6000cea0;
    }
    uVar7 = local_7c;
    local_7c._1_1_ = bVar8;
    uVar13 = FUN_601668a4();
    uVar7 = local_7c;
    uVar14 = *puVar12;
    uVar15 = puVar12[1];
    uVar29 = puVar12[3];
    uVar35 = FUN_6016759c(puVar12[2]);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar36 = FUN_6016759c(uVar29);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar35 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),(int)uVar36,
                          (int)((ulonglong)uVar36 >> 0x20));
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar32 = (undefined4)((ulonglong)DAT_6000c8e0 >> 0x20);
    uVar34 = (undefined4)DAT_6000c8e0;
    FUN_601678fc((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar16 = FUN_60167a50();
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar35 = FUN_6016759c();
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar29 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar3 = *(undefined1 *)(iVar10 + (uint)((uVar13 | 2) != 2));
    iVar17 = FUN_60159978(uVar29,uVar3);
    local_7c = uVar7;
    uVar7 = local_7c;
    local_104[0] = iVar17;
    uVar35 = FUN_6016759c(uVar14);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar36 = FUN_6016759c(uVar15);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar35 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),(int)uVar36,
                          (int)((ulonglong)uVar36 >> 0x20));
    local_7c = uVar7;
    uVar7 = local_7c;
    FUN_601678fc((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar18 = FUN_60167a50();
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar35 = FUN_6016759c();
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar14 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar19 = FUN_60159878(uVar14,uVar3);
    local_7c = uVar7;
    uVar7 = local_7c;
    local_114[0] = iVar19;
    uVar14 = FUN_60159a10(iVar17,uVar3);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar35 = FUN_60166bb4(uVar14);
    local_7c = uVar7;
    uVar7 = local_7c;
    FUN_601678fc((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar10 = FUN_60167a50();
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar14 = FUN_60159a60(iVar19,uVar3);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar20 = iVar17 + 1;
    uVar15 = FUN_60159a10(iVar20,uVar3);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar29 = FUN_60159a60(iVar19 + 1,uVar3);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar11 = DAT_6000ce8c;
    *(int *)(DAT_6000ce8c + 0x2b0) = iVar10;
    uVar35 = FUN_60166bb4(uVar14);
    local_7c = uVar7;
    uVar7 = local_7c;
    FUN_601678fc((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar21 = FUN_60167a50();
    local_7c = uVar7;
    uVar7 = local_7c;
    *(int *)(iVar11 + 0x2ac) = iVar21;
    local_114[1] = iVar19;
    uVar35 = FUN_60166bb4(uVar15);
    local_7c = uVar7;
    uVar7 = local_7c;
    FUN_601678fc((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar11 = FUN_60167a50();
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar10 = iVar16 - iVar10;
    if (iVar10 < 0) {
      iVar10 = -iVar10;
    }
    iVar11 = iVar11 - iVar16;
    if (iVar11 < 0) {
      iVar11 = -iVar11;
    }
    local_104[2] = iVar17;
    local_104[3] = iVar20;
    if (iVar10 <= iVar11) {
      iVar20 = iVar17 + -1;
      local_104[2] = iVar17 + -1;
      local_104[3] = iVar17;
    }
    local_104[1] = iVar20;
    uVar35 = FUN_60166bb4(uVar29);
    local_7c = uVar7;
    uVar7 = local_7c;
    FUN_601678fc((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),uVar34,uVar32);
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar10 = FUN_60167a50();
    local_7c = uVar7;
    uVar7 = local_7c;
    iVar21 = iVar18 - iVar21;
    if (iVar21 < 0) {
      iVar21 = -iVar21;
    }
    iVar10 = iVar10 - iVar18;
    iVar11 = -1;
    if (iVar10 < 0) {
      iVar10 = -iVar10;
    }
    if (iVar10 < iVar21) {
      iVar11 = 1;
    }
    iVar10 = 0;
    local_114[2] = iVar11 + iVar19;
    local_114[3] = iVar11 + iVar19;
    do {
      if (iVar10 == 4) {
        if (piVar4[1] != param_1) goto LAB_6000c80c;
        uVar14 = 0;
        goto LAB_6000c860;
      }
    } while (((piVar4[iVar10 + 0x14] != 0) || (piVar4[iVar10 + 0x18] != 0)) &&
            ((local_104[iVar10] == piVar4[iVar10 + 0x14] &&
             (piVar1 = local_114 + iVar10, iVar11 = iVar10 + 0x18, iVar10 = iVar10 + 1,
             *piVar1 == piVar4[iVar11]))));
    for (iVar10 = 0; iVar10 != 4; iVar10 = iVar10 + 1) {
      piVar4[iVar10 + 0x14] = local_104[iVar10];
      piVar4[iVar10 + 0x18] = local_114[iVar10];
    }
LAB_6000c80c:
    if (*(char *)(iVar9 + 0x1f) != '\0') {
      return 0xffffffff;
    }
    piVar4[1] = param_1;
    *(undefined1 *)(iVar9 + 0x1f) = 1;
    iVar10 = FUN_60163b60();
    local_7c = uVar7;
    uVar7 = local_7c;
    puVar12 = (undefined4 *)FUN_60162b78(1);
    local_7c = uVar7;
    uVar7 = local_7c;
    uVar14 = 0xffffffff;
    bVar8 = local_7c._1_1_;
    if ((iVar10 != 0) && (puVar12 != (undefined4 *)0x0)) {
      iVar10 = FUN_60166dd0(puVar12);
      local_7c = uVar7;
      uVar7 = local_7c;
      bVar8 = local_7c._1_1_;
      if ((iVar10 == 0) &&
         (iVar10 = FUN_60166dd0(puVar12 + 2), local_7c = uVar7, bVar8 = local_7c._1_1_,
         uVar7 = local_7c, iVar10 == 0)) {
        local_7c._1_1_ = bVar8;
        uVar13 = FUN_601668a4();
        uVar7 = local_7c;
        uVar14 = puVar12[3];
        uVar35 = FUN_6016759c(puVar12[2]);
        local_7c = uVar7;
        uVar7 = local_7c;
        uVar36 = FUN_6016759c(uVar14);
        local_7c = uVar7;
        uVar7 = local_7c;
        uVar14 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),(int)uVar36,
                              (int)((ulonglong)uVar36 >> 0x20));
        local_7c = uVar7;
        uVar7 = local_7c;
        uVar15 = 0xd;
        if (uVar13 < 2) {
          uVar15 = 9;
        }
        uVar13 = FUN_60159978(uVar14,uVar15);
        local_7c = uVar7;
        uVar7 = local_7c;
        uVar14 = puVar12[1];
        uVar35 = FUN_6016759c(*puVar12);
        local_7c = uVar7;
        uVar7 = local_7c;
        uVar36 = FUN_6016759c(uVar14);
        local_7c = uVar7;
        uVar7 = local_7c;
        uVar14 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),(int)uVar36,
                              (int)((ulonglong)uVar36 >> 0x20));
        local_7c = uVar7;
        uVar7 = local_7c;
        uVar22 = FUN_60159878(uVar14,uVar15);
        local_7c = uVar7;
        uVar7 = local_7c;
        if ((piVar4[2] == uVar13) && (piVar4[3] == uVar22)) {
LAB_6000c95c:
          local_7c = uVar7;
          bVar8 = local_7c._1_1_;
          *(undefined1 *)(iVar9 + 0x20) = 1;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          FUN_60167214(iVar27,*DAT_6000ce98);
          uVar7 = local_7c;
          iVar10 = DAT_6000ce8c;
          *(undefined4 *)(DAT_6000ce8c + 0x2a4) = 0;
          *(undefined4 *)(iVar10 + 0x2a8) = 0;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          ZeroBytes(iVar10 + 0x2b4,0x70);
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          ZeroBytes(iVar10 + 0x32c,0x58);
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          FUN_601021f4(auStack_178,iVar10 + *(int *)(iVar10 + 0x2a0) * 0x18 + 0x188);
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          FUN_6001b248();
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          uVar14 = FUN_600171a8(iVar27,auStack_178,local_104,local_114);
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          uVar13 = FUN_601668a4();
          uVar7 = local_7c;
          if (1 < uVar13) {
            bVar8 = local_7c._1_1_;
            local_7c = uVar7;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            FUN_600158f8(auStack_1dc,auStack_178);
            uVar7 = local_7c;
            bVar8 = local_7c._1_1_;
            local_7c = uVar7;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            uVar14 = FUN_60015618(iVar27,auStack_1dc,local_104,local_114);
            uVar7 = local_7c;
          }
          local_7c = uVar7;
          bVar8 = local_7c._1_1_;
          iVar11 = DAT_6000ce8c + 0x188;
          iVar10 = DAT_6000ce8c;
          for (uVar13 = 0; local_7c._1_1_ = bVar8, bVar8 = local_7c._1_1_, uVar7 = local_7c,
              uVar13 < *(uint *)(iVar10 + 0x184); uVar13 = uVar13 + 1) {
            if ((uVar13 != *(uint *)(iVar10 + 0x2a0)) &&
               (*(int *)(iVar10 + uVar13 * 4 + 0x278) != 0)) {
              local_7c._1_1_ = bVar8;
              FUN_601021f4(auStack_178,iVar11);
              uVar7 = local_7c;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar14 = FUN_600171a8(iVar27,auStack_178,local_104,local_114);
              uVar7 = local_7c;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar22 = FUN_601668a4();
              uVar7 = local_7c;
              iVar10 = DAT_6000ce8c;
              bVar8 = local_7c._1_1_;
              if (1 < uVar22) {
                local_7c = uVar7;
                uVar7 = local_7c;
                local_7c._1_1_ = bVar8;
                FUN_600158f8(auStack_1dc,auStack_178);
                uVar7 = local_7c;
                bVar8 = local_7c._1_1_;
                local_7c = uVar7;
                uVar7 = local_7c;
                local_7c._1_1_ = bVar8;
                uVar14 = FUN_60015618(iVar27,auStack_1dc,local_104,local_114);
                uVar7 = local_7c;
                iVar10 = DAT_6000ce8c;
                bVar8 = local_7c._1_1_;
              }
            }
            local_7c._1_1_ = bVar8;
            local_7c = uVar7;
            bVar8 = local_7c._1_1_;
            iVar11 = iVar11 + 0x18;
          }
          goto LAB_6000c858;
        }
        iVar10 = DAT_6000ce8c + 0x184;
        ZeroBytes(iVar10,0x120);
        iVar11 = FUN_60163b60();
        ZeroBytes(&local_f4,100);
        local_84 = 0;
        uStack_80 = 0;
        local_7c = 0;
        local_7c._1_1_ = 0;
        local_8c = (uint)local_8c._3_1_ << 0x18;
        local_90 = (uint)local_90._3_1_ << 0x18;
        local_88 = 0;
        local_86 = 0;
        uVar23 = FUN_601668a4();
        uVar7 = local_7c;
        if ((iVar11 != 0) && (*(char *)(iVar11 + 0x9d) != '\0')) {
          *(undefined4 *)(DAT_6000ce8c + 0x184) = 0;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          iVar11 = FUN_60162384(local_78,(char *)(iVar11 + 0x9d));
          uVar7 = local_7c;
          pcVar5 = DAT_6000ceac;
          if (iVar11 == 0) {
            bVar8 = local_7c._1_1_;
LAB_6000caea:
            do {
              local_7c._1_1_ = bVar8;
              local_7c = uVar7;
              bVar8 = local_7c._1_1_;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              iVar11 = FUN_600166ee(local_78,&local_f4,DAT_6000cea8,0,0,0,0);
              uVar7 = local_7c;
              if (iVar11 == 0) goto LAB_6000cc40;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              iVar11 = FUN_60168220(&local_f4);
              bVar8 = local_7c._1_1_;
              bVar6 = local_f0;
              uVar14 = local_f4;
              uVar7 = local_7c;
            } while (iVar11 != 0x1c);
            local_7c._1_1_ = bVar8;
            CopyBytes(&local_84,auStack_ef,10);
            uVar7 = local_7c;
            local_8c = CONCAT13(local_8c._3_1_,local_e5);
            local_90 = CONCAT13(local_90._3_1_,local_e2);
            local_88 = local_df;
            local_86 = local_dd;
            bVar8 = local_7c._1_1_;
            if (uVar23 < 2) {
              if (bVar6 < 0x3a) goto LAB_6000caea;
            }
            else if (0x39 < bVar6) goto LAB_6000caea;
            local_44._0_2_ = CONCAT21(uVar7,uStack_7d);
            local_44._2_2_ = (ushort)local_7c._1_1_;
            local_7c = uVar7;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            uVar24 = (*pcVar5)(0x24,&local_44);
            uVar7 = local_7c;
            local_44._0_3_ = (undefined3)local_8c;
            bVar8 = local_7c._1_1_;
            local_7c = uVar7;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            uVar25 = (*pcVar5)(0x24,&local_44);
            uVar7 = local_7c;
            local_44._0_3_ = (undefined3)local_90;
            bVar8 = local_7c._1_1_;
            local_7c = uVar7;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            iVar21 = (*pcVar5)(0x24,&local_44);
            uVar7 = local_7c;
            local_44._0_3_ = CONCAT12(local_86,local_88);
            bVar8 = local_7c._1_1_;
            local_7c = uVar7;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            iVar20 = (*pcVar5)(0x24,&local_44);
            uVar7 = local_7c;
            iVar11 = DAT_6000ce8c;
            bVar8 = local_7c._1_1_;
            if ((((uVar22 < uVar25) || (uVar13 < uVar24)) || (iVar21 + uVar24 < uVar13)) ||
               (iVar20 + uVar25 < uVar22)) goto LAB_6000caea;
            iVar21 = iVar10 + *(int *)(DAT_6000ce8c + 0x184) * 0x18;
            *(byte *)(iVar21 + 8) = bVar6;
            *(undefined4 *)(iVar21 + 4) = uVar14;
            local_7c = uVar7;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            CopyBytes(iVar21 + 9,&local_84,10);
            uVar7 = local_7c;
            *(undefined2 *)(iVar21 + 0x13) = (undefined2)local_8c;
            *(undefined1 *)(iVar21 + 0x18) = local_90._2_1_;
            *(undefined1 *)(iVar21 + 0x15) = local_8c._2_1_;
            *(undefined2 *)(iVar21 + 0x19) = local_88;
            *(undefined1 *)(iVar21 + 0x1b) = local_86;
            *(undefined2 *)(iVar21 + 0x16) = (undefined2)local_90;
            uVar24 = *(int *)(iVar11 + 0x184) + 1;
            *(uint *)(iVar11 + 0x184) = uVar24;
            bVar8 = local_7c._1_1_;
            if (uVar24 < 10) goto LAB_6000caea;
LAB_6000cc40:
            local_7c = uVar7;
            bVar8 = local_7c._1_1_;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            FUN_6016238c(local_78);
            uVar7 = local_7c;
          }
        }
        local_7c = uVar7;
        bVar8 = local_7c._1_1_;
        uVar7 = local_7c;
        if (*(int *)(DAT_6000ce8c + 0x184) != 0) {
          local_7c._1_1_ = bVar8;
          iVar10 = FUN_60163b60();
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          puVar12 = (undefined4 *)FUN_60162b78(1);
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          local_7c = uVar7;
          uVar7 = local_7c;
          local_7c._1_1_ = bVar8;
          ZeroBytes(&local_f4,100);
          uVar7 = local_7c;
          bVar8 = local_7c._1_1_;
          if ((iVar10 != 0) &&
             (local_7c = uVar7, uVar7 = local_7c, local_7c._1_1_ = bVar8,
             iVar10 = FUN_60168220(iVar10 + 0x9d), uVar7 = local_7c, bVar8 = local_7c._1_1_,
             iVar10 + 0x1cU < 100)) {
            if (*(uint *)(DAT_6000ce8c + 0x184) < 2) {
              *(undefined4 *)(DAT_6000ce8c + 0x2a0) = 0;
            }
            else {
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar23 = FUN_601668a4();
              uVar7 = local_7c;
              uVar14 = puVar12[3];
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar35 = FUN_6016759c(puVar12[2]);
              uVar7 = local_7c;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar36 = FUN_6016759c(uVar14);
              uVar7 = local_7c;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar14 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),(int)uVar36,
                                    (int)((ulonglong)uVar36 >> 0x20));
              uVar7 = local_7c;
              uVar15 = 0xe;
              if (uVar23 < 2) {
                uVar15 = 0xb;
              }
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar24 = FUN_60159978(uVar14,uVar15);
              uVar7 = local_7c;
              uVar14 = puVar12[1];
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar35 = FUN_6016759c(*puVar12);
              uVar7 = local_7c;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar36 = FUN_6016759c(uVar14);
              uVar7 = local_7c;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar14 = FUN_601675d8((int)uVar35,(int)((ulonglong)uVar35 >> 0x20),(int)uVar36,
                                    (int)((ulonglong)uVar36 >> 0x20));
              uVar7 = local_7c;
              bVar8 = local_7c._1_1_;
              local_7c = uVar7;
              uVar7 = local_7c;
              local_7c._1_1_ = bVar8;
              uVar25 = FUN_60159878(uVar14,uVar15);
              uVar7 = local_7c;
              iVar11 = 0x188;
              uVar23 = 0;
              iVar10 = DAT_6000ce8c;
              for (uVar28 = 0; local_7c = uVar7, bVar8 = local_7c._1_1_, uVar7 = local_7c,
                  uVar28 < *(uint *)(iVar10 + 0x184); uVar28 = uVar28 + 1) {
                local_7c._1_1_ = bVar8;
                FUN_601021f4(&local_f4,iVar10 + iVar11);
                uVar7 = local_7c;
                bVar8 = local_7c._1_1_;
                local_7c = uVar7;
                uVar7 = local_7c;
                local_7c._1_1_ = bVar8;
                iVar21 = FUN_600206c8(&local_f4);
                uVar7 = local_7c;
                iVar10 = DAT_6000ce8c;
                if ((iVar21 == 0) &&
                   (bVar8 = local_7c._1_1_, local_7c = uVar7, uVar7 = local_7c,
                   local_7c._1_1_ = bVar8, iVar20 = FUN_60166758(&local_90,&local_f4,1),
                   uVar7 = local_7c, iVar21 = local_90, iVar10 = DAT_6000ce8c, iVar20 == 0)) {
                  local_84 = 0;
                  local_78[0] = 0;
                  local_78[1] = 0;
                  local_44 = 0;
                  local_8c = 0;
                  uVar30 = 0;
                  if (local_90 != 0) {
                    uVar26 = *(uint *)(DAT_6000ce8c + 0x174);
                    bVar8 = local_7c._1_1_;
                    if ((uVar26 <= uVar24) && (uVar24 <= *(uint *)(DAT_6000ce8c + 0x17c))) {
                      uVar30 = 0;
                      if ((uVar25 < *(uint *)(DAT_6000ce8c + 0x178)) ||
                         (uVar30 = 0, *(uint *)(DAT_6000ce8c + 0x180) < uVar25)) goto LAB_6000cd7a;
                      iVar10 = *(int *)(DAT_6000ce8c + 0x148) +
                               ((uVar25 - *(uint *)(DAT_6000ce8c + 0x178)) *
                                ((*(uint *)(DAT_6000ce8c + 0x17c) - uVar26) + 1) + (uVar24 - uVar26)
                               ) * 5;
                      if (*(char *)(DAT_6000ce8c + 0x8a) < '\0') {
                        iVar10 = iVar10 + 0x10;
                      }
                      local_7c = uVar7;
                      uVar7 = local_7c;
                      local_7c._1_1_ = bVar8;
                      FUN_60163c98(local_90,iVar10);
                      uVar7 = local_7c;
                      bVar8 = local_7c._1_1_;
                      local_7c = uVar7;
                      uVar7 = local_7c;
                      local_7c._1_1_ = bVar8;
                      FUN_60161ef4(iVar21,local_78,5,&local_44);
                      uVar7 = local_7c;
                      bVar8 = local_7c._1_1_;
                      local_7c = uVar7;
                      uVar7 = local_7c;
                      local_7c._1_1_ = bVar8;
                      uVar35 = FUN_6012222c(local_78);
                      uVar7 = local_7c;
                      uVar30 = (uint)((ulonglong)uVar35 >> 0x20);
                      uVar31 = (uVar30 & 0x7fffffff) >> 0x18;
                      uVar26 = (uint)uVar35 >> 0x18 | uVar30 << 8;
                      bVar8 = local_7c._1_1_;
                      if (uVar31 <= *(uint *)(DAT_6000ce8c + 0x154) &&
                          (uint)(*(uint *)(DAT_6000ce8c + 0x150) <= uVar26) <=
                          uVar31 - *(uint *)(DAT_6000ce8c + 0x154)) {
                        local_7c = uVar7;
                        uVar7 = local_7c;
                        local_7c._1_1_ = bVar8;
                        FUN_60161ef4(iVar21,local_78,5,&local_44);
                        bVar8 = local_7c._1_1_;
                        uVar7 = local_7c;
                        local_7c._1_1_ = bVar8;
                        uVar35 = FUN_6012222c(local_78);
                        bVar8 = local_7c._1_1_;
                        iVar10 = DAT_6000ce8c;
                        uVar31 = (uint)((ulonglong)uVar35 >> 0x20);
                        uVar7 = local_7c;
                        if (((uint)uVar35 >> 0x18 | uVar31 << 8) != uVar26 ||
                            ((uVar31 ^ uVar30) & 0x7fffffff) >> 0x18 != 0) {
                          local_7c._1_1_ = bVar8;
                          FUN_60163c98(iVar21,uVar26 + *(int *)(DAT_6000ce8c + 0x148));
                          bVar8 = local_7c._1_1_;
                          uVar7 = local_7c;
                          if (0x7fffffff < (uint)(int)*(char *)(iVar10 + 0x8a)) {
                            local_7c._1_1_ = bVar8;
                            iVar10 = FUN_6015cbf2(iVar21);
                            uVar7 = local_7c;
                            bVar8 = local_7c._1_1_;
                            local_7c = uVar7;
                            uVar7 = local_7c;
                            local_7c._1_1_ = bVar8;
                            FUN_60163c98(iVar21,iVar10 + 0x20);
                            uVar7 = local_7c;
                            bVar8 = local_7c._1_1_;
                          }
                          local_7c._1_1_ = bVar8;
                          local_7c = uVar7;
                          bVar8 = local_7c._1_1_;
                          uVar7 = local_7c;
                          local_7c._1_1_ = bVar8;
                          FUN_60161ef4(iVar21,local_78,8,&local_44);
                          uVar7 = local_7c;
                          bVar8 = local_7c._1_1_;
                          local_7c = uVar7;
                          uVar7 = local_7c;
                          local_7c._1_1_ = bVar8;
                          iVar10 = FUN_6015a168(&local_8c,local_78);
                          uVar7 = local_7c;
                          bVar8 = local_7c._1_1_;
                          local_7c = uVar7;
                          uVar7 = local_7c;
                          local_7c._1_1_ = bVar8;
                          FUN_6015a168(&local_84,(int)local_78 + iVar10);
                          uVar7 = local_7c;
                          uVar30 = local_84;
                          goto LAB_6000cd7a;
                        }
                      }
                    }
                    local_7c._1_1_ = bVar8;
                    local_7c = uVar7;
                    bVar8 = local_7c._1_1_;
                    uVar30 = 0;
                    uVar7 = local_7c;
                    local_7c._1_1_ = bVar8;
                  }
LAB_6000cd7a:
                  local_7c = uVar7;
                  bVar8 = local_7c._1_1_;
                  uVar7 = local_7c;
                  local_7c._1_1_ = bVar8;
                  FUN_601667bc(local_90);
                  uVar7 = local_7c;
                  iVar10 = DAT_6000ce8c;
                  *(uint *)(DAT_6000ce8c + uVar28 * 4 + 0x278) = uVar30;
                  if (uVar23 < uVar30) {
                    *(uint *)(iVar10 + 0x2a0) = uVar28;
                    uVar23 = uVar30;
                  }
                }
                local_7c = uVar7;
                bVar8 = local_7c._1_1_;
                iVar11 = iVar11 + 0x18;
                uVar7 = local_7c;
                local_7c._1_1_ = bVar8;
              }
            }
            local_7c._1_1_ = bVar8;
            local_7c = uVar7;
            bVar8 = local_7c._1_1_;
            piVar4[2] = uVar13;
            piVar4[3] = uVar22;
            uVar7 = local_7c;
            local_7c._1_1_ = bVar8;
            goto LAB_6000c95c;
          }
        }
        local_7c._1_1_ = bVar8;
        local_7c = uVar7;
        bVar8 = local_7c._1_1_;
        piVar4[2] = uVar13;
        piVar4[3] = uVar22;
        uVar7 = local_7c;
      }
      local_7c._1_1_ = bVar8;
      local_7c = uVar7;
      bVar8 = local_7c._1_1_;
      uVar14 = 0xffffffff;
      uVar7 = local_7c;
    }
LAB_6000c858:
    local_7c._1_1_ = bVar8;
    local_7c = uVar7;
    bVar8 = local_7c._1_1_;
    *(undefined1 *)(iVar9 + 0x1f) = 0;
    uVar7 = local_7c;
    local_7c._1_1_ = bVar8;
  }
LAB_6000c860:
  local_7c = uVar7;
  bVar8 = local_7c._1_1_;
  uVar2 = *(ushort *)(iVar9 + 0x12);
  local_7c._1_1_ = bVar8;
  if (*(ushort *)(iVar9 + 0x10) == uVar2) {
    if (*(char *)(iVar9 + 0x1d) == '\0') goto LAB_6000c8ba;
    *(undefined1 *)(iVar9 + 0x1d) = 0;
    uVar7 = local_7c;
  }
  else {
    uVar7 = local_7c;
    uVar13 = FUN_601668a4();
    uVar7 = local_7c;
    if ((uVar2 < 2 == 1 < uVar13) ||
       (uVar2 = *(ushort *)(iVar9 + 0x12), bVar8 = local_7c._1_1_, local_7c = uVar7,
       uVar7 = local_7c, local_7c._1_1_ = bVar8, uVar13 = FUN_601668a4(), uVar7 = local_7c,
       ((uVar2 | 2) != 2) != ((uVar13 | 2) != 2))) {
      *(undefined1 *)(iVar9 + 0x1d) = 1;
      *(undefined2 *)(iVar9 + 0x10) = *(undefined2 *)(iVar9 + 0x12);
      return uVar14;
    }
    *(undefined1 *)(iVar9 + 0x1d) = 0;
    *(undefined2 *)(iVar9 + 0x10) = *(undefined2 *)(iVar9 + 0x12);
  }
  local_7c = uVar7;
  bVar8 = local_7c._1_1_;
  *(undefined1 *)(iVar9 + 0x1e) = 1;
LAB_6000c8ba:
  local_7c._1_1_ = bVar8;
  bVar8 = local_7c._1_1_;
  if (*(char *)(iVar9 + 0x1c) == '\0') {
    *(undefined1 *)(iVar9 + 0x16) = 0;
    if (*(char *)(iVar9 + 0x20) != '\0') {
      uVar7 = local_7c;
      local_7c._1_1_ = bVar8;
      FUN_6001b27c();
      uVar14 = 0;
    }
    *(undefined1 *)(iVar9 + 0x17) = 0;
  }
  return uVar14;
}

