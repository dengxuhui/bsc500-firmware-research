
undefined4 FUN_60019c8c(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_2c;
  undefined4 local_28;
  
  ZeroBytes(auStack_30,0x28);
  iVar1 = FUN_6014966c(2,0,7,auStack_30);
  if (((iVar1 == 0) && (iVar1 = FUN_6014966c(2,0,8,auStack_30), iVar1 == 0)) ||
     (iVar1 = FUN_6001b952(local_2d,local_2e,local_2c,local_28), iVar1 == 0)) {
    uVar2 = 0;
  }
  else {
    uVar2 = 1;
  }
  return uVar2;
}

