
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000299c(void)

{
  int iVar1;
  int local_78;
  undefined1 auStack_74 [100];
  
  iVar1 = DAT_600029dc;
  *(undefined4 *)(DAT_600029dc + 0x14) = 0;
  ZeroBytes(auStack_74,100);
  FUN_601681f4(auStack_74,DAT_600029e0,DAT_600029e4,DAT_600029e8);
  local_78 = 0;
  FUN_6016243c(auStack_74,_DAT_600029ec,&local_78);
  if (local_78 != 0) {
    *(int *)(iVar1 + 0x14) = local_78;
    FUN_60168578("$$$%s,s_auto_open_flag:%d\n","auto_flag_init");
  }
  return;
}

