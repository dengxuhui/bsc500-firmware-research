
void thunk_FUN_600e7fd0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_6015982e();
  FUN_60159828(uVar1,4,0,0);
  uVar2 = FUN_6015bd44();
  FUN_60159838(uVar2,DAT_600e7ff4,uVar1);
  return;
}

