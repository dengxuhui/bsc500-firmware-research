
void FUN_6000d650(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_44;
  undefined4 uStack_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined4 local_34;
  undefined1 auStack_30 [16];
  undefined4 local_20;
  undefined4 local_1c;
  
  iVar1 = DAT_6000d6a8;
  *(undefined4 *)(DAT_6000d6a8 + 0x10) = param_1;
  ZeroBytes(auStack_30,0x20);
  local_1c = 0x34;
  local_3c = 0;
  uStack_38 = 0;
  local_20 = 0x800;
  local_44 = DAT_6000d6ac;
  uStack_40 = 0;
  local_34 = DAT_6000d6ac;
  uVar2 = FUN_60165194(0xffff,0,&local_44);
  *(undefined4 *)(iVar1 + 8) = uVar2;
  FUN_60137768(iVar1 + 0x14);
  uVar2 = FUN_601566b4(DAT_6000d6b0,param_2,&local_34);
  *(undefined4 *)(iVar1 + 4) = uVar2;
  FUN_60156808();
  return;
}

