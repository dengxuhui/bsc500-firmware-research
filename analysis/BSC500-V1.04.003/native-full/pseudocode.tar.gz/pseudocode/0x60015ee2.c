
bool FUN_60015ee2(int param_1,undefined4 param_2,uint *param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  bool bVar3;
  int local_28;
  undefined4 uStack_24;
  uint *puStack_20;
  undefined4 uStack_1c;
  
  local_28 = param_1;
  uStack_24 = param_2;
  puStack_20 = param_3;
  uStack_1c = param_4;
  iVar1 = FUN_6015e0e8(param_2);
  if (iVar1 == 1) {
    iVar1 = FUN_601609d0(&uStack_24,param_2,2);
    bVar3 = false;
    if (iVar1 == 0) {
      local_28 = 0;
      iVar2 = FUN_6015c2f4(&uStack_24,param_3,4,&local_28);
      iVar1 = local_28;
      FUN_60160a64(&uStack_24);
      if ((iVar2 == 0) && (iVar1 == 4)) {
        bVar3 = (*param_3 & 0x1f) - 1 < 2;
      }
    }
  }
  else {
    bVar3 = false;
  }
  return bVar3;
}

