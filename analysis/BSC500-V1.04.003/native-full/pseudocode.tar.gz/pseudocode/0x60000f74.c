
void FUN_60000f74(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  puVar1 = DAT_60000f90;
  for (puVar2 = DAT_60000f8c; puVar2 < puVar1; puVar2 = puVar2 + 1) {
    if ((code *)*puVar2 != (code *)0x0) {
      (*(code *)*puVar2)();
    }
  }
  return;
}

