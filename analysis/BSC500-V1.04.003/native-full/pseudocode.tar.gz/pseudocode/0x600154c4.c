
void FUN_600154c4(void)

{
  undefined4 *puVar1;
  int iVar2;
  
  iVar2 = DAT_600154e8;
  if (*(char *)(DAT_600154e8 + 7) == '\x01') {
    puVar1 = (undefined4 *)(DAT_600154e8 + 0x14);
    *(undefined1 *)(DAT_600154e8 + 6) = 0;
    FUN_601667bc(*puVar1);
    *(undefined2 *)(iVar2 + 10) = 0;
    *(undefined1 *)(iVar2 + 7) = 0;
    *(undefined4 *)(iVar2 + 0x14) = 0;
    *(undefined4 *)(iVar2 + 0x18) = 0;
    *(undefined1 *)(iVar2 + 5) = 1;
  }
  return;
}

