
undefined4 FUN_600069b8(void)

{
  FUN_6015baa0(DAT_600069dc,&stack0xfffffff4,4);
  return 0x1001f000;
}

