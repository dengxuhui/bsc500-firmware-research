
void FUN_60016d94(void)

{
  undefined4 *puVar1;
  undefined1 *puVar2;
  
  puVar2 = DAT_60016db0;
  if (DAT_60016db0[2] == '\x01') {
    puVar1 = (undefined4 *)(DAT_60016db0 + 8);
    *DAT_60016db0 = 0;
    FUN_601667bc(*puVar1);
    *(undefined4 *)(puVar2 + 8) = 0;
    *(undefined2 *)(puVar2 + 1) = 0;
  }
  return;
}

