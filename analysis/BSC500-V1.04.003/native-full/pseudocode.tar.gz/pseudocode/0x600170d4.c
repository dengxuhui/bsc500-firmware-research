
int FUN_600170d4(undefined4 param_1)

{
  int iVar1;
  
  iVar1 = FUN_6015f71c();
  if (iVar1 != 0) {
    FUN_601608ac(iVar1,param_1);
  }
  return iVar1;
}

