
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60004968(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  char *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int local_18;
  int iStack_14;
  
  pcVar1 = DAT_600049f4;
  local_18 = param_3;
  iStack_14 = param_4;
  if (DAT_600049f4[0xd] == '\0') {
    FUN_60161424(DAT_600049f8,_DAT_600049fc,"cm_backtrace_assert");
    FUN_60161424(_DAT_60004a14);
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  FUN_60161424(s____4_C_Assert_on_thread__s_60004a15._3_4_);
  FUN_60161424(_DAT_60004a14);
  FUN_6000a660();
  piVar2 = (int *)getMainStackPointer();
  if (&local_18 == piVar2) {
    FUN_60161424("Assert on interrupt or bare metal(no OS) environment");
    FUN_60161424(_DAT_60004a14);
    iVar4 = 0;
    if (*pcVar1 != '\0') {
      iVar4 = DAT_60004a68;
    }
    iVar5 = 0;
    if (pcVar1[4] != '\0') {
      iVar5 = DAT_60004a6c - DAT_60004a68;
    }
  }
  else {
    piVar2 = (int *)getProcessStackPointer();
    if (&local_18 != piVar2) goto LAB_600049ec;
    uVar3 = FUN_60163ab8();
    FUN_60161424("Assert on thread %s",uVar3);
    FUN_60161424(_DAT_60004a14);
    FUN_6015a194(&iStack_14,&local_18);
    iVar4 = iStack_14;
    iVar5 = local_18;
  }
  FUN_6000abcc(iVar4,iVar5,param_1);
LAB_600049ec:
  FUN_6000d764(param_1);
  return;
}

