
void FUN_6000b224(void)

{
  char *pcVar1;
  code *pcVar2;
  
  pcVar2 = DAT_6000b264;
  pcVar1 = DAT_6000b260;
  if (*DAT_6000b260 == '\x01') {
    (*DAT_6000b264)(0x86,0);
    (*pcVar2)(0x83,0);
    FUN_601649b8(0);
    thunk_EXT_FUN_00020440(2);
    (*pcVar2)(0x74,0);
    thunk_EXT_FUN_00020440(3);
    FUN_601559cc();
    *pcVar1 = '\0';
  }
  return;
}

