
undefined4 FUN_60011dec(int param_1,int param_2,int param_3)

{
  undefined2 uVar1;
  short sVar2;
  uint uVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  
  if (param_1 == 0) {
    return 0;
  }
  if (param_2 == 0) {
    return 0;
  }
  uVar7 = (uint)*(ushort *)(param_2 + 8);
  if (uVar7 == 0) {
    return 0;
  }
  uVar3 = (uint)*(ushort *)(param_1 + 0x3c);
  uVar5 = (uint)*(ushort *)(param_1 + 0x3e);
  if (uVar3 <= uVar5) {
    return 1;
  }
  if (uVar5 == 0) {
    if (uVar3 <= uVar7) {
      *(ushort *)(param_1 + 0x3e) = *(ushort *)(param_2 + 8);
      if (param_3 == 0) {
        *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_2 + 0xc);
      }
      else {
        uVar4 = FUN_60137ef0();
        *(undefined4 *)(param_1 + 0x38) = uVar4;
        *(undefined1 *)(param_1 + 0x46) = 1;
        CopyBytes(uVar4,*(undefined4 *)(param_2 + 0xc),*(undefined2 *)(param_1 + 0x3c));
        uVar3 = (uint)*(ushort *)(param_1 + 0x3c);
        uVar7 = (uint)*(ushort *)(param_2 + 8);
      }
      if (uVar7 == uVar3) {
        sVar2 = 0;
      }
      else {
        sVar2 = (short)uVar7 - (short)uVar3;
        *(uint *)(param_2 + 0xc) = *(int *)(param_2 + 0xc) + uVar3;
      }
      goto LAB_60011e9a;
    }
    uVar4 = FUN_60137ef0();
    uVar6 = *(undefined4 *)(param_2 + 0xc);
    uVar1 = *(undefined2 *)(param_2 + 8);
    *(undefined4 *)(param_1 + 0x38) = uVar4;
    CopyBytes(uVar4,uVar6,uVar1);
    *(undefined1 *)(param_1 + 0x46) = 1;
    sVar2 = *(short *)(param_2 + 8);
  }
  else {
    if (uVar3 <= uVar5 + uVar7) {
      uVar3 = uVar3 - uVar5;
      CopyBytes(*(int *)(param_1 + 0x38) + uVar5,*(undefined4 *)(param_2 + 0xc),uVar3 & 0xffff);
      *(undefined2 *)(param_1 + 0x3e) = *(undefined2 *)(param_1 + 0x3c);
      *(uint *)(param_2 + 0xc) = *(int *)(param_2 + 0xc) + (uVar3 & 0xffff);
      sVar2 = *(short *)(param_2 + 8) - (short)uVar3;
LAB_60011e9a:
      *(short *)(param_2 + 8) = sVar2;
      return 1;
    }
    CopyBytes(*(int *)(param_1 + 0x38) + uVar5,*(undefined4 *)(param_2 + 0xc));
    sVar2 = *(short *)(param_2 + 8) + *(short *)(param_1 + 0x3e);
  }
  *(short *)(param_1 + 0x3e) = sVar2;
  *(undefined2 *)(param_2 + 8) = 0;
  return 0;
}

