
/* WARNING: Removing unreachable block (ram,0x6001e0ba) */

undefined4 FUN_60016a80(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_6002a8b8(5);
  (**(code **)(DAT_6001e0d4 + 0x38))();
  return uVar1;
}

