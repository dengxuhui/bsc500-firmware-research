
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_6000ceb0(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  char *local_18;
  undefined4 local_14;
  undefined4 uStack_10;
  undefined4 local_c;
  
  local_c = 0;
  local_14 = 0;
  uStack_10 = 0;
  local_18 = "navi_t";
  uVar2 = FUN_60165194(1,0,&local_18);
  uVar3 = DAT_6000cef8;
  iVar1 = _DAT_6000cee4;
  *(undefined4 *)(_DAT_6000cee4 + 4) = uVar2;
  uVar3 = FUN_6011c240("pm_navi_task",uVar3,5);
  *(undefined4 *)(iVar1 + 8) = uVar3;
  return CONCAT44(local_14,local_18);
}

