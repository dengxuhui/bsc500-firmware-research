
void FUN_60002ddc(void)

{
  *DAT_60002de4 = 1;
  return;
}

