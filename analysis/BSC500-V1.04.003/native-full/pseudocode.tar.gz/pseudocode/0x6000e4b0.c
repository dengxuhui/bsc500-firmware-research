
void FUN_6000e4b0(int param_1)

{
  if (param_1 != 0) {
    if (*(byte *)(param_1 + 0x24) - 1 < 4) {
      FUN_601203e4(4);
      return;
    }
    if (*(byte *)(param_1 + 0x24) - 0xfc < 4) {
      FUN_601203e4(3);
      return;
    }
  }
  return;
}

