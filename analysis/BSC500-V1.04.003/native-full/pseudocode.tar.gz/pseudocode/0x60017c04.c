
void FUN_60017c04(int param_1)

{
  if (param_1 != 0) {
    CopyBytes(DAT_60017c14 + 0x28,param_1,0x30);
    return;
  }
  return;
}

