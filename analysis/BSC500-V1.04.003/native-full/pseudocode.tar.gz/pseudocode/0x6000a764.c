
void FUN_6000a764(void)

{
  int *piVar1;
  
  piVar1 = (int *)thunk_FUN_60161ab0(0xc,DAT_6000a780);
  if (piVar1 != (int *)0x0) {
    *piVar1 = DAT_6000a784 + 8;
    piVar1[1] = 1;
    piVar1[2] = 0;
  }
  return;
}

