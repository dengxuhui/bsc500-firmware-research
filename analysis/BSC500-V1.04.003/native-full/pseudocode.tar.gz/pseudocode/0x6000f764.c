
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000f764(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  char cVar2;
  ushort uVar3;
  int iVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  undefined1 *puVar7;
  
  if (param_1 == (undefined1 *)0x0) {
    return 2;
  }
  if (param_2 == (undefined1 *)0x0) {
    return 2;
  }
  if ((param_1[1] == '\x04') && (*(int *)(param_2 + 0x88) == 0)) {
    return 2;
  }
  CopyBytes(param_1 + 8,param_2 + 8,0x20);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_2 + 0x8c);
  param_1[0x28] = *param_2;
  uVar6 = *(undefined4 *)(param_2 + 4);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_2 + 1);
  *(undefined4 *)(param_1 + 0x33) = uVar6;
  if (param_1[8] == '\x03') {
    uVar1 = 1;
  }
  else if (param_1[8] == '\x04') {
    uVar1 = 2;
  }
  else {
    uVar1 = 0;
  }
  param_1[0x29] = uVar1;
  param_1[0x2a] = 1;
  *(undefined2 *)(param_1 + 0x40) = 0x107;
  param_1[0x2f] = 0;
  uVar1 = param_2[8];
  param_1[0x2e] = param_2[0x24];
  param_1[1] = uVar1;
  switch(uVar1) {
  case 0:
    *(undefined2 *)(param_1 + 0x2c) = 3;
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    break;
  case 1:
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    uVar3 = (ushort)(param_1[0x14] != '\0') << 1;
    goto LAB_6000f860;
  case 2:
    uVar5 = 0xd;
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x14);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x14);
    if (param_1[0xc] == '\0') {
      uVar5 = 5;
    }
    *(undefined2 *)(param_1 + 0x2c) = uVar5;
    goto LAB_6000f8a8;
  case 3:
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    param_1[0x44] = param_1[0x14];
    *(undefined2 *)(param_1 + 0x45) = *(undefined2 *)(param_1 + 0x15);
    uVar3 = (ushort)(byte)param_1[0x17];
    if (param_1[0x17] != 0) {
      uVar3 = 1;
    }
LAB_6000f860:
    *(ushort *)(param_1 + 0x2c) = uVar3;
    break;
  case 4:
    *(undefined2 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    param_1[0x44] = param_1[0x14];
    *(undefined2 *)(param_1 + 0x45) = *(undefined2 *)(param_1 + 0x15);
    *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_1 + 0x18);
  }
  puVar7 = param_2 + 0x28;
  FUN_6013ac30(param_1,puVar7,0);
  cVar2 = param_1[1];
  if (cVar2 == '\0') {
    if (param_1[0x27] == '\0') {
      puVar7 = param_2 + 0x58;
    }
    FUN_6013ac30(param_1,puVar7,1);
    cVar2 = param_1[1];
  }
  if (cVar2 == '\x04') {
    iVar4 = thunk_FUN_60162e34(**(ushort **)(param_2 + 0x88) + 4);
    *(int *)(param_1 + 0x54) = iVar4;
    if (iVar4 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_6016804c(_DAT_6000f8c4,"sibles_advertising_init",0x139);
    }
    *(undefined2 *)(iVar4 + 2) = **(undefined2 **)(param_2 + 0x88);
  }
LAB_6000f8a8:
  *param_1 = 1;
  param_1[6] = 0;
  param_1[4] = 0xff;
  return 0;
}

