
void FUN_60019720(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = DAT_6001973c;
  uVar1 = DAT_60019738;
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 0x2efc) = DAT_60019740;
    *(undefined4 *)(param_1 + 0x2f00) = uVar2;
    *(undefined4 *)(param_1 + 0x2f04) = uVar1;
  }
  return;
}

