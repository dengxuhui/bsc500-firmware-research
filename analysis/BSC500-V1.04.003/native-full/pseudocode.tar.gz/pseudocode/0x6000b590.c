
void FUN_6000b590(void)

{
  *DAT_6000b598 = 0;
  return;
}

