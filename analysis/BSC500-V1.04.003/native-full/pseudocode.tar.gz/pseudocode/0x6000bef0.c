
undefined1 FUN_6000bef0(void)

{
  return *DAT_6000bef8;
}

