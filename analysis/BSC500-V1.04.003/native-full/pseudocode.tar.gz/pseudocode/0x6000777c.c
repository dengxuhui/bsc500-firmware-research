
void FUN_6000777c(uint param_1,ushort *param_2)

{
  uint *puVar1;
  uint *puVar2;
  int iVar3;
  ushort uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  bool bVar8;
  bool bVar9;
  
  puVar2 = DAT_60007810;
  uVar6 = *DAT_60007810;
  if (uVar6 != param_1) {
    uVar4 = *param_2;
    uVar5 = (uint)uVar4;
    if (((uVar5 != 0) && (uVar5 != 0xffff && param_1 != 0)) && (uVar6 != 0)) {
      bVar9 = uVar6 <= param_1;
      bVar8 = param_1 == uVar6;
      if (bVar9 && !bVar8) {
        bVar9 = 4 < param_1 - uVar6;
        bVar8 = param_1 - uVar6 == 5;
      }
      if ((!bVar9 || bVar8) && ((uVar6 <= param_1 || (uVar6 - param_1 < 6)))) {
        puVar1 = (uint *)((int)DAT_60007810 + 6);
        bVar8 = true;
        iVar3 = 0;
        *(ushort *)(DAT_60007810 + 2) = uVar4;
        puVar2[1] = *puVar1;
        uVar6 = 0;
        do {
          uVar7 = uVar5;
          if (iVar3 != 2) {
            if (iVar3 == 3) {
              if (bVar8) {
                for (iVar3 = 0; iVar3 != 3; iVar3 = iVar3 + 1) {
                  *(ushort *)((int)puVar2 + iVar3 * 2 + 4) = uVar4;
                }
              }
              else {
                uVar4 = (ushort)(uVar6 / 3);
              }
              *puVar2 = param_1;
              *param_2 = uVar4;
              return;
            }
            uVar7 = (uint)*(ushort *)((int)puVar2 + iVar3 * 2 + 4);
            if (uVar7 != 0) {
              bVar8 = false;
            }
          }
          uVar6 = uVar6 + uVar7;
          iVar3 = iVar3 + 1;
        } while( true );
      }
    }
    *DAT_60007810 = param_1;
    for (iVar3 = 0; iVar3 != 3; iVar3 = iVar3 + 1) {
      *(ushort *)((int)puVar2 + iVar3 * 2 + 4) = uVar4;
    }
  }
  return;
}

