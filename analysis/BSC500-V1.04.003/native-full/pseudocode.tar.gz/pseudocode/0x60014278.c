
void FUN_60014278(int param_1)

{
  ZeroBytes(param_1 + 0x98,0x70);
  *(undefined4 *)(param_1 + 0x102) = 0xffffffff;
  *(undefined4 *)(param_1 + 0xfc) = 0xffffffff;
  *(undefined4 *)(param_1 + 0xd8) = 0xffffffff;
  *(undefined4 *)(param_1 + 0xd0) = 0xffffffff;
  *(undefined4 *)(param_1 + 0x98) = 0xffffffff;
  *(undefined1 *)(param_1 + 0x106) = 0xff;
  *(undefined2 *)(param_1 + 200) = 1;
  return;
}

