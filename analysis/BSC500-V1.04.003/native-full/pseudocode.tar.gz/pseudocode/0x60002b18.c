
undefined4 FUN_60002b18(void)

{
  FUN_60004514();
  FUN_60167f4a("ble_app",DAT_60002b44,0,0x800,6,10);
  FUN_60167f8c();
  return 0;
}

