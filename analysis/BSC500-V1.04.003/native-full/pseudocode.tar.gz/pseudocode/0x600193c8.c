
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_600193c8(undefined4 param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  piVar1 = _DAT_6001942c;
  if (*_DAT_6001942c != 0) {
    FUN_60166b98();
  }
  iVar2 = FUN_60164eb0(1);
  if (iVar2 != 0) {
    piVar4 = (int *)(iVar2 + 4);
    do {
      piVar4 = (int *)*piVar4;
      if (piVar4 == (int *)(iVar2 + 4)) {
        if (*piVar1 != 0) {
          FUN_60166b64();
        }
        return 0;
      }
      iVar3 = FUN_601343dc(piVar4 + -5,param_1,0x10);
    } while (iVar3 != 0);
    if (*piVar1 != 0) {
      FUN_60166b64();
    }
    return (int)(piVar4 + -5);
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("information != RT_NULL","rt_thread_find",0x30c);
}

