
void FUN_60000d18(int param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  uint uVar5;
  
  uVar2 = FUN_60167d0c();
  iVar3 = FUN_60163aac();
  uVar1 = DAT_60000da8;
  if (iVar3 != 0) {
    FUN_60168578(DAT_60000da4,DAT_60000da8);
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(DAT_60000dac,uVar1,0x116);
  }
  uVar5 = param_2 & 0xfffffffc;
  FUN_60167d14(uVar2);
  iVar3 = DAT_60000db0;
  if ((0x30 < uVar5) &&
     (puVar4 = (undefined4 *)(param_1 + 3U & 0xfffffffc), puVar4 <= (undefined4 *)(uVar5 - 0x30))) {
    *(uint *)(DAT_60000db0 + 8) = (uVar5 - (int)puVar4) + -0x30;
    *(undefined4 **)(iVar3 + 0xc) = puVar4;
    puVar4[2] = 0;
    puVar4[1] = (uVar5 - (int)puVar4) + -0x18;
    *puVar4 = 0x1ea0;
    *(uint *)(iVar3 + 0x10) = uVar5 - 0x18;
    FUN_60162cd4();
    FUN_60167ef4(iVar3 + 0x2c,&DAT_60000db4,1,0);
    *(undefined4 *)(iVar3 + 0x14) = *(undefined4 *)(iVar3 + 0xc);
    *(undefined4 *)(iVar3 + 0x18) = 0;
    return;
  }
  FUN_60168578("mem init, error begin address 0x%x, and end address 0x%x\n",param_1,param_2,param_4)
  ;
  return;
}

