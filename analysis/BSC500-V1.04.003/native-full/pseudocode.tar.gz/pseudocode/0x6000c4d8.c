
undefined4 FUN_6000c4d8(void)

{
  int iVar1;
  undefined4 in_r3;
  undefined4 uVar2;
  undefined4 local_10;
  undefined4 local_c;
  
  if (*DAT_6000c4e8 != 0) {
    return 0;
  }
  local_10 = 0;
  local_c = in_r3;
  iVar1 = FUN_60166758(&local_c,DAT_60017ed4,1);
  if (iVar1 == 0) {
    uVar2 = FUN_60161ef4(local_c,DAT_60017ed8,0xf4,&local_10);
    FUN_601667bc(local_c);
  }
  else {
    uVar2 = 0xffffffff;
  }
  return uVar2;
}

