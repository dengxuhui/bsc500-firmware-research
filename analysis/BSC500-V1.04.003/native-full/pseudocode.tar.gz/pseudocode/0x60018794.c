
void FUN_60018794(undefined4 param_1)

{
  *DAT_6001879c = param_1;
  return;
}

