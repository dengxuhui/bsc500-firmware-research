
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_6000fcb8(void)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  undefined1 local_27;
  undefined2 local_26;
  undefined1 uStack_24;
  undefined1 local_23;
  undefined2 local_20;
  undefined2 local_1e;
  
  local_26 = 5;
  local_27 = 0x32;
  iVar3 = FUN_60166f2c(DAT_6000fd88);
  if (iVar3 != 0) {
    FUN_60164d4c(iVar3,_DAT_6000fd8c);
    iVar4 = FUN_60166e68(iVar3,3);
    if (iVar4 == 0) {
      FUN_60165124(iVar3,0x17,&uStack_24);
      FUN_60168578("Lcd info w:%d, h%d, bits_per_pixel %d\r\n",local_20,local_1e,local_23);
    }
    FUN_60165124(iVar3,0x1b,&local_26);
    FUN_60165124(iVar3,0x1a,&local_27);
    iVar4 = DAT_6000fdb8;
    FUN_60167ef4(DAT_6000fdb8 + 0x28,"lcdsem",1,0);
    uVar1 = DAT_6000fdc4;
    thunk_EXT_FUN_000219ea(DAT_6000fdc4,0,0x4b000);
    iVar5 = iVar4 + 0xc;
    FUN_60016e64(iVar5,uVar1,0,0x25800);
    puVar2 = DAT_6000fdc8;
    FUN_60016e80(DAT_6000fdc8);
    uVar1 = DAT_6000fdcc;
    puVar2[3] = iVar5;
    puVar2[0x13] = iVar3;
    puVar2[10] = uVar1;
    puVar2[5] = DAT_6000fdd0;
    *puVar2 = DAT_6000fdd4;
    puVar2[4] = puVar2[4] | 2;
    FUN_600170bc(puVar2);
    FUN_60016ec4(puVar2);
    *(undefined4 **)(iVar4 + 4) = puVar2;
    return puVar2;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("lcd_device != RT_NULL","lv_engine_hw_init",0x10a);
}

