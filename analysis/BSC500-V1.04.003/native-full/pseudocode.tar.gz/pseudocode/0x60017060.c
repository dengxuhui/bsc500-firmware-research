
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60017060(void)

{
  int iVar1;
  int iVar2;
  
  iVar2 = _DAT_60017088 + 0x28;
  iVar1 = FUN_601668f8(iVar2,0xffffffff);
  if (iVar1 == 0) {
    FUN_60166af4(iVar2);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("RT_EOK == err","lv_display_flush_wait_free",0xfb);
}

