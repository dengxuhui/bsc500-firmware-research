
void FUN_600044ac(void)

{
  char cVar1;
  undefined1 *puVar2;
  undefined1 uVar3;
  undefined4 uVar4;
  
  puVar2 = DAT_60004510;
  if (DAT_60004510[2] == '\x01') {
    cVar1 = DAT_60004510[7];
    DAT_60004510[7] = cVar1 + 1U;
    if ((byte)(cVar1 + 1U) < 6) {
      uVar4 = 0x5a;
      if (puVar2[4] == '\0') {
        uVar4 = 10;
      }
      FUN_60122688(uVar4);
      puVar2[4] = puVar2[4] == '\0';
      FUN_60163840(puVar2 + 0x1c);
      FUN_6016507e(puVar2 + 0x1c,500,0);
      return;
    }
    puVar2[4] = 0;
    puVar2[2] = 0;
    puVar2[7] = 0;
    uVar3 = *puVar2;
  }
  else {
    uVar3 = 0;
  }
  FUN_60122688(uVar3);
  FUN_60163840(puVar2 + 0x1c);
  return;
}

