
void FUN_600186a0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 local_14;
  
  piVar1 = DAT_600186e4;
  iVar2 = *DAT_600186e4;
  local_14 = param_4;
  if (iVar2 == 0) {
    iVar2 = FUN_60165098(DAT_600186e8,1,0,param_4,param_3);
    *piVar1 = iVar2;
    if (iVar2 == 0) goto LAB_600186c2;
  }
  FUN_601668f8(iVar2,0xffffffff);
LAB_600186c2:
  FUN_600239c0(piVar1[1],&local_14);
  if (*piVar1 != 0) {
    FUN_60166af4();
  }
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0x40000;
  }
  if (param_2 != (undefined4 *)0x0) {
    *param_2 = local_14;
  }
  return;
}

