
void FUN_600102ac(undefined4 param_1)

{
  FUN_6011e4a8(param_1,0xc,0);
  return;
}

