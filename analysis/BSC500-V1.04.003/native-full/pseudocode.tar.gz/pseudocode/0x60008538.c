
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60008538(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined1 auStack_50 [64];
  
  iVar1 = DAT_600085b0;
  if ((int)((uint)*(byte *)(DAT_600085b0 + 0x14) << 0x1b) < 0) {
    iVar3 = *(int *)(_DAT_600085b4 + 4);
    iVar2 = FUN_6011f77c();
    if (iVar2 == 0) {
      if (*(char *)(iVar1 + 4) == '\0') {
        *(int *)(iVar1 + 0x1c) = iVar3;
        *(undefined1 *)(iVar1 + 4) = 1;
        FUN_60168578("[auto_gnss] hot search started at %ums\n",iVar3);
        return;
      }
    }
    else {
      if (*(char *)(iVar1 + 4) == '\x01' && *(int *)(iVar1 + 0x1c) != 0) {
        uVar4 = (uint)(iVar3 - *(int *)(iVar1 + 0x1c)) / 1000;
        FUN_60164dec(auStack_50,0x40,"hot_fix_time_s:%u\r\n",uVar4);
        FUN_60118b7c(auStack_50);
        FUN_60168578("[auto_gnss] hot fix, ttff=%us\n",uVar4);
      }
      *(undefined4 *)(iVar1 + 0x1c) = 0;
      *(undefined1 *)(iVar1 + 4) = 0;
      FUN_601488a0(2);
    }
  }
  return;
}

