
/* WARNING: Removing unreachable block (ram,0x6001165e) */

void FUN_600090d4(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  ushort uStack_12;
  
  FUN_60011474(0);
  FUN_600115b4(0);
  FUN_60011514(0);
  iVar3 = DAT_600116f4;
  iVar1 = DAT_600116f0;
  uStack_12 = 0;
  uVar5 = (uint)*(ushort *)(DAT_600116f0 + 0x1c);
  if (uVar5 == 0) {
    if (*(char *)(DAT_600116f0 + 0xc) == '\0') {
      if (*(char *)(DAT_600116f0 + 3) == '\0') {
        uVar5 = 0x14;
        *(undefined2 *)(DAT_600116f0 + 0x1c) = 0x14;
      }
      else {
        uVar5 = 0;
        iVar4 = DAT_600116f0 + 0x5a;
        *(undefined1 *)(DAT_600116f0 + 3) = 0;
        CopyBytes(iVar3,iVar4,0x14);
      }
      *(short *)(iVar1 + 0x14) = *(short *)(iVar1 + 0x14) + 0x14;
      *(undefined1 *)(iVar1 + 0xc) = 1;
    }
    else {
      uVar5 = 0;
    }
  }
  if (uVar5 < *(ushort *)(iVar1 + 0x14)) {
    uVar2 = *(ushort *)(iVar1 + 0x14) - uVar5;
    if ((int)(uint)*DAT_600116f8 < (int)uVar2) {
      uVar2 = (uint)*DAT_600116f8;
    }
    uStack_12 = (ushort)uVar2;
    iVar3 = FUN_6012ea18(DAT_600116f4 + uVar5,&uStack_12,0x3e);
    if (iVar3 == 0) {
      uVar5 = (uint)*(ushort *)(iVar1 + 0x1c) + (uint)uStack_12;
      *(short *)(iVar1 + 0x1c) = (short)uVar5;
    }
    else {
      uVar5 = (uint)*(ushort *)(iVar1 + 0x1c);
    }
  }
  if ((uint)*(ushort *)(iVar1 + 0x14) <= (uVar5 & 0xffff)) {
    *(undefined1 *)(iVar1 + 0xc) = 0;
    *(undefined2 *)(iVar1 + 0x1c) = 0;
    *(undefined1 *)(iVar1 + 8) = 0;
    ZeroBytes(DAT_600116f4,(uint)*(ushort *)(iVar1 + 0x14));
    *(undefined2 *)(DAT_600116f0 + 0x14) = 0;
  }
  return;
}

