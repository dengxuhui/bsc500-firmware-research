
/* WARNING: Removing unreachable block (ram,0x60112e18) */
/* WARNING: Removing unreachable block (ram,0x60112d18) */
/* WARNING: Removing unreachable block (ram,0x60112ca0) */
/* WARNING: Removing unreachable block (ram,0x60112c44) */
/* WARNING: Removing unreachable block (ram,0x60112b1a) */
/* WARNING: Removing unreachable block (ram,0x60112b30) */
/* WARNING: Removing unreachable block (ram,0x60112b34) */
/* WARNING: Removing unreachable block (ram,0x60112e02) */
/* WARNING: Removing unreachable block (ram,0x60112e56) */
/* WARNING: Removing unreachable block (ram,0x60112c72) */
/* WARNING: Removing unreachable block (ram,0x60112e82) */
/* WARNING: Removing unreachable block (ram,0x60112e92) */
/* WARNING: Removing unreachable block (ram,0x60112e94) */
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60112c26 */
/* WARNING: Removing unreachable block (ram,0x60112c82) */
/* WARNING: Removing unreachable block (ram,0x60112c56) */
/* WARNING: Removing unreachable block (ram,0x60112dec) */
/* WARNING: Restarted to delay deadcode elimination for space: register */

uint FUN_60018ec4(undefined8 *param_1)

{
  bool bVar1;
  bool bVar2;
  float fVar3;
  float fVar4;
  float fVar5;
  int *piVar6;
  int iVar7;
  float fVar8;
  int iVar9;
  undefined4 uVar10;
  undefined1 *puVar11;
  undefined8 *unaff_r4;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  float fVar15;
  undefined8 in_d1;
  undefined4 uVar16;
  undefined4 in_s5;
  undefined8 uVar17;
  float fVar18;
  uint local_148;
  uint local_144;
  undefined4 local_138;
  undefined4 uStack_134;
  undefined4 local_130;
  undefined4 uStack_12c;
  undefined4 local_128;
  undefined4 uStack_124;
  undefined4 local_120;
  float local_118;
  undefined1 local_110 [16];
  float local_100;
  undefined1 local_f8 [16];
  float local_e8;
  undefined8 local_e0;
  undefined8 local_d8;
  float local_d0;
  undefined1 auStack_c8 [24];
  undefined1 auStack_b0 [16];
  undefined4 local_a0;
  undefined8 local_98;
  undefined8 local_90;
  undefined8 local_88;
  undefined8 local_80;
  undefined4 local_78;
  undefined4 uStack_74;
  undefined4 local_70;
  undefined4 uStack_6c;
  
  iVar9 = DAT_60018ee4;
  piVar6 = (int *)(DAT_60018ee4 + 0x50);
  if (piVar6 != (int *)0x0) {
    unaff_r4 = param_1;
  }
  if (piVar6 == (int *)0x0 || param_1 == (undefined8 *)0x0) {
    return 0xffffffff;
  }
  iVar7 = FUN_60137930(0xffffffff);
  if ((iVar7 == 0) || (iVar7 = FUN_60133cdc(), iVar7 == 0)) {
LAB_60112d42:
    uVar13 = 0xffffffff;
  }
  else {
    uVar13 = 0;
    local_70 = 0;
    uStack_6c = 0;
    local_78 = 0;
    uStack_74 = 0;
    FUN_6012fba8(&local_70,&local_78);
    local_90 = FUN_601682c8(local_70,uStack_6c);
    local_98 = FUN_60165558();
    local_80 = FUN_601682c8(local_78,uStack_74);
    local_88 = FUN_60165558();
    fVar5 = DAT_60112d84;
    fVar4 = DAT_60112d80;
    fVar3 = DAT_60112d78;
    uVar10 = (undefined4)((ulonglong)local_88 >> 0x20);
    fVar8 = (float)local_88;
    uVar17 = CONCAT44(0x3e800000,DAT_60112d74);
    bVar2 = false;
    local_148 = 0;
    bVar1 = false;
    local_144 = 0;
    fVar15 = DAT_60112d74;
    while( true ) {
      if ((uint)(*(int **)(iVar9 + 0x54))[1] <= uVar13) break;
      iVar7 = FUN_6012fb3c(&local_98,**(int **)(iVar9 + 0x54) + uVar13 * 0x30);
      if (iVar7 != 0) {
        iVar7 = **(int **)(iVar9 + 0x54) + uVar13 * 0x30;
        uVar12 = *(uint *)(iVar7 + 0x2c);
        for (uVar14 = *(uint *)(iVar7 + 0x28); uVar14 < uVar12; uVar14 = uVar14 + 1) {
          iVar7 = FUN_6013028a(*piVar6,uVar14,local_f8);
          if (iVar7 != 0) goto LAB_60112d42;
          iVar7 = uVar14 - 1;
          if (uVar14 == 0) {
            iVar7 = 1;
          }
          iVar7 = FUN_6013028a(*piVar6,iVar7,local_110);
          if (iVar7 != 0) goto LAB_60112d42;
          FUN_6012fee0();
          if (fVar8 <= fVar3) {
            FUN_6012fc48();
            fVar18 = (float)((ulonglong)uVar17 >> 0x20);
            if (fVar8 <= fVar4) {
              fVar18 = ABS(*(float *)(iVar9 + 0x5c) - local_e8) * fVar18 +
                       fVar8 * (fVar8 / 30.0 + 1.0);
              if ((!bVar2) || (fVar18 < fVar15)) {
                FUN_60156244(auStack_b0,local_f8);
                bVar2 = true;
                local_144 = uVar14;
                fVar15 = fVar18;
              }
              else {
                bVar2 = true;
              }
            }
            else if (fVar5 <= fVar8) {
              if ((!bVar1) || (fVar8 < (float)uVar17)) {
                FUN_60156244(auStack_c8,local_f8);
                uVar17 = CONCAT44(fVar18,fVar8);
                local_148 = uVar14;
              }
              bVar1 = true;
            }
          }
        }
      }
      uVar13 = uVar13 + 1;
    }
    if (!bVar1 && !bVar2) {
      *(undefined4 *)(iVar9 + 0x5c) = 0;
      return 2;
    }
    if (bVar2) {
      puVar11 = auStack_b0;
      *(undefined4 *)(iVar9 + 0x5c) = local_a0;
    }
    else {
      puVar11 = auStack_c8;
      *(undefined4 *)(iVar9 + 0x5c) = 0;
      local_144 = local_148;
    }
    FUN_60156244(&local_e0,puVar11);
    fVar15 = (float)local_e0;
    uVar16 = (undefined4)((ulonglong)in_d1 >> 0x20);
    FUN_6015e318(fVar15,uVar10,(int)local_d8);
    FUN_6012fc48();
    if (DAT_60112ea8 <= fVar15) {
      if (local_144 == 0) {
        *(float *)(unaff_r4 + 2) = local_d0;
      }
      else {
        iVar9 = FUN_6013028a(*piVar6,local_144 - 1,local_110);
        if (iVar9 != 0) goto LAB_60112d42;
        local_128 = 0;
        uStack_124 = 0;
        local_130 = 0;
        uStack_12c = 0;
        FUN_6012fc58(&local_128,&local_130);
        fVar3 = local_100;
        FUN_60161ad0(local_128,uVar10,local_130,uVar16,(undefined4)local_e0,in_s5,
                     (undefined4)local_d8);
        if (fVar15 <= ABS(local_d0 - fVar3)) {
          *(float *)(unaff_r4 + 2) = fVar15;
        }
        else {
          *(float *)(unaff_r4 + 2) = local_100;
        }
        local_e0 = CONCAT44(uStack_124,local_128);
        local_d8 = CONCAT44(uStack_12c,local_130);
      }
      *unaff_r4 = local_e0;
      unaff_r4[1] = local_d8;
      if (local_144 != 0) {
        local_144 = local_144 - 1;
      }
    }
    else {
      if (local_144 == *(int *)(*piVar6 + 0x14) - 1U) {
        *(float *)(unaff_r4 + 2) = local_d0;
      }
      else {
        iVar9 = FUN_6013028a(*piVar6,local_144 + 1,&local_128);
        if (iVar9 != 0) goto LAB_60112d42;
        local_130 = 0;
        uStack_12c = 0;
        local_138 = 0;
        uStack_134 = 0;
        FUN_6012fc58(&local_130,&local_138);
        fVar4 = local_d0;
        fVar3 = local_118;
        FUN_60161ad0(local_130,uVar10,local_138,uVar16,local_128,in_s5,local_120);
        if (fVar15 <= ABS(fVar3 - fVar4)) {
          *(float *)(unaff_r4 + 2) = local_118 - fVar15;
        }
        else {
          *(float *)(unaff_r4 + 2) = local_d0;
        }
        local_e0 = CONCAT44(uStack_12c,local_130);
        local_d8 = CONCAT44(uStack_134,local_138);
      }
      *unaff_r4 = local_e0;
      unaff_r4[1] = local_d8;
    }
    *(uint *)((int)unaff_r4 + 0x14) = local_144;
    uVar13 = (uint)!bVar2;
  }
  return uVar13;
}

