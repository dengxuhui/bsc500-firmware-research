
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60008f6c(undefined4 param_1,char *param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  bool bVar4;
  
  iVar1 = _DAT_60009010;
  if (*param_2 == '\x05') {
    *(undefined1 *)(_DAT_60009010 + 0x58) = **(undefined1 **)(param_2 + 8);
    FUN_60168578("[ble_app_gatts_set_cbk4] CCCD %d\r\n");
    uVar3 = FUN_601587e4(param_1);
    if (uVar3 < 2) {
      *(undefined1 *)(uVar3 + iVar1 + 3) = 2;
    }
    else {
      FUN_60168578("[CH4_RX] Warning: Connection index %d not found in env\r\n",param_1);
    }
    if (*(char *)(iVar1 + 0x58) == '\0') {
      thunk_FUN_6001bdd0(0x10);
    }
    else {
      thunk_FUN_6001bd58();
      thunk_FUN_6001bde4(0x10);
    }
  }
  else if (*param_2 == '\x02') {
    FUN_60168578(_DAT_60009074,*(undefined2 *)(param_2 + 2));
    FUN_60168578("[CH4_RX] Data: ");
    uVar3 = 0;
    while( true ) {
      uVar2 = (uint)*(ushort *)(param_2 + 2);
      bVar4 = 0xe < uVar3;
      if (uVar3 < 0x10) {
        bVar4 = uVar2 <= uVar3;
      }
      if (bVar4) break;
      FUN_60168578("%02X ",*(undefined1 *)(*(int *)(param_2 + 8) + uVar3));
      uVar3 = uVar3 + 1;
    }
    if (0x10 < uVar2) {
      FUN_60168578("... (%d more bytes)",uVar2 - 0x10);
    }
    FUN_60168578(&DAT_6000909c);
    thunk_FUN_6001bd58();
    thunk_FUN_6001be54(*(undefined4 *)(param_2 + 8),*(undefined2 *)(param_2 + 2));
  }
  return 0;
}

