
int FUN_600019e0(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  
  uVar1 = DAT_60001a18;
  uVar2 = param_3 + 4U & 0xfffffff8;
  for (iVar3 = -0x48; iVar3 != 0; iVar3 = iVar3 + 4) {
    *(undefined4 *)(uVar2 + iVar3) = uVar1;
  }
  *(undefined4 *)(uVar2 - 0x20) = param_2;
  *(undefined4 *)(uVar2 - 0x1c) = 0;
  *(undefined4 *)(uVar2 - 0x18) = 0;
  *(undefined4 *)(uVar2 - 0x14) = 0;
  *(undefined4 *)(uVar2 - 0x10) = 0;
  *(undefined4 *)(uVar2 - 0xc) = param_4;
  *(undefined4 *)(uVar2 - 8) = param_1;
  *(undefined4 *)(uVar2 - 4) = 0x1000000;
  *(undefined4 *)(uVar2 - 0x48) = 0;
  *(undefined4 *)(uVar2 - 0x44) = 0;
  return uVar2 - 0x48;
}

