
undefined4 FUN_600028d0(void)

{
  FUN_60156c34(DAT_600028e4);
  FUN_60156bb4(DAT_600028e8,1);
  return 1;
}

