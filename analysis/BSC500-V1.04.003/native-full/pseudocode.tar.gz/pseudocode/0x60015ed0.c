
void FUN_60015ed0(undefined4 param_1,int param_2)

{
  if (*(int *)(param_2 + 0x18) != 0) {
    FUN_60160aa4();
    *(undefined4 *)(param_2 + 0x18) = 0;
  }
  return;
}

