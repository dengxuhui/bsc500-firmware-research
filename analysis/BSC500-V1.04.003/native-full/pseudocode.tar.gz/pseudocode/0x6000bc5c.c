
undefined4 FUN_6000bc5c(void)

{
  return DAT_6000bc60;
}

