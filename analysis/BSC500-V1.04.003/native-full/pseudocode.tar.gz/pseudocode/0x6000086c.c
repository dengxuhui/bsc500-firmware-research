
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000086c(void)

{
  undefined8 uVar1;
  
  uVar1 = FUN_60167f4a(&DAT_6000089c,_DAT_600008a4,0,0x1000);
  if ((int)uVar1 != 0) {
    FUN_60167f8c((int)uVar1,(int)((ulonglong)uVar1 >> 0x20),0xf,0x14);
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("tid != RT_NULL","rt_application_init",0x153);
}

