
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009b20(void)

{
  int iVar1;
  
  iVar1 = FUN_60161a98();
  if (iVar1 != 0) {
    FUN_60161424("mtu[%d],channel:[%d,%d,%d],[%d,%d,%d],[%d,%d,%d],[%d,%d,%d]\n",*DAT_60009b9c,
                 *(undefined1 *)(DAT_60009ba0 + 0x24),*(undefined1 *)(DAT_60009ba0 + 0x25),
                 *(undefined1 *)(DAT_60009ba0 + 0x27),*(undefined1 *)(DAT_60009ba4 + 0x18),
                 *(undefined1 *)(DAT_60009ba4 + 0x19),*(undefined1 *)(DAT_60009ba4 + 0x1b),
                 *(undefined1 *)(DAT_60009ba8 + 0x18),*(undefined1 *)(DAT_60009ba8 + 0x19),
                 *(undefined1 *)(DAT_60009ba8 + 0x1b),*(undefined1 *)(_DAT_60009bac + 0x18),
                 *(undefined1 *)(_DAT_60009bac + 0x19),*(undefined1 *)(_DAT_60009bac + 0x1b));
    return;
  }
  FUN_60161424("ble offline\n");
  return;
}

