
void FUN_60011d4c(void)

{
  int iVar1;
  
  iVar1 = DAT_60011d68;
  if (*(int *)(DAT_60011d68 + 4) != 0) {
    FUN_60168578("[ABORT]\r\n");
    FUN_6001ccd0(iVar1 + 4);
    return;
  }
  return;
}

