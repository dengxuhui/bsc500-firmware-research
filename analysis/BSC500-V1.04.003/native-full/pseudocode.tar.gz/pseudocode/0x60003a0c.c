
void FUN_60003a0c(void)

{
  *DAT_60003a14 = 1;
  return;
}

