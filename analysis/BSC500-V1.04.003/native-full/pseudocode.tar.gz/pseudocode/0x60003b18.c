
void FUN_60003b18(void)

{
  code *pcVar1;
  
  FUN_60006a20(DAT_60003b38,6,1);
  pcVar1 = DAT_60003b3c;
  (*DAT_60003b3c)(0);
  (*pcVar1)(1);
  (*pcVar1)(2);
  return;
}

