
undefined4 FUN_6000c4ec(void)

{
  int iVar1;
  undefined4 uVar2;
  
  FUN_60017188();
  uVar2 = FUN_60164b70();
  *DAT_6000c558 = uVar2;
  FUN_6001716c();
  iVar1 = DAT_6000c55c;
  ZeroBytes(DAT_6000c55c + 0x68,0xf8);
  FUN_60166858(iVar1 + 0x9e,0x85,0xff);
  *(undefined1 *)(iVar1 + 0x9a) = 0xff;
  *(undefined4 *)(iVar1 + 0x96) = 0xffffffff;
  *(undefined4 *)(iVar1 + 0x92) = 0xffffffff;
  *(undefined4 *)(iVar1 + 0x8e) = 0xffffffff;
  iVar1 = DAT_6000c560;
  ZeroBytes(DAT_6000c560 + 0x68,0xf8);
  FUN_60166858(iVar1 + 0x9e,0x85,0xff);
  *(undefined1 *)(iVar1 + 0x9a) = 0xff;
  *(undefined4 *)(iVar1 + 0x96) = 0xffffffff;
  *(undefined4 *)(iVar1 + 0x92) = 0xffffffff;
  *(undefined4 *)(iVar1 + 0x8e) = 0xffffffff;
  return 0;
}

