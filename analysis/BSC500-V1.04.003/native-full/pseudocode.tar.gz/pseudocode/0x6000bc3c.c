
void FUN_6000bc3c(void)

{
  undefined1 *puVar1;
  undefined1 auStack_38 [48];
  
  puVar1 = DAT_6000bc58;
  *DAT_6000bc58 = 1;
  FUN_6013a8de(*(undefined4 *)(puVar1 + 8),auStack_38,0,0);
  return;
}

