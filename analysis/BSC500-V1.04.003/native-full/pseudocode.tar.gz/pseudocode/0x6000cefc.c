
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x6000d1b8 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_6000cefc(void)

{
  int iVar1;
  int iVar2;
  undefined8 *puVar3;
  undefined1 uVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined1 *puVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  char cVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined4 uVar16;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined8 in_d0;
  float fVar17;
  undefined8 in_d1;
  undefined4 in_s5;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined4 local_10c;
  undefined1 auStack_108 [20];
  float local_f4;
  undefined1 auStack_f0 [32];
  undefined4 local_d0;
  undefined4 uStack_cc;
  undefined4 local_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 local_b4;
  float local_b0 [2];
  undefined4 local_a8;
  undefined1 auStack_a0 [32];
  undefined1 auStack_80 [32];
  undefined8 local_60;
  undefined8 local_58;
  float local_50;
  undefined4 local_4c;
  
  iVar2 = DAT_6000d4f4;
  iVar1 = DAT_6000d4f0;
  if (*(char *)(DAT_6000d4f0 + 0x30) != '\x04') {
    return;
  }
  iVar5 = FUN_60166dd0(DAT_6000d4f4 + 0x48);
  if ((iVar5 == 1) || (iVar5 = FUN_60166dd0(iVar2 + 0x50), iVar5 == 1)) {
    puVar3 = DAT_6000d4f8;
    *(undefined4 *)(iVar1 + 100) = 0;
    *(undefined1 *)((int)puVar3 + 0x74) = 0;
    *(undefined1 *)((int)puVar3 + 0x51) = 0;
    *(undefined1 *)((int)puVar3 + 0xa1) = 0;
    uVar9 = DAT_6000d2f4;
    *(undefined1 *)((int)puVar3 + 0x21) = 5;
    *(undefined4 *)(puVar3 + 0xe) = uVar9;
    *(undefined4 *)((int)puVar3 + 0x54) = 0xffffffff;
    *(undefined4 *)(puVar3 + 0xb) = 0xffffffff;
    *(undefined4 *)((int)puVar3 + 0x5c) = 0xffffffff;
    return;
  }
  ZeroBytes(&local_60,0x18);
  puVar3 = DAT_6000d4f8;
  fVar17 = (float)in_d0;
  uVar9 = (undefined4)((ulonglong)in_d0 >> 0x20);
  uVar10 = (undefined4)((ulonglong)in_d1 >> 0x20);
  if (*(int *)(iVar1 + 100) == 0) {
    *(undefined1 *)((int)DAT_6000d4f8 + 0x74) = 0;
    *(undefined1 *)((int)puVar3 + 0x51) = 0;
    *(undefined1 *)((int)puVar3 + 0xa1) = 0;
    uVar11 = DAT_6000d4fc;
    *(undefined1 *)((int)puVar3 + 0x21) = 4;
    *(undefined4 *)(puVar3 + 0xe) = uVar11;
    *(undefined4 *)((int)puVar3 + 0x54) = 0xffffffff;
    *(undefined4 *)(puVar3 + 0xb) = 0xffffffff;
    *(undefined4 *)((int)puVar3 + 0x5c) = 0xffffffff;
    *(undefined4 *)(iVar1 + 100) = 1;
    uVar11 = *(undefined4 *)(iVar2 + 0x4c);
    uVar14 = *(undefined4 *)(iVar2 + 0x50);
    uVar15 = *(undefined4 *)(iVar2 + 0x54);
    *(undefined4 *)(iVar1 + 0x44) = *(undefined4 *)(iVar2 + 0x48);
    *(undefined4 *)(iVar1 + 0x48) = uVar11;
    *(undefined4 *)(iVar1 + 0x4c) = uVar14;
    *(undefined4 *)(iVar1 + 0x50) = uVar15;
    uVar18 = FUN_6016759c();
    uVar19 = FUN_6016759c(uVar11);
    uVar11 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                          (int)((ulonglong)uVar19 >> 0x20));
    uVar18 = FUN_6016759c(uVar14);
    uVar19 = FUN_6016759c(uVar15);
    uVar14 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                          (int)((ulonglong)uVar19 >> 0x20));
    iVar5 = FUN_60137da4(uVar11,uVar9,uVar14,*(undefined1 *)(iVar1 + 0x69),&local_60);
    if (iVar5 == 0) {
      FUN_60161ad0(uVar11,uVar9,uVar14,uVar10,(int)local_60,in_s5,(int)local_58);
      uVar4 = *(undefined1 *)(iVar1 + 0x69);
      *(float *)((int)puVar3 + 0xa4) = local_50;
      *puVar3 = local_60;
      puVar3[1] = local_58;
      *(float *)(puVar3 + 0x15) = fVar17 + (*(float *)(iVar1 + 0x38) - local_50);
      FUN_600fdc70(iVar2 + 0x28,uVar4,local_4c);
      FUN_600fdc60(local_50,*(undefined1 *)(iVar1 + 0x69));
    }
    goto LAB_6000d4ce;
  }
  uVar14 = *(undefined4 *)(iVar1 + 0x50);
  *(int *)(iVar1 + 100) = *(int *)(iVar1 + 100) + 1;
  uVar11 = *(undefined4 *)(iVar1 + 0x48);
  uVar15 = *(undefined4 *)(iVar1 + 0x4c);
  uVar18 = FUN_6016759c(*(undefined4 *)(iVar1 + 0x44));
  uVar19 = FUN_6016759c(uVar11);
  uVar11 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                        (int)((ulonglong)uVar19 >> 0x20));
  uVar18 = FUN_6016759c(uVar15);
  uVar19 = FUN_6016759c(uVar14);
  uVar14 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                        (int)((ulonglong)uVar19 >> 0x20));
  uVar15 = *(undefined4 *)(iVar2 + 0x4c);
  uVar13 = *(undefined4 *)(iVar2 + 0x50);
  uVar16 = *(undefined4 *)(iVar2 + 0x54);
  uVar18 = FUN_6016759c(*(undefined4 *)(iVar2 + 0x48));
  uVar19 = FUN_6016759c(uVar15);
  uVar15 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                        (int)((ulonglong)uVar19 >> 0x20));
  uVar18 = FUN_6016759c(uVar13);
  uVar19 = FUN_6016759c(uVar16);
  uVar13 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                        (int)((ulonglong)uVar19 >> 0x20));
  FUN_60161ad0(uVar11,uVar9,uVar14,uVar10,uVar15,in_s5,uVar13);
  iVar2 = DAT_6000d4f4;
  if (fVar17 < 4.0) goto LAB_6000d4ce;
  FUN_6015e318(uVar11,uVar9,uVar14,uVar10,uVar15,in_s5,uVar13);
  ZeroBytes(local_b0,0x50);
  ZeroBytes(&local_d0,0x20);
  ZeroBytes(auStack_108,0x38);
  local_10c = 0;
  iVar5 = FUN_60018064(uVar15,uVar9,uVar13,uVar10,fVar17,*(undefined1 *)(iVar1 + 0x69),&local_60);
  puVar3 = DAT_6000d4f8;
  if (iVar5 == 2) {
    *(undefined1 *)((int)DAT_6000d4f8 + 0x21) = 3;
    uVar11 = DAT_6000d4fc;
    *(undefined1 *)((int)puVar3 + 0x74) = 0;
    *(undefined1 *)((int)puVar3 + 0x51) = 0;
    *(undefined1 *)((int)puVar3 + 0xa1) = 0;
    *(undefined4 *)(puVar3 + 0xe) = uVar11;
    *(undefined4 *)((int)puVar3 + 0x54) = 0xffffffff;
    *(undefined4 *)(puVar3 + 0xb) = 0xffffffff;
    *(undefined4 *)((int)puVar3 + 0x5c) = 0xffffffff;
    iVar5 = FUN_60137da4(uVar15,uVar9,uVar13,*(undefined1 *)(iVar1 + 0x69),&local_60);
    if (iVar5 == 0) {
      FUN_60161ad0(uVar15,uVar9,uVar13,uVar10,(int)local_60,in_s5,(int)local_58);
      uVar4 = *(undefined1 *)(iVar1 + 0x69);
      *(float *)((int)puVar3 + 0xa4) = local_50;
      *puVar3 = local_60;
      puVar3[1] = local_58;
      *(float *)(puVar3 + 0x15) = fVar17 + (*(float *)(iVar1 + 0x38) - local_50);
      FUN_600fdc70(iVar2 + 0x28,uVar4,local_4c);
      FUN_600fdc60(local_50,*(undefined1 *)(iVar1 + 0x69));
      if (*(char *)(iVar1 + 0x6b) == '\0') {
        *(undefined1 *)(iVar1 + 0x6b) = 1;
        *(float *)(iVar1 + 0x40) = local_50;
      }
      coprocessor_function2(10,8,2,in_cr0,in_cr0,in_cr1);
      iVar5 = FUN_60018084(fVar17 + DAT_6000d500,uVar9,*(undefined4 *)(iVar1 + 0x38),
                           *(undefined1 *)(iVar1 + 0x69),puVar3 + 2,puVar3 + 3);
      if (iVar5 != 0) {
        puVar3[3] = puVar3[1];
        puVar3[2] = *puVar3;
      }
    }
  }
  else {
    if (iVar5 == 1) {
      *(undefined1 *)((int)DAT_6000d4f8 + 0x74) = 0;
      *(undefined1 *)((int)puVar3 + 0x51) = 0;
      *(undefined1 *)((int)puVar3 + 0xa1) = 0;
      uVar9 = DAT_6000d4fc;
      *(undefined1 *)((int)puVar3 + 0x21) = 1;
      *(float *)((int)puVar3 + 0xa4) = local_50;
      *(undefined4 *)(puVar3 + 0xe) = uVar9;
      *(undefined4 *)((int)puVar3 + 0x54) = 0xffffffff;
      *(undefined4 *)(puVar3 + 0xb) = 0xffffffff;
      *(undefined4 *)((int)puVar3 + 0x5c) = 0xffffffff;
      *puVar3 = local_60;
      puVar3[1] = local_58;
      uVar4 = *(undefined1 *)(iVar1 + 0x69);
      *(float *)(puVar3 + 0x15) = *(float *)(iVar1 + 0x38) - local_50;
      FUN_600fdc70(iVar2 + 0x28,uVar4,local_4c);
      FUN_600fdc60(local_50,*(undefined1 *)(iVar1 + 0x69));
      *(undefined2 *)(iVar1 + 0x6a) = 1;
    }
    else {
      if (iVar5 != 0) goto LAB_6000d4c2;
      fVar17 = *(float *)(iVar1 + 0x38);
      if (fVar17 + -20.0 <= local_50) {
        *(undefined4 *)(DAT_6000d4f8 + 0x15) = 0;
        *(float *)((int)puVar3 + 0xa4) = local_50;
        *(undefined1 *)((int)puVar3 + 0x21) = 2;
      }
      else {
        uVar4 = *(undefined1 *)(iVar1 + 0x69);
        *(undefined1 *)((int)DAT_6000d4f8 + 0x21) = 0;
        *(float *)((int)puVar3 + 0xa4) = local_50;
        *(float *)(puVar3 + 0x15) = fVar17 - local_50;
        iVar5 = FUN_60018204(uVar4,local_b0,&local_10c);
        if (iVar5 == 0) {
          *(undefined1 *)((int)puVar3 + 0x51) = 1;
          uVar4 = FUN_60018214(local_a8);
          fVar17 = local_50;
          *(undefined1 *)((int)puVar3 + 0x24) = uVar4;
          cVar12 = *(char *)(iVar1 + 0x69);
          puVar7 = auStack_a0;
          *(undefined4 *)((int)puVar3 + 0x2c) = local_10c;
          *(float *)(puVar3 + 5) = local_b0[0] - local_50;
          if (cVar12 == '\x01') {
            puVar7 = auStack_80;
          }
          CopyBytes(puVar3 + 6,puVar7,0x20);
          *(undefined1 *)(puVar3 + 10) = 0;
        }
        else {
          cVar12 = *(char *)(iVar1 + 0x69);
          *(undefined1 *)((int)puVar3 + 0x51) = 0;
          fVar17 = local_50;
        }
        iVar5 = FUN_60017e44(fVar17,cVar12,&local_d0);
        if (iVar5 == 0) {
          *(undefined1 *)((int)puVar3 + 0x74) = 1;
          *(undefined4 *)((int)puVar3 + 0x54) = local_d0;
          *(undefined4 *)(puVar3 + 0xb) = uStack_cc;
          *(undefined4 *)((int)puVar3 + 0x5c) = local_c8;
          *(undefined4 *)(puVar3 + 0xc) = uStack_c4;
          *(undefined4 *)((int)puVar3 + 100) = uStack_c0;
          *(undefined4 *)(puVar3 + 0xd) = uStack_bc;
          puVar6 = (undefined4 *)((int)puVar3 + 0x6c);
          puVar8 = &uStack_b8;
        }
        else {
          *(undefined1 *)((int)puVar3 + 0x74) = 0;
          *(undefined4 *)((int)puVar3 + 0x54) = local_d0;
          *(undefined4 *)(puVar3 + 0xb) = uStack_cc;
          puVar6 = (undefined4 *)((int)puVar3 + 0x5c);
          puVar8 = &local_c8;
        }
        *puVar6 = *puVar8;
        uVar4 = *(undefined1 *)(iVar1 + 0x69);
        *(undefined4 *)(puVar3 + 0xe) = local_b4;
        iVar5 = FUN_60018138(local_50,uVar4,auStack_108,&local_10c);
        uVar9 = local_10c;
        if (iVar5 == 0) {
          *(undefined1 *)((int)puVar3 + 0xa1) = 1;
          *(undefined4 *)(puVar3 + 0xf) = local_10c;
          *(float *)((int)puVar3 + 0x7c) = local_f4 - local_50;
          CopyBytes(puVar3 + 0x10,auStack_f0,0x20);
          *(undefined1 *)(puVar3 + 0x14) = 0;
          FUN_6001812c(*(undefined1 *)(iVar1 + 0x69),uVar9);
        }
        else {
          *(undefined1 *)((int)puVar3 + 0xa1) = 0;
        }
      }
      puVar3 = DAT_6000d4f8;
      uVar4 = *(undefined1 *)(iVar1 + 0x69);
      *DAT_6000d4f8 = local_60;
      puVar3[1] = local_58;
      FUN_600fdc70(iVar2 + 0x28,uVar4,local_4c);
      FUN_600fdc60(local_50,*(undefined1 *)(iVar1 + 0x69));
      *(undefined2 *)(iVar1 + 0x6a) = 1;
    }
    *(float *)(iVar1 + 0x3c) = local_50;
  }
LAB_6000d4c2:
  uVar9 = *(undefined4 *)(iVar2 + 0x4c);
  uVar10 = *(undefined4 *)(iVar2 + 0x50);
  uVar11 = *(undefined4 *)(iVar2 + 0x54);
  *(undefined4 *)(iVar1 + 0x44) = *(undefined4 *)(iVar2 + 0x48);
  *(undefined4 *)(iVar1 + 0x48) = uVar9;
  *(undefined4 *)(iVar1 + 0x4c) = uVar10;
  *(undefined4 *)(iVar1 + 0x50) = uVar11;
LAB_6000d4ce:
  if (*(char *)((int)DAT_6000d4f8 + 0x21) == '\x02') {
    FUN_60160914(0);
    if (*(code **)(iVar1 + 0x60) != (code *)0x0) {
      (**(code **)(iVar1 + 0x60))();
    }
    FUN_601608f8();
  }
  return;
}

