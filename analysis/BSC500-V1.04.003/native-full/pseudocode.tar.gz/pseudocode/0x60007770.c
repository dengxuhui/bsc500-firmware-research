
void FUN_60007770(void)

{
  FUN_60159738(DAT_60007778,0);
  return;
}

