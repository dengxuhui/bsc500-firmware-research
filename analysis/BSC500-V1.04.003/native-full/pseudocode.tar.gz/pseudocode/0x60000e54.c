
undefined4 FUN_60000e54(void)

{
  longlong lVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  
  uVar6 = 1;
  uVar2 = thunk_EXT_FUN_00021290(1,1);
  if (uVar2 <= DAT_60000ed0) {
    uVar6 = 0;
    uVar4 = uVar2 / DAT_60000ed8;
    uVar3 = uVar2 / DAT_60000ed4;
    uVar7 = (DAT_60000edc + uVar2 * 10) / DAT_60000ee0;
    lVar1 = (ulonglong)uVar7 * (ulonglong)DAT_60000ee4;
    uVar2 = FUN_60162a88((int)lVar1,(int)((ulonglong)lVar1 >> 0x20),uVar2,0);
    uVar5 = (uint)(uVar2 < 9000);
    if (11000 < uVar2) {
      uVar5 = 0xffffffff;
    }
    *DAT_60000eec = DAT_60000ee8 & (uVar5 + uVar7) * 0x400 | uVar4 * 0x80 + 0x80 & 0x380 | uVar3 + 1
    ;
  }
  return uVar6;
}

