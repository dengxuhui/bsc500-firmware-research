
void FUN_6000bfa8(char *param_1,int param_2)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  uint uVar5;
  byte bVar6;
  uint uVar7;
  
  if ((*(short *)(param_1 + 0xd0) != -1) && (param_1[0x8c] == '\x01')) {
    if ((((int)*(short *)(param_1 + 0x26) != 0x7fff) &&
        (*(uint *)(param_2 + 4) < (uint)(int)*(short *)(param_1 + 0x26))) ||
       (iVar2 = FUN_6011679c(*(short *)(param_1 + 0xd0),0,0,0), iVar2 == 0)) {
LAB_6000c074:
      *(undefined1 *)(DAT_6000c0c8 + 3) = 0;
      *(undefined1 *)(param_2 + 0x329) = 0;
      return;
    }
    *(undefined1 *)(DAT_6000c0c8 + 2) = 0;
LAB_6000c04a:
    *(undefined1 *)(param_2 + 0x329) = 1;
    return;
  }
  if (param_1[0xcc] == '\0') {
    iVar2 = FUN_6011679c(0,param_1[0xda],param_1[0xd8],*(undefined2 *)(param_1 + 0xd6));
    if (iVar2 != 0) {
      *(undefined1 *)(DAT_6000c0c8 + 2) = 0;
      goto LAB_6000c04a;
    }
    if ((*param_1 == '\0') || (iVar2 = FUN_6012d794(), iVar2 != 0)) goto LAB_6000c074;
    uVar5 = *(uint *)(param_1 + 0xac);
    uVar7 = *(uint *)(DAT_6000c0cc + 4);
    iVar2 = DAT_6000c0c8;
    if (*(char *)(param_2 + 0x329) == '\0') {
      if ((uVar5 < uVar7) && ((uVar7 - uVar5) - 500 < 0x5dd)) {
        bVar6 = *(char *)(DAT_6000c0c8 + 3) + 1;
        *(byte *)(DAT_6000c0c8 + 3) = bVar6;
        if (bVar6 < 3) {
          return;
        }
        goto LAB_6000c04a;
      }
    }
    else if ((uVar5 < uVar7) && (10000 < uVar7 - uVar5)) {
      *(undefined1 *)(param_2 + 0x329) = 0;
      iVar2 = DAT_6000c0c8;
    }
  }
  else {
    bVar1 = false;
    if (((int)*(short *)(param_1 + 0x26) != 0x7fff) &&
       (*(uint *)(param_2 + 4) < (uint)(int)*(short *)(param_1 + 0x26))) {
      bVar1 = true;
    }
    iVar3 = FUN_6015c548(*(undefined4 *)(param_1 + 0xc4),0);
    iVar2 = DAT_6000c0c8;
    if ((!bVar1) && (iVar3 != 0)) {
      pcVar4 = (char *)(DAT_6000c0c8 + 3);
      *(undefined1 *)(DAT_6000c0c8 + 2) = 0;
      if (*pcVar4 != '\0') {
        pcVar4 = (char *)(param_2 + 0x329);
      }
      *pcVar4 = '\x01';
      return;
    }
    if (*(char *)(DAT_6000c0c8 + 2) == '\x01') {
      *(undefined1 *)(param_2 + 0x329) = 0;
    }
    else {
      *(undefined1 *)(DAT_6000c0c8 + 2) = 1;
    }
  }
  *(undefined1 *)(iVar2 + 3) = 0;
  return;
}

