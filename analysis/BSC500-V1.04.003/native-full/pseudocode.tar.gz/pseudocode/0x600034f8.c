
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600034f8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  
  iVar1 = DAT_60003560;
  if (*(char *)(DAT_60003560 + 3) == '\0') {
    FUN_6016572c(DAT_60003584,0,DAT_60003588,param_4,param_3,param_4);
    uVar4 = DAT_6000358c;
    FUN_60156878(DAT_6000358c);
    uVar3 = FUN_60167488(&DAT_60003590,DAT_60003594,uVar4,10,4);
    uVar2 = DAT_6000359c;
    uVar4 = DAT_60003598;
    *(undefined4 *)(iVar1 + 8) = uVar3;
    FUN_6000f6c0(uVar4,uVar2);
    FUN_60160bc0(0x3f800000,uVar4);
    uVar4 = FUN_6016717c();
    FUN_60167f3c(6,_DAT_60003564,1,DAT_600035a0,uVar4);
  }
  else {
    FUN_60167f3c(6,_DAT_60003564,1,"gps firmware is updated\n");
    FUN_6015d0e4();
  }
  return 1;
}

