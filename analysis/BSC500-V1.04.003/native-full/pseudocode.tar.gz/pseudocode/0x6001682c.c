
bool FUN_6001682c(void)

{
  if (*DAT_6001683c == '\x01') {
    return *(char *)(DAT_6011f78c + 0xcc) != '\0';
  }
  return false;
}

