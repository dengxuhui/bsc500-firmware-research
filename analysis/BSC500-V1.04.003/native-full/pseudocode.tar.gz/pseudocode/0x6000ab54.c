
undefined8 FUN_6000ab54(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  byte *pbVar2;
  byte bVar3;
  undefined4 local_14;
  undefined4 uStack_10;
  uint local_c;
  
  local_14 = param_2;
  if ((*(char *)*DAT_6000abbc == '\0') ||
     (uStack_10 = param_3, local_c = param_4, iVar1 = FUN_60019c8c(), iVar1 == 0)) {
    *DAT_6000abc0 = 0x1d;
    bVar3 = 0;
    pbVar2 = DAT_6000abc4;
  }
  else {
    local_c = local_c & 0xffff0000;
    local_14 = 0;
    uStack_10 = 0;
    iVar1 = FUN_60019c04(&local_14);
    if (iVar1 == 0) {
      *DAT_6000abc0 = 0x1d;
      *DAT_6000abc4 = 0;
      return CONCAT44(local_14,param_1);
    }
    bVar3 = *DAT_6000abc4;
    if ((bVar3 < 5) && (*DAT_6000abc4 = bVar3 + 1, bVar3 != 4)) goto LAB_6000abaa;
    if (0x1c < *DAT_6000abc0) {
      *DAT_6000abc0 = 0;
      FUN_60163e70(DAT_6000abc8,&local_14,0);
      return CONCAT44(local_14,param_1);
    }
    bVar3 = *DAT_6000abc0 + 1;
    pbVar2 = DAT_6000abc0;
  }
  *pbVar2 = bVar3;
LAB_6000abaa:
  return CONCAT44(local_14,param_1);
}

