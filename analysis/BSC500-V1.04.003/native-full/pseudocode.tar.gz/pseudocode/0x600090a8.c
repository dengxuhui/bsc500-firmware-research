
undefined8 FUN_600090a8(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined4 unaff_r6;
  undefined1 local_18;
  undefined1 uStack_17;
  undefined2 local_16;
  undefined2 local_14;
  undefined2 local_12;
  undefined2 local_10;
  undefined2 local_e;
  undefined2 uStack_c;
  undefined2 uStack_a;
  
  uStack_a = (undefined2)((uint)unaff_r6 >> 0x10);
  uStack_17 = (undefined1)((uint)param_4 >> 8);
  local_10 = (undefined2)param_4;
  local_e = (undefined2)DAT_600090d0;
  uStack_c = (undefined2)((uint)DAT_600090d0 >> 0x10);
  local_12 = 0;
  local_18 = param_1;
  local_16 = param_3;
  local_14 = param_2;
  FUN_60011710(&local_18);
  return CONCAT26(local_12,CONCAT24(local_14,CONCAT22(local_16,CONCAT11(uStack_17,local_18))));
}

