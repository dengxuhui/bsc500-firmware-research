
void FUN_6001036c(void)

{
  FUN_6013cc84(DAT_60010378 + 0x38,0xffffffff);
  return;
}

