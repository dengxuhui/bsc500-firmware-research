
undefined4 FUN_60015c78(int param_1,uint param_2)

{
  undefined4 uVar1;
  char local_28 [24];
  
  FUN_60163ac4(9,local_28);
  if (local_28[0] == '\x02') {
    if (param_1 == 2) {
      FUN_6001bc78(param_2);
    }
    else if (param_1 == 1) {
      FUN_6001bc9c(param_2 & 0xff);
    }
    else if (param_1 == 0) {
      FUN_6001bc58(param_2);
    }
    uVar1 = 0;
  }
  else {
    uVar1 = 0xffffffff;
  }
  return uVar1;
}

