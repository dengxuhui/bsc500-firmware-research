
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000abcc(undefined4 *param_1,int param_2,undefined4 *param_3)

{
  undefined4 uVar1;
  char *pcVar2;
  int iVar3;
  undefined4 *puVar4;
  
  iVar3 = _DAT_6000ac5c;
  puVar4 = param_3;
  if (*(char *)(_DAT_6000ac5c + 0xf) == '\x01') {
    FUN_60161424("stack_is_overflow\n");
    FUN_60161424(_DAT_6000ac74);
    if (*(char *)(iVar3 + 0x10) == '\0') {
      pcVar2 = "Error: Main stack(%08x) was overflow";
    }
    else {
      FUN_60161424("on_thread_before_fault\n");
      FUN_60161424(_DAT_6000ac74);
      pcVar2 = "Error: Thread stack(%08x) was overflow";
    }
    FUN_60161424(pcVar2,param_3);
    FUN_60161424(_DAT_6000ac74);
    puVar4 = param_1;
    if ((param_1 <= param_3) && (puVar4 = param_3, (undefined4 *)(param_2 + (int)param_1) < param_3)
       ) {
      puVar4 = (undefined4 *)(param_2 + (int)param_1);
    }
  }
  FUN_60161424(DAT_6000ace0);
  uVar1 = _DAT_6000ac74;
  FUN_60161424(_DAT_6000ac74);
  for (; puVar4 < (undefined4 *)((int)param_1 + param_2); puVar4 = puVar4 + 1) {
    iVar3 = FUN_601597bc(*puVar4);
    if (iVar3 != 0) {
      FUN_60161424("0x%08x",*puVar4);
      FUN_60161424(uVar1);
    }
  }
  FUN_60161424(DAT_6000ace4);
  FUN_60161424(_DAT_6000ac74);
  return;
}

