
undefined4 FUN_6000f6c0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  undefined4 uVar7;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 uStack_20;
  
  piVar1 = DAT_6000f75c;
  if (param_2 == 0) {
    uVar7 = 0;
  }
  else {
    iVar2 = *DAT_6000f75c;
    if (iVar2 == 0) {
      local_24 = 0;
      uStack_20 = 0;
      local_28 = 1;
      local_2c = DAT_6000f760;
      iVar2 = FUN_60168494(&local_2c);
      *piVar1 = iVar2;
    }
    FUN_6016825e(iVar2,0xffffffff);
    uVar7 = 1;
    piVar6 = (int *)piVar1[1];
LAB_6000f700:
    piVar5 = piVar6;
    if (piVar5 != (int *)0x0) {
      piVar6 = (int *)piVar5[0xc];
      if (*piVar5 == param_1) {
        piVar5 = piVar5 + 0xb;
        piVar4 = piVar5;
        do {
          piVar3 = (int *)*piVar4;
          if (piVar3 == (int *)0x0) {
            piVar4 = (int *)thunk_FUN_60162e34(0xc,1);
            if (piVar4 == (int *)0x0) {
              uVar7 = 0;
            }
            else {
              *piVar4 = param_2;
              iVar2 = *piVar5;
              piVar4[1] = iVar2;
              if (iVar2 != 0) {
                *(int **)(iVar2 + 8) = piVar4 + 1;
              }
              piVar4[2] = (int)piVar5;
              *piVar5 = (int)piVar4;
            }
            break;
          }
          piVar4 = piVar3 + 1;
        } while (*piVar3 != param_2);
      }
      goto LAB_6000f700;
    }
    if (*piVar1 != 0) {
      FUN_601682ae();
    }
  }
  return uVar7;
}

