
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

char FUN_6000a87c(void)

{
  undefined4 *puVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  puVar1 = _DAT_6000a8d8;
  iVar3 = FUN_600f92bc(*_DAT_6000a8d8,*(short *)(_DAT_6000a8d8 + 1) << 0xf | 0x7fff);
  if (iVar3 == 0xff) {
    cVar2 = '\0';
  }
  else {
    FUN_60164a88();
    iVar4 = FUN_6015d5fc(*puVar1,iVar3);
    iVar5 = FUN_60162e34(0x20);
    *(int *)(iVar4 + 0xc) = iVar5;
    if (iVar5 == 0) {
                    /* WARNING: Subroutine does not return */
      FUN_6016804c("clnt->user_data","datac_open",0x4d1);
    }
    FUN_60167214(iVar5,0x20);
    *(undefined1 *)(*(int *)(iVar4 + 0xc) + 8) = 1;
    FUN_60164ac8();
    cVar2 = (char)iVar3 + '\n';
  }
  return cVar2;
}

