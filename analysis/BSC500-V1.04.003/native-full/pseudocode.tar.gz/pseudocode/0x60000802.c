
void FUN_60000802(void)

{
  FUN_6006dc36(0);
  FUN_6006d20a();
  return;
}

