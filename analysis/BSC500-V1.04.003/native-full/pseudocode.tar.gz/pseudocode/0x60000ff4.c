
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000ff4(int param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  char *pcVar4;
  
  uVar2 = _DAT_60001064;
  uVar1 = DAT_60001060;
  param_3 = param_3 + 1;
  pcVar4 = (char *)(param_1 + 0x11c);
  do {
    param_3 = param_3 + -1;
    if (param_3 == 0) {
      return 0;
    }
    iVar3 = 0x703;
    *(undefined4 *)(pcVar4 + 0x5c) = uVar2;
    *(undefined4 *)(pcVar4 + 0x60) = param_4;
    *(undefined4 *)(pcVar4 + 100) = uVar1;
    *(undefined4 **)(pcVar4 + -0xa4) = param_2;
    if (*pcVar4 == '\0') {
      iVar3 = 0x503;
    }
    if (pcVar4[1] != '\0') {
      iVar3 = iVar3 + 0x800;
    }
    iVar3 = FUN_6000194c(pcVar4 + 4,*param_2,iVar3,pcVar4 + -0x11c);
    param_2 = param_2 + 5;
    pcVar4 = pcVar4 + 0x18c;
  } while (iVar3 == 0);
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("result == RT_EOK","rt_hw_usart_init2",0x363);
}

