
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009484(uint param_1)

{
  byte *pbVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  byte *pbVar5;
  undefined1 uVar6;
  char cVar7;
  short sVar8;
  int iVar9;
  uint uVar10;
  undefined4 uVar11;
  int iVar12;
  uint uVar13;
  uint uVar14;
  int *piVar15;
  char *pcVar16;
  uint uVar17;
  int iVar18;
  int local_38;
  code *local_34;
  code *local_30;
  undefined4 local_2c;
  
  uVar17 = 0;
  local_38 = 0;
  do {
    pbVar1 = _DAT_60009a64;
    if (uVar17 == 8) {
      for (iVar9 = 0; pbVar1 = _DAT_60009a64, iVar9 != 8; iVar9 = iVar9 + 1) {
        iVar18 = *(int *)(_DAT_60009a64 + iVar9 * 4 + 0x24);
        if (iVar18 != 0) {
          if (*(char *)(iVar18 + 0x18) != -1) {
            if (*(code **)(iVar18 + 0x10) != (code *)0x0) {
              (**(code **)(iVar18 + 0x10))
                        (*(undefined1 *)(iVar18 + 0x19),*(undefined1 *)(iVar18 + 0x1b));
            }
            *(undefined1 *)(iVar18 + 0x1b) = 0xff;
            *(undefined2 *)(iVar18 + 0x18) = 0xffff;
          }
          FUN_60129ec8(*(undefined1 *)(iVar18 + 0x25),*(undefined1 *)(iVar18 + 0x26),
                       *(undefined1 *)(iVar18 + 0x28),*(undefined1 *)(iVar18 + 0x29));
          FUN_600fcf04(iVar18);
          pbVar1 = pbVar1 + iVar9 * 4 + 0x24;
          pbVar1[0] = 0;
          pbVar1[1] = 0;
          pbVar1[2] = 0;
          pbVar1[3] = 0;
        }
      }
      return;
    }
    piVar15 = *(int **)(_DAT_60009a64 + uVar17 * 4 + 4);
    if ((piVar15 != (int *)0x0) && (*(byte *)((int)piVar15 + 0x1a) == param_1)) {
      if (*piVar15 != 0) {
        iVar9 = thunk_FUN_6016717c();
        piVar15[8] = iVar9;
        uVar10 = uVar17 - 4;
        do {
          FUN_60011ea0(uVar17,&local_38);
          iVar9 = local_38;
          if (((local_38 != 0) && (iVar18 = *(int *)(pbVar1 + uVar17 * 4 + 4), iVar18 != 0)) &&
             (uVar13 = (uint)*(ushort *)(local_38 + 8), uVar13 != 0)) {
            pcVar16 = (char *)(iVar18 + 0x24);
            while (uVar14 = (uint)*(byte *)(iVar18 + 0x45), uVar14 != 0x14) {
              if (uVar14 == 0) {
                uVar11 = thunk_FUN_6016717c();
                *(undefined4 *)(iVar18 + 0x20) = uVar11;
                FUN_6016507e(*(undefined4 *)(iVar18 + 0x14),2000,iVar18);
                if (0x13 < *(ushort *)(iVar9 + 8)) {
                  CopyBytes(pcVar16,*(undefined4 *)(iVar9 + 0xc),0x14);
                  *(int *)(iVar9 + 0xc) = *(int *)(iVar9 + 0xc) + 0x14;
                  sVar8 = *(short *)(iVar9 + 8) + -0x14;
LAB_6000957a:
                  *(short *)(iVar9 + 8) = sVar8;
                  *(undefined1 *)(iVar18 + 0x45) = 0x14;
                  if (*(char *)(iVar18 + 0x24) == '\x01') {
                    *(ushort *)(iVar18 + 0x3c) =
                         (ushort)(((uint)*(ushort *)(iVar18 + 0x2b) << 0x18) >> 0x10) |
                         *(ushort *)(iVar18 + 0x2b) >> 8;
                  }
                  break;
                }
                CopyBytes(pcVar16,*(undefined4 *)(iVar9 + 0xc));
                cVar7 = *(char *)(iVar9 + 8);
                *(undefined2 *)(iVar9 + 8) = 0;
LAB_60009982:
                *(char *)(iVar18 + 0x45) = cVar7;
                goto LAB_600099ca;
              }
              if (uVar14 < 0x14) {
                if (uVar14 + uVar13 < 0x14) {
                  CopyBytes(iVar18 + uVar14 + 0x24,*(undefined4 *)(iVar9 + 0xc));
                  cVar7 = *(char *)(iVar9 + 8);
                  *(undefined2 *)(iVar9 + 8) = 0;
                  cVar7 = cVar7 + *(char *)(iVar18 + 0x45);
                  goto LAB_60009982;
                }
                uVar13 = 0x14 - uVar14;
                CopyBytes(pcVar16 + uVar14,*(undefined4 *)(iVar9 + 0xc),uVar13 & 0xffff);
                *(uint *)(iVar9 + 0xc) = *(int *)(iVar9 + 0xc) + (uVar13 & 0xffff);
                sVar8 = *(short *)(iVar9 + 8) - (short)uVar13;
                goto LAB_6000957a;
              }
LAB_60009902:
              uVar13 = (uint)*(ushort *)(iVar9 + 8);
              if (uVar13 == 0) goto LAB_600099ca;
            }
            if (*(short *)(iVar18 + 0x3e) == 0) {
              bVar2 = *(byte *)(iVar18 + 0x37);
              uVar13 = FUN_60160db4(pcVar16,0x13);
              if (bVar2 != uVar13) goto LAB_6000994e;
              *(undefined1 *)(iVar18 + 0x19) = *(undefined1 *)(iVar18 + 0x25);
              *(undefined1 *)(iVar18 + 0x1b) = *(undefined1 *)(iVar18 + 0x28);
            }
            if (*(ushort *)(iVar18 + 0x3c) < 0x2000) {
              cVar7 = *(char *)(iVar18 + 0x27);
              if (cVar7 == -0x56) {
                if (*(int *)(iVar18 + 8) == 0) goto LAB_60009902;
                if (*(char *)(iVar18 + 0x47) != '\0') {
                  uVar13 = (uint)*(byte *)(iVar18 + 0x44);
                  if (uVar13 == 4) {
LAB_60009794:
                    iVar12 = FUN_60011dec(iVar18,iVar9,1);
                    if (iVar12 != 0) {
                      local_30 = (code *)(uint)*(ushort *)(iVar18 + 0x3c);
                      local_2c = *(undefined4 *)(iVar18 + 0x38);
                      iVar12 = (**(code **)(iVar18 + 8))
                                         (*(undefined1 *)(iVar18 + 0x19),
                                          *(undefined1 *)(iVar18 + 0x1b),&local_30,
                                          *(undefined4 *)(iVar9 + 0xc));
                      if (iVar12 != 0) goto LAB_60009800;
                    }
                  }
                  else if (*(ushort *)(iVar9 + 8) + uVar13 < 4) {
                    if (*(ushort *)(iVar9 + 8) != 0) {
                      CopyBytes(iVar18 + uVar13 + 0x40,*(undefined4 *)(iVar9 + 0xc));
                      cVar7 = *(char *)(iVar9 + 8) + *(char *)(iVar18 + 0x44);
LAB_600099be:
                      *(char *)(iVar18 + 0x44) = cVar7;
                      *(undefined2 *)(iVar9 + 8) = 0;
                    }
                  }
                  else {
                    uVar14 = 4 - uVar13;
                    CopyBytes(iVar18 + uVar13 + 0x40,*(undefined4 *)(iVar9 + 0xc),uVar14 & 0xffff);
                    uVar4 = *(ushort *)(iVar18 + 0x42);
                    *(undefined1 *)(iVar18 + 0x44) = 4;
                    *(uint *)(iVar9 + 0xc) = *(int *)(iVar9 + 0xc) + (uVar14 & 0xffff);
                    uVar14 = *(ushort *)(iVar9 + 8) - uVar14;
LAB_60009780:
                    *(short *)(iVar9 + 8) = (short)uVar14;
                    *(ushort *)(iVar18 + 0x3c) =
                         (ushort)(((uint)uVar4 << 0x18) >> 0x10) | uVar4 >> 8;
                    if ((uVar14 & 0xffff) != 0) goto LAB_60009794;
                  }
LAB_600099c6:
                  *(undefined2 *)(iVar9 + 8) = 0;
                  goto LAB_600099ca;
                }
                uVar6 = FUN_60160db4(pcVar16,0x13);
                *(undefined1 *)(iVar18 + 0x47) = uVar6;
                bVar2 = *(byte *)(iVar18 + 0x37);
                uVar13 = FUN_60160db4(pcVar16,0x13);
                if (bVar2 == uVar13) {
                  *(undefined1 *)(iVar18 + 0x18) = 0xaa;
                  if (*(char *)(iVar18 + 0x28) == '\x03') {
                    if (3 < *(ushort *)(iVar9 + 8)) {
                      *(undefined1 *)(iVar18 + 0x44) = 4;
                      uVar4 = *(ushort *)(*(int *)(iVar9 + 0xc) + 2);
                      *(int *)(iVar9 + 0xc) = *(int *)(iVar9 + 0xc) + 4;
                      uVar14 = *(ushort *)(iVar9 + 8) - 4;
                      goto LAB_60009780;
                    }
                    if (*(ushort *)(iVar9 + 8) != 0) {
                      CopyBytes(iVar18 + 0x40,*(undefined4 *)(iVar9 + 0xc));
                      cVar7 = *(char *)(iVar9 + 8);
                      goto LAB_600099be;
                    }
                  }
                  else {
                    *(undefined1 *)(iVar18 + 0x44) = 4;
                    if (*(short *)(iVar9 + 8) != 0) goto LAB_60009794;
                  }
                  goto LAB_600099c6;
                }
                FUN_60129ec8(*(undefined1 *)(iVar18 + 0x25),*(undefined1 *)(iVar18 + 0x26),
                             *(undefined1 *)(iVar18 + 0x28),*(undefined1 *)(iVar18 + 0x29));
LAB_60009800:
                *(undefined1 *)(iVar18 + 0x47) = 0;
                *(undefined1 *)(iVar18 + 0x1b) = 0xff;
                *(undefined2 *)(iVar18 + 0x18) = 0xffff;
                *(undefined2 *)(iVar9 + 8) = 0;
              }
              else {
                if (*pcVar16 != '\x01') {
                  local_34 = (code *)0x0;
                  local_30 = (code *)0x0;
                  iVar12 = FUN_6013d6ca(*(undefined4 *)(iVar18 + 0x14));
                  if (iVar12 == 0) {
                    FUN_60163840(*(undefined4 *)(iVar18 + 0x14));
                  }
                  bVar2 = *(byte *)(iVar18 + 0x37);
                  uVar13 = FUN_60160db4(pcVar16,0x13);
                  uVar14 = (uint)*(byte *)(iVar18 + 0x25);
                  if (bVar2 == uVar13) {
                    if (*(char *)(iVar18 + 0x1a) == '\0') {
                      switch(uVar14) {
                      case 0x65:
                        uVar6 = 0x65;
                        break;
                      default:
                        goto switchD_6000981e_caseD_66;
                      case 0x69:
                        uVar6 = 0x69;
                        break;
                      case 0x6b:
                        FUN_60011f64(0x6b,&local_34);
                        if ((3 < uVar17) && (local_34 != (code *)0x0)) {
                          (*local_34)(pcVar16,uVar10 & 0xff);
                        }
                      case 0x6e:
                        uVar6 = *(undefined1 *)(iVar18 + 0x25);
                      }
                      FUN_60011f64(uVar6,&local_34);
                      if ((3 < uVar17) && (local_34 != (code *)0x0)) {
                        (*local_34)(pcVar16,uVar10 & 0xff);
                      }
                    }
                    else if ((((uVar14 < 0x20) && ((1 << uVar14 & DAT_600099a8) != 0)) ||
                             (uVar14 == 0x6e)) &&
                            (FUN_6001327c(uVar14,&local_30), local_30 != (code *)0x0)) {
                      (*local_30)(pcVar16);
                    }
                  }
                  else if (*(char *)(iVar18 + 0x1a) == '\0') {
                    FUN_60011f24(uVar14,*(undefined1 *)(iVar18 + 0x26),
                                 *(undefined1 *)(iVar18 + 0x28),*(undefined1 *)(iVar18 + 0x29));
                  }
                  else {
                    FUN_60129ec8();
                  }
switchD_6000981e_caseD_66:
                  FUN_600fcf04(iVar18);
                  *(undefined1 *)(iVar18 + 0x1b) = 0xff;
                  *(undefined1 *)(iVar18 + 0x19) = 0xff;
                  goto LAB_60009902;
                }
                iVar12 = FUN_60011dec(iVar18,iVar9,0);
                if (iVar12 == 0) goto LAB_60009902;
                local_34 = (code *)0x0;
                local_30 = (code *)0x0;
                iVar12 = FUN_6013d6ca(*(undefined4 *)(iVar18 + 0x14));
                if (iVar12 == 0) {
                  FUN_60163840(*(undefined4 *)(iVar18 + 0x14));
                }
                bVar2 = *(byte *)(iVar18 + 0x2d);
                uVar13 = FUN_6015f2e8(*(undefined4 *)(iVar18 + 0x38),*(undefined2 *)(iVar18 + 0x3c))
                ;
                pbVar5 = _DAT_60009a64;
                if (bVar2 == uVar13) {
                  cVar3 = *(char *)(iVar18 + 0x1a);
                  uVar13 = (uint)*(byte *)(iVar18 + 0x25);
                  bVar2 = *(byte *)(iVar18 + 0x28);
                  *_DAT_60009a64 = *(byte *)(iVar18 + 0x25);
                  pbVar5[1] = bVar2;
                  if (cVar3 == '\0') {
                    if (uVar13 == 0x6e) {
                      uVar11 = 0x6e;
                    }
                    else if (uVar13 == 0x6b) {
                      uVar11 = 0x6b;
                    }
                    else {
                      if (uVar13 != 0x69) goto LAB_600098e2;
                      uVar11 = 0x69;
                    }
                    FUN_60011f34(uVar11,&local_34);
                    if ((3 < uVar17) && (local_34 != (code *)0x0)) {
                      (*local_34)(*(undefined4 *)(iVar18 + 0x38),*(undefined2 *)(iVar18 + 0x3c),
                                  *(undefined1 *)(iVar18 + 0x2e),uVar10 & 0xff);
                    }
                  }
                  else if ((((uVar13 < 0x20) && ((1 << uVar13 & DAT_600099a4) != 0)) ||
                           (uVar13 == 0x6e)) &&
                          (FUN_60018448(uVar13,&local_30), local_30 != (code *)0x0)) {
                    (*local_30)(*(undefined4 *)(iVar18 + 0x38),*(undefined2 *)(iVar18 + 0x3c),
                                *(undefined1 *)(iVar18 + 0x2e));
                  }
LAB_600098e2:
                  pbVar5 = _DAT_60009a64;
                  pbVar5[0] = 0;
                  pbVar5[1] = 0;
                }
                else if (*(char *)(iVar18 + 0x1a) == '\0') {
                  FUN_60011f24(*(undefined1 *)(iVar18 + 0x25),*(undefined1 *)(iVar18 + 0x26),
                               *(undefined1 *)(iVar18 + 0x28),*(undefined1 *)(iVar18 + 0x29));
                }
                else {
                  FUN_60129ec8();
                }
                if (cVar7 == 'U') {
                  *(undefined1 *)(iVar18 + 0x18) = 0x55;
                }
                else {
                  *(undefined1 *)(iVar18 + 0x1b) = 0xff;
                  *(undefined1 *)(iVar18 + 0x19) = 0xff;
                }
              }
              FUN_600fcf04(iVar18);
              goto LAB_60009902;
            }
            FUN_60168578("except_length error:except: %d\n");
            FUN_60168578("header_buffer: ");
            for (iVar12 = 0x24; iVar12 != 0x38; iVar12 = iVar12 + 1) {
              FUN_60168578("%02X ",*(undefined1 *)(iVar18 + iVar12));
            }
            FUN_60168578(&DAT_60009aa0);
            FUN_6002688c("except_length error",pcVar16,0x14);
LAB_6000994e:
            FUN_600fcf04(iVar18);
LAB_600099ca:
            FUN_60119c50(iVar9);
          }
        } while (*piVar15 != 0);
        if (param_1 != 0) {
          FUN_6015b9fc(DAT_60009ab8,0,0);
        }
      }
      if (((char)piVar15[6] == 'U') &&
         (iVar9 = (*(code *)piVar15[3])
                            (*(undefined1 *)((int)piVar15 + 0x19),
                             *(undefined1 *)((int)piVar15 + 0x1b)), iVar9 != 0)) {
        *(undefined1 *)((int)piVar15 + 0x1b) = 0xff;
        *(undefined2 *)(piVar15 + 6) = 0xffff;
      }
    }
    uVar17 = uVar17 + 1;
  } while( true );
}

