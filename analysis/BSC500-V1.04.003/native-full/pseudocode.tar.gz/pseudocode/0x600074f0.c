
void FUN_600074f0(uint param_1,uint param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint unaff_r6;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  bool bVar8;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 local_30;
  int local_2c;
  int local_28;
  
  local_2c = 0;
  local_28 = 0;
  bVar8 = (param_2 & param_1) != param_1;
  if (bVar8) {
    unaff_r6 = param_2;
  }
  if ((bVar8 && (param_2 & 0x40000000) != 0) &&
     (iVar2 = FUN_601169e8(param_1,&local_28), piVar1 = DAT_60007684, iVar2 != 0)) {
    uVar6 = 0;
    for (uVar4 = unaff_r6 & 0xbfffffff; uVar4 != 0; uVar4 = uVar4 >> 1) {
      if ((uVar4 & 1) != 0) {
        uVar7 = 1 << (uVar6 & 0xff);
        uVar5 = uVar7 | 0x40000000;
        iVar2 = FUN_601169e8(uVar5,&local_2c);
        if (iVar2 != 0) {
          iVar2 = *piVar1;
          if (iVar2 == 0) {
            local_30 = 0;
            local_38 = 1;
            uStack_34 = 0;
            local_3c = DAT_60007688;
            iVar2 = FUN_60168494(&local_3c);
            *piVar1 = iVar2;
          }
          FUN_6016825e(iVar2,0xffffffff);
          if ((*(uint *)(local_2c + 0x1c) & param_1 & 0xbfffffff) != param_1) {
            uVar3 = *(uint *)(local_2c + 0x24);
            if (param_3 == 0) {
              if (((uVar3 & param_1) == param_1) && (*(short *)(local_2c + 0x22) != 0)) {
                *(short *)(local_2c + 0x22) = *(short *)(local_2c + 0x22) + -1;
                *(uint *)(local_2c + 0x24) = uVar3 & (param_1 ^ 0xbfffffff) | 0x40000000;
                *(uint *)(local_28 + 0x1c) = *(uint *)(local_28 + 0x1c) & ~uVar7 | 0x40000000;
              }
            }
            else if ((uVar3 & param_1) != param_1) {
              *(uint *)(local_2c + 0x24) = uVar3 | param_1;
              *(uint *)(local_28 + 0x1c) = *(uint *)(local_28 + 0x1c) | uVar5;
              *(short *)(local_2c + 0x22) = *(short *)(local_2c + 0x22) + 1;
            }
          }
          if (*piVar1 != 0) {
            FUN_601682ae();
          }
        }
      }
      uVar6 = uVar6 + 1;
    }
  }
  return;
}

