
bool FUN_60003b40(void)

{
  int iVar1;
  undefined4 uVar2;
  char *local_34;
  undefined1 auStack_30 [16];
  undefined4 local_20;
  undefined4 local_1c;
  
  ZeroBytes(auStack_30,0x20);
  local_1c = 0x10;
  local_34 = "sys_low_priority_task";
  local_20 = 0x1000;
  FUN_60003bdc();
  uVar2 = FUN_6011e4a8(0x14,4,0);
  iVar1 = DAT_60003c00;
  *(undefined4 *)(DAT_60003c00 + 8) = uVar2;
  uVar2 = FUN_601566b4(DAT_60003ba4,0,&local_34);
  *(undefined4 *)(iVar1 + 4) = uVar2;
  FUN_60156808();
  return *(int *)(iVar1 + 4) != 0;
}

