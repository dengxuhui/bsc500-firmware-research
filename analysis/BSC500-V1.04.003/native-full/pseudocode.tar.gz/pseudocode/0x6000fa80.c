
bool FUN_6000fa80(void)

{
  return *DAT_6000fa90 == '\x01';
}

