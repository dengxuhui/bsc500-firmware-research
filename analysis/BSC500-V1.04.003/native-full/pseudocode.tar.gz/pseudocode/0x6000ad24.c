
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000ad24(int *param_1)

{
  if (param_1 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x6000ad30. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*param_1 + 8))();
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c(_DAT_6000ad3c,"erpc_server_run",0x9b);
}

