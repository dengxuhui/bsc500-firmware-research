
void FUN_60011edc(int param_1)

{
  if (param_1 != 0) {
    FUN_60119c50();
    return;
  }
  return;
}

