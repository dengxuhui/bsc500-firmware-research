
undefined4 FUN_60004e7c(void)

{
  undefined1 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 auStack_54 [64];
  undefined4 local_14;
  
  uVar3 = 0;
  local_14 = 0;
  FUN_601681f4(auStack_54,"%scheckfw",DAT_60004f00);
  iVar2 = FUN_60166758(&local_14,auStack_54,1);
  puVar1 = DAT_60004f08;
  if (iVar2 == 0) {
    *DAT_60004f08 = 0;
    FUN_601667bc(local_14);
    FUN_601681f4(auStack_54,DAT_60004f0c,DAT_60004f00,DAT_60004f10);
    iVar2 = FUN_60166758(&local_14,auStack_54,1);
    if (iVar2 == 0) {
      uVar3 = FUN_6016506c(local_14);
      *(undefined4 *)(puVar1 + 4) = uVar3;
      FUN_601667bc(local_14);
      uVar3 = 0;
      if (0x100000 < *(uint *)(puVar1 + 4)) {
        *(undefined2 *)(puVar1 + 1) = 0x101;
        uVar3 = 1;
      }
    }
  }
  else {
    *DAT_60004f04 = 0;
    *DAT_60004f08 = 1;
  }
  return uVar3;
}

