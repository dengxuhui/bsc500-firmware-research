
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000fb80(void)

{
  FUN_60161424("ble_deal:%d, %d\n",*_DAT_6000fb8c,_DAT_6000fb8c[1]);
  return;
}

