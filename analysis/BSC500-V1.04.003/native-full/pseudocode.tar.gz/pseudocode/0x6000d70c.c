
undefined4 FUN_6000d70c(int param_1,int param_2)

{
  undefined4 uVar1;
  
  uVar1 = 0xfffffffc;
  if ((param_1 != 0) && (param_2 - 1U < 0x38)) {
    *(char *)(param_1 + 0xa1) = (char)param_2;
    FUN_6013fdb8(param_1 + 4,2,&stack0xfffffff7);
    uVar1 = 0;
  }
  return uVar1;
}

