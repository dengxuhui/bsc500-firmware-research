
int * FUN_60016ddc(int param_1,int param_2,int param_3,int param_4,int param_5,int param_6)

{
  uint uVar1;
  int iVar2;
  int *piVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  
  uVar5 = param_2 + 3U & 0xfffffffc;
  uVar1 = param_1 + 3U & 0xfffffffc;
  if (param_3 == 0) {
    iVar2 = FUN_6015c074(uVar1,uVar5 - uVar1);
  }
  else {
    iVar2 = FUN_6001ed84(uVar1,uVar5,param_4,param_5);
  }
  if (iVar2 == 0) {
    piVar6 = (int *)0x0;
  }
  else {
    piVar3 = (int *)FUN_6015bb22(iVar2,param_3,0x24);
    iVar4 = FUN_6015bb22(iVar2,param_3,0x800);
    piVar6 = (int *)0x0;
    if ((piVar3 != (int *)0x0) && (iVar4 != 0)) {
      *piVar3 = iVar4;
      piVar3[1] = 0x100;
      for (iVar7 = 0; iVar7 != 0x800; iVar7 = iVar7 + 8) {
        iVar8 = iVar4 + iVar7;
        *(int *)(iVar4 + iVar7) = iVar8;
        *(int *)(iVar8 + 4) = iVar8;
      }
      *(char *)(piVar3 + 2) = (char)param_3;
      piVar3[3] = iVar2;
      piVar3[4] = (int)(piVar3 + 4);
      piVar3[5] = (int)(piVar3 + 4);
      piVar3[6] = param_4;
      piVar3[7] = param_5;
      piVar3[8] = param_6;
      piVar6 = piVar3;
    }
  }
  return piVar6;
}

