
int FUN_600168ac(void)

{
  return DAT_600168b4 + 0xc;
}

