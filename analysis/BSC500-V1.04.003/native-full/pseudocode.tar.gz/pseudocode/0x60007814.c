
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60007814(short *param_1)

{
  short sVar1;
  char cVar2;
  undefined4 *puVar3;
  code *pcVar4;
  undefined1 uVar5;
  char *pcVar6;
  int iVar7;
  undefined4 uVar8;
  char cVar9;
  uint uVar10;
  char *pcVar11;
  int iVar12;
  int iVar13;
  uint uVar14;
  int iVar15;
  char *pcVar16;
  uint in_fpscr;
  float fVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  
  sVar1 = *param_1;
  if (sVar1 == -0x8000) {
    if (*(int *)(param_1 + 2) != 0) {
      return 0;
    }
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(&DAT_60007a54,DAT_60007a58,0x17b);
  }
  if (sVar1 == -0x7fff) {
    *(undefined1 *)(DAT_60007a50 + 1) = 0;
    return 0;
  }
  if (sVar1 != -0x7ff7) {
    return 0;
  }
  pcVar16 = *(char **)(param_1 + 2);
  if (pcVar16 == (char *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("arg->data",DAT_60007a58,0x15e);
  }
  if (*pcVar16 != '\x02') {
    if (*pcVar16 != '\0') {
      return 0;
    }
    uVar10 = (uint)*(ushort *)(pcVar16 + 4);
    pcVar6 = (char *)thunk_FUN_60162e34(uVar10 + 1);
    CopyBytes(pcVar6,pcVar16 + 6,uVar10);
    pcVar6[uVar10] = '\0';
    cVar9 = pcVar16[1];
    if (cVar9 == '\0') {
      FUN_60167370((int)DAT_60007a50 + 5,pcVar6);
    }
    else if (cVar9 == '\x02') {
      fVar17 = (float)FUN_6001b608(pcVar6,0);
      *(char *)((int)DAT_60007a50 + 0x72) = (char)(int)(fVar17 * 16.0);
      FUN_60138570(_DAT_60007a68);
    }
    else if (cVar9 == '\x01') {
      cVar9 = '\0';
      pcVar16 = pcVar6;
      do {
        while( true ) {
          pcVar11 = pcVar16 + 1;
          cVar2 = *pcVar16;
          if (cVar2 != ',') break;
          *pcVar16 = '\0';
          if (cVar9 == '\x01') goto LAB_600079b0;
          cVar9 = cVar9 + '\x01';
          pcVar16 = pcVar11;
        }
        pcVar16 = pcVar11;
      } while (cVar2 != '\0');
LAB_600079b0:
      puVar3 = DAT_60007a50;
      *(undefined1 *)(DAT_60007a50 + 0x1c) = 1;
      uVar5 = FUN_6016811c(pcVar6);
      *(undefined1 *)((int)puVar3 + 0x71) = uVar5;
      uVar8 = FUN_6016811c(pcVar11);
      uVar8 = VectorSignedToFloat(uVar8,(byte)(in_fpscr >> 0x16) & 3);
      uVar8 = VectorFloatToUnsigned(uVar8,3);
      puVar3[0x1b] = uVar8;
    }
    goto switchD_600078cc_default;
  }
  uVar14 = (uint)*(ushort *)(pcVar16 + 4);
  uVar10 = uVar14 + 1;
  pcVar6 = (char *)thunk_FUN_60162e34(uVar10);
  CopyBytes(pcVar6,pcVar16 + 6,uVar14);
  pcVar6[uVar14] = '\0';
  iVar7 = DAT_60007a5c;
  puVar3 = DAT_60007a50;
  switch(pcVar16[1]) {
  case '\0':
    if (0x17 < uVar14) {
      uVar10 = 0x18;
    }
    uVar10 = uVar10 & 0xffff;
    iVar12 = DAT_60007a5c + 0x19;
    uVar8 = DAT_60007a60;
    pcVar16 = pcVar6;
    goto LAB_6000795e;
  case '\x01':
    if (uVar14 < 0x18) {
      if (uVar14 == 0) break;
      uVar10 = uVar10 & 0xffff;
    }
    else {
      uVar10 = 0x18;
    }
    iVar13 = DAT_60007a5c + 0x49;
    FUN_60164dec(iVar13,uVar10,DAT_60007a60,pcVar6);
    puVar3 = DAT_60007a50;
    iVar15 = (int)DAT_60007a50 + 0x4d;
    iVar12 = FUN_6016727c(iVar15,pcVar6,uVar10);
    pcVar4 = DAT_60007a64;
    uVar8 = DAT_60007a60;
    if (iVar12 != 0) {
      (*DAT_60007a64)((int)puVar3 + 0x35,0x18,DAT_60007a60,iVar7 + 0x31);
      (*pcVar4)((int)puVar3 + 0x1d,0x18,uVar8,iVar7 + 0x19);
      (*pcVar4)(iVar15,0x18,uVar8,iVar13);
      *(undefined1 *)(puVar3 + 0x1d) = 1;
    }
    break;
  case '\x02':
    if (0x17 < uVar14) {
      uVar10 = 0x18;
    }
    iVar12 = DAT_60007a5c + 0x31;
    FUN_60164dec(iVar12,uVar10 & 0xffff,DAT_60007a60,pcVar6);
    uVar8 = DAT_60007a60;
    puVar3 = DAT_60007a50;
    if (*(char *)((int)DAT_60007a50 + 0x75) != '\0') break;
    *(undefined1 *)((int)DAT_60007a50 + 0x75) = 1;
    FUN_60164dec((int)puVar3 + 0x35,0x18,uVar8,iVar12);
    iVar12 = (int)puVar3 + 0x1d;
    uVar10 = 0x18;
    pcVar16 = (char *)(iVar7 + 0x19);
LAB_6000795e:
    FUN_60164dec(iVar12,uVar10,uVar8,pcVar16);
    break;
  case '\x03':
    uVar19 = FUN_60166bb4(*DAT_60007a50);
    uVar18 = FUN_60167338(pcVar6);
    iVar7 = FUN_60167b7e((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                         (int)((ulonglong)uVar19 >> 0x20));
    if (iVar7 == 0) {
      *(undefined2 *)(puVar3 + 0x1d) = 1;
    }
    uVar18 = FUN_60167338(pcVar6);
    uVar8 = FUN_601672d4((int)uVar18,(int)((ulonglong)uVar18 >> 0x20));
    *puVar3 = uVar8;
    uVar8 = VectorFloatToUnsigned(uVar8,3);
    puVar3[0x1a] = uVar8;
  }
switchD_600078cc_default:
  thunk_FUN_60166c0c(pcVar6);
  return 0;
}

