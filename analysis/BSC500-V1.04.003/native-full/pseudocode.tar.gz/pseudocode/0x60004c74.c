
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60004c74(int *param_1,int param_2)

{
  code *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  int *piVar4;
  
  pcVar1 = DAT_60004cdc;
  if (param_1 == (int *)0x0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("transport != 0",_DAT_60004d04,0x25);
  }
  if (param_2 != 0) {
    piVar2 = (int *)(*DAT_60004cdc)(4);
    *piVar2 = _DAT_60004ce0 + 8;
    uVar3 = (*pcVar1)(4);
    FUN_600f5a7c();
    piVar4 = (int *)(*pcVar1)(0x20);
    ZeroBytes(piVar4 + 1,0x18);
    *(undefined1 *)(piVar4 + 7) = 1;
    *piVar4 = s_x___x__message_buffer_factory____60004ce1._3_4_ + 8;
    (**(code **)(*param_1 + 0x14))(param_1,uVar3);
    piVar4[3] = param_2;
    piVar4[4] = (int)piVar2;
    piVar4[5] = (int)param_1;
    return piVar4;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("message_buffer_factory != 0",_DAT_60004d04,0x26);
}

