
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60011d78(int param_1)

{
  char *pcVar1;
  int iVar2;
  
  pcVar1 = _DAT_60011da8;
  if (*_DAT_60011da8 == '\x01') {
    iVar2 = FUN_6015eff4();
    if (3000 < (uint)(**(int **)(iVar2 + 4) - *(int *)(pcVar1 + 4))) {
      *(undefined1 *)(param_1 + 2) = 0;
      FUN_60168578("[BLE_HRM_TIMEOUT] No data for %u ms, set heart_rate to 0xff\r\n");
      return;
    }
  }
  return;
}

