
void FUN_60010720(int param_1,int param_2,int param_3,int *param_4,int *param_5)

{
  int iVar1;
  
  if (*(int *)(param_1 + 0xc) == 0) {
    iVar1 = *DAT_60010748;
  }
  else {
    iVar1 = FUN_60164d88();
    *DAT_60010748 = iVar1;
  }
  *param_4 = iVar1 + param_2;
  *param_5 = iVar1 + param_3;
  return;
}

