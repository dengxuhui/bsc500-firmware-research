
undefined4 FUN_600143c8(int param_1,int param_2)

{
  uint uVar1;
  undefined1 uVar2;
  byte bVar3;
  undefined8 *puVar4;
  int iVar5;
  undefined2 uVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  ushort uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  uint in_fpscr;
  uint uVar13;
  undefined4 uVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  
  puVar4 = DAT_60014a24;
  if (*DAT_60014a20 == '\x02') {
    uVar7 = 0xffffffff;
    if ((param_1 != 0) && (param_2 != 0)) {
      FUN_60136728(DAT_60014a24);
      iVar8 = FUN_60166dd0();
      if ((iVar8 != 1) && (iVar8 = FUN_60166dd0(param_1 + 0xbc), iVar8 != 1)) {
        uVar11 = *(undefined4 *)(param_1 + 0xc0);
        uVar7 = *(undefined4 *)(param_1 + 0xb4);
        uVar12 = *(undefined4 *)(param_1 + 0xb8);
        uVar22 = FUN_6016759c(*(undefined4 *)(param_1 + 0xbc));
        uVar23 = FUN_6016759c(uVar11);
        uVar22 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                              (int)((ulonglong)uVar23 >> 0x20));
        *puVar4 = uVar22;
        uVar22 = FUN_6016759c(uVar7);
        uVar23 = FUN_6016759c(uVar12);
        uVar22 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                              (int)((ulonglong)uVar23 >> 0x20));
        puVar4[1] = uVar22;
      }
      iVar8 = DAT_60014a28;
      *(undefined1 *)(puVar4 + 2) = 1;
      FUN_6010f996(iVar8,puVar4);
      iVar5 = DAT_60014a2c;
      FUN_6010f966(iVar8,DAT_60014a2c);
      iVar9 = FUN_60123188(iVar5 + 0x20);
      uVar22 = DAT_60014498;
      uVar7 = DAT_60014490;
      if (iVar9 == 1) {
        uVar23 = *(undefined8 *)(iVar5 + 0x20);
        *(undefined4 *)(param_2 + 0xa4) = DAT_60014490;
        *(undefined4 *)(param_2 + 0xac) = uVar7;
        uVar12 = (undefined4)((ulonglong)uVar22 >> 0x20);
        uVar14 = (undefined4)uVar22;
        FUN_601678fc((int)*(undefined8 *)(iVar5 + 0x28),
                     (int)((ulonglong)*(undefined8 *)(iVar5 + 0x28) >> 0x20),uVar14,uVar12);
        uVar11 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0xa0) = uVar11;
        FUN_601678fc((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),uVar14,uVar12);
        uVar11 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0xa8) = uVar11;
      }
      iVar9 = FUN_60123188(iVar5 + 0x30);
      uVar22 = DAT_60014498;
      if (iVar9 == 1) {
        uVar23 = *(undefined8 *)(iVar5 + 0x30);
        *(undefined4 *)(param_2 + 0xb4) = uVar7;
        *(undefined4 *)(param_2 + 0xbc) = uVar7;
        uVar11 = (undefined4)((ulonglong)uVar22 >> 0x20);
        uVar12 = (undefined4)uVar22;
        FUN_601678fc((int)*(undefined8 *)(iVar5 + 0x38),
                     (int)((ulonglong)*(undefined8 *)(iVar5 + 0x38) >> 0x20),uVar12,uVar11);
        uVar7 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0xb0) = uVar7;
        FUN_601678fc((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),uVar12,uVar11);
        uVar7 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0xb8) = uVar7;
      }
      *(undefined4 *)((int)puVar4 + 0x7c) = *(undefined4 *)(param_1 + 4);
      FUN_6010fa56(iVar8 + 500,(undefined4 *)((int)puVar4 + 0x7c));
      FUN_6010fa48(iVar8 + 500,iVar5 + 0x118);
      *(undefined4 *)(param_2 + 0x98) = *(undefined4 *)(param_1 + 4);
      *(undefined4 *)(param_2 + 0x9c) = *(undefined4 *)(iVar5 + 0x118);
      FUN_60136728(puVar4 + 3);
      iVar9 = FUN_60166dd0(param_1 + 0xb4);
      if ((iVar9 != 1) && (iVar9 = FUN_60166dd0(param_1 + 0xbc), iVar9 != 1)) {
        uVar7 = *(undefined4 *)(param_1 + 0xb4);
        uVar11 = *(undefined4 *)(param_1 + 0xb8);
        uVar12 = *(undefined4 *)(param_1 + 0xc0);
        uVar22 = FUN_6016759c(*(undefined4 *)(param_1 + 0xbc));
        uVar23 = FUN_6016759c(uVar12);
        uVar22 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                              (int)((ulonglong)uVar23 >> 0x20));
        puVar4[3] = uVar22;
        uVar22 = FUN_6016759c(uVar7);
        uVar23 = FUN_6016759c(uVar11);
        uVar22 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                              (int)((ulonglong)uVar23 >> 0x20));
        puVar4[4] = uVar22;
      }
      *(undefined1 *)(puVar4 + 5) = 1;
      *(undefined4 *)((int)puVar4 + 0x2c) = *(undefined4 *)(param_1 + 4);
      *(undefined2 *)(puVar4 + 6) = *(undefined2 *)(param_1 + 0xd0);
      *(undefined2 *)((int)puVar4 + 0x32) = *(undefined2 *)(param_1 + 0x1c);
      FUN_60110c8c(iVar8 + 0x40,puVar4 + 3);
      FUN_60110c78(iVar8 + 0x40,iVar5 + 0x40);
      fVar16 = DAT_600144a4;
      fVar18 = DAT_600144a0;
      fVar17 = *(float *)(iVar5 + 0x44);
      fVar15 = *(float *)(iVar5 + 0x40) * DAT_600144a0;
      *(int *)(param_2 + 0xc4) = *(int *)(iVar5 + 0x48) * 1000;
      uVar7 = VectorFloatToUnsigned(fVar15,3);
      *(undefined4 *)(param_2 + 0xc0) = uVar7;
      *(short *)(param_2 + 0xcc) = (short)(int)(fVar17 * fVar16);
      fVar15 = DAT_60014a30;
      if (*(int *)(param_1 + 0x9c) != 0x7fffffff) {
        fVar15 = (float)VectorSignedToFloat(*(int *)(param_1 + 0x9c),(byte)(in_fpscr >> 0x16) & 3);
        fVar15 = fVar15 / fVar18;
      }
      *(float *)(puVar4 + 7) = fVar15;
      FUN_6010fb00(iVar8 + 0x88,puVar4 + 7);
      FUN_6010faec(iVar8 + 0x88,iVar5 + 0x4c);
      fVar15 = *(float *)(iVar5 + 0x4c);
      uVar2 = *(undefined1 *)(param_1 + 0x91);
      fVar17 = *(float *)(iVar5 + 0x50);
      fVar19 = *(float *)(iVar5 + 0x54);
      *(undefined1 *)(puVar4 + 8) = *(undefined1 *)(param_1 + 0xd9);
      *(undefined1 *)((int)puVar4 + 0x41) = uVar2;
      *(int *)(param_2 + 0xf8) = (int)(fVar15 * fVar18);
      *(int *)(param_2 + 0xdc) = (int)(fVar17 * fVar18);
      *(int *)(param_2 + 0xe0) = (int)(fVar19 * fVar18);
      *(uint *)((int)puVar4 + 0x3c) = *(uint *)(param_2 + 0xc4) / 1000;
      FUN_60110ee0(iVar8 + 0xa0,(uint *)((int)puVar4 + 0x3c));
      FUN_60110eae(iVar8 + 0xa0,iVar5 + 0x58);
      *(undefined2 *)(param_2 + 0xfe) = *(undefined2 *)(iVar5 + 0x7c);
      *(undefined4 *)((int)puVar4 + 0x44) = *(undefined4 *)(param_2 + 0x2c8);
      FUN_601111ce(iVar8 + 0xe0,(undefined4 *)((int)puVar4 + 0x44));
      FUN_601111c4(iVar8 + 0xe0,iVar5 + 0x80);
      fVar15 = *(float *)(iVar5 + 0x80);
      uVar7 = *(undefined4 *)(param_2 + 0x2b4);
      uVar11 = *(undefined4 *)(param_2 + 700);
      uVar12 = *(undefined4 *)(param_2 + 0x2c0);
      *(undefined4 *)((int)puVar4 + 0x4c) = *(undefined4 *)(param_2 + 0x2b8);
      *(undefined4 *)(puVar4 + 10) = uVar11;
      *(undefined4 *)((int)puVar4 + 0x54) = uVar12;
      *(short *)(param_2 + 0xca) = (short)(int)(fVar15 / fVar16);
      *(undefined4 *)(puVar4 + 9) = uVar7;
      FUN_601112bc(iVar8 + 0xe4,puVar4 + 9);
      FUN_60111298(iVar8 + 0xe4,iVar5 + 0x84);
      fVar15 = DAT_60014a34;
      fVar19 = *(float *)(iVar5 + 0x88);
      fVar20 = *(float *)(iVar5 + 0x8c);
      fVar21 = *(float *)(iVar5 + 0x90);
      fVar17 = *(float *)(iVar5 + 0x84) * DAT_60014a34;
      *(undefined1 *)((int)puVar4 + 0x5c) = *(undefined1 *)(param_1 + 0xd8);
      *(short *)(param_2 + 0xea) = (short)(int)fVar17;
      *(short *)(param_2 + 0xec) = (short)(int)(fVar19 * fVar15);
      *(short *)(param_2 + 0xe6) = (short)(int)(fVar20 * fVar15);
      *(short *)(param_2 + 0xe8) = (short)(int)(fVar21 * fVar15);
      *(uint *)(puVar4 + 0xb) = *(uint *)(param_2 + 0xc4) / 1000;
      FUN_60111506(iVar8 + 0x104,puVar4 + 0xb);
      FUN_601114ca(iVar8 + 0x104,iVar5 + 0xa4);
      *(undefined1 *)(param_2 + 0x102) = *(undefined1 *)(iVar5 + 200);
      *(undefined2 *)(param_2 + 0xfc) = *(undefined2 *)(iVar5 + 0xc9);
      *(undefined4 *)((int)puVar4 + 0x61) = *(undefined4 *)(param_1 + 0xf9);
      *(undefined1 *)(puVar4 + 0xc) = *(undefined1 *)(param_1 + 0xf8);
      FUN_6010fdca(iVar8 + 0x140,puVar4 + 0xc);
      FUN_6010fdbc(iVar8 + 0x140,iVar5 + 0xcc);
      fVar15 = *(float *)(iVar5 + 0xcc);
      uVar10 = 0xffff;
      uVar1 = in_fpscr & 0xfffffff | (uint)(fVar15 < 0.0) << 0x1f | (uint)(fVar15 == 0.0) << 0x1e;
      uVar13 = uVar1 | (uint)NAN(fVar15) << 0x1c;
      bVar3 = (byte)(uVar1 >> 0x18);
      if (!(bool)(bVar3 >> 6 & 1) && bVar3 >> 7 == ((byte)(uVar13 >> 0x1c) & 1)) {
        uVar10 = (ushort)(int)(fVar15 * fVar18) | 0x8000;
      }
      *(ushort *)(param_2 + 0xda) = uVar10;
      *(undefined4 *)(param_2 + 0x103) = *(undefined4 *)(iVar5 + 0xd0);
      *(uint *)(puVar4 + 0xd) = *(uint *)(param_2 + 0xc4) / 1000;
      *(undefined2 *)((int)puVar4 + 0x6e) = *(undefined2 *)(param_2 + 0x294);
      *(undefined2 *)((int)puVar4 + 0x6c) = *(undefined2 *)(param_1 + 0xd4);
      *(undefined1 *)(puVar4 + 0xe) = *(undefined1 *)(param_1 + 0x92);
      FUN_60111924(iVar8 + 0x170);
      FUN_601118e4(iVar8 + 0x170,iVar5 + 0xd4);
      fVar15 = *(float *)(iVar5 + 0xf8);
      uVar1 = uVar13 & 0xfffffff | (uint)(fVar15 < 0.0) << 0x1f;
      uVar13 = uVar1 | (uint)NAN(fVar15) << 0x1c;
      uVar6 = (undefined2)(int)fVar15;
      if ((byte)(uVar1 >> 0x1f) != ((byte)(uVar13 >> 0x1c) & 1)) {
        uVar6 = 0xffff;
      }
      *(undefined2 *)(param_2 + 0xd8) = uVar6;
      *(undefined4 *)(param_2 + 0xd0) = *(undefined4 *)(iVar5 + 0x104);
      fVar15 = DAT_60014a38;
      if (*(int *)(param_2 + 4) != -1) {
        fVar15 = (float)VectorUnsignedToFloat(*(int *)(param_2 + 4),(byte)(uVar13 >> 0x16) & 3);
        fVar15 = fVar15 / fVar16;
      }
      *(float *)((int)puVar4 + 0x74) = fVar15;
      FUN_60111c16(iVar8 + 0x1d8,(int)puVar4 + 0x74);
      FUN_60111c0c(iVar8 + 0x1d8,iVar5 + 0x108);
      fVar15 = (float)VectorSignedToFloat(*(undefined4 *)(param_1 + 0xa4),(byte)(uVar13 >> 0x16) & 3
                                         );
      *(float *)(puVar4 + 0xf) = fVar15 / 10.0;
      *(short *)(param_2 + 0xce) = (short)(int)(*(float *)(iVar5 + 0x108) * fVar16);
      FUN_60111c4c(iVar8 + 0x1dc,puVar4 + 0xf);
      FUN_60111c3a(iVar8 + 0x1dc,iVar5 + 0x10c);
      fVar15 = DAT_60014a3c;
      fVar17 = *(float *)(iVar5 + 0x114);
      *(char *)(param_2 + 0x100) = (char)(int)*(float *)(iVar5 + 0x110);
      *(char *)(param_2 + 0x101) = (char)(int)fVar17;
      fVar17 = (float)VectorSignedToFloat((int)*(short *)(param_2 + 0x28c),
                                          (byte)(uVar13 >> 0x16) & 3);
      *(float *)(puVar4 + 0x10) = (fVar17 * fVar15) / fVar16;
      FUN_6010feb2(iVar8 + 0x200,puVar4 + 0x10);
      FUN_6010fe98(iVar8 + 0x200,iVar5 + 0x120);
      uVar7 = *(undefined4 *)(param_2 + 0xc0);
      iVar9 = *(int *)(param_1 + 0x9c);
      *(undefined4 *)((int)puVar4 + 0x84) = *(undefined4 *)(param_1 + 4);
      fVar17 = (float)VectorUnsignedToFloat(uVar7,(byte)(uVar13 >> 0x16) & 3);
      fVar20 = *(float *)(iVar5 + 0x128);
      fVar19 = *(float *)(iVar5 + 0x124);
      fVar21 = *(float *)(iVar5 + 300);
      *(float *)(puVar4 + 0x11) = fVar17 / fVar18;
      fVar17 = *(float *)(iVar5 + 0x120);
      *(short *)(param_2 + 0xee) = (short)(int)((fVar20 * fVar16) / fVar15);
      *(short *)(param_2 + 0xf2) = (short)(int)((fVar17 * fVar16) / fVar15);
      *(short *)(param_2 + 0xf0) = (short)(int)((fVar21 * fVar16) / fVar15);
      *(short *)(param_2 + 0xf4) = (short)(int)((fVar19 * fVar16) / fVar15);
      fVar16 = DAT_60014a30;
      if (iVar9 != 0x7fffffff) {
        fVar16 = (float)VectorSignedToFloat(iVar9,(byte)(uVar13 >> 0x16) & 3);
        fVar16 = fVar16 / fVar18;
      }
      *(float *)((int)puVar4 + 0x8c) = fVar16;
      FUN_601125a4(iVar8 + 0x220,(int)puVar4 + 0x84);
      FUN_60112594(iVar8 + 0x220,iVar5 + 0x130);
      fVar18 = *(float *)(iVar5 + 0x134);
      *(short *)(param_2 + 0xd4) = (short)(int)*(float *)(iVar5 + 0x130);
      *(short *)(param_2 + 0xd6) = (short)(int)-fVar18;
      uVar7 = 0;
    }
  }
  else {
    uVar7 = 0xffffffff;
  }
  return uVar7;
}

