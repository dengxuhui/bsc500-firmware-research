
void FUN_6000bda8(undefined4 param_1)

{
  CopyBytes(DAT_6000bdb4,param_1,0x20);
  return;
}

