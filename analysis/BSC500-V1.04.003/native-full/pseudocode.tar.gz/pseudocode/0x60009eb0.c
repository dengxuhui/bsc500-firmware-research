
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60009eb0(int param_1,undefined4 param_2,undefined2 *param_3,int param_4,int param_5)

{
  int iVar1;
  undefined1 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  char *pcVar6;
  undefined1 auStack_98 [128];
  
  iVar1 = DAT_6000a000;
  if ((param_3 == (undefined2 *)0x0) || (param_4 == 0)) {
    FUN_60167f3c(3,_DAT_6000a004,1,DAT_6000a0ac);
    return 0;
  }
  if (*(char *)(DAT_6000a000 + 2) == '\0') {
    *(undefined1 *)(DAT_6000a000 + 2) = 1;
    FUN_60164e2c(1);
  }
  if (param_1 != 0x6e) {
    return 0;
  }
  if (*(int *)(iVar1 + 0x14) == 0) {
    FUN_60167f3c(7,_DAT_6000a004,1,"file_operate_handle is NULL\n");
    ZeroBytes(auStack_98,0x80);
    iVar4 = _DAT_6000a028;
    ZeroBytes(_DAT_6000a028,0xa4);
    iVar5 = FUN_60119330(*(undefined4 *)(param_3 + 2),*param_3,iVar4);
    if (iVar5 == 0) {
      pcVar6 = "genaral_file_download_pb_decode fail\n";
    }
    else {
      puVar2 = auStack_98;
      FUN_60164dec(puVar2,0x80,"%s/%s");
      iVar5 = FUN_60160ed0(puVar2);
      if (0 < iVar5) {
        pcVar6 = "file %s exist";
        uVar3 = 6;
        goto LAB_60009fbe;
      }
      iVar5 = FUN_601194e8(auStack_98,iVar4 + 0xc);
      *(int *)(iVar1 + 0x14) = iVar5;
      pcVar6 = _DAT_6000a098;
      if (iVar5 != 0) {
        FUN_601195d8(iVar5,*(undefined4 *)(iVar4 + 4));
        goto LAB_60009ed8;
      }
    }
    uVar3 = 3;
  }
  else {
LAB_60009ed8:
    if (param_5 != 0) {
      FUN_6001d084(*(undefined4 *)(iVar1 + 0x14),param_4);
    }
    puVar2 = (undefined1 *)FUN_60129b9c(*(undefined4 *)(iVar1 + 0x14));
    uVar3 = FUN_601233d4(*(undefined4 *)(iVar1 + 0x14));
    FUN_60167f3c(7,_DAT_6000a004,1,"receive_size = %d, except_size = %d\n",puVar2,uVar3);
    iVar4 = FUN_60129b9c(*(undefined4 *)(iVar1 + 0x14));
    iVar5 = FUN_601233d4(*(undefined4 *)(iVar1 + 0x14));
    if (iVar4 != iVar5) {
      return 0;
    }
    iVar4 = FUN_6001cefc(iVar1 + 0x14);
    if (iVar4 != 0) {
      uVar3 = 7;
      pcVar6 = DAT_6000a094;
LAB_60009fbe:
      FUN_60167f3c(uVar3,_DAT_6000a004,1,pcVar6,puVar2);
      uVar3 = 1;
      goto LAB_60009fc6;
    }
    uVar3 = 4;
    pcVar6 = DAT_6000a090;
  }
  FUN_60167f3c(uVar3,_DAT_6000a004,1,pcVar6);
  uVar3 = 0;
LAB_60009fc6:
  FUN_60015fec(uVar3);
  if (*(char *)(iVar1 + 2) != '\x01') {
    return 1;
  }
  *(undefined1 *)(iVar1 + 2) = 0;
  FUN_60164e80(1);
  return 1;
}

