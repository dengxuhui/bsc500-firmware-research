
void FUN_60016818(undefined4 *param_1,int param_2)

{
  int iVar1;
  
  iVar1 = DAT_600169ec;
  if (param_2 == 6) {
    *(undefined2 *)(DAT_600169ec + 0xb70) = *(undefined2 *)(param_1 + 1);
    *(undefined4 *)(iVar1 + 0xb6c) = *param_1;
  }
  return;
}

