
void FUN_6000a82c(void)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  
  cVar2 = thunk_FUN_6015f704();
  pcVar1 = DAT_6000a864;
  if (cVar2 == '\0') {
    DAT_6000a864[1] = '\0';
  }
  else if (((*DAT_6000a864 == '\x01') && (DAT_6000a864[1] == '\0')) &&
          (iVar3 = *(int *)(DAT_6000a864 + 4), *(uint *)(DAT_6000a864 + 4) = iVar3 + 1U,
          2 < iVar3 + 1U)) {
    FUN_60019568(*(undefined4 *)(pcVar1 + 8));
    pcVar1[4] = '\0';
    pcVar1[5] = '\0';
    pcVar1[6] = '\0';
    pcVar1[7] = '\0';
    pcVar1[1] = '\x01';
    return;
  }
  return;
}

