
undefined1 FUN_600182f0(void)

{
  return *DAT_600182f8;
}

