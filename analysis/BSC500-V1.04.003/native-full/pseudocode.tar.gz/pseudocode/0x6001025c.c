
undefined4 FUN_6001025c(int param_1)

{
  if (param_1 != 0) {
    *(int *)(DAT_6001026c + 4) = param_1;
    return 1;
  }
  return 0;
}

