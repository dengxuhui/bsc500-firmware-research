
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000a6e8(uint param_1)

{
  if (param_1 < 3) {
    *(char *)(DAT_6000a760 + 0xb) = (char)param_1;
    return 0;
  }
  FUN_60167f3c(3,_DAT_6000a708,1,"error bond ack %d",param_1);
  return 9;
}

