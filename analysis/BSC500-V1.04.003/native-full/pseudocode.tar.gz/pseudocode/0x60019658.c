
undefined4 FUN_60019658(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint local_18;
  int local_14;
  
  uVar2 = 0;
  local_18 = 0;
  local_14 = param_4;
  iVar1 = FUN_6015e8c2(&local_14,&local_18);
  if (iVar1 == 0) {
    iVar1 = FUN_6001bd84(param_1,local_14 + 1,&local_18);
    if (iVar1 != 0) {
      FUN_6016713c(iVar1,0x659,DAT_60019698);
    }
    local_18 = local_18 + 1;
    uVar2 = FUN_6015e94c(local_14,local_18 & 0xffff,DAT_6001969c);
  }
  return uVar2;
}

