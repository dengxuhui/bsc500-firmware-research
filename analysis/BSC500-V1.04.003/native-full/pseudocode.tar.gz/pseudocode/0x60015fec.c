
void FUN_60015fec(int param_1)

{
  char cVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  
  cVar1 = FUN_60124ec0();
  cVar2 = FUN_6014ab94();
  if (param_1 == 0) {
    FUN_60031c0c(cVar1 + '\x01');
    FUN_60129ec8(0x6e,4,3,0);
  }
  else {
    FUN_60031bc0(cVar2 + '\x01');
    FUN_60127660(0x6e,4,3,0);
  }
  iVar3 = FUN_60124ec0();
  iVar4 = FUN_6014ab94();
  FUN_60168578("cur_count=%d, fail_count=%d\n",iVar4,iVar3);
  uVar5 = FUN_6014ab8c();
  if ((uint)(iVar3 + iVar4) < uVar5) {
    return;
  }
  iVar3 = FUN_6015982e();
  if (iVar3 != 0) {
    FUN_60159828(iVar3,0,0,0);
    uVar6 = FUN_600217fc();
    FUN_60159838(uVar6,0x1b,iVar3);
  }
  FUN_60138736(500);
  FUN_60155e04(4);
  FUN_60133d80();
  FUN_6015f328(1);
  if (*DAT_6001bd80 != 9) {
    return;
  }
  FUN_600400fc();
  return;
}

