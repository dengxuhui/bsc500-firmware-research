
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016ad8(void)

{
  undefined4 uVar1;
  undefined4 local_7c;
  char *local_78;
  undefined4 local_74;
  undefined4 local_70;
  undefined4 *local_6c;
  undefined4 local_68;
  int iStack_64;
  undefined4 local_60;
  char *pcStack_5c;
  undefined1 local_58;
  undefined4 local_54;
  undefined4 local_50;
  int local_4c;
  undefined4 local_48;
  undefined4 local_44;
  undefined1 local_40;
  undefined4 *local_3c;
  undefined4 local_38;
  int local_34;
  undefined4 local_30;
  char *local_2c;
  undefined1 local_28;
  undefined4 *local_24;
  undefined4 local_20;
  undefined4 uStack_1c;
  undefined4 local_18;
  char *local_14;
  undefined1 local_10;
  undefined4 *local_c;
  
  local_c = &local_38;
  local_14 = "partition_table";
  local_10 = 0;
  local_18 = 0x1000;
  local_20 = 0;
  uStack_1c = 0x8000000;
  local_24 = &local_50;
  local_54 = 0;
  local_58 = 0;
  local_38 = 0;
  local_50 = 0;
  local_40 = 0;
  local_28 = 1;
  local_2c = "bootloader";
  local_30 = 0x5000;
  local_3c = &local_68;
  local_44 = DAT_60016b88;
  local_48 = *(undefined4 *)(DAT_60016b8c + 4);
  local_4c = DAT_60016b90 + 0x10000;
  local_34 = DAT_60016b90;
  local_60 = 0x1000;
  pcStack_5c = "gnss_config";
  iStack_64 = DAT_60016b90 + 0x3fc000;
  local_68 = 0;
  local_6c = &local_20;
  local_70 = DAT_60016ba0;
  local_74 = _DAT_60016ba4;
  local_78 = "Download Images now...";
  local_7c = _DAT_60016bc0;
  uVar1 = FUN_6001e0d8(&local_7c);
  FUN_60168578("hdl_download %d\n",uVar1);
  return uVar1;
}

