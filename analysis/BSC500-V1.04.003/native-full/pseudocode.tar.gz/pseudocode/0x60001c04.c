
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60001c04(undefined4 *param_1,int *param_2)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 local_34 [5];
  undefined4 local_20;
  undefined4 uStack_1c;
  
  ZeroBytes(local_34,0x24);
  if ((param_1 == (undefined4 *)0x0) || (param_2 == (int *)0x0)) {
    FUN_60167f3c(3,DAT_60001cf0,1,DAT_60001cf4,DAT_60001cec);
    uVar2 = 0;
  }
  else {
    iVar1 = FUN_6011e4a8(*param_1,0xc,0);
    param_2[1] = iVar1;
    uVar2 = DAT_60001cec;
    if (iVar1 == 0) {
      FUN_60167f3c(3,DAT_60001cf0,1,"%s queue creat failed\r\n",DAT_60001cec);
      FUN_60167f3c(0,DAT_60001d1c,1,_DAT_60001d20,DAT_60001d18,uVar2,0x2d);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    iVar1 = FUN_60003600();
    param_2[2] = iVar1;
    uVar2 = DAT_60001cec;
    if (iVar1 == 0) {
      FUN_60167f3c(3,DAT_60001cf0,1,"%s listener_manager creat failed\r\n",DAT_60001cec);
      FUN_60167f3c(0,DAT_60001d1c,1,_DAT_60001d20,DAT_60001d18,uVar2,0x35);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    local_34[0] = param_1[1];
    local_20 = param_1[2];
    uStack_1c = param_1[3];
    param_2[3] = param_1[4];
    iVar1 = FUN_601566b4(_DAT_60001cf8,param_2,local_34);
    *param_2 = iVar1;
    FUN_60156808();
    uVar2 = DAT_60001cec;
    if (*param_2 == 0) {
      FUN_60167f3c(3,DAT_60001cf0,1,"%s thread creat failed\r\n",DAT_60001cec);
      FUN_60167f3c(0,DAT_60001d1c,1,_DAT_60001d20,DAT_60001d18,uVar2,0x49);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    uVar2 = 1;
  }
  return uVar2;
}

