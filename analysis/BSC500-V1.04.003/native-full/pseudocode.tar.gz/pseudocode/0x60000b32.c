
undefined4 FUN_60000b32(void)

{
  FUN_60000f74();
  FUN_60001b40();
  return 0;
}

