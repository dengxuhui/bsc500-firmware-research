
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60002498(int param_1,undefined4 param_2,undefined1 *param_3,int param_4)

{
  int iVar1;
  char cVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  
  if (param_1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(_DAT_60002588,"rt_serial_write",0x332);
  }
  if (param_4 != 0) {
    if ((int)((uint)*(ushort *)(param_1 + 0x20) << 0x15) < 0) {
      iVar5 = *(int *)(param_1 + 0x68);
      iVar4 = param_4;
      if (iVar5 != 0) {
        for (; iVar4 != 0; iVar4 = iVar4 + -1) {
          while (iVar1 = (**(code **)(*(int *)(param_1 + 0x58) + 8))(param_1,*param_3), iVar1 == -1)
          {
            FUN_6013cc84(iVar5,0xffffffff);
          }
          param_3 = param_3 + 1;
        }
        return param_4;
      }
                    /* WARNING: Subroutine does not return */
      FUN_6016804c("tx != RT_NULL","_serial_int_tx",0x14b);
    }
    if (-1 < (int)((uint)*(ushort *)(param_1 + 0x20) << 0x14)) {
      for (iVar4 = 0; param_4 != iVar4; iVar4 = iVar4 + 1) {
        cVar2 = param_3[iVar4];
        if (cVar2 == '\n') {
          if ((int)((uint)*(ushort *)(param_1 + 0x20) << 0x19) < 0) {
            (**(code **)(*(int *)(param_1 + 0x58) + 8))(param_1,0xd);
            cVar2 = param_3[iVar4];
          }
          else {
            cVar2 = '\n';
          }
        }
        (**(code **)(*(int *)(param_1 + 0x58) + 8))(param_1,cVar2);
      }
      return param_4;
    }
    piVar3 = *(int **)(param_1 + 0x68);
    iVar4 = FUN_60156040(piVar3 + 1,param_3,param_4,0xffffffff);
    if (iVar4 == 0) {
      FUN_60167d0c();
      if (*piVar3 == 1) {
        FUN_60167d14();
        return param_4;
      }
      *piVar3 = 1;
      FUN_60167d14();
      (**(code **)(*(int *)(param_1 + 0x58) + 0x10))(param_1,param_3,param_4,2);
      return param_4;
    }
    FUN_60167888();
  }
  return 0;
}

