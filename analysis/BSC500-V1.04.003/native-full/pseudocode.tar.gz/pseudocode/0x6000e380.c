
undefined4 FUN_6000e380(float *param_1)

{
  char cVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int *piVar6;
  float fVar7;
  float fVar8;
  float fVar9;
  
  iVar2 = FUN_60167080();
  iVar3 = FUN_60164dd4();
  piVar4 = (int *)FUN_60162410();
  iVar5 = FUN_60164dbc();
  piVar6 = (int *)FUN_601623fc();
  cVar1 = *(char *)(iVar2 + 0x12);
  *param_1 = 0.0;
  if (cVar1 == '\0') {
    return 0;
  }
  if (iVar3 == 0 || piVar4 == (int *)0x0) {
    if (iVar5 == 0) {
      return 0;
    }
    if (piVar6 == (int *)0x0) {
      return 0;
    }
  }
  if (((iVar5 == 0) || (piVar6 == (int *)0x0)) || (*piVar6 == 0)) {
    if (iVar3 == 0 || piVar4 == (int *)0x0) {
      return 0;
    }
    if (*piVar4 == 0) {
      return 0;
    }
    if (*(char *)(iVar3 + 0x21) == '\x02') {
      return 0;
    }
    iVar2 = FUN_601624ca(iVar3,0);
    if (iVar2 < 0) {
      return 0;
    }
    iVar2 = FUN_601632f4();
    if (iVar2 == 0) {
      return 0;
    }
    fVar7 = *(float *)(iVar3 + 0xa4);
    fVar8 = *(float *)(iVar2 + 8);
    if ((fVar8 < fVar7) || (fVar9 = fVar8 - fVar7, DAT_6000e4ac < fVar9)) {
      if ((fVar8 < fVar7) && (fVar7 < *(float *)(iVar2 + 0xc))) {
        return 1;
      }
      cVar1 = *(char *)(iVar3 + 0x74);
      goto LAB_6000e496;
    }
  }
  else {
    if (*(char *)(iVar5 + 0x21) == '\x02') {
      return 0;
    }
    iVar2 = FUN_601624ca(iVar5,1);
    if (iVar2 < 0) {
      return 0;
    }
    iVar2 = FUN_60162514();
    if (iVar2 == 0) {
      return 0;
    }
    fVar7 = *(float *)(iVar5 + 0xa4);
    fVar8 = *(float *)(iVar2 + 8);
    if ((fVar8 < fVar7) || (fVar9 = fVar8 - fVar7, DAT_6000e4ac < fVar9)) {
      if ((fVar8 < fVar7) && (fVar7 < *(float *)(iVar2 + 0xc))) {
        return 1;
      }
      cVar1 = *(char *)(iVar5 + 0x74);
LAB_6000e496:
      if (cVar1 != '\0') {
        return 0;
      }
      return 2;
    }
  }
  *param_1 = fVar9;
  return 1;
}

