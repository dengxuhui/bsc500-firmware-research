
void FUN_60007a8c(void)

{
  FUN_6013bc30(DAT_60007a94,0);
  return;
}

