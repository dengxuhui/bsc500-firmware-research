
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60002b48(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  char *pcVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 uStack_20;
  undefined4 local_1c;
  
  piVar2 = DAT_60002be4;
  iVar4 = *DAT_60002be4;
  local_28 = param_1;
  local_24 = param_2;
  uStack_20 = param_3;
  local_1c = param_4;
  if (iVar4 == 0) {
    local_1c = 0;
    local_24 = 0;
    uStack_20 = 0;
    local_28 = DAT_60002be8;
    iVar4 = FUN_60168494(&local_28);
    *piVar2 = iVar4;
  }
  FUN_6016825e(iVar4,0xffffffff);
  puVar3 = _DAT_60002bec;
  FUN_60167214((int)_DAT_60002bec + 0x19,0x4b);
  uVar6 = *(undefined4 *)(s_THC__CALIBRATION__Failed_to_open_60002bef._1_4_ + 4);
  uVar7 = *(undefined4 *)(s_THC__CALIBRATION__Failed_to_open_60002bef._1_4_ + 8);
  uVar9 = *(undefined4 *)(s_THC__CALIBRATION__Failed_to_open_60002bef._1_4_ + 0xc);
  uVar10 = *(undefined4 *)(s_THC__CALIBRATION__Failed_to_open_60002bef._1_4_ + 0x10);
  uVar8 = *(undefined4 *)(s_THC__CALIBRATION__Failed_to_open_60002bef._1_4_ + 0x14);
  uVar1 = *(undefined1 *)(s_THC__CALIBRATION__Failed_to_open_60002bef._1_4_ + 0x18);
  *puVar3 = *(undefined4 *)s_THC__CALIBRATION__Failed_to_open_60002bef._1_4_;
  puVar3[1] = uVar6;
  puVar3[2] = uVar7;
  puVar3[3] = uVar9;
  puVar3[4] = uVar10;
  *(undefined1 *)(puVar3 + 6) = uVar1;
  puVar3[5] = uVar8;
  iVar4 = FUN_60166758(piVar2 + 1,puVar3,3);
  if (iVar4 == 0) {
    FUN_60168578("[CALIBRATION] Opened: %s\n",_DAT_60002bec);
    iVar4 = FUN_601667bc(piVar2[1]);
    pcVar5 = DAT_60002c34;
    if (iVar4 == 0) {
      if (*piVar2 != 0) {
        FUN_601682ae();
      }
      FUN_60004fe0();
      return 1;
    }
  }
  else {
    pcVar5 = "[CALIBRATION] Failed to open: %s\n";
  }
  FUN_60168578(pcVar5,_DAT_60002bec);
  if (*piVar2 != 0) {
    FUN_601682ae();
  }
  return 0;
}

