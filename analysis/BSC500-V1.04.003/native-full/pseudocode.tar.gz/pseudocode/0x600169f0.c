
void FUN_600169f0(void)

{
  FUN_60166c0c(*DAT_60016a14);
  return;
}

