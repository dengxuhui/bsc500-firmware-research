
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600076b4(undefined4 *param_1,char *param_2,undefined4 *param_3)

{
  bool bVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 uVar4;
  
  if (((param_1 != (undefined4 *)0x0) && (param_2 != (char *)0x0)) && (param_3 != (undefined4 *)0x0)
     ) {
    *param_1 = *param_3;
    iVar3 = FUN_6011d9b4();
    if (iVar3 == 1) {
      uVar4 = *(undefined4 *)(param_2 + 0x9c);
    }
    else {
      uVar4 = FUN_6015616c();
    }
    param_1[1] = uVar4;
    param_1[2] = 0;
    *(undefined1 *)((int)param_1 + 0x15) = 1;
    *(bool *)((int)param_1 + 0x12) = *param_2 != '\0';
    iVar3 = DAT_6000772c;
    *(byte *)(param_1 + 5) = *(byte *)(DAT_6000772c + 0xa88) & 1;
    *(byte *)((int)param_1 + 0x13) = (byte)(((uint)*(byte *)(iVar3 + 0xa88) << 0x1e) >> 0x1f);
    uVar2 = FUN_60167258();
    *(undefined1 *)((int)param_1 + 0x16) = uVar2;
    uVar2 = FUN_60167458(0xc);
    *(undefined1 *)((int)param_1 + 0x17) = uVar2;
    return;
  }
  if ((*DAT_60007730 & 1) != 0) {
    software_bkpt(0);
  }
  bVar1 = (bool)isCurrentModePrivileged();
  if (bVar1) {
    isIRQinterruptsEnabled();
  }
  disableIRQinterrupts();
                    /* WARNING: Subroutine does not return */
  FUN_6016804c(_DAT_60007734,"altitude_graph_input",0x17f);
}

