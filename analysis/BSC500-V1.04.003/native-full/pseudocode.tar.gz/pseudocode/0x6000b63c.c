
uint FUN_6000b63c(void)

{
  return (*(byte *)(DAT_6000b648 + 1) & 3) >> 1;
}

