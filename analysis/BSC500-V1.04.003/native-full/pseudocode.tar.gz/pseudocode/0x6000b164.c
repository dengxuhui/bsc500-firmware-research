
void FUN_6000b164(uint param_1,char *param_2,undefined4 *param_3)

{
  byte bVar1;
  char *pcVar2;
  undefined4 uVar3;
  char cVar4;
  uint uVar5;
  bool bVar6;
  bool bVar7;
  
  pcVar2 = DAT_6000b1c4;
  uVar5 = *(uint *)(DAT_6000b1c4 + 4);
  if (uVar5 == param_1) {
    return;
  }
  if ((param_1 == 0) || (uVar5 == 0)) {
LAB_6000b184:
    *(uint *)(DAT_6000b1c4 + 4) = param_1;
    *pcVar2 = *param_2;
    uVar3 = *param_3;
    pcVar2[1] = '\0';
    *(undefined4 *)(pcVar2 + 8) = uVar3;
    return;
  }
  bVar7 = uVar5 <= param_1;
  bVar6 = param_1 == uVar5;
  if (bVar7 && !bVar6) {
    bVar7 = 9 < param_1 - uVar5;
    bVar6 = param_1 - uVar5 == 10;
  }
  if ((bVar7 && !bVar6) || ((param_1 < uVar5 && (10 < uVar5 - param_1)))) goto LAB_6000b184;
  cVar4 = *param_2;
  if (cVar4 == '\0') {
    bVar1 = DAT_6000b1c4[1];
    if (0xe < bVar1) {
      cVar4 = '\0';
      goto LAB_6000b1be;
    }
    uVar3 = *(undefined4 *)(DAT_6000b1c4 + 8);
    cVar4 = *DAT_6000b1c4;
    *param_3 = uVar3;
    pcVar2[1] = bVar1 + 1;
    if (*param_2 == '\0') goto LAB_6000b1be;
  }
  else {
    *DAT_6000b1c4 = cVar4;
    pcVar2[1] = '\0';
    uVar3 = *param_3;
  }
  *(undefined4 *)(pcVar2 + 8) = uVar3;
LAB_6000b1be:
  *(uint *)(pcVar2 + 4) = param_1;
  *param_2 = cVar4;
  return;
}

