
void FUN_6000d5e4(void)

{
  FUN_60133d38(DAT_6000d64c);
  return;
}

