
void FUN_6000fae4(void)

{
  int iVar1;
  int *piVar2;
  
  iVar1 = FUN_60164eb0(3);
  piVar2 = (int *)(iVar1 + 4);
  while (piVar2 = (int *)*piVar2, piVar2 != (int *)(iVar1 + 4)) {
    if (piVar2[5] != 0) {
      FUN_60161424("owner %s hold mutex %s\n",piVar2[5],piVar2 + -5);
    }
  }
  return;
}

