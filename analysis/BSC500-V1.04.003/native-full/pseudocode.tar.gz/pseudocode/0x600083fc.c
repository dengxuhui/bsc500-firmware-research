
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600083fc(void)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined1 auStack_50 [64];
  
  pcVar1 = DAT_600084a0;
  if ((int)((uint)(byte)DAT_600084a0[0x14] << 0x1c) < 0) {
    iVar3 = *(int *)(_DAT_600084a4 + 4);
    iVar2 = FUN_6011f77c();
    if (iVar2 == 0) {
      if (*pcVar1 == '\0') {
        *(int *)(pcVar1 + 0x18) = iVar3;
        *pcVar1 = '\x01';
        FUN_60168578("[auto_gnss] cold search started at %ums\n",iVar3);
        return;
      }
      if (DAT_600084d4 <= (uint)(iVar3 - *(int *)(pcVar1 + 0x18))) {
        FUN_60168578("[auto_gnss] cold timeout %us, reboot\n",
                     (uint)(iVar3 - *(int *)(pcVar1 + 0x18)) / 1000);
        pcVar1[0x18] = '\0';
        pcVar1[0x19] = '\0';
        pcVar1[0x1a] = '\0';
        pcVar1[0x1b] = '\0';
        *pcVar1 = '\0';
        FUN_60167194(6,0,0,0);
        return;
      }
    }
    else {
      if (*pcVar1 == '\x01' && *(int *)(pcVar1 + 0x18) != 0) {
        uVar4 = (uint)(iVar3 - *(int *)(pcVar1 + 0x18)) / 1000;
        FUN_60164dec(auStack_50,0x40,"cold_fix_time_s:%u\r\n",uVar4);
        FUN_60118b7c(auStack_50);
        FUN_60168578("[auto_gnss] cold fix, ttff=%us\n",uVar4);
      }
      pcVar1[0x18] = '\0';
      pcVar1[0x19] = '\0';
      pcVar1[0x1a] = '\0';
      pcVar1[0x1b] = '\0';
      *pcVar1 = '\0';
      FUN_601488a0(0);
    }
  }
  return;
}

