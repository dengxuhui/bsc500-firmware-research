
void FUN_600169f8(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_60162e34(0x1000);
  *DAT_60016a14 = uVar1;
  thunk_EXT_FUN_000219ea(uVar1,0,0x1000);
  return;
}

