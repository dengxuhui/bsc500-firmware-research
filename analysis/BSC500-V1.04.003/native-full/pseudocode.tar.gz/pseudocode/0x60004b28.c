
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60004b28(int param_1,int param_2)

{
  if (param_1 != 0) {
    if (param_2 != 0) {
      *(int *)(param_1 + 8) = param_2;
    }
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c(_DAT_60004b3c,"erpc_client_add_post_cb_action",0xae);
}

