
void FUN_60000a10(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar3 = DAT_60000a58;
  uVar2 = DAT_60000a50;
  iVar1 = DAT_60000a48;
  iVar4 = DAT_60000a48 + 0x18;
  *(int *)(DAT_60000a48 + 0x18) = iVar4;
  *(int *)(iVar1 + 0x1c) = iVar4;
  FUN_6016305c(uVar2,DAT_60000a54,uVar3,0,DAT_60000a4c,0x400,7,10);
  FUN_60167f8c(uVar2);
  return;
}

