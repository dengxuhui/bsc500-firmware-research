
/* WARNING: Removing unreachable block (ram,0x60113532) */
/* WARNING: Removing unreachable block (ram,0x60113544) */
/* WARNING: Removing unreachable block (ram,0x60113548) */
/* WARNING: Removing unreachable block (ram,0x60113554) */
/* WARNING: Removing unreachable block (ram,0x60113592) */
/* WARNING: Removing unreachable block (ram,0x60113594) */
/* WARNING: Removing unreachable block (ram,0x6011359a) */
/* WARNING: Removing unreachable block (ram,0x601135a0) */
/* WARNING: Removing unreachable block (ram,0x601135c8) */
/* WARNING: Removing unreachable block (ram,0x60113562) */
/* WARNING: Removing unreachable block (ram,0x60113566) */
/* WARNING: Removing unreachable block (ram,0x60113568) */
/* WARNING: Removing unreachable block (ram,0x6011356a) */

undefined4 FUN_60019264(int param_1,uint *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint uVar7;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr8;
  float unaff_s16;
  float local_88 [20];
  
  iVar4 = DAT_60019288;
  puVar1 = (undefined4 *)(DAT_60019288 + 0x10);
  if (((puVar1 != (undefined4 *)0x0) && (param_1 != 0)) && (param_2 != (uint *)0x0)) {
    piVar2 = *(int **)(DAT_60019288 + 0x14);
    iVar6 = 0;
    uVar7 = 0;
    uVar5 = piVar2[1];
    coprocessor_function2(10,0,0,in_cr8,in_cr1,in_cr0);
    while( true ) {
      if (uVar5 <= uVar7) {
        return 1;
      }
      iVar3 = FUN_6010e156(*piVar2 + iVar6);
      if (iVar3 == 1) break;
      piVar2 = *(int **)(iVar4 + 0x14);
      iVar6 = iVar6 + 0x10;
      uVar7 = uVar7 + 1;
      uVar5 = piVar2[1];
    }
    ZeroBytes(local_88,0x50);
    iVar6 = **(int **)(iVar4 + 0x14) + iVar6;
    uVar7 = *(uint *)(iVar6 + 8);
    uVar5 = *(uint *)(iVar6 + 0xc);
    while( true ) {
      if (uVar5 <= uVar7) {
        return 1;
      }
      iVar4 = FUN_6015d0fc(*puVar1,uVar7,local_88);
      if ((iVar4 == 0) && (unaff_s16 <= local_88[0])) break;
      uVar7 = uVar7 + 1;
    }
    FUN_600e8cfc(param_1,local_88);
    *param_2 = uVar7;
    return 0;
  }
  return 0xffffffff;
}

