
void FUN_600195c0(void)

{
  undefined4 *puVar1;
  undefined1 *puVar2;
  
  puVar2 = DAT_60019640;
  if (DAT_60019640[2] == '\x01') {
    puVar1 = (undefined4 *)(DAT_60019640 + 0xc);
    *DAT_60019640 = 0;
    FUN_60159154(*puVar1);
    thunk_FUN_60166c0c(*(undefined4 *)(puVar2 + 0xc));
    *(undefined2 *)(puVar2 + 4) = 0;
    *(undefined4 *)(puVar2 + 8) = 0;
    *(undefined4 *)(puVar2 + 0xc) = 0;
    *(undefined2 *)(puVar2 + 1) = 1;
  }
  return;
}

