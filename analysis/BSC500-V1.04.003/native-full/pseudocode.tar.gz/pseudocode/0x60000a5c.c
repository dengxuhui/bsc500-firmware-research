
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000a5c(void)

{
  undefined4 uVar1;
  
  uVar1 = _DAT_60000a90;
  FUN_6016305c(_DAT_60000a90,"tidle",DAT_60000a9c,0,DAT_60000a8c,0x800,0x37,0x20);
  FUN_60167f8c(uVar1);
  return;
}

