
undefined4 FUN_6000a39c(void)

{
  FUN_6004ac24();
  if (*DAT_6000a3b4 == '\x02') {
    *DAT_6000a3b4 = '\x01';
  }
  return 0;
}

