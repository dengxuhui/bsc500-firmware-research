
bool FUN_600028ec(void)

{
  int *piVar1;
  int iVar2;
  char *local_34;
  undefined1 auStack_30 [16];
  undefined4 local_20;
  undefined4 local_1c;
  
  ZeroBytes(auStack_30,0x20);
  local_1c = 0x2f;
  local_34 = "alg_task";
  local_20 = 0x600;
  iVar2 = FUN_6011e4a8(0x20,4,0);
  piVar1 = DAT_60002940;
  DAT_60002940[1] = iVar2;
  iVar2 = FUN_601566b4(DAT_60002944,0,&local_34);
  *piVar1 = iVar2;
  FUN_60156808();
  return *piVar1 != 0;
}

