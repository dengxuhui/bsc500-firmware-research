
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60016a18(void)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 local_24;
  char *local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined1 local_14;
  
  uVar3 = DAT_60016a60;
  iVar2 = DAT_60016a5c;
  local_14 = 0;
  puVar1 = (undefined4 *)(DAT_60016a5c + 8);
  *puVar1 = 0;
  local_1c = _DAT_60016a68;
  local_18 = DAT_60016a64;
  *(undefined4 *)(iVar2 + 0xc) = uVar3;
  *(undefined4 *)(iVar2 + 0x10) = 0x7000;
  local_20 = "Download DA now...";
  local_24 = _DAT_60016bc0;
  ZeroBytes(iVar2 + 0x14,0x14);
  FUN_6001e030(puVar1,&local_24,iVar2 + 0x14);
  return;
}

