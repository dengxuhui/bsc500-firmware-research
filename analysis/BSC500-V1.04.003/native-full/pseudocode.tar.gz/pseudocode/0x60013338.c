
undefined4 FUN_60013338(uint *param_1,uint *param_2)

{
  byte bVar1;
  byte bVar2;
  uint uVar3;
  uint uVar4;
  
  if (((param_2 == (uint *)0x0) || (uVar3 = *param_2, uVar3 == 0xffffffff)) ||
     (bVar1 = (byte)param_2[1], bVar1 == 0xff)) {
    if ((param_1 != (uint *)0x0) && ((code *)param_1[3] != (code *)0x0)) {
      (*(code *)param_1[3])();
    }
    return 0xffffffff;
  }
  uVar4 = *param_1;
  if ((uVar4 != 0xffffffff) && (bVar2 = (byte)param_1[1], bVar2 != 0xff)) {
    if (uVar3 <= uVar4) {
      return 0;
    }
    if ((bVar2 < bVar1) && (0x3c < (uint)(byte)(bVar1 - bVar2) / (uVar3 - uVar4))) {
      *(byte *)(param_2 + 1) = bVar2;
      return 0;
    }
  }
  uVar3 = param_2[1];
  *param_1 = *param_2;
  param_1[1] = uVar3;
  return 0;
}

