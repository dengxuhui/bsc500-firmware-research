
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60004514(void)

{
  int iVar1;
  
  iVar1 = FUN_6000a87c();
  *DAT_60004540 = (char)iVar1;
  if (iVar1 != 0) {
    FUN_6000a8f8(iVar1,&DAT_60004544,_DAT_60004548,0,0);
    return 0;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("DATA_CLIENT_INVALID_HANDLE != env->ams_handle","ble_ams_service_init",0x19a);
}

