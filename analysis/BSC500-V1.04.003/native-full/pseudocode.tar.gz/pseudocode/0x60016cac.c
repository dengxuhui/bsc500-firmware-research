
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016cac(void)

{
  int iVar1;
  
  iVar1 = _DAT_60017088;
  FUN_6001e638(*(undefined4 *)(_DAT_60017088 + 4));
  FUN_60164e80(1);
  FUN_60164afc(0xc);
  FUN_60166af4(iVar1 + 0x28);
  return 0;
}

