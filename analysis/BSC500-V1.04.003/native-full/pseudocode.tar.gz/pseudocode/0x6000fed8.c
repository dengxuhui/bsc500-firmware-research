
void FUN_6000fed8(void)

{
  int iVar1;
  
  iVar1 = DAT_6000ffec;
  if (*(int *)(DAT_6000ffec + 8) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 8) = 0;
  }
  return;
}

