
void FUN_60011ee4(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = thunk_FUN_6016717c();
  if (3999 < (uint)(iVar1 - *(int *)(param_1 + 0x20))) {
    iVar1 = FUN_6013d6ca(*(undefined4 *)(param_1 + 0x14));
    if (iVar1 == 0) {
      FUN_60163840(*(undefined4 *)(param_1 + 0x14));
    }
    iVar1 = DAT_60011f20;
    iVar2 = 0;
    while (iVar2 != 8) {
      iVar3 = iVar1 + iVar2 * 4;
      iVar2 = iVar2 + 1;
      if (*(int *)(iVar3 + 4) == param_1) {
        *(int *)(iVar3 + 0x24) = param_1;
      }
    }
  }
  return;
}

