
undefined4 FUN_6000a750(uint param_1)

{
  undefined4 uVar1;
  
  if (param_1 < 6) {
    *(char *)(DAT_6000a760 + 0x2a) = (char)param_1;
    uVar1 = 0;
  }
  else {
    uVar1 = 5;
  }
  return uVar1;
}

