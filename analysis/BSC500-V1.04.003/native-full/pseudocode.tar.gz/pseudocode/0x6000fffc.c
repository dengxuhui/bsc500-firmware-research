
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000fffc(int param_1,uint param_2,int param_3,int param_4,int param_5,undefined4 param_6)

{
  uint *puVar1;
  undefined4 uVar2;
  code *pcVar3;
  uint uVar4;
  int iVar5;
  undefined *puVar6;
  uint uVar7;
  undefined4 uVar8;
  
  puVar1 = DAT_600101b0;
  if (param_1 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c("log_buf",DAT_600101ac,0xfe);
  }
  if (7 < param_2) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(DAT_600101a8,DAT_600101ac,0xff);
  }
  if (param_3 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(DAT_60010210,DAT_600101ac,0x100);
  }
  if (param_5 == 0) {
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(DAT_6001020c,DAT_600101ac,0x101);
  }
  *DAT_600101b0 = 0;
  uVar4 = FUN_601626c0(_DAT_600101b4);
  puVar1[1] = uVar4;
  FUN_60016db4(puVar1 + 7,puVar1 + 6,puVar1 + 5,puVar1 + 4,puVar1 + 3,puVar1 + 2);
  FUN_60162c3a(param_1 + *puVar1,0x80 - *puVar1,"%2d-%02d-%02d %02d:%02d:%02d",puVar1[7],puVar1[6],
               puVar1[5],puVar1[4],puVar1[3],puVar1[2]);
  iVar5 = FUN_601626c0(*puVar1 + param_1);
  pcVar3 = DAT_600101dc;
  uVar2 = DAT_600101d8;
  uVar4 = iVar5 + *puVar1;
  *puVar1 = uVar4;
  iVar5 = (*pcVar3)(uVar4,param_1 + uVar4,uVar2);
  uVar8 = *(undefined4 *)(&DAT_600101e0 + param_2 * 4);
  uVar4 = iVar5 + *puVar1;
  *puVar1 = uVar4;
  iVar5 = (*pcVar3)(uVar4,param_1 + uVar4,uVar8);
  uVar4 = iVar5 + *puVar1;
  *puVar1 = uVar4;
  iVar5 = (*pcVar3)(uVar4,param_1 + uVar4,param_3);
  uVar4 = iVar5 + *puVar1;
  *puVar1 = uVar4;
  iVar5 = (*pcVar3)(uVar4,param_1 + uVar4,uVar2);
  *puVar1 = iVar5 + *puVar1;
  iVar5 = FUN_60163aac();
  if (iVar5 == 0) {
    iVar5 = FUN_60163ab8();
    if (iVar5 == 0) {
      puVar6 = &DAT_60010204;
    }
    else {
      puVar6 = (undefined *)FUN_60163ab8();
    }
    iVar5 = FUN_601308ac(puVar6,0x10);
    FUN_6015f784(*puVar1 + param_1,puVar6,iVar5);
  }
  else {
    iVar5 = FUN_600f40dc(*puVar1,param_1 + *puVar1,&DAT_60010200);
  }
  uVar2 = DAT_60010208;
  uVar4 = *puVar1 + iVar5;
  *puVar1 = uVar4;
  iVar5 = FUN_600f40dc(uVar4,param_1 + uVar4,uVar2);
  uVar4 = *puVar1 + iVar5;
  *puVar1 = uVar4;
  uVar7 = FUN_60164d18(param_1 + uVar4,0x80 - uVar4,param_5,param_6);
  uVar4 = *puVar1 + uVar7;
  if (0x80 < uVar4) {
    uVar4 = 0x80;
  }
  if (0x7fffffff < uVar7) {
    uVar4 = 0x80;
  }
  *puVar1 = uVar4;
  if (0x80 < uVar4 + puVar1[1]) {
    uVar4 = 0x80 - puVar1[1];
    *puVar1 = uVar4;
  }
  if (param_4 != 0) {
    iVar5 = FUN_600f40dc(uVar4,param_1 + uVar4,_DAT_600101b4);
    *puVar1 = iVar5 + *puVar1;
  }
  return;
}

