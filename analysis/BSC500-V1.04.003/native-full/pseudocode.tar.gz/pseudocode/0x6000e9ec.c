
void FUN_6000e9ec(void)

{
  int iVar1;
  
  iVar1 = DAT_6000ea2c;
  if (*(char *)(DAT_6000ea2c + 0x40) == '\x03') {
    FUN_6014a9b0();
  }
  else if (*(char *)(DAT_6000ea2c + 0x40) == '\x02') {
    FUN_6011c750();
    FUN_6011c6ec();
    FUN_6011c710();
    *(undefined1 *)(iVar1 + 0x40) = 1;
  }
  *(undefined4 *)(iVar1 + 0x44) = 0;
  *(undefined4 *)(iVar1 + 0x48) = 0;
  *(undefined4 *)(iVar1 + 0x4c) = 0;
  FUN_60018ed0();
  FUN_60019274();
  iVar1 = DAT_60018ce0;
  if (*(int *)(DAT_60018ce0 + 0x48) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 0x48) = 0;
  }
  return;
}

