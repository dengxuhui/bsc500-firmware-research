
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a8f8(uint param_1,undefined4 param_2,code *param_3,undefined4 ***param_4,int param_5)

{
  int iVar1;
  undefined4 *puVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 ****ppppuVar7;
  uint uVar8;
  uint uVar9;
  undefined4 local_48;
  undefined4 local_44;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 *local_34;
  undefined4 ***local_30 [3];
  
  iVar1 = FUN_60168220(param_2);
  if ((param_1 < 10) || (uVar8 = param_1 - 10 & 0xff, 0xf < uVar8)) {
LAB_6000a998:
    FUN_60164ac8();
    local_44 = CONCAT31(local_44._1_3_,(char)param_1);
    local_48 = 0xffffffff;
    local_38 = 0x88000;
    local_30[0] = param_4;
    if (param_5 == 0) {
      if (param_3 != (code *)0x0) {
        local_34 = &local_48;
        (*param_3)(&local_38);
      }
    }
    else {
      local_3c = param_3;
      local_34 = (undefined4 *)FUN_60162e34(8);
      if (local_34 == (undefined4 *)0x0) {
                    /* WARNING: Subroutine does not return */
        FUN_6016804c("arg_mq.arg.data",_DAT_6000aad0,0x559);
      }
      *local_34 = local_48;
      local_34[1] = local_44;
      iVar1 = FUN_601622a0(param_5,&local_3c,0x10);
      if (iVar1 != 0) {
        FUN_60167f3c(7,DAT_6000aac4,1,DAT_6000aac8,0,local_38 & 0xffff,local_34,local_38 >> 0x10);
                    /* WARNING: Subroutine does not return */
        FUN_6016804c(DAT_6000aacc,_DAT_6000aad0,0x55f);
      }
    }
    return;
  }
  FUN_60164a88();
  puVar2 = (undefined4 *)FUN_60164a70(uVar8);
  if (*(char *)(puVar2 + 2) != '\x01') goto LAB_6000a998;
  uVar9 = iVar1 + 1U & 0xffff;
  *(undefined1 *)(puVar2 + 2) = 2;
  puVar2[3] = 0;
  puVar2[4] = param_5;
  *puVar2 = param_3;
  puVar2[1] = param_4;
  FUN_60163b68(puVar2 + 5,param_2,8);
  *(undefined1 *)(puVar2 + 7) = 0;
  FUN_60164ac8();
  iVar1 = _DAT_6000aae4;
  uVar3 = FUN_60159df0(&local_3c,0,uVar8 | (*(uint *)(_DAT_6000aae4 + 4) & 1) << 0xf,
                       (*(uint *)(_DAT_6000aae4 + 4) & 1) << 0xf | 0x7fff,uVar9);
  iVar4 = FUN_60163b68(uVar3,param_2,uVar9);
  *(undefined1 *)(iVar4 + uVar9 + -1) = 0;
  if (local_38._2_2_ < 0xd) {
    ppppuVar7 = local_30;
  }
  else {
    ppppuVar7 = (undefined4 ****)local_30[0];
    if ((undefined4 ****)local_30[0] == (undefined4 ****)0x0) {
                    /* WARNING: Subroutine does not return */
      FUN_6016804c("RT_NULL != req","datac_subscribe_int",0x2c1);
    }
  }
  iVar5 = FUN_6015d5cc(ppppuVar7);
  iVar4 = iVar5;
  FUN_60167f3c(7,DAT_6000aac4,1,"data service subscribe (%s), service (%x)",ppppuVar7,iVar5);
  if (iVar5 == 0) {
    if (*(uint *)(iVar1 + 4) != (uint)((ushort)local_3c >> 0xf)) {
      FUN_600e9818(&local_3c,0xffffffff);
      FUN_60159dd4(&local_3c);
      return;
    }
    local_3c = (code *)(CONCAT22((ushort)local_3c,(ushort)local_3c) | 0x7fff0000);
  }
  else {
    iVar6 = FUN_600f92bc(iVar5);
    if (iVar6 != 0xff) {
      local_3c = (code *)CONCAT22((ushort)iVar6 | (ushort)(*(int *)(iVar1 + 4) << 0xf) |
                                  (*(byte *)(iVar5 + 1) & 0x7f) << 8,(ushort)local_3c);
      FUN_60167f3c(7,DAT_6000aac4,1,"datac subscribe dev open",ppppuVar7,iVar4);
      FUN_60120690(iVar5,&local_3c);
      uVar3 = 0;
      goto LAB_6000aa8e;
    }
  }
  uVar3 = 0xffffffff;
LAB_6000aa8e:
  FUN_600e9818(&local_3c,uVar3);
  return;
}

