
uint FUN_60010b70(undefined4 param_1,int *param_2)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  int *piVar4;
  
  uVar1 = FUN_60168220();
  iVar2 = FUN_6001a114(param_1,uVar1);
  piVar4 = (int *)(DAT_60010ba8 + 4);
  uVar3 = 0;
  do {
    if (uVar3 == 4) {
      iVar2 = 0;
      uVar3 = 3;
LAB_60010ba2:
      *param_2 = iVar2;
      return uVar3 & 0xff;
    }
    if (*piVar4 == iVar2) {
      iVar2 = piVar4[-1];
      goto LAB_60010ba2;
    }
    piVar4 = piVar4 + 7;
    uVar3 = uVar3 + 1;
  } while( true );
}

