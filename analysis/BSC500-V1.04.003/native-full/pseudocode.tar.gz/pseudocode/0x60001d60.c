
void FUN_60001d60(undefined4 *param_1,byte *param_2,int *param_3,undefined4 param_4)

{
  uint uVar1;
  int *piVar2;
  undefined4 *puVar3;
  byte *pbVar4;
  undefined8 *puVar5;
  byte bVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int *piVar10;
  undefined4 unaff_r4;
  int iVar11;
  char *pcVar12;
  undefined4 unaff_lr;
  int *piVar13;
  
  if (param_2 == (byte *)0x0) {
    return;
  }
  bVar6 = *param_2;
  piVar13 = param_3;
LAB_60001d7a:
  param_2 = param_2 + 1;
  if (bVar6 == 0x25) {
    piVar10 = (int *)0x0;
    do {
      uVar1 = (uint)*param_2;
      uVar7 = 1;
      if (uVar1 == 0x2b) {
        uVar7 = 4;
      }
      else if (uVar1 != 0x2d) {
        if (uVar1 != 0x30) goto LAB_60001dae;
        uVar7 = 2;
      }
      piVar10 = (int *)((uint)piVar10 | uVar7);
      param_2 = param_2 + 1;
    } while( true );
  }
  if (bVar6 != 0) goto LAB_60001d8a;
  goto LAB_60001f6e;
LAB_60001dae:
  uVar7 = 0;
  while (uVar1 != 0x2a) {
    uVar1 = (uint)*param_2;
    if (9 < uVar1 - 0x30) goto LAB_60001de0;
    param_2 = param_2 + 1;
    uVar7 = (uVar1 + uVar7 * 10) - 0x30;
  }
  piVar2 = (int *)*param_3;
  *param_3 = (int)(piVar2 + 1);
  uVar7 = uVar7 + *piVar2;
  param_2 = param_2 + 1;
  uVar1 = (uint)*param_2;
LAB_60001de0:
  if (uVar1 == 0x2e) {
    iVar11 = 0;
    while( true ) {
      param_2 = param_2 + 1;
      uVar1 = (uint)*param_2;
      if (9 < uVar1 - 0x30) break;
      iVar11 = uVar1 + iVar11 * 10 + -0x30;
    }
  }
  else {
    iVar11 = 0;
  }
LAB_60001e06:
  param_2 = param_2 + 1;
  switch(uVar1) {
  case 99:
    goto switchD_60001e0e_caseD_63;
  case 100:
  case 0x69:
    puVar3 = (undefined4 *)*param_3;
    *param_3 = (int)(puVar3 + 1);
    FUN_6011140c(param_1,*puVar3,iVar11,uVar7,piVar10);
  case 0x65:
  case 0x67:
  case 0x6a:
  case 0x6b:
  case 0x6d:
  case 0x6e:
  case 0x6f:
  case 0x71:
  case 0x72:
  case 0x74:
  case 0x76:
  case 0x77:
    goto switchD_60001e0e_caseD_65;
  case 0x66:
    puVar5 = (undefined8 *)(*param_3 + 7U & 0xfffffff8);
    *param_3 = (int)(puVar5 + 1);
    uVar8 = (undefined4)*puVar5;
    uVar9 = 0;
    goto LAB_60001f18;
  case 0x68:
  case 0x6c:
    goto switchD_60001e0e_caseD_68;
  case 0x70:
    puVar3 = (undefined4 *)*param_3;
    *param_3 = (int)(puVar3 + 1);
    uVar8 = *puVar3;
    FUN_60116830(param_1,0x30);
    FUN_60116830(param_1,0x78);
    uVar9 = 0x10;
    iVar11 = 8;
    uVar7 = 8;
    piVar13 = (int *)0x0;
    break;
  case 0x73:
    puVar3 = (undefined4 *)*param_3;
    *param_3 = (int)(puVar3 + 1);
    pcVar12 = (char *)*puVar3;
    if (((uint)piVar10 & 1) == 0) {
      if (pcVar12 == (char *)0x0) {
        uVar1 = 0;
      }
      else {
        uVar1 = FUN_60168220(pcVar12);
      }
      for (; uVar1 < uVar7; uVar7 = uVar7 - 1) {
        FUN_60116830(param_1,0x20);
      }
      for (; *pcVar12 != '\0'; pcVar12 = pcVar12 + 1) {
        FUN_60116830(param_1);
      }
    }
    else {
      for (uVar1 = 0; pcVar12[uVar1] != '\0'; uVar1 = uVar1 + 1) {
        FUN_60116830(param_1);
      }
      for (; uVar1 < uVar7; uVar7 = uVar7 - 1) {
        FUN_60116830(param_1,0x20);
      }
    }
    goto switchD_60001e0e_caseD_65;
  case 0x75:
    puVar3 = (undefined4 *)*param_3;
    uVar9 = 10;
    *param_3 = (int)(puVar3 + 1);
    uVar8 = *puVar3;
    piVar13 = piVar10;
    break;
  case 0x78:
switchD_60001e0e_caseD_78:
    puVar3 = (undefined4 *)*param_3;
    uVar9 = 0x10;
    *param_3 = (int)(puVar3 + 1);
    uVar8 = *puVar3;
    piVar13 = piVar10;
    break;
  default:
    if (uVar1 == 0x25) {
      bVar6 = 0x25;
      goto LAB_60001d8a;
    }
    if (uVar1 == 0x46) {
      puVar5 = (undefined8 *)(*param_3 + 7U & 0xfffffff8);
      *param_3 = (int)(puVar5 + 1);
      uVar8 = (undefined4)*puVar5;
      uVar9 = 1;
LAB_60001f18:
      FUN_60003100(uVar8,param_1,iVar11,uVar7,piVar10,uVar9,piVar13);
    }
    else if (uVar1 == 0x58) goto switchD_60001e0e_caseD_78;
    goto switchD_60001e0e_caseD_65;
  }
  FUN_60111aa0(param_1,uVar8,uVar9,iVar11,uVar7,piVar13,param_4);
  goto switchD_60001e0e_caseD_65;
switchD_60001e0e_caseD_68:
  uVar1 = (uint)*param_2;
  goto LAB_60001e06;
switchD_60001e0e_caseD_63:
  pbVar4 = (byte *)*param_3;
  *param_3 = (int)(pbVar4 + 4);
  bVar6 = *pbVar4;
LAB_60001d8a:
  FUN_60116830(param_1,bVar6);
switchD_60001e0e_caseD_65:
  bVar6 = *param_2;
  if (bVar6 == 0) {
LAB_60001f6e:
    if (*(char *)(param_1 + 3) == '\0') {
      return;
    }
    if (param_1[2] != 0) {
      (*(code *)param_1[5])(param_1[4],*param_1,param_1[2],(code *)param_1[5],unaff_r4,unaff_lr);
      param_1[2] = 0;
    }
    return;
  }
  goto LAB_60001d7a;
}

