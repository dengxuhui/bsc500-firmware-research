
undefined4 FUN_60019c04(undefined4 param_1)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  byte *pbVar5;
  byte bVar6;
  byte *pbVar7;
  byte bVar8;
  bool bVar9;
  undefined1 auStack_38 [40];
  
  ZeroBytes(auStack_38,0x28);
  iVar4 = FUN_6014966c(2,0,7,auStack_38);
  iVar3 = DAT_60019c80;
  if (iVar4 == 0) {
    iVar4 = FUN_6014966c(2,0,8,auStack_38);
    if (iVar4 == 0) {
      return 0;
    }
    pbVar5 = (byte *)(iVar3 + 0x104);
    pbVar7 = (byte *)(iVar3 + 0x103);
  }
  else {
    pbVar5 = (byte *)(DAT_60019c80 + 0xfe);
    pbVar7 = (byte *)(DAT_60019c80 + 0xfd);
  }
  bVar6 = *pbVar7;
  bVar1 = *pbVar5;
  bVar2 = bVar6 >> 5;
  bVar8 = bVar6 & 0x1f;
  bVar9 = bVar6 >> 5 == 1;
  if (bVar9) {
    bVar6 = bVar1 & 0x1f;
  }
  if (!bVar9 || bVar6 != bVar8) {
    if (bVar8 == 1) {
      bVar1 = bVar1 >> 5;
    }
    if (bVar8 != 1 || bVar1 != bVar2) {
      return 0;
    }
  }
  FUN_601681f4(param_1,"%d-%d");
  return 1;
}

