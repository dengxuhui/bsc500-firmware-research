
undefined4 FUN_6000495c(void)

{
  return *DAT_60004964;
}

