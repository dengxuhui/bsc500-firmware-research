
uint FUN_6000ea30(undefined4 param_1,int param_2,uint param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined1 local_34 [32];
  
  if (((param_2 != 0) && (param_3 < 0x11)) && (iVar1 = FUN_6016087c(param_1), iVar1 != 0)) {
    uVar4 = 0x20;
    if (*(char *)(iVar1 + 0x21) == '\0') {
      uVar4 = 0x10;
    }
    iVar2 = thunk_EXT_FUN_00010e44(iVar1,local_34,uVar4);
    if (iVar2 == 0) {
      if (*(char *)(iVar1 + 0x21) == '\0') {
        for (uVar3 = 0; param_3 != uVar3; uVar3 = uVar3 + 1) {
          *(undefined1 *)(param_2 + uVar3) = local_34[uVar3];
        }
        return param_3;
      }
      for (uVar3 = 0; param_3 != uVar3; uVar3 = uVar3 + 1) {
        *(undefined1 *)(param_2 + uVar3) = local_34[uVar3 * 2];
      }
      return param_3;
    }
  }
  return 0;
}

