
void FUN_60006c80(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = DAT_60006c8c;
  *DAT_60006c8c = *param_1;
  puVar1[1] = param_1[1];
  return;
}

