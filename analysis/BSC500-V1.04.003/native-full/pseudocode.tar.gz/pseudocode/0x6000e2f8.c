
void FUN_6000e2f8(void)

{
  if ((*(byte *)(DAT_6000e318 + 0x328) < 0xb) &&
     ((1 << (uint)*(byte *)(DAT_6000e318 + 0x328) & 0x418U) != 0)) {
    thunk_FUN_60059aa8(DAT_6000e31c);
    return;
  }
  return;
}

