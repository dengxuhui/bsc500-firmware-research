
void FUN_60018918(void)

{
  ushort uVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  
  puVar4 = DAT_6001895c;
  iVar3 = DAT_60018958;
  uVar5 = *(undefined4 *)(DAT_60018958 + 0x40);
  uVar6 = *(undefined4 *)(DAT_60018958 + 0x44);
  uVar7 = *(undefined4 *)(DAT_60018958 + 0x48);
  *(undefined2 *)(DAT_6001895c + 2) = *(undefined2 *)(DAT_60018958 + 0x54);
  *puVar4 = uVar6;
  puVar4[1] = uVar7;
  *(undefined1 *)((int)puVar4 + 10) = *(undefined1 *)(iVar3 + 0x8c);
  *(undefined1 *)((int)puVar4 + 0xb) = *(undefined1 *)(iVar3 + 0x8a);
  *(undefined2 *)(puVar4 + 3) = *(undefined2 *)(iVar3 + 0x58);
  uVar1 = *(ushort *)(iVar3 + 0x5c);
  puVar4[4] = uVar5;
  puVar4[5] = (uint)uVar1;
  uVar2 = *(undefined2 *)(iVar3 + 0x6e);
  *(undefined2 *)(puVar4 + 6) = *(undefined2 *)(iVar3 + 0x76);
  *(undefined2 *)((int)puVar4 + 0x1a) = uVar2;
  return;
}

