
void FUN_6000e4d0(undefined4 *param_1)

{
  int iVar1;
  
  iVar1 = DAT_6000e4f4;
  *(undefined2 *)(DAT_6000e4f4 + 0x1e) = 0;
  *(undefined4 *)(iVar1 + 0x1a) = 0;
  *(undefined4 *)(iVar1 + 0x16) = 0;
  *(undefined2 *)(iVar1 + 0x14) = *(undefined2 *)(param_1 + 1);
  *(undefined4 *)(iVar1 + 0x10) = *param_1;
  if (0x39 < *(byte *)(iVar1 + 0x14)) {
    *(byte *)(iVar1 + 0x14) = *(byte *)(iVar1 + 0x14) - 0x11;
  }
  return;
}

