
undefined4 FUN_60002de8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int local_14;
  
  uVar1 = DAT_60002e60;
  local_14 = 0;
  FUN_6015baa0(DAT_60002e60,&local_14,4,param_4,param_3);
  iVar2 = DAT_60002e64;
  if (local_14 == DAT_60002e64) {
    FUN_6015baa0(uVar1,DAT_60002e68,0x2000);
  }
  if (*DAT_60002e68 == iVar2) {
    uVar4 = DAT_60002e68[1];
    piVar3 = DAT_60002e68 + 2;
    if (0x1fff < uVar4) {
      uVar4 = 0x2000;
    }
    *DAT_60002e6c = uVar4;
    iVar2 = FUN_60006b70(DAT_60002e70 + 8,"HFault",piVar3);
    if (iVar2 == 0) {
      FUN_6015c650(uVar1,0x2000);
    }
    ZeroBytes(DAT_60002e68,0x2000);
    return 1;
  }
  ZeroBytes(DAT_60002e68,0x2000);
  *DAT_60002e6c = 0;
  return 0;
}

