
undefined4 FUN_600168b8(void)

{
  short sVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  short *psVar5;
  
  uVar2 = FUN_6016708c();
  iVar4 = (short)uVar2 * 0x5a4 + DAT_600169ec;
  iVar3 = FUN_60161014(uVar2,5);
  psVar5 = (short *)(iVar4 + 0xe94);
  do {
    if (iVar3 == 0) {
      return 0;
    }
    sVar1 = *psVar5;
    iVar3 = iVar3 + -1;
    psVar5 = psVar5 + 1;
  } while (sVar1 != 0xb1d);
  return 1;
}

