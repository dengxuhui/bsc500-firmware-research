
void FUN_60006e38(int param_1)

{
  int iVar1;
  
  iVar1 = DAT_60006e6c;
  if ((*(int *)(DAT_60006e6c + 8) != 0) && (*(char *)(*(int *)(DAT_60006e6c + 8) + 8) != '\0')) {
    *(undefined4 *)(param_1 + 400) = 0;
    *(undefined1 *)(param_1 + 0x18b) = 1;
    if (*(int *)(iVar1 + 4) != 0) {
      *(undefined4 *)(*(int *)(iVar1 + 4) + 0x3c) = 0;
    }
  }
  return;
}

