
void FUN_60009bf0(uint param_1,int param_2)

{
  if ((param_1 < 8) && (param_2 != 0)) {
    *(int *)(*(int *)(DAT_60009c2c + param_1 * 4 + 4) + 8) = param_2;
  }
  return;
}

