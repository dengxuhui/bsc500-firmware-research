
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60004a70(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  uint uVar2;
  undefined4 uVar3;
  
  FUN_60161424("cmbacktrace_assert_hook\n");
  FUN_60161424(_DAT_60004ae4);
  FUN_6016252c();
  uVar2 = 0;
  bVar1 = (bool)isCurrentModePrivileged();
  if (bVar1) {
    uVar2 = getCurrentExceptionNumber();
    uVar2 = uVar2 & 0x1f;
  }
  if (uVar2 == 0) {
    uVar3 = getProcessStackPointer();
  }
  else {
    uVar3 = getMainStackPointer();
  }
  FUN_60004968(uVar3);
  FUN_60161424("cmbacktrace_assert at function:%s, line number:%d ,(%s)\n",param_2,param_3,param_1);
  FUN_60161424(_DAT_60004ae4);
  if ((*DAT_60004b24 & 1) == 0) {
    FUN_60006a90();
    FUN_6016384a();
    return;
  }
  software_bkpt(0);
  return;
}

