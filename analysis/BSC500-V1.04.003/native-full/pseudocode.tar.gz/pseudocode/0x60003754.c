
bool FUN_60003754(void)

{
  int iVar1;
  undefined4 uVar2;
  char *local_2c;
  undefined1 auStack_28 [16];
  undefined4 local_18;
  undefined4 local_14;
  
  ZeroBytes(auStack_28,0x20);
  local_14 = 0x18;
  local_2c = "ride_task";
  local_18 = 0x1000;
  uVar2 = FUN_601566b4(DAT_6000379c,0,&local_2c);
  iVar1 = DAT_600037a0;
  *(undefined4 *)(DAT_600037a0 + 0x10) = uVar2;
  FUN_60156808();
  return *(int *)(iVar1 + 0x10) != 0;
}

