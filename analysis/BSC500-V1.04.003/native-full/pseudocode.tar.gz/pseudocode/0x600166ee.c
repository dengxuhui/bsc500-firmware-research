
undefined4
FUN_600166ee(int param_1,int param_2,int param_3,int param_4,int param_5,int param_6,int param_7)

{
  undefined4 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  undefined1 auStack_13c [22];
  char local_126 [258];
  
  uVar1 = 0;
  if ((param_1 != 0) && (param_2 != 0)) {
    do {
      do {
        iVar2 = FUN_6015c834(param_1,auStack_13c);
        if (iVar2 != 0) {
          return 0;
        }
      } while (local_126[0] == '.');
      if (local_126[0] == '\0') {
        return 0;
      }
      uVar3 = FUN_60168220(local_126);
    } while ((((((param_3 == 0) || (uVar4 = FUN_60168220(param_3), uVar3 <= uVar4)) ||
               (iVar2 = FUN_60168418(param_3,local_126 + (uVar3 - uVar4)), iVar2 != 0)) &&
              (((param_4 == 0 || (uVar4 = FUN_60168220(param_4), uVar3 <= uVar4)) ||
               (iVar2 = FUN_60168418(param_4,local_126 + (uVar3 - uVar4)), iVar2 != 0)))) &&
             (((param_5 == 0 || (uVar4 = FUN_60168220(param_5), uVar3 <= uVar4)) ||
              (iVar2 = FUN_60168418(param_5,local_126 + (uVar3 - uVar4)), iVar2 != 0)))) &&
            ((((param_6 == 0 || (uVar4 = FUN_60168220(param_6), uVar3 <= uVar4)) ||
              (iVar2 = FUN_60168418(param_6,local_126 + (uVar3 - uVar4)), iVar2 != 0)) &&
             (((param_7 == 0 || (uVar4 = FUN_60168220(param_7), uVar3 <= uVar4)) ||
              (iVar2 = FUN_60168418(param_7,local_126 + (uVar3 - uVar4)), iVar2 != 0))))));
    CopyBytes(param_2,local_126,uVar3);
    *(undefined1 *)(param_2 + uVar3) = 0;
    uVar1 = 1;
  }
  return uVar1;
}

