
undefined4 FUN_6001546c(void)

{
  int iVar1;
  int iVar2;
  
  iVar1 = DAT_600154e8;
  if ((*(char *)(DAT_600154e8 + 6) == '\0') && (iVar2 = FUN_601176c4(0x6e), iVar2 != 0)) {
    iVar2 = FUN_6001c7b8(*(byte *)(iVar1 + 6) ^ 1);
    if (iVar2 == 0) goto LAB_600154bc;
    *(undefined1 *)(iVar1 + 6) = 1;
  }
  else {
    if ((*(char *)(iVar1 + 7) != '\x01') ||
       ((iVar2 = FUN_601176c4(0x6e), iVar2 == 0 || (*(char *)(iVar1 + 5) != '\0')))) {
      return 0;
    }
    iVar2 = FUN_6001c7b8(*(byte *)(iVar1 + 6) ^ 1);
    if (iVar2 == 0) goto LAB_600154bc;
  }
  if (*(char *)(iVar1 + 5) != '\x01') {
    return 0;
  }
LAB_600154bc:
  *(undefined2 *)(iVar1 + 5) = 0;
  return 1;
}

