
undefined4 FUN_6000af48(int param_1)

{
  if (param_1 == 2) {
    return *(undefined4 *)(DAT_6000af80 + 0x10);
  }
  if (param_1 != 1) {
    if (param_1 == 0) {
      return *(undefined4 *)(DAT_6000af80 + 8);
    }
    return 0;
  }
  return *(undefined4 *)(DAT_6000af80 + 0xc);
}

