
void FUN_6000f8f8(undefined4 *param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = DAT_6000f910;
  uVar1 = DAT_6000f90c;
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0xffffffff;
    param_1[1] = 0xffffffff;
    param_1[2] = uVar2;
    param_1[3] = uVar1;
  }
  return;
}

