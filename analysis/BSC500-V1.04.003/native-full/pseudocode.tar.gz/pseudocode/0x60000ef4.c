
void FUN_60000ef4(uint param_1)

{
  if (param_1 - 3 < 5) {
    *DAT_60000f14 = DAT_60000f18 | *DAT_60000f14 & 0xf8ff | (param_1 & 7) << 8;
    return;
  }
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

