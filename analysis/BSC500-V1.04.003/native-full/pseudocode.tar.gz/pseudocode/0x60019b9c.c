
void FUN_60019b9c(int param_1)

{
  byte *pbVar1;
  byte bVar2;
  
  pbVar1 = DAT_60019bd4;
  if (param_1 == 2) {
    if ((int)((uint)*DAT_60019bd4 << 0x1e) < 0) {
      return;
    }
    FUN_601203e4(2);
    bVar2 = *pbVar1 | 2;
  }
  else {
    if (param_1 != 1) {
      return;
    }
    if ((*DAT_60019bd4 & 1) != 0) {
      return;
    }
    FUN_601203e4(1);
    bVar2 = *pbVar1 | 1;
  }
  *pbVar1 = bVar2;
  return;
}

