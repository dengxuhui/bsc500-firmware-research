
undefined4 FUN_600106c2(void)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = FUN_6001b75c();
  uVar2 = 0;
  if (iVar1 != 1) {
    uVar2 = 0xffffffff;
  }
  return uVar2;
}

