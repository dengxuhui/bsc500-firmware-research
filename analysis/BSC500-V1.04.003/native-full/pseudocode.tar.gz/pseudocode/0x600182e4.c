
undefined4 FUN_600182e4(void)

{
  return *(undefined4 *)(DAT_600182ec + 0x34);
}

