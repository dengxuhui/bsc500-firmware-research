
undefined4 FUN_600035f4(void)

{
  return *(undefined4 *)(DAT_600035fc + 8);
}

