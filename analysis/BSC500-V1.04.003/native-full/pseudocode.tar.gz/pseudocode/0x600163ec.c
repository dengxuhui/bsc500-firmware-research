
undefined4 FUN_600163ec(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  char *pcVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined2 uVar7;
  
  if (param_1 == 0) {
    return 0xffffffff;
  }
  if (param_2 == (undefined4 *)0x0) {
    return 0xffffffff;
  }
  if (param_3 == (undefined4 *)0x0) {
    return 0xffffffff;
  }
  FUN_6013bb40(*(undefined4 *)(DAT_600164c8 + 0x70),param_3);
  *param_3 = *(undefined4 *)(param_1 + 4);
  FUN_60118c40(param_1 + 0xb4,param_1 + 0xbc,param_3 + 1,param_3 + 2);
  pcVar1 = DAT_600164cc;
  iVar5 = *(int *)(param_1 + 0xa0);
  uVar7 = 0xffff;
  if (iVar5 != 0x7fffffff) {
    iVar3 = *(int *)(param_1 + 0x9c);
    if (((iVar3 != 0x7fffffff) && (iVar5 = iVar3, *DAT_600164cc == '\0')) &&
       (*(int *)(param_1 + 0x98) != 0)) {
      FUN_60021540();
      *pcVar1 = '\x01';
      iVar5 = *(int *)(param_1 + 0x9c);
      if (iVar5 == 0x7fffffff) goto LAB_60016478;
    }
    uVar7 = (undefined2)((iVar5 + 50000) / 0x14);
  }
LAB_60016478:
  iVar5 = *(int *)(param_1 + 0xa4);
  *(undefined2 *)(param_3 + 5) = uVar7;
  if (iVar5 == 0x7fff) {
    uVar2 = 0x7f;
  }
  else {
    uVar2 = (undefined1)(iVar5 / 10);
  }
  *(undefined1 *)((int)param_3 + 0x23) = uVar2;
  *(undefined2 *)((int)param_3 + 0x1f) = *(undefined2 *)((int)param_2 + 0x11);
  uVar4 = *param_2;
  uVar6 = param_2[1];
  *(undefined4 *)((int)param_3 + 0x16) = param_2[2];
  *(undefined2 *)(param_3 + 7) = *(undefined2 *)((int)param_2 + 0xe);
  param_3[3] = uVar4;
  param_3[4] = uVar6;
  *(undefined1 *)((int)param_3 + 0x21) = *(undefined1 *)((int)param_2 + 0x13);
  *(byte *)((int)param_3 + 0x1e) = *(byte *)(param_2 + 4) | 0x80;
  *(undefined1 *)((int)param_3 + 0x22) = *(undefined1 *)(param_2 + 5);
  *(undefined2 *)((int)param_3 + 0x1a) = *(undefined2 *)(param_2 + 3);
  return 0;
}

