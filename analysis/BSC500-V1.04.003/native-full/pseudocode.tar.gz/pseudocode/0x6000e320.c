
undefined8 FUN_6000e320(undefined4 param_1,undefined4 param_2)

{
  byte *pbVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  undefined4 uVar6;
  
  iVar4 = FUN_600188e0();
  pbVar1 = DAT_6000e358;
  if (iVar4 == 0) {
    bVar3 = *DAT_6000e358;
    bVar2 = FUN_6012b1b8();
    if (bVar3 != bVar2) {
      bVar3 = FUN_6012b1b8();
      *pbVar1 = bVar3;
      uVar5 = (uint)bVar3;
      uVar6 = 0;
      FUN_60164f44(0xd,0xff,2,0xff,uVar5,0,0,0);
      return CONCAT44(uVar6,uVar5);
    }
  }
  return CONCAT44(param_2,param_1);
}

