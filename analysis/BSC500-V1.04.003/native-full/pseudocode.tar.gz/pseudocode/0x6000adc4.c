
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000adc4(void)

{
  bool bVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  ushort local_12;
  
  local_12 = 0;
  iVar3 = FUN_6012c09c();
  if (iVar3 != 0) {
    iVar3 = thunk_FUN_60162e34(100);
    if (iVar3 == 0) {
      if ((*DAT_6000ae94 & 1) != 0) {
        software_bkpt(0);
      }
      bVar1 = (bool)isCurrentModePrivileged();
      if (bVar1) {
        isIRQinterruptsEnabled();
      }
      disableIRQinterrupts();
                    /* WARNING: Subroutine does not return */
      FUN_6016804c("0 != fnamestr",_DAT_6000ae9c,0x58);
    }
    FUN_60167214(iVar3,100);
    iVar4 = thunk_FUN_60162e34(800);
    if (iVar4 == 0) {
      if ((*DAT_6000ae94 & 1) != 0) {
        software_bkpt(0);
      }
      bVar1 = (bool)isCurrentModePrivileged();
      if (bVar1) {
        isIRQinterruptsEnabled();
      }
      disableIRQinterrupts();
                    /* WARNING: Subroutine does not return */
      FUN_6016804c(DAT_6000ae98,_DAT_6000ae9c,0x5d);
    }
    ZeroBytes(iVar4,800);
    FUN_60015a2c(DAT_6000ae8c,&local_12,iVar4,0,0);
    uVar2 = DAT_6000ae90;
    uVar5 = (uint)local_12;
    if (uVar5 != 0) {
      while( true ) {
        FUN_60160afc(uVar2,*(undefined4 *)(iVar4 + uVar5 * 4 + -4),0,iVar3);
        iVar6 = FUN_60163bbe(iVar3);
        if (iVar6 == 0) {
          local_12 = local_12 - 1;
        }
        if ((local_12 == 0) || (iVar6 = FUN_6012c09c(), iVar6 == 0)) break;
        uVar5 = (uint)local_12;
      }
    }
    thunk_FUN_60166c0c(iVar4);
    thunk_FUN_60166c0c(iVar3);
  }
  return;
}

