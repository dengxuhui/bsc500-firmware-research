
undefined4 FUN_60015618(int param_1,int param_2,uint *param_3,uint *param_4)

{
  undefined8 uVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  undefined4 uVar11;
  uint uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  undefined8 uVar15;
  undefined4 local_6c;
  undefined4 uStack_68;
  int local_64 [5];
  uint local_50 [4];
  uint local_40 [4];
  
  local_64[0] = 0;
  local_6c = 0;
  uStack_68 = 0;
  if (param_1 == 0 || param_2 == 0) {
    return 0xffffffff;
  }
  if (param_3 == (uint *)0x0) {
    return 0xffffffff;
  }
  if (param_4 == (uint *)0x0) {
    return 0xffffffff;
  }
  iVar2 = FUN_60020350(param_2);
  if (iVar2 == 0) {
    uVar3 = FUN_601668a4();
    iVar2 = DAT_600158f0;
    if ((uVar3 | 2) == 2) {
      local_40[0] = *param_3;
      local_40[1] = param_3[1];
      local_40[2] = param_3[2];
      local_40[3] = param_3[3];
      local_50[0] = *param_4;
      local_50[3] = param_4[3];
      local_50[1] = param_4[1];
      local_50[2] = param_4[2];
    }
    else {
      local_40[1] = param_3[1] >> 1;
      local_40[2] = param_3[2] >> 1;
      local_40[0] = *param_3 >> 1;
      local_40[3] = param_3[3] >> 1;
      local_50[0] = *param_4 >> 1;
      local_50[1] = param_4[1] >> 1;
      local_50[2] = param_4[2] >> 1;
      local_50[3] = param_4[3] >> 1;
    }
    uVar3 = *(uint *)(DAT_600158f0 + 0x164);
    if (local_40[0] < uVar3) {
      return 0;
    }
    uVar8 = *(uint *)(DAT_600158f0 + 0x16c);
    if (uVar8 < local_40[0]) {
      return 0;
    }
    uVar4 = *(uint *)(DAT_600158f0 + 0x168);
    if (local_50[0] < uVar4) {
      return 0;
    }
    if (*(uint *)(DAT_600158f0 + 0x170) < local_50[0]) {
      return 0;
    }
    for (iVar9 = 0; iVar9 != 4; iVar9 = iVar9 + 1) {
      local_64[iVar9 + 1] =
           (local_50[iVar9] - uVar4) * ((uVar8 - uVar3) + 1) + (local_40[iVar9] - uVar3);
    }
    iVar9 = FUN_60166758(DAT_600158f0 + 0x160,DAT_600158f0,1);
    uVar1 = DAT_600158e8;
    if (iVar9 == 0) {
      iVar9 = 0;
      uVar11 = 0;
      while( true ) {
        if (iVar9 == 0x10) break;
        uVar3 = *(uint *)((int)local_40 + iVar9);
        if ((((*(uint *)(iVar2 + 0x164) <= uVar3) && (uVar3 <= *(uint *)(iVar2 + 0x16c))) &&
            (uVar8 = *(uint *)((int)local_50 + iVar9), *(uint *)(iVar2 + 0x168) <= uVar8)) &&
           ((uVar8 <= *(uint *)(iVar2 + 0x170) &&
            ((iVar7 = local_64[1], iVar9 == 0 ||
             (iVar7 = *(int *)((int)local_64 + iVar9 + 4), iVar7 != *(int *)((int)local_64 + iVar9))
             ))))) {
          iVar7 = iVar7 * 5 + *(int *)(iVar2 + 0x130);
          if (*(char *)(iVar2 + 0x8a) < '\0') {
            iVar7 = iVar7 + 0x10;
          }
          FUN_60163c98(*(undefined4 *)(iVar2 + 0x160),iVar7);
          uVar11 = FUN_60161ef4(*(undefined4 *)(DAT_600158f0 + 0x160),&uStack_68,5,&local_6c);
          uVar15 = FUN_6012222c(&uStack_68);
          iVar2 = DAT_600158f0;
          uVar4 = (uint)((ulonglong)uVar15 >> 0x20);
          uVar12 = (uVar4 & 0x7fffffff) >> 0x18;
          uVar10 = (uint)uVar15 >> 0x18 | uVar4 << 8;
          if (uVar12 <= *(uint *)(DAT_600158f0 + 0x13c) &&
              (uint)(*(uint *)(DAT_600158f0 + 0x138) <= uVar10) <=
              uVar12 - *(uint *)(DAT_600158f0 + 0x13c)) {
            uVar11 = FUN_60161ef4(*(undefined4 *)(DAT_600158f0 + 0x160),&uStack_68,5,&local_6c);
            uVar15 = FUN_6012222c(&uStack_68);
            uVar12 = (uint)((ulonglong)uVar15 >> 0x20);
            if (((uint)uVar15 >> 0x18 | uVar12 << 8) != uVar10 ||
                ((uVar12 ^ uVar4) & 0x7fffffff) >> 0x18 != 0) {
              FUN_60163c98(*(undefined4 *)(iVar2 + 0x160),*(int *)(iVar2 + 0x130) + uVar10);
              if (0x7fffffff < (uint)(int)*(char *)(iVar2 + 0x8a)) {
                iVar2 = FUN_6015cbf2(*(undefined4 *)(iVar2 + 0x160));
                FUN_60163c98(*(undefined4 *)(DAT_600158f0 + 0x160),iVar2 + 0x20);
                iVar2 = DAT_600158f0;
              }
              uVar11 = FUN_60159a10(uVar3,*(undefined1 *)(iVar2 + 0x128));
              uVar15 = FUN_60166bb4(uVar11);
              uVar11 = (undefined4)((ulonglong)uVar1 >> 0x20);
              uVar14 = (undefined4)uVar1;
              FUN_601678fc((int)uVar15,(int)((ulonglong)uVar15 >> 0x20),uVar14,uVar11);
              iVar7 = FUN_60167a50();
              iVar2 = DAT_600158f4;
              iVar5 = *(int *)(DAT_600158f4 + 0x2b0);
              uVar13 = FUN_60159a60(uVar8,*(undefined1 *)(DAT_600158f0 + 0x128));
              uVar15 = FUN_60166bb4(uVar13);
              FUN_601678fc((int)uVar15,(int)((ulonglong)uVar15 >> 0x20),uVar14,uVar11);
              iVar6 = FUN_60167a50();
              uVar11 = FUN_6001ee88(param_1,iVar7 - iVar5,iVar6 - *(int *)(iVar2 + 0x2ac),
                                    DAT_600158f0);
              FUN_60163c98(*(undefined4 *)(DAT_600158f0 + 0x160),
                           *(int *)(DAT_600158f0 + 0x130) + uVar10);
              iVar2 = DAT_600158f0;
              if (0x7fffffff < (uint)(int)*(char *)(DAT_600158f0 + 0x8a)) {
                iVar2 = FUN_6015cbf2(*(undefined4 *)(DAT_600158f0 + 0x160));
                FUN_60163c98(*(undefined4 *)(DAT_600158f0 + 0x160),iVar2 + 0x20);
                iVar2 = DAT_600158f0;
              }
            }
          }
        }
        iVar9 = iVar9 + 4;
      }
      FUN_601667bc(*(undefined4 *)(iVar2 + 0x160));
      return uVar11;
    }
  }
  return 0xffffffff;
}

