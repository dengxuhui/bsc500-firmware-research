
undefined4 FUN_6001107c(char *param_1,int param_2)

{
  undefined4 uVar1;
  
  if (*param_1 == '\0') {
LAB_600110a6:
    *DAT_60011114 = 0;
    return 0;
  }
  if (*param_1 != '\x01') {
    return 0;
  }
  switch(param_1[0x30]) {
  case '\0':
    goto LAB_600110a6;
  case '\x01':
    uVar1 = 0;
    if ((uint)((uint)((ulonglong)*(uint *)(param_1 + 0x28) * 100) <= *(uint *)(param_2 + 0x40)) <=
        (uint)-(int)((ulonglong)*(uint *)(param_1 + 0x28) * 100 >> 0x20)) goto LAB_6001110c;
    if ((uint)(*(int *)(param_1 + 8) - *(int *)(DAT_60011114 + 8)) < 0x1389) {
LAB_6001110a:
      uVar1 = 0;
      goto LAB_6001110c;
    }
    *(int *)(DAT_60011114 + 8) = *(int *)(param_1 + 8);
    break;
  case '\x02':
    uVar1 = FUN_60050000(param_1);
    return uVar1;
  case '\x03':
    uVar1 = 0;
    if (*(uint *)(param_2 + 0x44) < (uint)(*(int *)(param_1 + 0x2c) * 1000)) goto LAB_6001110c;
    if ((uint)(*(int *)(param_1 + 8) - *(int *)(DAT_60011114 + 0xc)) < 0x1389) goto LAB_6001110a;
    *(int *)(DAT_60011114 + 0xc) = *(int *)(param_1 + 8);
    break;
  default:
    return 0;
  }
  uVar1 = 1;
LAB_6001110c:
  *DAT_60011114 = 0;
  return uVar1;
}

