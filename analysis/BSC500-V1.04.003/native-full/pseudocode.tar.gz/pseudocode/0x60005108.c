
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60005108(undefined4 param_1,uint param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  int *piVar4;
  int *piVar5;
  
  iVar2 = FUN_60164eb0(7);
  uVar1 = _DAT_60005160;
  piVar4 = (int *)(iVar2 + 4);
  uVar3 = FUN_6015de24(_DAT_60005160,piVar4);
  FUN_60168578("%-*.s  pool size  max used size available size\n",uVar3,uVar1);
  FUN_6015de60(uVar3);
  FUN_60168578(" ---------- ------------- --------------\n");
  piVar5 = piVar4;
  while (piVar5 = (int *)*piVar5, piVar5 != piVar4) {
    param_2 = piVar5[4];
    FUN_60168578("%-*.*s %-010d %-013d %-05d\n",uVar3,0x10,piVar5 + -5,param_2,piVar5[6],piVar5[5]);
  }
  return (ulonglong)param_2 << 0x20;
}

