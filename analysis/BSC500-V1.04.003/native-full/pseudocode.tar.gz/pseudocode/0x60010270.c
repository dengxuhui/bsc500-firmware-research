
undefined8 FUN_60010270(undefined4 param_1,undefined4 param_2)

{
  char cVar1;
  
  if ((int)((uint)*(byte *)(DAT_600102a4 + 0x74) << 0x1d) < 0) {
    if (*DAT_600102a8 != '\0') goto LAB_600102a2;
    cVar1 = '\x01';
    param_1 = 0;
    param_2 = 0;
    FUN_60164f44(0xc,1,0,0xff,0,0,0,0);
  }
  else {
    cVar1 = '\0';
  }
  *DAT_600102a8 = cVar1;
LAB_600102a2:
  return CONCAT44(param_2,param_1);
}

