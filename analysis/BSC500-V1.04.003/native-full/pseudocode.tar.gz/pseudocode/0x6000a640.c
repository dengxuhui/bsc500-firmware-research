
void FUN_6000a640(void)

{
  FUN_6001928c(DAT_6000a658,DAT_6000a65c,0x2000);
  thunk_EXT_FUN_00020440(10);
  return;
}

