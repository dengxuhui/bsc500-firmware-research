
int FUN_60004c5c(void)

{
  int iVar1;
  int iVar2;
  
  iVar1 = DAT_60004c70;
  FUN_600e9ee8(DAT_60004c70);
  iVar2 = 0;
  if (*(char *)(iVar1 + 8) != '\0') {
    iVar2 = iVar1;
  }
  return iVar2;
}

