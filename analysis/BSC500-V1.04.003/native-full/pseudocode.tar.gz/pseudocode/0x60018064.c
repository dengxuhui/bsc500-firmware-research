
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60112c26 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

uint FUN_60018064(int param_1,undefined8 *param_2)

{
  bool bVar1;
  float fVar2;
  float fVar3;
  int *piVar4;
  int iVar5;
  float fVar6;
  int iVar7;
  undefined1 *puVar8;
  undefined8 *unaff_r4;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  bool bVar12;
  float fVar13;
  float fVar14;
  undefined8 in_d1;
  undefined4 uVar15;
  undefined4 in_s5;
  undefined8 uVar16;
  undefined8 uVar17;
  float fVar18;
  undefined8 uVar19;
  uint uStack_148;
  uint uStack_144;
  undefined4 uStack_138;
  undefined4 uStack_134;
  undefined4 uStack_130;
  undefined4 uStack_12c;
  undefined4 uStack_128;
  undefined4 uStack_124;
  undefined4 uStack_120;
  float fStack_118;
  undefined1 auStack_110 [16];
  float fStack_100;
  undefined1 auStack_f8 [16];
  float fStack_e8;
  float fStack_e4;
  undefined8 uStack_e0;
  undefined8 uStack_d8;
  float fStack_d0;
  undefined1 auStack_c8 [24];
  undefined1 auStack_b0 [16];
  undefined4 uStack_a0;
  undefined8 uStack_98;
  undefined8 uStack_90;
  undefined4 uStack_88;
  undefined4 uStack_84;
  undefined8 uStack_80;
  undefined4 uStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  
  iVar7 = DAT_60018094;
  piVar4 = (int *)(DAT_60018094 + 0x50);
  if (piVar4 != (int *)0x0) {
    unaff_r4 = param_2;
  }
  if (piVar4 == (int *)0x0 || param_2 == (undefined8 *)0x0) {
    return 0xffffffff;
  }
  iVar5 = FUN_60137930(0xffffffff);
  if ((iVar5 == 0) || (iVar5 = FUN_60133cdc(), iVar5 == 0)) {
LAB_60112d42:
    uVar10 = 0xffffffff;
  }
  else {
    uVar10 = 0;
    uStack_70 = 0;
    uStack_6c = 0;
    uStack_78 = 0;
    uStack_74 = 0;
    FUN_6012fba8(&uStack_70,&uStack_78);
    uStack_90 = FUN_601682c8(uStack_70,uStack_6c);
    uStack_98 = FUN_60165558();
    uStack_80 = FUN_601682c8(uStack_78,uStack_74);
    uVar19 = FUN_60165558();
    fVar3 = DAT_60112d84;
    fVar2 = DAT_60112d80;
    fVar13 = DAT_60112d78;
    uStack_84 = (undefined4)((ulonglong)uVar19 >> 0x20);
    fVar6 = (float)uVar19;
    uVar16 = CONCAT44(0x3e800000,DAT_60112d74);
    bVar1 = false;
    uStack_148 = 0;
    uVar17 = CONCAT44(DAT_60112d74,DAT_60112d7c);
    bVar12 = false;
    uStack_144 = 0;
    while( true ) {
      fVar14 = (float)((ulonglong)uVar19 >> 0x20);
      uStack_88 = (undefined4)uVar19;
      if ((uint)(*(int **)(iVar7 + 0x54))[1] <= uVar10) break;
      iVar5 = FUN_6012fb3c(&uStack_98,**(int **)(iVar7 + 0x54) + uVar10 * 0x30);
      if (iVar5 != 0) {
        iVar5 = **(int **)(iVar7 + 0x54) + uVar10 * 0x30;
        uVar9 = *(uint *)(iVar5 + 0x2c);
        for (uVar11 = *(uint *)(iVar5 + 0x28); uVar11 < uVar9; uVar11 = uVar11 + 1) {
          iVar5 = FUN_6013028a(*piVar4,uVar11,auStack_f8);
          if (iVar5 != 0) goto LAB_60112d42;
          iVar5 = uVar11 - 1;
          if (uVar11 == 0) {
            iVar5 = 1;
          }
          iVar5 = FUN_6013028a(*piVar4,iVar5,auStack_110);
          if (iVar5 != 0) goto LAB_60112d42;
          FUN_6012fee0();
          if (fVar6 <= fVar13) {
            if (param_1 == 1) {
              fVar14 = (float)uVar17;
              if (fStack_e4 < 0.0) {
                fVar14 = DAT_60112eac;
              }
              fStack_e4 = fStack_e4 + fVar14;
              fVar14 = fStack_e4;
            }
            FUN_6012fc48();
            fVar18 = (float)((ulonglong)uVar16 >> 0x20);
            if (fVar6 <= fVar2) {
              fVar18 = ABS(*(float *)(iVar7 + 0x5c) - fStack_e8) * fVar18 +
                       fVar6 * (fVar6 / 30.0 + 1.0);
              if ((!bVar1) || (fVar18 < (float)((ulonglong)uVar17 >> 0x20))) {
                FUN_60156244(auStack_b0,auStack_f8);
                bVar1 = true;
                uVar17 = CONCAT44(fVar18,(float)uVar17);
                uStack_144 = uVar11;
              }
              else {
                bVar1 = true;
              }
            }
            else if (fVar3 <= fVar6) {
              if ((!bVar12) || (fVar6 < (float)uVar16)) {
                FUN_60156244(auStack_c8,auStack_f8);
                uVar16 = CONCAT44(fVar18,fVar6);
                uStack_148 = uVar11;
              }
              bVar12 = true;
            }
          }
        }
      }
      uVar19 = CONCAT44(fVar14,uStack_88);
      uVar10 = uVar10 + 1;
    }
    if (!bVar12 && !bVar1) {
      *(undefined4 *)(iVar7 + 0x5c) = 0;
      return 2;
    }
    if (bVar1) {
      puVar8 = auStack_b0;
      *(undefined4 *)(iVar7 + 0x5c) = uStack_a0;
    }
    else {
      puVar8 = auStack_c8;
      *(undefined4 *)(iVar7 + 0x5c) = 0;
      uStack_144 = uStack_148;
    }
    FUN_60156244(&uStack_e0,puVar8);
    fVar13 = (float)uStack_e0;
    uVar15 = (undefined4)((ulonglong)in_d1 >> 0x20);
    FUN_6015e318(fVar13,fVar14,(int)uStack_d8);
    FUN_6012fc48();
    if (DAT_60112ea8 <= fVar13) {
      if (param_1 == 1) {
        uVar10 = *(int *)(*piVar4 + 0x14) - 1;
      }
      else {
        uVar10 = 0;
      }
      if (uStack_144 == uVar10) {
        if (param_1 == 1) {
          *(float *)(unaff_r4 + 2) = *(float *)(*(int *)(iVar7 + 0x58) + 0x20) - fStack_d0;
        }
        else {
          *(float *)(unaff_r4 + 2) = fStack_d0;
        }
      }
      else {
        iVar7 = 1;
        if (param_1 != 1) {
          iVar7 = -1;
        }
        iVar7 = FUN_6013028a(*piVar4,uStack_144 + iVar7,auStack_110);
        if (iVar7 != 0) goto LAB_60112d42;
        uStack_128 = 0;
        uStack_124 = 0;
        uStack_130 = 0;
        uStack_12c = 0;
        FUN_6012fc58(&uStack_128,&uStack_130);
        fVar2 = fStack_100;
        FUN_60161ad0(uStack_128,fVar14,uStack_130,uVar15,(undefined4)uStack_e0,in_s5,
                     (undefined4)uStack_d8);
        if ((fVar13 <= ABS(fStack_d0 - fVar2)) || (param_1 == 1)) {
          *(float *)(unaff_r4 + 2) = fVar13;
        }
        else {
          *(float *)(unaff_r4 + 2) = fStack_100;
        }
        uStack_e0 = CONCAT44(uStack_124,uStack_128);
        uStack_d8 = CONCAT44(uStack_12c,uStack_130);
      }
      *unaff_r4 = uStack_e0;
      unaff_r4[1] = uStack_d8;
      if (param_1 == 1) {
        iVar7 = *(int *)(*piVar4 + 0x14) - uStack_144;
        bVar12 = uStack_144 < *(int *)(*piVar4 + 0x14) - 1U;
        uStack_144 = 0;
        if (bVar12) {
          uStack_144 = iVar7 - 2;
        }
      }
      else if (uStack_144 != 0) {
        uStack_144 = uStack_144 - 1;
      }
    }
    else {
      if (param_1 == 1) {
        uVar10 = 0;
      }
      else {
        uVar10 = *(int *)(*piVar4 + 0x14) - 1;
      }
      if (uStack_144 == uVar10) {
        if (param_1 == 1) {
          *(float *)(unaff_r4 + 2) = *(float *)(*(int *)(iVar7 + 0x58) + 0x20) - fStack_d0;
        }
        else {
          *(float *)(unaff_r4 + 2) = fStack_d0;
        }
      }
      else {
        iVar7 = 1;
        if (param_1 == 1) {
          iVar7 = -1;
        }
        iVar7 = FUN_6013028a(*piVar4,uStack_144 + iVar7,&uStack_128);
        if (iVar7 != 0) goto LAB_60112d42;
        uStack_130 = 0;
        uStack_12c = 0;
        uStack_138 = 0;
        uStack_134 = 0;
        FUN_6012fc58(&uStack_130,&uStack_138);
        fVar2 = fStack_d0;
        FUN_60161ad0(uStack_130,fVar14,uStack_138,uVar15,uStack_128,in_s5,uStack_120);
        if ((fVar13 <= ABS(fStack_118 - fVar2)) || (param_1 == 1)) {
          *(float *)(unaff_r4 + 2) = fVar13;
        }
        else {
          *(float *)(unaff_r4 + 2) = fStack_d0;
        }
        uStack_e0 = CONCAT44(uStack_12c,uStack_130);
        uStack_d8 = CONCAT44(uStack_134,uStack_138);
      }
      *unaff_r4 = uStack_e0;
      unaff_r4[1] = uStack_d8;
      if (param_1 == 1) {
        uStack_144 = ~uStack_144 + *(int *)(*piVar4 + 0x14);
      }
    }
    *(uint *)((int)unaff_r4 + 0x14) = uStack_144;
    uVar10 = (uint)!bVar1;
  }
  return uVar10;
}

