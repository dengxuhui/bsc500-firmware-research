
void FUN_60003a74(void)

{
  *DAT_60003a7c = 1;
  return;
}

