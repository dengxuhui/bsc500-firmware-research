
void FUN_6000fc70(int param_1,undefined8 *param_2,undefined8 *param_3)

{
  undefined8 *puVar1;
  
  if (param_1 < (int)(uint)*(byte *)(DAT_6000fcb4 + 8)) {
    puVar1 = (undefined8 *)(*(int *)(DAT_6000fcb4 + 0xc) + param_1 * 0x18);
    *param_2 = *puVar1;
    *param_3 = puVar1[1];
  }
  return;
}

