
undefined4 FUN_60002950(void)

{
  int iVar1;
  undefined4 uVar2;
  char *local_34;
  undefined1 auStack_30 [16];
  undefined4 local_20;
  undefined4 local_1c;
  
  ZeroBytes(auStack_30,0x20);
  iVar1 = DAT_60002994;
  local_1c = 0x2c;
  local_34 = "touchx";
  local_20 = 0x2000;
  FUN_60137768(DAT_60002994 + 0x38);
  uVar2 = FUN_601566b4(DAT_60002998,0,&local_34);
  *(undefined4 *)(iVar1 + 4) = uVar2;
  FUN_60156808();
  return 0;
}

