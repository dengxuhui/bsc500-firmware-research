
void FUN_60002a1c(void)

{
  int iVar1;
  
  InitializeBacklight();
  FUN_6016572c(DAT_60002a50,1,DAT_60002a54);
  FUN_6016572c(DAT_60002a58,1,DAT_60002a5c);
  FUN_6011694c(DAT_60002a60,DAT_60002a64);
  iVar1 = DAT_60002a68;
  FUN_600040a4(DAT_60002a68 + 0x54);
  *(undefined1 *)(iVar1 + 1) = 1;
  return;
}

