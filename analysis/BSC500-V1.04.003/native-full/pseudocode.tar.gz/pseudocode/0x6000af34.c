
bool FUN_6000af34(void)

{
  return *DAT_6000af44 == '\x01';
}

