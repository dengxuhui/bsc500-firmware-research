
void FUN_60000a04(void)

{
  int iVar1;
  int iVar2;
  
  iVar1 = DAT_60000a48;
  iVar2 = DAT_60000a48 + 0x10;
  *(int *)(DAT_60000a48 + 0x10) = iVar2;
  *(int *)(iVar1 + 0x14) = iVar2;
  return;
}

