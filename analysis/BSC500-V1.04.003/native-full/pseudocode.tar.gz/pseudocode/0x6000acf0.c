
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000acf0(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  
  if (param_1 != 0) {
    piVar1 = (int *)(param_1 + 0x18);
    iVar3 = *piVar1;
    if (*piVar1 != 0) {
      do {
        iVar2 = iVar3;
        iVar3 = *(int *)(iVar2 + 8);
      } while (iVar3 != 0);
      piVar1 = (int *)(iVar2 + 8);
    }
    *piVar1 = param_2;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c(_DAT_6000ad04,"erpc_add_service_to_server",0x7f);
}

