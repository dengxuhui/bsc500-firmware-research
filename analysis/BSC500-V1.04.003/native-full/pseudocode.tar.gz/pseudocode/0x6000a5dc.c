
uint FUN_6000a5dc(void)

{
  uint uVar1;
  
  uVar1 = FUN_60159114();
  return uVar1 ^ 1;
}

