
bool FUN_60015a1c(void)

{
  int iVar1;
  
  iVar1 = FUN_60122010(0);
  return iVar1 != 0;
}

