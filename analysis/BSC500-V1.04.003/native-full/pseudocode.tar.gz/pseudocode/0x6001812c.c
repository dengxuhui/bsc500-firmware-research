
undefined4 FUN_6001812c(int param_1,uint param_2)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  int iVar12;
  uint uVar13;
  bool bVar14;
  float fVar15;
  
  iVar1 = DAT_6001817c;
  piVar2 = (int *)(DAT_6001817c + 0x50);
  if ((piVar2 == (int *)0x0) || (uVar3 = *(uint *)(*piVar2 + 0x14), uVar3 <= param_2)) {
LAB_6001faac:
    uVar5 = 0xffffffff;
  }
  else {
    if (param_1 == 1) {
      param_2 = uVar3 + ~param_2;
    }
    uVar8 = *(uint *)(DAT_6001817c + 100);
    uVar13 = param_2 - (uVar8 >> 1);
    if (param_2 < uVar8 >> 1) {
      uVar13 = 0;
    }
    uVar10 = param_2 + (uVar8 >> 1) + (uVar8 & 1);
    if (uVar3 < uVar10) {
      uVar10 = uVar3;
    }
    uVar9 = uVar10;
    if (uVar10 - uVar13 < uVar8) {
      uVar8 = uVar8 - (uVar10 - uVar13);
      bVar14 = uVar8 <= uVar13;
      uVar9 = uVar13 - uVar8;
      uVar13 = 0;
      if (bVar14) {
        uVar13 = uVar9;
      }
      uVar9 = uVar10 + uVar8;
      if (uVar3 < uVar10 + uVar8) {
        uVar9 = uVar3;
      }
    }
    uVar3 = *(uint *)(DAT_6001817c + 0x5c);
    if ((uVar3 != uVar13) || (*(uint *)(DAT_6001817c + 0x60) != uVar9)) {
      if ((uVar3 < uVar9) && (uVar13 < *(uint *)(DAT_6001817c + 0x60))) {
        if (uVar13 < uVar3) {
          iVar12 = -uVar9;
          iVar11 = uVar9 * 0x38;
          uVar3 = uVar9;
          while( true ) {
            iVar11 = iVar11 + -0x38;
            uVar3 = uVar3 - 1;
            if (uVar3 <= uVar13) break;
            uVar8 = *(uint *)(iVar1 + 0x5c);
            if ((uVar8 <= uVar3) && (uVar3 < *(uint *)(iVar1 + 0x60))) {
              iVar7 = *(int *)(iVar1 + 0x58);
              if (param_1 == 1) {
                iVar4 = iVar7 + (uVar13 + iVar12 + *(int *)(iVar1 + 0x68)) * 0x38;
                iVar7 = iVar7 + (uVar8 + *(int *)(iVar1 + 0x68) + iVar12) * 0x38;
              }
              else {
                iVar4 = iVar7 + uVar13 * -0x38 + iVar11;
                iVar7 = iVar7 + uVar8 * -0x38 + iVar11;
              }
              FUN_600fb404(iVar4,iVar7);
            }
            iVar12 = iVar12 + 1;
          }
        }
        else {
          iVar11 = -1;
          iVar12 = 0;
          for (uVar3 = uVar13; uVar3 < uVar9; uVar3 = uVar3 + 1) {
            uVar8 = *(uint *)(iVar1 + 0x5c);
            if ((uVar8 <= uVar3) && (uVar3 < *(uint *)(iVar1 + 0x60))) {
              iVar7 = *(int *)(iVar1 + 0x58);
              if (param_1 == 1) {
                iVar6 = iVar7 + (uVar8 + *(int *)(iVar1 + 0x68) + (iVar11 - uVar13)) * 0x38;
                iVar4 = (iVar11 + *(int *)(iVar1 + 0x68)) * 0x38;
              }
              else {
                iVar6 = iVar7 + uVar13 * 0x38 + iVar12 + uVar8 * -0x38;
                iVar4 = iVar12;
              }
              FUN_600fb404(iVar7 + iVar4,iVar6);
            }
            iVar12 = iVar12 + 0x38;
            iVar11 = iVar11 + -1;
          }
        }
      }
      iVar11 = ~uVar13 + uVar9;
      fVar15 = *(float *)(**(int **)(iVar1 + 0x54) + (*(int **)(iVar1 + 0x54))[1] * 0x10 + -0xc);
      for (iVar12 = 0; uVar3 = uVar13 + iVar12, uVar3 < uVar9; iVar12 = iVar12 + 1) {
        if ((uVar3 < *(uint *)(iVar1 + 0x5c)) || (*(uint *)(iVar1 + 0x60) <= uVar3)) {
          iVar7 = iVar12;
          if (param_1 == 1) {
            iVar7 = iVar11;
          }
          iVar4 = *(int *)(iVar1 + 0x58) + iVar7 * 0x38;
          iVar7 = FUN_600f7576(*piVar2,uVar3,iVar4);
          if (iVar7 == 0 && param_1 == 1) {
            *(float *)(iVar4 + 0x14) = fVar15 - *(float *)(iVar4 + 0x14);
          }
          else if (iVar7 != 0) goto LAB_6001faac;
        }
        iVar11 = iVar11 + -1;
      }
      *(uint *)(iVar1 + 0x5c) = uVar13;
      *(uint *)(iVar1 + 0x60) = uVar9;
      *(uint *)(iVar1 + 0x68) = uVar9 - uVar13;
    }
    uVar5 = 0;
  }
  return uVar5;
}

