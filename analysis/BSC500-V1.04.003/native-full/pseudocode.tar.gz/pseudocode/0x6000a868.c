
undefined4 FUN_6000a868(void)

{
  FUN_60018794(*DAT_6000a878);
  return 1;
}

