
undefined4 FUN_600106b8(void)

{
  FUN_6001b77c();
  return 0;
}

