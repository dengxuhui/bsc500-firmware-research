
/* WARNING: Removing unreachable block (ram,0x6001166a) */
/* WARNING: Removing unreachable block (ram,0x60011670) */
/* WARNING: Removing unreachable block (ram,0x60011678) */
/* WARNING: Removing unreachable block (ram,0x6001168e) */
/* WARNING: Removing unreachable block (ram,0x6001167c) */
/* WARNING: Removing unreachable block (ram,0x60011692) */
/* WARNING: Removing unreachable block (ram,0x60011674) */
/* WARNING: Removing unreachable block (ram,0x6001169c) */
/* WARNING: Removing unreachable block (ram,0x600116a2) */
/* WARNING: Removing unreachable block (ram,0x600116ae) */
/* WARNING: Removing unreachable block (ram,0x600116b0) */
/* WARNING: Removing unreachable block (ram,0x600116c6) */
/* WARNING: Removing unreachable block (ram,0x600116c2) */
/* WARNING: Removing unreachable block (ram,0x600116d0) */
/* WARNING: Removing unreachable block (ram,0x600116d8) */

void FUN_600090f2(void)

{
  int iVar1;
  
  FUN_60011474(1);
  FUN_60011514(1);
  FUN_600115b4(1);
  iVar1 = DAT_600116f0;
  *(undefined1 *)(DAT_600116f0 + 0xc) = 0;
  *(undefined2 *)(iVar1 + 0x1c) = 0;
  *(undefined1 *)(iVar1 + 8) = 0;
  ZeroBytes(DAT_600116f4,*(undefined2 *)(iVar1 + 0x14));
  *(undefined2 *)(DAT_600116f0 + 0x14) = 0;
  return;
}

