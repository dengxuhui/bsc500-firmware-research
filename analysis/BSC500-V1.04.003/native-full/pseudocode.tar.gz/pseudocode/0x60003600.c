
undefined4 *
FUN_60003600(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  undefined4 *puVar3;
  
  iVar1 = DAT_60003660;
  if (*(int *)(DAT_60003660 + 4) != 0) {
    iVar2 = FUN_6016825e(*(int *)(DAT_60003660 + 4),0xffffffff,param_3,param_4,param_1,param_2,
                         param_3);
    if (iVar2 == 0) {
      puVar3 = (undefined4 *)FUN_60161f90(8,10);
      *puVar3 = 0;
      puVar3[1] = 0;
      FUN_601682ae(*(undefined4 *)(iVar1 + 4));
    }
    else {
      FUN_60167f3c(3,DAT_60003728,1,DAT_60003668,DAT_60003664,param_2,param_3,param_4);
      puVar3 = (undefined4 *)0x0;
    }
    return puVar3;
  }
  FUN_60167f3c(0,DAT_60003670,1,DAT_60003674,DAT_6000366c,DAT_60003664,0xcb,param_4);
  FUN_6013dd48();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

