
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000194c(int param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 0x54) = param_4;
    uVar6 = DAT_600019a8;
    uVar5 = DAT_600019a4;
    uVar4 = DAT_600019a0;
    uVar3 = DAT_6000199c;
    uVar2 = DAT_60001998;
    uVar1 = DAT_60001994;
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = uVar6;
    *(undefined4 *)(param_1 + 0x30) = uVar5;
    *(undefined4 *)(param_1 + 0x34) = uVar4;
    *(undefined4 *)(param_1 + 0x38) = uVar3;
    *(undefined4 *)(param_1 + 0x3c) = uVar2;
    *(undefined4 *)(param_1 + 0x40) = uVar1;
    *(undefined1 *)(param_1 + 0x1c) = 0;
    FUN_601637f8(param_1,param_2,param_3);
    *(undefined4 *)(param_1 + 0x44) = _DAT_600019ac;
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c("serial != RT_NULL","rt_hw_serial_register",0x488,param_4,param_4);
}

