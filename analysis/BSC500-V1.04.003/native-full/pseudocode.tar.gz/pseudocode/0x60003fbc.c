
undefined1 * FUN_60003fbc(undefined4 *param_1)

{
  uint *puVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  undefined1 uVar5;
  undefined1 *puVar6;
  int iVar7;
  undefined1 *puVar8;
  uint uVar9;
  uint in_fpscr;
  uint uVar10;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr2;
  float fVar11;
  undefined4 uVar12;
  float fVar13;
  undefined4 uVar14;
  float fVar15;
  
  puVar8 = DAT_6000409c;
  iVar4 = DAT_60004098;
  iVar3 = DAT_60004094;
  if ((((int)((uint)*(byte *)(DAT_60004098 + 0xa1d) << 0x19) < 0) &&
      (*(char *)(DAT_60004094 + 5) == '\0')) &&
     (puVar6 = (undefined1 *)((uint)*(byte *)(DAT_60004098 + 0xba4) << 0x1d), -1 < (int)puVar6)) {
    if (param_1 == (undefined4 *)0x0) {
      return puVar6;
    }
    if (&LAB_00000064 < (undefined1 *)*param_1) {
      return (undefined1 *)*param_1;
    }
    *(undefined1 *)(DAT_60004094 + 8) = *(undefined1 *)(param_1 + 2);
    *(undefined4 *)(iVar3 + 0xc) = param_1[1];
    if ((undefined1 *)(uint)*(byte *)(iVar3 + 3) != (undefined1 *)0x0) {
      return (undefined1 *)(uint)*(byte *)(iVar3 + 3);
    }
    iVar7 = FUN_60008aa4();
    if (iVar7 != 0) {
      puVar6 = (undefined1 *)FUN_60008aac(param_1[1],*(undefined1 *)(iVar3 + 8));
      puVar8 = DAT_6000409c;
      uVar9 = (uint)puVar6 & 0xff;
      puVar1 = (uint *)(DAT_6000409c + 4);
      *DAT_6000409c = (char)puVar6;
      if (uVar9 == *puVar1) {
        return puVar6;
      }
      *(char *)(iVar4 + 0xa1c) = (char)puVar6;
      *(uint *)(puVar8 + 4) = uVar9;
      puVar8 = (undefined1 *)FUN_60122688(uVar9);
      return puVar8;
    }
    *(undefined4 *)(iVar3 + 0x14) = param_1[1];
    uVar5 = FUN_60167b4c();
    *(undefined1 *)(iVar3 + 0x18) = uVar5;
    FUN_60008188(iVar3 + 0x54,(undefined4 *)(iVar3 + 0x14));
    puVar8 = DAT_6000409c;
    fVar11 = *(float *)(iVar3 + 0x74);
    fVar13 = *(float *)(DAT_6000409c + 8);
    uVar9 = in_fpscr & 0xfffffff | (uint)(fVar11 < fVar13) << 0x1f |
            (uint)(fVar11 == fVar13) << 0x1e;
    bVar2 = (byte)(uVar9 >> 0x18);
    if (!(bool)(bVar2 >> 6 & 1) && (bool)(bVar2 >> 7) == (NAN(fVar11) || NAN(fVar13))) {
      fVar15 = fVar11 - fVar13;
      uVar9 = in_fpscr & 0xfffffff | (uint)(fVar15 < DAT_600040a0) << 0x1f |
              (uint)(fVar15 == DAT_600040a0) << 0x1e;
      bVar2 = (byte)(uVar9 >> 0x18);
      if (!(bool)(bVar2 >> 6 & 1) && (bool)(bVar2 >> 7) == (NAN(fVar15) || NAN(DAT_600040a0)))
      goto LAB_60004078;
    }
    if (NAN(fVar11) || NAN(fVar13)) {
      fVar13 = fVar13 - fVar11;
      uVar9 = uVar9 & 0xfffffff | (uint)(fVar13 < DAT_600040a0) << 0x1f |
              (uint)(fVar13 == DAT_600040a0) << 0x1e;
      bVar2 = (byte)(uVar9 >> 0x18);
      if (!(bool)(bVar2 >> 6 & 1) && (bool)(bVar2 >> 7) == (NAN(fVar13) || NAN(DAT_600040a0))) {
LAB_60004078:
        *(float *)(DAT_6000409c + 8) = fVar11;
        *(char *)(iVar4 + 0xa1c) = (char)(int)fVar11;
        *puVar8 = (char)(int)fVar11;
        uVar10 = uVar9 & 0xfffffff | (uint)(fVar11 < 1.0) << 0x1f;
        if ((SUB41(uVar10 >> 0x1f,0) == NAN(fVar11)) &&
           (uVar10 = uVar9 & 0xfffffff | (uint)(fVar11 < DAT_6000b6cc) << 0x1f,
           SUB41(uVar10 >> 0x1f,0) != (NAN(fVar11) || NAN(DAT_6000b6cc)))) {
          uVar14 = VectorFloatToUnsigned((fVar11 * DAT_6000b6d4) / DAT_6000b6cc,3);
        }
        else {
          uVar10 = uVar10 & 0xfffffff;
          uVar14 = DAT_6000b6d0;
          if (NAN(fVar11)) {
            uVar14 = 10000;
          }
          coprocessor_function2(10,3,0,in_cr0,in_cr1,in_cr2);
        }
        fVar13 = (float)VectorUnsignedToFloat
                                  ((uint)(byte)DAT_6000b6d8[2],(byte)(uVar10 >> 0x16) & 3);
        if (fVar11 == fVar13) {
          return DAT_6000b6d8;
        }
        uVar12 = VectorFloatToUnsigned(fVar11,3);
        DAT_6000b6d8[2] = (char)uVar12;
        if (*DAT_6001bd54 != '\x01') {
          return (undefined1 *)0xffffffff;
        }
        fVar11 = (float)VectorUnsignedToFloat(uVar14,(byte)((uVar10 & 0xfffffff) >> 0x16) & 3);
        FUN_60122458(2,(int)fVar11);
        return (undefined1 *)0x0;
      }
    }
  }
  else {
    *(undefined4 *)(DAT_6000409c + 4) = 0xffffffff;
  }
  return puVar8;
}

