
undefined1 FUN_60008aa4(void)

{
  return *(undefined1 *)(DAT_60008b7c + 1);
}

