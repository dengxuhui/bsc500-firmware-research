
undefined4 FUN_6000b59c(void)

{
  char *pcVar1;
  int iVar2;
  char *pcVar3;
  undefined4 local_40;
  undefined4 uStack_3c;
  undefined4 local_38;
  undefined4 uStack_34;
  undefined4 local_30;
  int local_2c;
  
  pcVar1 = DAT_6000b600;
  if (*DAT_6000b600 != '\0') {
    pcVar3 = DAT_6000b600 + 4;
    iVar2 = FUN_60166dd0(pcVar3);
    if (iVar2 == 0) {
      iVar2 = FUN_60166dd0(pcVar1 + 0xc);
      if (iVar2 == 0) {
        local_40 = *(undefined4 *)(pcVar1 + 0x38);
        uStack_34 = *(undefined4 *)(pcVar1 + 0x24);
        local_30 = *(undefined4 *)(pcVar1 + 0x28);
        local_38 = *(undefined4 *)(pcVar1 + 0x30);
        uStack_3c = *(undefined4 *)(pcVar1 + 0x34);
        local_2c = *(int *)(pcVar1 + 0x2c) + 2000;
        iVar2 = FUN_601648ec(&local_40);
        if (iVar2 != 0) {
          FUN_60010750(pcVar3,pcVar1 + 0xc,&local_40,DAT_6000b604 + 0xa78,DAT_6000b604 + 0xa7c);
          FUN_600169a4();
          return 1;
        }
      }
    }
  }
  return 0;
}

