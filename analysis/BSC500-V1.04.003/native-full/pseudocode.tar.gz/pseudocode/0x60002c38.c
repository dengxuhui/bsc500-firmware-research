
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60002c38(void)

{
  ushort uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  char *pcVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  uint local_23c;
  uint local_230;
  undefined1 auStack_22c [96];
  undefined1 auStack_1cc [96];
  undefined1 auStack_16c [22];
  char local_156 [6];
  undefined1 auStack_150 [252];
  undefined1 auStack_54 [48];
  
  uVar1 = *(ushort *)(DAT_60002d9c + 0xb46);
  uVar4 = FUN_60030e0c();
  if (uVar4 == uVar1) {
    pcVar7 = "map file count is same, no need to clean!\n";
  }
  else {
    iVar5 = FUN_6000bc5c();
    iVar6 = FUN_6015c8a2(auStack_54,DAT_60002da0);
    pcVar7 = DAT_60002da4;
    if (iVar6 == 0) {
      iVar6 = -1;
      local_23c = 0;
      while (iVar8 = FUN_6015c834(auStack_54,auStack_16c), iVar8 == 0) {
        if (local_156[0] != '.') {
          if (local_156[0] == '\0') break;
          uVar4 = FUN_60168220(local_156);
          if (0xb < uVar4) {
            iVar10 = local_23c * 0x6e + iVar5;
            FUN_60163b68(iVar10,local_156,6);
            *(undefined1 *)(iVar10 + 6) = 0;
            FUN_60163b68(iVar10 + 7,auStack_150,6);
            *(undefined1 *)(iVar10 + 0xd) = 0;
            iVar8 = FUN_60168220(local_156);
            CopyBytes(iVar10 + 0xe,local_156,iVar8 + 1);
            iVar6 = iVar6 + 1;
            local_23c = local_23c + 1;
          }
        }
      }
      FUN_6015bd24(auStack_54);
      uVar3 = DAT_60002da8;
      uVar2 = DAT_60002da0;
      local_230 = 0;
      iVar8 = iVar5;
      do {
        iVar8 = iVar8 + 0x6e;
        if (local_23c <= local_230) {
          return;
        }
        iVar11 = local_230 * 0x6e + iVar5;
        local_230 = local_230 + 1;
        iVar10 = iVar8;
        for (iVar12 = iVar6; iVar12 != 0; iVar12 = iVar12 + -1) {
          iVar9 = FUN_60168418(iVar11,iVar10);
          if (iVar9 == 0) {
            FUN_601681f4(auStack_1cc,uVar3,uVar2,iVar11 + 0xe);
            FUN_601681f4(auStack_22c,uVar3,uVar2,iVar10 + 0xe);
            iVar9 = FUN_60168418(iVar11 + 7,iVar10 + 7);
            if (iVar9 < 0) {
              FUN_60168578(_DAT_60002dac,auStack_1cc);
              FUN_6015c57c(auStack_1cc);
              break;
            }
            FUN_60168578(_DAT_60002dac,auStack_22c);
            FUN_6015c57c(auStack_22c);
          }
          iVar10 = iVar10 + 0x6e;
        }
        iVar6 = iVar6 + -1;
      } while( true );
    }
  }
  FUN_60168578(pcVar7);
  return;
}

