
void FUN_600182cc(void)

{
  int *piVar1;
  
  piVar1 = DAT_600182e0;
  if (*DAT_600182e0 != 0) {
    FUN_601667bc();
    *piVar1 = 0;
  }
  return;
}

