
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a4e4(int param_1)

{
  char *pcVar1;
  code *pcVar2;
  code *pcVar3;
  undefined1 uVar4;
  int iVar5;
  undefined1 *puVar6;
  int iVar7;
  undefined4 extraout_r2;
  undefined4 extraout_r3;
  undefined1 auStack_d8 [8];
  undefined4 local_d0;
  undefined2 local_bc;
  undefined1 auStack_b8 [32];
  undefined1 auStack_98 [20];
  undefined1 *local_84;
  undefined1 auStack_68 [8];
  undefined2 *local_60;
  undefined1 *local_50;
  undefined2 *local_40;
  undefined1 auStack_36 [8];
  undefined2 local_2e;
  undefined1 local_2c;
  undefined1 local_2b;
  undefined2 local_2a;
  undefined4 local_28;
  undefined4 uStack_24;
  
  iVar5 = FUN_60149334();
  if ((iVar5 == 0) || (*DAT_6000a510 == 0)) {
    *DAT_6000a510 = param_1;
  }
  else if (599 < (uint)(param_1 - *DAT_6000a510)) {
    FUN_6014a9f8(0);
    *DAT_6001170c = 0;
    FUN_60168578("[BLE ADV] Updating advertisement data...\n");
    pcVar1 = _DAT_6005613c;
    local_2a = 0x481;
    local_28 = 0;
    uStack_24 = 0;
    iVar5 = *(int *)(_DAT_6005613c + 0x10);
    iVar7 = *(int *)(_DAT_6005613c + 0x14);
    if (iVar5 == 0 && iVar7 == 0) {
      FUN_60168578("[BLE ADV] [ERROR] Reading device info number from storage...\n");
      iVar5 = *(int *)(pcVar1 + 0x10);
      iVar7 = *(int *)(pcVar1 + 0x14);
    }
    FUN_60162a88(iVar5,iVar7,DAT_60056180,0);
    *(undefined4 *)(pcVar1 + 0x10) = extraout_r2;
    *(undefined4 *)(pcVar1 + 0x14) = extraout_r3;
    FUN_6005239a(extraout_r2,extraout_r3,&local_28);
    pcVar2 = DAT_60056184;
    (*DAT_60056184)(auStack_36,&local_28,8);
    local_2b = 0;
    local_2e = 0x43ff;
    local_2c = 0;
    if (*pcVar1 != '\0') {
      local_2c = 0xc0;
    }
    ZeroBytes(auStack_68,0x30);
    ZeroBytes(auStack_98,0x30);
    pcVar3 = DAT_60056188;
    local_40 = (undefined2 *)(*DAT_60056188)(0x10);
    *(undefined1 *)(local_40 + 1) = 0xc;
    *local_40 = 0x73;
    (*pcVar2)((int)local_40 + 3,auStack_36,0xc);
    local_50 = (undefined1 *)(*pcVar3)(0x12);
    *local_50 = 1;
    local_50[2] = 10;
    local_50[1] = 2;
    local_50[3] = 0x18;
    local_60 = &local_2a;
    ZeroBytes(auStack_b8,0x1f);
    FUN_60162c3a(auStack_b8,0xc,DAT_6005618c);
    iVar5 = FUN_601626c0(auStack_b8);
    puVar6 = (undefined1 *)(*pcVar3)(iVar5 + 1);
    local_84 = puVar6;
    uVar4 = FUN_601626c0(auStack_b8);
    *puVar6 = uVar4;
    (*pcVar2)(local_84 + 1,auStack_b8,*local_84);
    ZeroBytes(auStack_d8,0x20);
    local_d0 = 0x30;
    local_bc = 0x7f;
    FUN_60168578(DAT_60056190);
    iVar5 = DAT_60056194;
    iVar7 = FUN_6005cab4(*(undefined4 *)(DAT_60056194 + 4),auStack_68,auStack_98);
    if (iVar7 != 0) {
      FUN_60168578(DAT_60056198,iVar7);
    }
    FUN_60168578(DAT_6005619c);
    iVar7 = FUN_6014d820(*(undefined4 *)(iVar5 + 4));
    if (iVar7 != 0) {
      FUN_60168578(DAT_600561a0,iVar7);
    }
    FUN_60168578(DAT_600561a4);
    iVar7 = FUN_6005ca18(*(undefined4 *)(iVar5 + 4),auStack_d8);
    if (iVar7 != 0) {
      FUN_60168578(DAT_600561a8,iVar7);
    }
    FUN_60168578(DAT_600561ac);
    iVar5 = FUN_60163d34(*(undefined4 *)(iVar5 + 4));
    if (iVar5 != 0) {
      FUN_60168578(DAT_600561b0,iVar5);
    }
    pcVar2 = DAT_600561b4;
    (*DAT_600561b4)(local_40);
    (*pcVar2)(local_50);
    (*pcVar2)(local_84);
    FUN_60168578(DAT_600561b8,local_2c);
    return;
  }
  return;
}

