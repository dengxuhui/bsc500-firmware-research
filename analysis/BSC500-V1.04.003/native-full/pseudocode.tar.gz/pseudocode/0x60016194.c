
undefined4 FUN_60016194(int param_1,undefined4 *param_2,undefined4 *param_3)

{
  undefined1 uVar1;
  float fVar2;
  undefined4 uVar3;
  uint in_fpscr;
  float fVar4;
  
  uVar3 = 0xffffffff;
  if (((param_1 != 0) && (param_2 != (undefined4 *)0x0)) && (param_3 != (undefined4 *)0x0)) {
    *param_3 = param_2[0xd2];
    FUN_60118c40(param_2 + 0xd3,param_2 + 0xd5,param_3 + 1,param_3 + 2);
    fVar2 = DAT_60016254;
    param_3[8] = *(undefined4 *)((int)param_2 + 0x36a);
    param_3[7] = *(undefined4 *)((int)param_2 + 0x366);
    uVar3 = *param_2;
    param_3[4] = param_2[0xd8];
    param_3[5] = param_2[0xd7];
    *(undefined2 *)(param_3 + 6) = *(undefined2 *)((int)param_2 + 0x382);
    *(undefined2 *)((int)param_3 + 0x1a) = *(undefined2 *)(param_2 + 0xd9);
    *(undefined2 *)(param_3 + 9) = *(undefined2 *)((int)param_2 + 0x36e);
    fVar4 = (float)VectorUnsignedToFloat(uVar3,(byte)(in_fpscr >> 0x16) & 3);
    *(undefined1 *)(param_3 + 0xc) = *(undefined1 *)(param_2 + 0xde);
    *(undefined1 *)((int)param_3 + 0x31) = *(undefined1 *)((int)param_2 + 0x379);
    *(undefined1 *)((int)param_3 + 0x32) = *(undefined1 *)((int)param_2 + 0x37a);
    *(undefined1 *)((int)param_3 + 0x33) = *(undefined1 *)((int)param_2 + 0x37b);
    *(undefined2 *)((int)param_3 + 0x26) = *(undefined2 *)(param_2 + 0xdc);
    *(undefined2 *)(param_3 + 10) = *(undefined2 *)((int)param_2 + 0x372);
    *(undefined2 *)((int)param_3 + 0x2a) = *(undefined2 *)(param_2 + 0xdd);
    *(undefined2 *)(param_3 + 0xb) = *(undefined2 *)((int)param_2 + 0x376);
    uVar1 = *(undefined1 *)(param_2 + 0xdf);
    param_3[3] = fVar4 / fVar2;
    *(undefined1 *)(param_3 + 0xd) = uVar1;
    *(undefined1 *)((int)param_3 + 0x35) = *(undefined1 *)((int)param_2 + 0x37d);
    uVar3 = 0;
    *(undefined1 *)((int)param_3 + 0x2f) = 0;
  }
  return uVar3;
}

