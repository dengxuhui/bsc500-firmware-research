
void FUN_6000bdb8(void)

{
  bool bVar1;
  char *pcVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  float fVar10;
  
  iVar4 = FUN_60164dd4();
  iVar5 = FUN_60164dbc();
  iVar6 = FUN_60167080();
  if (*(char *)(iVar6 + 0x16) != '\0') {
    return;
  }
  iVar6 = FUN_601639fc();
  iVar7 = FUN_60163b60();
  if ((iVar5 == 0) && (iVar5 = iVar4, iVar4 == 0)) {
    return;
  }
  if (*(char *)(iVar7 + 0x31) == '\0') {
    return;
  }
  if (*(char *)(iVar6 + 0x1b) != '\0') {
    return;
  }
  fVar10 = *(float *)(iVar5 + 0x28);
  iVar5 = FUN_60163b60();
  iVar4 = FUN_60166dd0();
  if (iVar4 != 0) {
    return;
  }
  iVar4 = FUN_60166dd0(iVar5 + 8);
  pcVar2 = DAT_6000bee4;
  if (iVar4 != 0) {
    return;
  }
  if (((fVar10 <= 0.0) || (DAT_6000bee8 < fVar10)) || (*DAT_6000bee4 != '\x11')) {
    bVar1 = false;
    iVar4 = 4;
    if (fVar10 != 0.0 && fVar10 <= DAT_6000bee8 || *DAT_6000bee4 != '\x10') goto LAB_6000be7a;
    cVar3 = '\x11';
  }
  else {
    iVar4 = 6;
    cVar3 = '\x10';
  }
  bVar1 = true;
  *DAT_6000bee4 = cVar3;
LAB_6000be7a:
  iVar6 = DAT_6000beec;
  iVar9 = *(int *)(DAT_6000beec + 0x1c);
  iVar7 = FUN_60163b54();
  if (((iVar9 == iVar7) && (iVar7 = FUN_60163b54(), iVar4 == iVar7)) ||
     ((bVar1 || (*pcVar2 == '\x10')))) {
    iVar9 = *(int *)(iVar5 + 0x28);
    *(int *)(iVar6 + 0x18) = iVar9;
    iVar7 = iVar9;
  }
  else {
    iVar9 = *(int *)(iVar6 + 0x18);
    iVar7 = *(int *)(iVar5 + 0x28);
  }
  if ((bVar1) || (30000 < (uint)(iVar7 - iVar9))) {
    FUN_60160d64(iVar4);
    *(int *)(iVar6 + 0x1c) = iVar4;
  }
  else {
    iVar4 = *(int *)(iVar6 + 0x1c);
  }
  iVar7 = FUN_60163b54();
  if (iVar4 != iVar7) {
    *(undefined4 *)(iVar6 + 0x18) = *(undefined4 *)(iVar5 + 0x28);
    uVar8 = FUN_60163b54();
    *(undefined4 *)(iVar6 + 0x1c) = uVar8;
  }
  return;
}

