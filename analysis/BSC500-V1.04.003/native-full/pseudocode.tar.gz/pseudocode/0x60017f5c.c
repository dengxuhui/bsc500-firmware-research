
undefined4 * FUN_60017f5c(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  int *piVar9;
  
  puVar5 = DAT_60018094;
  uVar1 = DAT_60018038;
  *DAT_60018094 = 0;
  puVar5[1] = 0;
  FUN_6013a69a(uVar1);
  uVar1 = DAT_60018040;
  puVar5[0xd] = DAT_6001803c;
  puVar5[0xe] = 300;
  puVar5[0xc] = uVar1;
  FUN_6013a692(puVar5 + 0xc);
  uVar2 = DAT_60018048;
  puVar5[0x13] = DAT_60018044;
  puVar5[0x11] = 100;
  puVar5[0x10] = uVar2;
  FUN_6013a67e(puVar5 + 0x10);
  uVar2 = DAT_6001804c;
  puVar5[0x18] = DAT_6001804c;
  puVar5[0x1c] = 0x14;
  puVar5[0x19] = 100;
  FUN_6013a662(puVar5 + 0x18);
  iVar3 = DAT_60018054;
  iVar6 = DAT_60018050;
  puVar5[2] = uVar1;
  puVar5[3] = 300;
  puVar5[4] = uVar2;
  puVar5[5] = 100;
  for (iVar7 = 0; piVar4 = DAT_60018058, iVar7 != 0x80; iVar7 = iVar7 + 0x10) {
    *(int *)(iVar3 + iVar7) = iVar6;
    iVar6 = iVar6 + 0x4b0;
    *(undefined4 *)(iVar3 + iVar7 + 0xc) = 0x32;
  }
  DAT_60018058[5] = 0;
  *piVar4 = iVar3;
  piVar4[1] = (int)(puVar5 + 1);
  piVar4[2] = 8;
  FUN_6013a652(piVar4);
  iVar3 = DAT_60018060;
  iVar6 = DAT_6001805c;
  piVar9 = piVar4 + 0xe;
  puVar8 = puVar5 + 4;
  piVar4[6] = (int)piVar4;
  piVar4[7] = (int)puVar8;
  piVar4[8] = iVar3;
  piVar4[9] = (int)piVar9;
  piVar4[10] = iVar6;
  piVar4[0xb] = 300;
  piVar4[0xc] = 100;
  FUN_6013a64a(piVar4 + 6);
  puVar5[0x14] = piVar4;
  puVar5[0x15] = puVar8;
  puVar5[0x16] = piVar9;
  puVar5[6] = iVar3;
  puVar5[7] = iVar6;
  puVar5[8] = 0;
  FUN_6013a642(puVar5 + 0x14);
  puVar5[9] = piVar4;
  puVar5[10] = puVar8;
  puVar5[0xb] = piVar9;
  return puVar5 + 0xc;
}

