
undefined4 FUN_60017edc(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined2 local_24;
  undefined1 local_22;
  undefined1 uStack_21;
  undefined1 local_20;
  undefined1 local_1d;
  undefined1 local_11;
  
  iVar1 = FUN_6015f704();
  uVar2 = 0;
  if ((iVar1 == 1) && (iVar1 = FUN_60161a98(), iVar1 != 0)) {
    FUN_60168578("-->navi_request_reroute_to_app\n");
    *DAT_60017f58 = 0;
    FUN_60166858(&uStack_21,0x11,0xff);
    local_1d = 0;
    local_22 = 0;
    local_20 = 10;
    local_24 = 0x703;
    local_11 = FUN_60160db4(&local_24,0x13);
    FUN_6015e018(&local_24);
    uVar2 = 1;
  }
  return uVar2;
}

