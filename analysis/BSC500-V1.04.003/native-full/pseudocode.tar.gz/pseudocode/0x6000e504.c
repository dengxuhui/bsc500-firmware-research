
undefined4 FUN_6000e504(undefined4 *param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  
  iVar1 = DAT_6000e540;
  uVar3 = 0;
  *(undefined1 *)(DAT_6000e540 + 0x68) = 0;
  *(undefined1 *)(iVar1 + 0x42) = 0;
  *(undefined2 *)(iVar1 + 0x40) = 0;
  FUN_60018dcc();
  FUN_600191ec();
  FUN_60018a94();
  if (param_1 == (undefined4 *)0x0) {
    *(undefined4 *)(iVar1 + 0x44) = 0;
    *(undefined4 *)(iVar1 + 0x48) = 0;
  }
  else {
    uVar2 = param_1[1];
    uVar3 = param_1[2];
    *(undefined4 *)(iVar1 + 0x44) = *param_1;
    *(undefined4 *)(iVar1 + 0x48) = uVar2;
  }
  *(undefined4 *)(iVar1 + 0x4c) = uVar3;
  *(undefined1 *)(iVar1 + 0x40) = 1;
  return 0;
}

