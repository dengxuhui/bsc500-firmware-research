
undefined4 FUN_60004d18(undefined4 param_1)

{
  int iVar1;
  undefined4 local_38;
  undefined1 auStack_34 [32];
  undefined4 local_14;
  
  local_14 = 0;
  ZeroBytes(auStack_34,0x20);
  local_38 = 0;
  iVar1 = FUN_60166758(&local_14,param_1,1);
  if (iVar1 != 0) {
    return 0;
  }
  FUN_601667bc(local_14);
  iVar1 = FUN_60166758(&local_14,DAT_60004dc8,1);
  if (iVar1 == 0) {
    ZeroBytes(auStack_34,0x20);
    FUN_60161ef4(local_14,auStack_34,0x1f,&local_38);
    iVar1 = FUN_60166834(auStack_34,DAT_60004dcc);
    FUN_601667bc(local_14);
    if (iVar1 != 0) {
      return 1;
    }
    FUN_60163bbe(param_1);
    local_14 = 0;
    iVar1 = FUN_60166758(&local_14,DAT_60004dd0,1);
    if (iVar1 == 0) {
      ZeroBytes(auStack_34,0x20);
      FUN_60161ef4(local_14,auStack_34,0x1f,&local_38);
      iVar1 = FUN_60166834(auStack_34,DAT_60004dcc);
      FUN_601667bc(local_14);
      if (iVar1 != 0) {
        return 1;
      }
    }
  }
  FUN_60163bbe(param_1);
  return 0;
}

