
void FUN_6000d73c(void)

{
  char *pcVar1;
  undefined4 uVar2;
  
  uVar2 = FUN_6016717c();
  pcVar1 = DAT_6000d760;
  *(undefined4 *)(DAT_6000d760 + 4) = uVar2;
  if (*pcVar1 == '\x01') {
    FUN_6016507e(pcVar1 + 0xc,3000,0);
    *pcVar1 = '\0';
  }
  return;
}

