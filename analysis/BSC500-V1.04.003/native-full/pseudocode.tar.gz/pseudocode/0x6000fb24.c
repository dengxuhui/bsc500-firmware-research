
void FUN_6000fb24(void)

{
  int *piVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  iVar2 = FUN_60164eb0(2);
  piVar3 = (int *)(iVar2 + 4);
  while (piVar3 = (int *)*piVar3, piVar3 != (int *)(iVar2 + 4)) {
    piVar1 = piVar3 + 2;
    if ((int *)*piVar1 != piVar1) {
      piVar4 = piVar1;
      while (piVar4 = (int *)*piVar4, piVar4 != piVar1) {
        FUN_60161424("owner %s wait sem %s\n",piVar4 + -7,piVar3 + -5);
      }
    }
  }
  return;
}

