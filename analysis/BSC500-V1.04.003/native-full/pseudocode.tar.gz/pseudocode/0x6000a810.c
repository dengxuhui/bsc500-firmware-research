
void FUN_6000a810(void)

{
  int iVar1;
  code *pcVar2;
  int iVar3;
  
  iVar1 = DAT_6000a828;
  for (iVar3 = 0; iVar3 != 8; iVar3 = iVar3 + 1) {
    pcVar2 = *(code **)(iVar1 + iVar3 * 4);
    if (pcVar2 != (code *)0x0) {
      (*pcVar2)();
    }
  }
  return;
}

