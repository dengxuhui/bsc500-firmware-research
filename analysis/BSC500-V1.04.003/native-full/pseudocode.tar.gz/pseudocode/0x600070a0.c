
void FUN_600070a0(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  uint in_fpscr;
  float fVar5;
  undefined1 auStack_24 [20];
  
  iVar2 = FUN_6016708c();
  ZeroBytes(auStack_24,0x14);
  iVar1 = DAT_60007414;
  iVar3 = *(int *)(DAT_60007414 + 0x330);
  if (iVar3 << 0xc < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(10,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    ZeroBytes(auStack_24,0x14);
    FUN_601681f4(auStack_24,DAT_60007418,*(undefined1 *)(iVar1 + 0xe));
    FUN_60163e70(DAT_6000741c + 5,auStack_24,0);
    FUN_601203e4(1);
    FUN_600132cc(1,*(undefined1 *)(iVar1 + 0xe),
                 *(undefined1 *)(DAT_60007420 + iVar2 * 0x38 + 0x4690));
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 0xb < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(0xb,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    ZeroBytes(auStack_24,0x14);
    FUN_601681f4(auStack_24,DAT_60007418,*(undefined1 *)(iVar1 + 0xe));
    FUN_60163e70(DAT_6000741c + 6,auStack_24,0);
    FUN_601203e4(2);
    FUN_600132cc(0,*(undefined1 *)(iVar1 + 0xe),
                 *(undefined1 *)(DAT_60007420 + iVar2 * 0x38 + 0x4691));
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 8 < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(0x10,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_600132f0(1,*(undefined2 *)(iVar1 + 10),*(undefined2 *)(DAT_60007420 + iVar2 * 0x38 + 0x4694)
                );
    ZeroBytes(auStack_24,0x14);
    FUN_601681f4(auStack_24,DAT_60007424,*(undefined2 *)(iVar1 + 10));
    FUN_60163e70(DAT_6000741c + 9,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 7 < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(0x11,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_600132f0(0,*(undefined2 *)(iVar1 + 10),*(undefined2 *)(DAT_60007420 + iVar2 * 0x38 + 0x4696)
                );
    ZeroBytes(auStack_24,0x14);
    FUN_601681f4(auStack_24,DAT_60007424,*(undefined2 *)(iVar1 + 10));
    FUN_60163e70(DAT_6000741c + 10,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 6 < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(7,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_60013314(1,*(undefined4 *)(iVar1 + 4),*(undefined2 *)(DAT_60007420 + iVar2 * 0x38 + 0x4698))
    ;
    ZeroBytes(auStack_24,0x14);
    fVar5 = (float)VectorUnsignedToFloat(*(undefined4 *)(iVar1 + 4),(byte)(in_fpscr >> 0x16) & 3);
    FUN_6001a91c(fVar5 / DAT_60007428,1,1,auStack_24);
    FUN_60163e70(DAT_6000741c + 3,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 5 < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(8,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_60013314(0,*(undefined4 *)(iVar1 + 4),*(undefined2 *)(DAT_60007420 + iVar2 * 0x38 + 0x469a))
    ;
    ZeroBytes(auStack_24,0x14);
    fVar5 = (float)VectorUnsignedToFloat(*(undefined4 *)(iVar1 + 4),(byte)(in_fpscr >> 0x16) & 3);
    FUN_6001a91c(fVar5 / DAT_60007428,1,1,auStack_24);
    FUN_60163e70(DAT_6000741c + 4,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 10 < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(0xd,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_600132a8(1,*(undefined1 *)(iVar1 + 0xf),
                 *(undefined1 *)(DAT_60007420 + iVar2 * 0x38 + 0x4692));
    ZeroBytes(auStack_24,0x14);
    FUN_601681f4(auStack_24,DAT_6000742c,*(undefined1 *)(iVar1 + 0xf));
    FUN_60163e70(DAT_6000741c + 7,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 9 < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(0xe,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_600132a8(0,*(undefined1 *)(iVar1 + 0xf),
                 *(undefined1 *)(DAT_60007420 + iVar2 * 0x38 + 0x4693));
    ZeroBytes(auStack_24,0x14);
    FUN_601681f4(auStack_24,DAT_6000742c,*(undefined1 *)(iVar1 + 0xf));
    FUN_60163e70(DAT_6000741c + 8,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  iVar2 = DAT_6000741c;
  if (iVar3 << 0xf < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(0,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_60163e70(iVar2,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 0xe < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(2,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_60163e70(iVar2 + 1,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 0xd < 0) {
    uVar4 = FUN_601671f0();
    iVar3 = FUN_6014afc0(4,uVar4,auStack_24);
    if (iVar3 == 0) {
      return;
    }
    FUN_60163e70(iVar2 + 2,auStack_24,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 3 < 0) {
    FUN_60163e70(iVar2 + 0xe,0,0);
    iVar3 = *(int *)(iVar1 + 0x330);
  }
  if (iVar3 << 4 < 0) {
    FUN_60163e70(iVar2 + 0xd,0,0);
  }
  return;
}

