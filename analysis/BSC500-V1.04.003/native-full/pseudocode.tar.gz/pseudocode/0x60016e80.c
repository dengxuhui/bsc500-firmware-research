
void FUN_60016e80(undefined4 *param_1)

{
  undefined4 uVar1;
  uint uVar2;
  
  FUN_601608ac(param_1,0x58);
  *param_1 = DAT_60016eb8;
  param_1[1] = 0xffffffff;
  uVar1 = DAT_60016ebc;
  param_1[2] = 0;
  param_1[0x10] = uVar1;
  param_1[0x11] = uVar1;
  param_1[0x12] = 0x54;
  uVar2 = DAT_60016ec0;
  *(undefined2 *)(param_1 + 0xe) = 0x7e0;
  param_1[4] = param_1[4] & uVar2 | 0x4108;
  return;
}

