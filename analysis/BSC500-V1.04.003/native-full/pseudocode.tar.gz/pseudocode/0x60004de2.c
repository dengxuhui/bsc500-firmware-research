
bool FUN_60004de2(void)

{
  int iVar1;
  
  iVar1 = FUN_6000ad50();
  if (iVar1 != 0) {
    return true;
  }
  iVar1 = FUN_6000ad50();
  return iVar1 != 0;
}

