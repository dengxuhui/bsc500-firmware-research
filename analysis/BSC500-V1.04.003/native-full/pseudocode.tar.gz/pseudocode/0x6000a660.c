
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a660(void)

{
  FUN_60161424("Firmware name: %s, hardware version: %s, software version: %s",_DAT_6000a680 + 0x11,
               _DAT_6000a680 + 0x31,_DAT_6000a680 + 0x51);
  FUN_60161424(DAT_6000a6c4);
  return;
}

