
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60018700 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_600186ec(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  float fVar3;
  undefined8 local_30;
  undefined8 local_28;
  undefined8 local_20;
  undefined8 local_18;
  
  if ((((param_1 != (undefined8 *)0x0) && (param_2 != (undefined8 *)0x0)) &&
      (iVar1 = FUN_60137930((int)*param_1,(int)((ulonglong)*param_1 >> 0x20),(int)param_1[1],
                            0xffffffff), iVar1 != 0)) &&
     (iVar1 = FUN_60137930((int)*param_2,(int)((ulonglong)*param_2 >> 0x20),(int)param_2[1]),
     iVar1 != 0)) {
    fVar3 = (float)*param_1;
    FUN_60161ad0(fVar3,(int)((ulonglong)*param_1 >> 0x20),(int)param_1[1],
                 (int)((ulonglong)param_1[1] >> 0x20),(int)*param_2,
                 (int)((ulonglong)*param_2 >> 0x20),(int)param_2[1]);
    uVar2 = DAT_60018790;
    if ((1.0 <= fVar3) && ((int)(fVar3 * DAT_60018784) <= DAT_60018a70)) {
      *DAT_60018788 = -(~(int)(fVar3 * DAT_60018784) >> 0x1f);
      local_30 = *param_1;
      local_28 = param_1[1];
      local_20 = *param_2;
      local_18 = param_2[1];
      uVar2 = FUN_60020be0(&local_30,2,2,uVar2,1,0,DAT_6001878c);
      return uVar2;
    }
  }
  return 0xffffffff;
}

