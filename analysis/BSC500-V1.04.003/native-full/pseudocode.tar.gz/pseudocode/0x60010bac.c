
int * FUN_60010bac(int *param_1)

{
  *param_1 = DAT_60010bd0 + 8;
  param_1[1] = 0;
  FUN_600e7fa8(param_1 + 2);
  FUN_600e7fa8(param_1 + 0xe);
  return param_1;
}

