
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600188e0(void)

{
  if ((*(char *)(_DAT_600188fc + 1) == '\0') && (*(char *)(_DAT_600188fc + 3) != '\x01')) {
    return 0;
  }
  FUN_60168578("fit is decodeing...\r\n");
  return 1;
}

