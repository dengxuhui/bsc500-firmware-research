
void FUN_600169a4(void)

{
  int iVar1;
  int iVar2;
  undefined1 auStack_3c [44];
  
  iVar1 = DAT_600169e8;
  FUN_60163c5c(*DAT_600169e4 + *(int *)(DAT_600169e8 + 8),auStack_3c);
  iVar2 = DAT_600169ec;
  FUN_60010b28(*(undefined4 *)(DAT_600169ec + 0xa78),*(undefined4 *)(DAT_600169ec + 0xa7c),
               *(undefined4 *)(DAT_600169ec + 0xa74));
  FUN_60010720(auStack_3c,*(undefined4 *)(iVar2 + 0xa78),*(undefined4 *)(iVar2 + 0xa7c),iVar1,
               iVar1 + 4);
  return;
}

