
void FUN_600040a4(int *param_1)

{
  int iVar1;
  
  iVar1 = DAT_600040c8;
  if (param_1 != (int *)0x0) {
    param_1[2] = DAT_600040c8;
    param_1[3] = 3;
    param_1[4] = 0;
    param_1[5] = 0;
    param_1[6] = 0;
    param_1[7] = 0;
    param_1[8] = 0;
    *(undefined2 *)(param_1 + 1) = 10;
    *param_1 = iVar1 + 0xc;
  }
  return;
}

