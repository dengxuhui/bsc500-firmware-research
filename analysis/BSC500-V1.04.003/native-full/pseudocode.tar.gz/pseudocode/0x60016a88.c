
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60016a88(void)

{
  undefined4 local_20;
  char *local_1c;
  undefined4 local_18;
  
  local_18 = _DAT_60016ac0;
  local_1c = "Format All now...";
  local_20 = _DAT_60016bc0;
  FUN_6001e130(&local_20);
  return;
}

