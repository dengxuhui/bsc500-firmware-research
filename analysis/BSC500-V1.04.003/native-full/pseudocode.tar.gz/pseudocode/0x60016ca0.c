
void thunk_FUN_6001be2c(undefined4 param_1,undefined4 param_2)

{
  FUN_60139d78(2,param_1,param_2);
  FUN_6015de78();
  return;
}

