
void FUN_600089d8(void)

{
  short sVar1;
  char *pcVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  
  pcVar2 = DAT_60008a8c;
  if (*DAT_60008a8c == '\0') {
    if ((*DAT_60008a94 != 0xffff) || (*DAT_60008a98 != 0)) {
      FUN_6012e25c();
      return;
    }
  }
  else {
    iVar3 = FUN_6015c548(*(undefined4 *)(DAT_60008a8c + 0xc4),0);
    if (((iVar3 == 0) || (*(short *)(pcVar2 + 0xd0) == -1)) ||
       (*(short *)(DAT_60008a90 + 0x288) == 0x7fff)) {
      uVar4 = (uint)*DAT_60008a94;
    }
    else {
      uVar4 = FUN_6001b394(*(undefined2 *)(pcVar2 + 0xc4),*(short *)(pcVar2 + 0xd0),
                           (int)*(short *)(DAT_60008a90 + 0x288));
      *DAT_60008a94 = (ushort)uVar4;
    }
    if (uVar4 != 0xffff) {
      sVar1 = *DAT_60008a98;
      if (sVar1 < 1) {
        if (((sVar1 != -1) && (49999 < *(uint *)(DAT_60008a90 + 0x1b4))) &&
           (*(uint *)(DAT_60008a90 + 0x1c8) <= DAT_60008a9c)) {
          uVar5 = (uint)*(ushort *)(pcVar2 + 0x1c);
          iVar3 = uVar4 - uVar5;
          if (uVar4 < uVar5) {
            iVar3 = uVar5 - uVar4;
          }
          if (uVar5 * 5 <= (uint)(iVar3 * 1000) && iVar3 * 1000 + uVar5 * -5 != 0) {
            *DAT_60008a98 = -1;
            FUN_60164914(DAT_60008aa0);
            return;
          }
        }
      }
      else {
        *DAT_60008a98 = sVar1 + -1;
      }
    }
  }
  return;
}

