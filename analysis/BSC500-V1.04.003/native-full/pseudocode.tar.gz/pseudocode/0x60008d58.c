
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60008d58(int param_1,undefined4 param_2,undefined1 *param_3)

{
  undefined4 uVar1;
  undefined1 uVar2;
  
  if (param_1 == 1) {
    uVar1 = DAT_60008d84;
    if (*(char *)(_DAT_60009010 + 5) == '\0') goto LAB_60008d78;
    uVar2 = 0;
  }
  else {
    if (param_1 != 0) {
      return 0;
    }
    uVar1 = DAT_60008d88;
    if (*(char *)(_DAT_60009010 + 5) != '\0') goto LAB_60008d78;
    uVar2 = 1;
  }
  *(undefined1 *)(_DAT_60009010 + 5) = uVar2;
LAB_60008d78:
  FUN_60168578(uVar1,*param_3,param_3[1]);
  return 0;
}

