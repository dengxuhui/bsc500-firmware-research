
undefined4 FUN_60017188(void)

{
  int iVar1;
  
  iVar1 = DAT_600171a0;
  *(undefined4 *)(DAT_600171a0 + 0x1c) = 0x7fffffff;
  *(undefined4 *)(iVar1 + 0x20) = 1;
  *(undefined4 *)(iVar1 + 0x24) = 0x7fffffff;
  *(undefined4 *)(iVar1 + 0x28) = 1;
  *(undefined4 *)(iVar1 + 0x2c) = 0;
  return 0;
}

