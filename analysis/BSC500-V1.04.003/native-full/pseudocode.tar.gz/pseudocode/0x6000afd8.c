
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000afd8(void)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  undefined1 auStack_84 [96];
  uint local_24;
  uint local_20;
  undefined4 local_1c;
  undefined4 local_18;
  
  FUN_60167188(5000);
  FUN_60164e2c(1);
  FUN_60164a4c(6);
  iVar3 = DAT_6000b0fc;
  if (*(int *)(DAT_6000b0fc + 4) == 0) {
    local_18 = 0;
    FUN_601681f4(auStack_84,DAT_6000b100,DAT_6000b104,_DAT_6000b108);
    iVar1 = FUN_60166758(&local_18,auStack_84,1);
    if (iVar1 == 0) {
      uVar2 = FUN_6016506c(local_18);
      *(undefined4 *)(iVar3 + 4) = uVar2;
      FUN_60168578("******gnss_fw_size = %d ****** \n",uVar2);
      FUN_601667bc(local_18);
      if (*(uint *)(iVar3 + 4) >> 0x14 == 0) {
        return 0;
      }
    }
  }
  FUN_600169f8();
  FUN_60016a18();
  FUN_60016a88();
  iVar3 = FUN_60016ad8();
  FUN_60016a80();
  FUN_600169f0();
  FUN_601559f8();
  if (iVar3 != 0) {
    FUN_60168578("gnss_fw_download success\n");
    FUN_60163bbe(DAT_6000b14c);
    local_1c = 0;
    local_18 = 0;
    local_24 = 0;
    local_20 = 0;
    iVar3 = FUN_60166758(&local_18,DAT_6000b150,1);
    if (iVar3 == 0) {
      iVar3 = FUN_60166758(&local_1c,DAT_6000b14c,10);
      if (iVar3 == 0) {
        while ((iVar3 = FUN_60161ef4(local_18,auStack_84,10,&local_20), iVar3 == 0 &&
               (local_20 != 0))) {
          local_24 = 0;
          iVar3 = FUN_60164ed8(local_1c,auStack_84,local_20,&local_24);
          if ((iVar3 != 0) || ((local_24 != local_20 || (local_20 < 10)))) break;
          local_20 = 0;
        }
        FUN_601667bc(local_1c);
      }
      FUN_601667bc(local_18);
    }
    uVar2 = DAT_6000b154;
    FUN_6015b088(DAT_6000b154);
    FUN_60163bbe(uVar2);
  }
  FUN_60167188(2000);
  FUN_6015f088(1);
  FUN_60164e80(1);
  FUN_60164afc(6);
  return 1;
}

