
void FUN_6000d504(void)

{
  int iVar1;
  
  iVar1 = FUN_60163b60();
  if (*(char *)(iVar1 + 0x33) != '\0') {
    FUN_6001ddec();
    return;
  }
  return;
}

