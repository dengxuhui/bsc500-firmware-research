
undefined4 FUN_6000c0dc(void)

{
  int iVar1;
  undefined4 extraout_r3;
  undefined4 uVar2;
  undefined4 local_10;
  undefined4 local_c;
  
  iVar1 = DAT_6000c0f4;
  ZeroBytes(DAT_6000c0f4,0x98);
  *(undefined1 *)(iVar1 + 1) = 3;
  local_10 = 0;
  local_c = extraout_r3;
  iVar1 = FUN_60166758(&local_c,DAT_60017e9c,1);
  if (iVar1 == 0) {
    uVar2 = FUN_60161ef4(local_c,DAT_60017ea0,0x98,&local_10);
    FUN_601667bc(local_c);
  }
  else {
    uVar2 = 0xffffffff;
  }
  return uVar2;
}

