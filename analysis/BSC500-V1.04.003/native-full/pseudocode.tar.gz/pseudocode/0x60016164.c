
undefined4 FUN_60016164(int param_1,int param_2,int param_3,int *param_4)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  
  uVar4 = 0xffffffff;
  if (((param_1 != 0) && (param_2 != 0)) && (param_4 != (int *)0x0)) {
    if (*param_4 == -1) {
      *(undefined1 *)((int)param_4 + 0xe) = 0;
      *(undefined2 *)(param_4 + 3) = 1;
      param_4[1] = 1;
    }
    iVar2 = *(int *)(param_1 + 4);
    iVar1 = *(int *)(param_1 + 0xc);
    iVar3 = *(int *)(param_3 + 0x14);
    uVar4 = 0;
    *param_4 = iVar2;
    param_4[1] = iVar3;
    param_4[2] = iVar1 + iVar2;
  }
  return uVar4;
}

