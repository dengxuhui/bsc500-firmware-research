
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60004b60(int param_1,int param_2)

{
  if (param_1 != 0) {
    if (param_2 != 0) {
      *(int *)(param_1 + 4) = param_2;
    }
    return;
  }
                    /* WARNING: Subroutine does not return */
  FUN_6016804c(_DAT_60004b74,"erpc_client_add_pre_cb_action",0xa5);
}

