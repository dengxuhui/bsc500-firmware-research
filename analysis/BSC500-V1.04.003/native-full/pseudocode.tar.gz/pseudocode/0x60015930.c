
int FUN_60015930(int param_1,byte *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = FUN_60168220(param_2);
  iVar2 = 0;
  while (iVar1 != 0) {
    iVar1 = iVar1 + -1;
    iVar3 = -0x37;
    if (*param_2 < 0x3a) {
      iVar3 = -0x30;
    }
    iVar2 = iVar2 * param_1 + (uint)*param_2 + iVar3;
    param_2 = param_2 + 1;
  }
  return iVar2;
}

