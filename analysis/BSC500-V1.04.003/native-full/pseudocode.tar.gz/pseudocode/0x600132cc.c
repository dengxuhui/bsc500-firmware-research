
void FUN_600132cc(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 uVar1;
  int iVar2;
  undefined2 uStack_90;
  undefined1 uStack_8e;
  undefined1 uStack_86;
  undefined1 uStack_76;
  undefined1 uStack_75;
  undefined1 uStack_74;
  undefined4 uStack_70;
  undefined1 uStack_6c;
  undefined4 uStack_68;
  
  iVar2 = FUN_6014893c();
  if (iVar2 != 0) {
    uVar1 = 4;
    if (param_1 != 0) {
      uVar1 = 3;
    }
    ZeroBytes(&uStack_90,0x7c);
    uStack_6c = 1;
    uStack_74 = 1;
    uStack_76 = 1;
    uStack_86 = 1;
    uStack_8e = 1;
    uStack_90 = 0x36e;
    uStack_75 = uVar1;
    uStack_70 = param_2;
    uStack_68 = param_3;
    FUN_60156dac(&uStack_90);
    return;
  }
  return;
}

