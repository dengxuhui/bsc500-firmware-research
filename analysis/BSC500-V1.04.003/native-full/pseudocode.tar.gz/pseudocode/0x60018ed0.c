
void FUN_60018ed0(void)

{
  int iVar1;
  
  iVar1 = DAT_60018ee4;
  if (*(int *)(DAT_60018ee4 + 4) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 4) = 0;
  }
  return;
}

