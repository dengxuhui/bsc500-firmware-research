
undefined4 FUN_60011f64(uint param_1,undefined4 *param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  uVar2 = (uint)*DAT_60011f90;
  if (3 < uVar2) {
    uVar2 = 4;
  }
  do {
    if (uVar2 <= uVar3) {
      return 3;
    }
    iVar1 = uVar3 * 8;
    uVar3 = uVar3 + 1;
  } while (DAT_60011f90[iVar1 + 4] != param_1);
  *param_2 = *(undefined4 *)(DAT_60011f90 + uVar3 * 8);
  return 0;
}

