
void FUN_60016db4(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3,undefined4 *param_4,
                 undefined4 *param_5,undefined4 *param_6)

{
  int iVar1;
  
  iVar1 = DAT_60016dd8;
  *param_1 = *(undefined4 *)(DAT_60016dd8 + 0x1c);
  *param_2 = *(undefined4 *)(iVar1 + 0x18);
  *param_3 = *(undefined4 *)(iVar1 + 0x14);
  *param_4 = *(undefined4 *)(iVar1 + 0x10);
  *param_5 = *(undefined4 *)(iVar1 + 0xc);
  *param_6 = *(undefined4 *)(iVar1 + 8);
  return;
}

