
undefined4 FUN_60008188(int *param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int iVar3;
  byte bVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint in_fpscr;
  uint uVar8;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr2;
  undefined4 in_cr8;
  float fVar9;
  float fVar10;
  float fVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  
  uVar1 = 0xffffffff;
  if ((param_1 != (int *)0x0) && (param_2 != (undefined4 *)0x0)) {
    bVar4 = *(byte *)((int)param_1 + 5);
    if ((uint)bVar4 < (uint)*(byte *)(param_1 + 1)) {
      *(undefined4 *)(*param_1 + (uint)bVar4 * 4) = *param_2;
      *(byte *)((int)param_1 + 5) = bVar4 + 1;
    }
    else {
      iVar3 = *(byte *)(param_1 + 1) - 1;
      for (iVar5 = 0; iVar5 < iVar3; iVar5 = iVar5 + 1) {
        *(undefined4 *)(*param_1 + iVar5 * 4) = *(undefined4 *)(*param_1 + iVar5 * 4 + 4);
      }
      *(undefined4 *)(*param_1 + iVar3 * 4) = *param_2;
    }
    uVar2 = FUN_6015e58a(param_1 + 2,*param_2);
    if (uVar2 - 0xb < 0x5d1) {
      uVar12 = FUN_601673c4();
      FUN_601678fc((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)DAT_600083c8,
                   (int)((ulonglong)DAT_600083c8 >> 0x20));
      iVar3 = FUN_6015e530();
      uVar2 = iVar3 - 0x18;
    }
    else if (uVar2 < 0x5dd) {
      uVar2 = 0;
    }
    else {
      uVar12 = FUN_601673c4();
      FUN_601678fc((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)DAT_600083c0,
                   (int)((ulonglong)DAT_600083c0 >> 0x20));
      iVar3 = FUN_6015e530();
      uVar2 = iVar3 + 0x3f4;
    }
    iVar3 = 1;
    do {
      iVar5 = iVar3;
      if (iVar5 == 0x1a) {
        bVar4 = 0;
        goto LAB_60008242;
      }
      iVar3 = iVar5 + 1;
    } while (*(uint *)(DAT_600083d8 + iVar5 * 4) <= uVar2);
    bVar4 = (char)iVar5 - 1;
LAB_60008242:
    iVar3 = DAT_600083e0;
    if (*(char *)(param_2 + 1) == '\0') {
      iVar3 = DAT_600083dc;
    }
    uVar6 = (uint)*(byte *)(iVar3 + (uint)bVar4 * 4);
    if (0x39d0 < uVar2) {
      uVar6 = 100;
    }
    fVar10 = (float)param_1[7];
    uVar7 = uVar6 - (int)fVar10;
    uVar2 = in_fpscr & 0xfffffff | (uint)(fVar10 < DAT_600083e4) << 0x1f |
            (uint)(fVar10 == DAT_600083e4) << 0x1e;
    uVar8 = uVar2 | (uint)(NAN(fVar10) || NAN(DAT_600083e4)) << 0x1c;
    if ((int)uVar7 < 0) {
      uVar7 = -uVar7;
    }
    bVar4 = (byte)(uVar2 >> 0x18);
    if (((bool)(bVar4 >> 6 & 1) || bVar4 >> 7 != ((byte)(uVar8 >> 0x1c) & 1)) && (uVar6 < 0x29)) {
      uVar2 = (uint)*(byte *)(param_1 + 1);
      iVar3 = *param_1;
      bVar4 = 0;
      fVar11 = DAT_600083e8;
      while (uVar6 = (uint)bVar4, uVar6 < uVar2) {
        bVar4 = bVar4 + 1;
        fVar9 = (float)VectorUnsignedToFloat
                                 (*(undefined4 *)(iVar3 + uVar6 * 4),(byte)(uVar8 >> 0x16) & 3);
        fVar11 = fVar11 + fVar9;
      }
      if (uVar2 != 0) {
        fVar9 = (float)VectorSignedToFloat(uVar2,(byte)(uVar8 >> 0x16) & 3);
        fVar11 = fVar11 / fVar9;
      }
      bVar4 = 0;
      uVar12 = DAT_600083d0;
      while( true ) {
        uVar1 = (undefined4)((ulonglong)uVar12 >> 0x20);
        if (uVar2 <= bVar4) break;
        fVar9 = (float)VectorUnsignedToFloat
                                 (*(undefined4 *)(iVar3 + (uint)bVar4 * 4),(byte)(uVar8 >> 0x16) & 3
                                 );
        uVar13 = FUN_60166bb4((fVar9 - fVar11) * (fVar9 - fVar11));
        uVar12 = FUN_601682c8((int)uVar12,uVar1,(int)uVar13,(int)((ulonglong)uVar13 >> 0x20));
        bVar4 = bVar4 + 1;
      }
      if (uVar2 != 0) {
        uVar13 = FUN_6016759c(uVar2);
        uVar12 = FUN_601675d8((int)uVar12,uVar1,(int)uVar13,(int)((ulonglong)uVar13 >> 0x20));
      }
      fVar9 = (float)FUN_601672d4((int)uVar12,(int)((ulonglong)uVar12 >> 0x20));
      fVar11 = DAT_600083e8;
      if (((fVar9 < DAT_600083ec) && (fVar11 = DAT_600083f0, 6.0 <= fVar10)) &&
         (fVar11 = DAT_600083f4, 10.0 <= fVar10)) {
        coprocessor_function2(10,3,0,in_cr0,in_cr2,in_cr1);
        fVar11 = 20.0;
      }
    }
    else if (uVar7 < 0x1f) {
      if (uVar7 < 0x10) {
        fVar11 = 1.0;
        if (5 < uVar7) {
          fVar11 = 2.0;
        }
      }
      else {
        fVar11 = 3.0;
      }
    }
    else {
      fVar11 = 5.0;
    }
    uVar1 = 0;
    coprocessor_function2(10,2,0,in_cr1,in_cr8,in_cr1);
    coprocessor_function2(10,3,0,in_cr0,in_cr0,in_cr1);
    param_1[7] = (int)(fVar10 + fVar11);
    param_1[8] = (int)(fVar10 + fVar11);
  }
  return uVar1;
}

