
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60013bba */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_60013840(char *param_1,int param_2)

{
  uint uVar1;
  char cVar2;
  byte bVar3;
  float fVar4;
  undefined8 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  ushort uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  uint in_fpscr;
  uint uVar14;
  undefined4 in_cr0;
  undefined4 in_cr1;
  float fVar15;
  float fVar16;
  undefined8 in_d0;
  undefined2 uVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  float fVar21;
  undefined8 uVar22;
  undefined8 uVar23;
  
  puVar5 = DAT_60013f38;
  if (*DAT_60013f34 == '\x02') {
    uVar7 = 0xffffffff;
    if ((param_1 != (char *)0x0) && (param_2 != 0)) {
      FUN_60136728(DAT_60013f38);
      iVar8 = FUN_60166dd0(param_1 + 0xb4);
      if ((iVar8 != 1) && (iVar8 = FUN_60166dd0(param_1 + 0xbc), iVar8 != 1)) {
        uVar12 = *(undefined4 *)(param_1 + 0xb4);
        uVar7 = *(undefined4 *)(param_1 + 0xb8);
        uVar13 = *(undefined4 *)(param_1 + 0xc0);
        uVar22 = FUN_6016759c(*(undefined4 *)(param_1 + 0xbc));
        uVar23 = FUN_6016759c(uVar13);
        uVar22 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                              (int)((ulonglong)uVar23 >> 0x20));
        *puVar5 = uVar22;
        uVar22 = FUN_6016759c(uVar12);
        uVar23 = FUN_6016759c(uVar7);
        in_d0 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                             (int)((ulonglong)uVar23 >> 0x20));
        puVar5[1] = in_d0;
      }
      iVar8 = DAT_60013f3c;
      *(char *)(puVar5 + 2) = *param_1;
      FUN_6010f996(iVar8,puVar5);
      iVar6 = DAT_60013f40;
      FUN_6010f966(iVar8,DAT_60013f40);
      iVar9 = FUN_60123188(iVar6 + 0x20);
      uVar22 = DAT_60013910;
      uVar7 = DAT_6001390c;
      if (iVar9 == 1) {
        *(undefined4 *)(param_2 + 0x24) = DAT_6001390c;
        *(undefined4 *)(param_2 + 0x2c) = uVar7;
        uVar23 = *(undefined8 *)(iVar6 + 0x20);
        uVar12 = (undefined4)((ulonglong)uVar22 >> 0x20);
        uVar13 = (undefined4)uVar22;
        in_d0 = *(undefined8 *)(iVar6 + 0x28);
        FUN_601678fc((int)in_d0,(int)((ulonglong)in_d0 >> 0x20),uVar13,uVar12);
        uVar7 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0x20) = uVar7;
        uVar7 = DAT_60013954;
        FUN_601678fc((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),uVar13,uVar12);
        uVar12 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0x28) = uVar12;
      }
      iVar9 = FUN_60123188(iVar6 + 0x30);
      uVar22 = DAT_60013910;
      if (iVar9 == 1) {
        *(undefined4 *)(param_2 + 0x34) = uVar7;
        *(undefined4 *)(param_2 + 0x3c) = uVar7;
        uVar23 = *(undefined8 *)(iVar6 + 0x30);
        uVar12 = (undefined4)((ulonglong)uVar22 >> 0x20);
        uVar13 = (undefined4)uVar22;
        in_d0 = *(undefined8 *)(iVar6 + 0x38);
        FUN_601678fc((int)in_d0,(int)((ulonglong)in_d0 >> 0x20),uVar13,uVar12);
        uVar7 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0x30) = uVar7;
        FUN_601678fc((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),uVar13,uVar12);
        uVar7 = FUN_60167a50();
        *(undefined4 *)(param_2 + 0x38) = uVar7;
      }
      *(undefined4 *)(puVar5 + 0x10) = *(undefined4 *)(param_1 + 4);
      FUN_6010fa56(iVar8 + 0x20c,puVar5 + 0x10);
      FUN_6010fa48(iVar8 + 0x20c,iVar6 + 0x124);
      *(undefined4 *)(param_2 + 0x18) = *(undefined4 *)(param_1 + 4);
      *(undefined4 *)(param_2 + 0x1c) = *(undefined4 *)(iVar6 + 0x124);
      FUN_60136728(puVar5 + 3);
      iVar9 = FUN_60166dd0(param_1 + 0xb4);
      if ((iVar9 != 1) && (iVar9 = FUN_60166dd0(param_1 + 0xbc), iVar9 != 1)) {
        uVar12 = *(undefined4 *)(param_1 + 0xb4);
        uVar7 = *(undefined4 *)(param_1 + 0xb8);
        uVar13 = *(undefined4 *)(param_1 + 0xc0);
        uVar22 = FUN_6016759c(*(undefined4 *)(param_1 + 0xbc));
        uVar23 = FUN_6016759c(uVar13);
        iVar8 = DAT_60013f3c;
        uVar22 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                              (int)((ulonglong)uVar23 >> 0x20));
        puVar5[3] = uVar22;
        uVar22 = FUN_6016759c(uVar12);
        uVar23 = FUN_6016759c(uVar7);
        in_d0 = FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                             (int)((ulonglong)uVar23 >> 0x20));
        puVar5[4] = in_d0;
      }
      *(char *)(puVar5 + 5) = *param_1;
      *(undefined4 *)((int)puVar5 + 0x2c) = *(undefined4 *)(param_1 + 4);
      *(undefined2 *)(puVar5 + 6) = *(undefined2 *)(param_1 + 0xd0);
      *(undefined2 *)((int)puVar5 + 0x32) = *(undefined2 *)(param_1 + 0x1c);
      FUN_60110c8c(iVar8 + 0x40,puVar5 + 3);
      FUN_60110c78(iVar8 + 0x40,iVar6 + 0x40);
      fVar4 = DAT_6001395c;
      fVar16 = DAT_60013958;
      fVar18 = *(float *)(iVar6 + 0x44);
      fVar15 = *(float *)(iVar6 + 0x40) * DAT_60013958;
      *(int *)(param_2 + 0x44) = *(int *)(iVar6 + 0x48) * 1000;
      uVar7 = VectorFloatToUnsigned(fVar15,3);
      *(undefined4 *)(param_2 + 0x40) = uVar7;
      fVar18 = fVar18 * fVar4;
      uVar7 = VectorFloatToUnsigned(fVar18,3);
      *(undefined4 *)(param_2 + 0x48) = uVar7;
      *(short *)(param_2 + 0x54) = (short)(int)fVar18;
      if (*param_1 == '\x01') {
        if (*(int *)(param_1 + 0x9c) != 0x7fffffff) {
          VectorSignedToFloat(*(int *)(param_1 + 0x9c),(byte)(in_fpscr >> 0x16) & 3);
        }
        uVar12 = (undefined4)in_d0;
        *(undefined4 *)(puVar5 + 7) = uVar12;
        FUN_6010fb00(iVar8 + 0x88,puVar5 + 7);
        FUN_6010faec(iVar8 + 0x88,iVar6 + 0x4c);
        fVar15 = *(float *)(iVar6 + 0x4c);
        cVar2 = param_1[0x91];
        fVar18 = *(float *)(iVar6 + 0x50);
        fVar19 = *(float *)(iVar6 + 0x54);
        *(char *)(puVar5 + 8) = param_1[0xd9];
        *(char *)((int)puVar5 + 0x41) = cVar2;
        *(int *)(param_2 + 0x80) = (int)(fVar15 * fVar16);
        *(int *)(param_2 + 100) = (int)(fVar18 * fVar16);
        *(int *)(param_2 + 0x68) = (int)(fVar19 * fVar16);
        *(uint *)((int)puVar5 + 0x3c) = *(uint *)(param_2 + 0x44) / 1000;
        FUN_60110ee0(iVar8 + 0xa0,(uint *)((int)puVar5 + 0x3c));
        FUN_60110eae(iVar8 + 0xa0,iVar6 + 0x58);
        *(undefined2 *)(param_2 + 0x8c) = *(undefined2 *)(iVar6 + 0x7c);
        *(undefined4 *)((int)puVar5 + 0x44) = *(undefined4 *)(param_2 + 0x2c8);
        FUN_601111ce(iVar8 + 0xe0,(undefined4 *)((int)puVar5 + 0x44));
        FUN_601111c4(iVar8 + 0xe0,iVar6 + 0x80);
        uVar7 = DAT_60013f48;
        *(short *)(param_2 + 0x52) = (short)(int)(*(float *)(iVar6 + 0x80) / fVar4);
        uVar13 = VectorUnsignedToFloat
                           ((uint)*(ushort *)(param_1 + 0x114),(byte)(in_fpscr >> 0x16) & 3);
        coprocessor_function2(10,0,0,in_cr0,in_cr1,in_cr0);
        *(undefined4 *)(puVar5 + 9) = uVar13;
        FUN_6001c894(uVar13,(int)((ulonglong)in_d0 >> 0x20),uVar7,iVar8 + 0xe4,puVar5 + 9);
        FUN_6001c880(iVar8 + 0xe4,iVar6 + 0x84);
        fVar15 = DAT_60013f4c;
        uVar17 = (undefined2)(int)*(float *)(iVar6 + 0x84);
        if (NAN(*(float *)(iVar6 + 0x84)) || NAN(DAT_60013f4c)) {
          uVar17 = 0xffff;
        }
        *(undefined2 *)(param_2 + 0x88) = uVar17;
        uVar17 = (undefined2)(int)*(float *)(iVar6 + 0x88);
        if (NAN(*(float *)(iVar6 + 0x88)) || NAN(fVar15)) {
          uVar17 = 0xffff;
        }
        *(undefined2 *)(param_2 + 0x84) = uVar17;
        fVar18 = *(float *)(iVar6 + 0x8c);
        uVar7 = *(undefined4 *)(param_2 + 0x2b4);
        uVar13 = *(undefined4 *)(param_2 + 700);
        uVar11 = *(undefined4 *)(param_2 + 0x2c0);
        *(undefined4 *)(puVar5 + 10) = *(undefined4 *)(param_2 + 0x2b8);
        *(undefined4 *)((int)puVar5 + 0x54) = uVar13;
        *(undefined4 *)(puVar5 + 0xb) = uVar11;
        uVar17 = (undefined2)(int)fVar18;
        uVar1 = in_fpscr & 0xfffffff | (uint)(fVar18 < fVar15) << 0x1f;
        uVar14 = uVar1 | (uint)(NAN(fVar18) || NAN(fVar15)) << 0x1c;
        if ((byte)(uVar1 >> 0x1f) != ((byte)(uVar14 >> 0x1c) & 1)) {
          uVar17 = 0xffff;
        }
        *(undefined2 *)(param_2 + 0x86) = uVar17;
        *(undefined4 *)((int)puVar5 + 0x4c) = uVar7;
        FUN_601112bc(iVar8 + 0xfc,(undefined4 *)((int)puVar5 + 0x4c));
        FUN_60111298(iVar8 + 0xfc,iVar6 + 0x90);
        fVar15 = DAT_60013f50;
        fVar19 = *(float *)(iVar6 + 0x94);
        fVar20 = *(float *)(iVar6 + 0x98);
        fVar21 = *(float *)(iVar6 + 0x9c);
        fVar18 = *(float *)(iVar6 + 0x90) * DAT_60013f50;
        *(char *)(puVar5 + 0xc) = param_1[0xd8];
        *(short *)(param_2 + 0x72) = (short)(int)fVar18;
        *(short *)(param_2 + 0x74) = (short)(int)(fVar19 * fVar15);
        *(short *)(param_2 + 0x6e) = (short)(int)(fVar20 * fVar15);
        *(short *)(param_2 + 0x70) = (short)(int)(fVar21 * fVar15);
        *(uint *)((int)puVar5 + 0x5c) = *(uint *)(param_2 + 0x44) / 1000;
        FUN_60111506(iVar8 + 0x11c,(uint *)((int)puVar5 + 0x5c));
        FUN_601114ca(iVar8 + 0x11c,iVar6 + 0xb0);
        *(undefined1 *)(param_2 + 0x90) = *(undefined1 *)(iVar6 + 0xd4);
        *(undefined2 *)(param_2 + 0x8a) = *(undefined2 *)(iVar6 + 0xd5);
        *(undefined4 *)((int)puVar5 + 0x65) = *(undefined4 *)(param_1 + 0xf9);
        *(char *)((int)puVar5 + 100) = param_1[0xf8];
        FUN_6010fdca(iVar8 + 0x158,(char *)((int)puVar5 + 100));
        FUN_6010fdbc(iVar8 + 0x158,iVar6 + 0xd8);
        fVar15 = *(float *)(iVar6 + 0xd8);
        uVar10 = 0xffff;
        uVar1 = uVar14 & 0xfffffff | (uint)(fVar15 < 0.0) << 0x1f | (uint)(fVar15 == 0.0) << 0x1e;
        uVar14 = uVar1 | (uint)NAN(fVar15) << 0x1c;
        bVar3 = (byte)(uVar1 >> 0x18);
        if (!(bool)(bVar3 >> 6 & 1) && bVar3 >> 7 == ((byte)(uVar14 >> 0x1c) & 1)) {
          uVar10 = (ushort)(int)(fVar15 * fVar16) | 0x8000;
        }
        *(ushort *)(param_2 + 0x62) = uVar10;
        *(undefined4 *)(param_2 + 0x91) = *(undefined4 *)(iVar6 + 0xdc);
        *(uint *)((int)puVar5 + 0x6c) = *(uint *)(param_2 + 0x44) / 1000;
        *(undefined2 *)(puVar5 + 0xe) = *(undefined2 *)(param_1 + 0xd4);
        *(undefined2 *)((int)puVar5 + 0x72) = *(undefined2 *)(param_2 + 0x294);
        *(char *)((int)puVar5 + 0x74) = param_1[0x92];
        FUN_60111924(iVar8 + 0x188);
        FUN_601118e4(iVar8 + 0x188,iVar6 + 0xe0);
        fVar15 = *(float *)(iVar6 + 0x104);
        uVar17 = (undefined2)(int)fVar15;
        uVar1 = uVar14 & 0xfffffff | (uint)(fVar15 < 0.0) << 0x1f;
        uVar14 = uVar1 | (uint)NAN(fVar15) << 0x1c;
        if ((byte)(uVar1 >> 0x1f) != ((byte)(uVar14 >> 0x1c) & 1)) {
          uVar17 = 0xffff;
        }
        *(undefined2 *)(param_2 + 0x60) = uVar17;
        *(undefined4 *)(param_2 + 0x58) = *(undefined4 *)(iVar6 + 0x110);
        if (*(int *)(param_2 + 4) != -1) {
          VectorUnsignedToFloat(*(int *)(param_2 + 4),(byte)(uVar14 >> 0x16) & 3);
        }
        *(undefined4 *)(puVar5 + 0xf) = uVar12;
        FUN_60111c16(iVar8 + 0x1f0,puVar5 + 0xf);
        FUN_60111c0c(iVar8 + 0x1f0,iVar6 + 0x114);
        fVar15 = *(float *)(iVar6 + 0x114) * fVar4;
        uVar7 = VectorFloatToUnsigned(fVar15,3);
        *(undefined4 *)(param_2 + 0x4c) = uVar7;
        fVar18 = (float)VectorSignedToFloat(*(undefined4 *)(param_1 + 0xa4),
                                            (byte)(uVar14 >> 0x16) & 3);
        *(float *)((int)puVar5 + 0x7c) = fVar18 / 10.0;
        *(short *)(param_2 + 0x56) = (short)(int)fVar15;
        FUN_60111c4c(iVar8 + 500,(int)puVar5 + 0x7c);
        FUN_60111c3a(iVar8 + 500,iVar6 + 0x118);
        fVar15 = DAT_60013f58;
        fVar18 = *(float *)(iVar6 + 0x120);
        *(char *)(param_2 + 0x8e) = (char)(int)*(float *)(iVar6 + 0x11c);
        *(char *)(param_2 + 0x8f) = (char)(int)fVar18;
        fVar18 = (float)VectorSignedToFloat((int)*(short *)(param_2 + 0x28c),
                                            (byte)(uVar14 >> 0x16) & 3);
        *(float *)((int)puVar5 + 0x84) = (fVar18 * fVar15) / fVar4;
        FUN_6010feb2(iVar8 + 0x218,(int)puVar5 + 0x84);
        FUN_6010fe98(iVar8 + 0x218,iVar6 + 300);
        uVar7 = *(undefined4 *)(param_2 + 0x40);
        iVar9 = *(int *)(param_1 + 0x9c);
        *(undefined4 *)(puVar5 + 0x11) = *(undefined4 *)(param_1 + 4);
        fVar18 = (float)VectorUnsignedToFloat(uVar7,(byte)(uVar14 >> 0x16) & 3);
        fVar20 = *(float *)(iVar6 + 0x134);
        fVar19 = *(float *)(iVar6 + 0x130);
        fVar21 = *(float *)(iVar6 + 0x138);
        *(float *)((int)puVar5 + 0x8c) = fVar18 / fVar16;
        fVar16 = *(float *)(iVar6 + 300);
        *(short *)(param_2 + 0x76) = (short)(int)((fVar20 * fVar4) / fVar15);
        *(short *)(param_2 + 0x7a) = (short)(int)((fVar16 * fVar4) / fVar15);
        *(short *)(param_2 + 0x78) = (short)(int)((fVar21 * fVar4) / fVar15);
        *(short *)(param_2 + 0x7c) = (short)(int)((fVar19 * fVar4) / fVar15);
        if (iVar9 != 0x7fffffff) {
          VectorSignedToFloat(iVar9,(byte)(uVar14 >> 0x16) & 3);
        }
        *(undefined4 *)(puVar5 + 0x12) = uVar12;
        FUN_601125a4(iVar8 + 0x238,puVar5 + 0x11);
        FUN_60112594(iVar8 + 0x238,iVar6 + 0x13c);
        fVar16 = *(float *)(iVar6 + 0x140);
        *(short *)(param_2 + 0x5c) = (short)(int)*(float *)(iVar6 + 0x13c);
        *(short *)(param_2 + 0x5e) = (short)(int)-fVar16;
      }
      uVar7 = 0;
    }
  }
  else {
    uVar7 = 0xffffffff;
  }
  return uVar7;
}

