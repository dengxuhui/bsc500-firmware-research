
undefined4 FUN_600106d4(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  
  pcVar1 = DAT_60010718;
  if (*DAT_60010718 == '\x01') {
    iVar4 = *(int *)(DAT_60010718 + 4);
    iVar2 = FUN_6001b6a0(param_1,iVar4,param_3,param_4,param_4);
    if (*(int *)(pcVar1 + 8) != *(int *)(pcVar1 + 0xc)) {
      uVar3 = param_1 + iVar4 + DAT_6001071c;
      if (((uint)(*(int *)(pcVar1 + 8) + iVar2 + *(int *)(pcVar1 + 4) + param_2) < uVar3) &&
         (uVar3 < (uint)(((iVar2 + *(int *)(pcVar1 + 4)) - param_2) + *(int *)(pcVar1 + 0xc)))) {
        return 1;
      }
    }
  }
  return 0;
}

