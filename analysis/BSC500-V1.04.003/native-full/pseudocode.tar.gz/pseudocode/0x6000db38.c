
void FUN_6000db38(undefined4 param_1,int param_2)

{
  FUN_60130bb4();
  *(undefined4 *)(param_2 + 0x11) = 0xffffffff;
  *(undefined4 *)(param_2 + 0xe) = 0xffffffff;
  *(undefined4 *)(param_2 + 10) = 0xffffffff;
  *(undefined4 *)(param_2 + 0x37e) = 0;
  *(undefined2 *)(param_2 + 0x382) = 0;
  return;
}

