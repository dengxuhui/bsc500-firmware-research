
bool FUN_60007a78(void)

{
  int iVar1;
  
  iVar1 = FUN_6012b7fc(DAT_60007a94,0);
  return iVar1 == 0;
}

