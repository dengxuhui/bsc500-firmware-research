
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60014f12 */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_60014a40(char *param_1,undefined4 *param_2)

{
  uint uVar1;
  char cVar2;
  byte bVar3;
  float fVar4;
  undefined8 *puVar5;
  undefined8 *puVar6;
  undefined4 uVar7;
  int iVar8;
  int iVar9;
  ushort uVar10;
  undefined4 *unaff_r4;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined2 uVar13;
  uint in_fpscr;
  uint uVar14;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 uVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  float fVar20;
  undefined2 uVar21;
  float fVar22;
  undefined8 uVar23;
  undefined8 uVar24;
  undefined8 local_68;
  undefined8 local_60;
  undefined8 local_58;
  undefined8 local_50;
  undefined8 local_48;
  
  puVar5 = DAT_60015394;
  if (*DAT_60015390 == '\x02') {
    uVar7 = 0xffffffff;
    if (param_1 != (char *)0x0) {
      unaff_r4 = param_2;
    }
    if (param_1 != (char *)0x0 && param_2 != (undefined4 *)0x0) {
      FUN_60136728(DAT_60015394);
      iVar8 = FUN_60166dd0();
      if ((iVar8 != 1) && (iVar8 = FUN_60166dd0(param_1 + 0xbc), iVar8 != 1)) {
        uVar11 = *(undefined4 *)(param_1 + 0xc0);
        uVar12 = *(undefined4 *)(param_1 + 0xb4);
        uVar7 = *(undefined4 *)(param_1 + 0xb8);
        uVar23 = FUN_6016759c(*(undefined4 *)(param_1 + 0xbc));
        uVar24 = FUN_6016759c(uVar11);
        uVar23 = FUN_601675d8((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),(int)uVar24,
                              (int)((ulonglong)uVar24 >> 0x20));
        *puVar5 = uVar23;
        uVar23 = FUN_6016759c(uVar12);
        uVar24 = FUN_6016759c(uVar7);
        uVar23 = FUN_601675d8((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),(int)uVar24,
                              (int)((ulonglong)uVar24 >> 0x20));
        puVar5[1] = uVar23;
      }
      iVar8 = DAT_60015398;
      *(char *)(puVar5 + 2) = *param_1;
      FUN_6010f996(iVar8,puVar5);
      puVar6 = DAT_6001539c;
      FUN_6010f966(iVar8,DAT_6001539c);
      iVar9 = FUN_60123188(puVar6 + 4);
      uVar23 = DAT_60014e90;
      uVar7 = DAT_60014e8c;
      if (iVar9 == 1) {
        uVar24 = puVar6[4];
        unaff_r4[0x65] = DAT_60014e8c;
        unaff_r4[0x67] = uVar7;
        uVar12 = (undefined4)((ulonglong)uVar23 >> 0x20);
        uVar15 = (undefined4)uVar23;
        FUN_601678fc((int)puVar6[5],(int)((ulonglong)puVar6[5] >> 0x20),uVar15,uVar12);
        uVar11 = FUN_60167a50();
        unaff_r4[100] = uVar11;
        FUN_601678fc((int)uVar24,(int)((ulonglong)uVar24 >> 0x20),uVar15,uVar12);
        uVar11 = FUN_60167a50();
        unaff_r4[0x66] = uVar11;
      }
      iVar9 = FUN_60123188(puVar6 + 6);
      uVar23 = DAT_60014e90;
      if (iVar9 == 1) {
        uVar24 = puVar6[6];
        unaff_r4[0x69] = uVar7;
        unaff_r4[0x6b] = uVar7;
        uVar12 = (undefined4)((ulonglong)uVar23 >> 0x20);
        uVar15 = (undefined4)uVar23;
        FUN_601678fc((int)puVar6[7],(int)((ulonglong)puVar6[7] >> 0x20),uVar15,uVar12);
        uVar11 = FUN_60167a50();
        unaff_r4[0x68] = uVar11;
        FUN_601678fc((int)uVar24,(int)((ulonglong)uVar24 >> 0x20),uVar15,uVar12);
        uVar11 = FUN_60167a50();
        unaff_r4[0x6a] = uVar11;
      }
      local_50 = *puVar6;
      local_48 = puVar6[2];
      local_58 = 0;
      local_60 = 0;
      local_68 = 0;
      iVar9 = FUN_60123188(&local_50);
      uVar23 = local_50;
      if (iVar9 == 1) {
        local_58._4_4_ = uVar7;
        local_60._4_4_ = uVar7;
        uVar12 = (undefined4)((ulonglong)DAT_60014e90 >> 0x20);
        uVar15 = (undefined4)DAT_60014e90;
        FUN_601678fc((int)local_48,(int)((ulonglong)local_48 >> 0x20),uVar15,uVar12);
        uVar11 = FUN_60167a50();
        local_58 = CONCAT44(local_58._4_4_,uVar11);
        FUN_601678fc((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),uVar15,uVar12);
        uVar11 = FUN_60167a50();
        local_60 = CONCAT44(local_60._4_4_,uVar11);
        FUN_60118c40(&local_58,&local_60,(int)&local_68 + 4,&local_68);
        unaff_r4[0x70] = local_68._4_4_;
        unaff_r4[0x71] = (undefined4)local_68;
      }
      uVar24 = puVar6[1];
      local_48 = puVar6[3];
      local_50 = uVar24;
      iVar9 = FUN_60123188(&local_50);
      uVar23 = local_50;
      if (iVar9 == 1) {
        local_58._4_4_ = uVar7;
        local_60._4_4_ = uVar7;
        uVar11 = (undefined4)((ulonglong)DAT_60014e90 >> 0x20);
        uVar12 = (undefined4)DAT_60014e90;
        FUN_601678fc((int)local_48,(int)((ulonglong)local_48 >> 0x20),uVar12,uVar11);
        uVar7 = FUN_60167a50();
        local_58 = CONCAT44(local_58._4_4_,uVar7);
        FUN_601678fc((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),uVar12,uVar11);
        uVar7 = FUN_60167a50();
        local_60 = CONCAT44(local_60._4_4_,uVar7);
        FUN_60118c40(&local_58,&local_60,(int)&local_68 + 4,&local_68);
        unaff_r4[0x6e] = local_68._4_4_;
        unaff_r4[0x6f] = (undefined4)local_68;
      }
      *(undefined4 *)(puVar5 + 0x10) = *(undefined4 *)(param_1 + 4);
      FUN_6010fa56(iVar8 + 0x20c,puVar5 + 0x10);
      FUN_6010fa48(iVar8 + 0x20c,(int)puVar6 + 0x124);
      uVar7 = *(undefined4 *)((int)puVar6 + 0x124);
      iVar9 = *(int *)(puVar6 + 0x25);
      unaff_r4[0x62] = *(undefined4 *)(param_1 + 4);
      unaff_r4[99] = uVar7;
      unaff_r4[0x6c] = iVar9 * 1000;
      FUN_60136728(puVar5 + 3);
      iVar9 = FUN_60166dd0(param_1 + 0xb4);
      if ((iVar9 != 1) && (iVar9 = FUN_60166dd0(param_1 + 0xbc), iVar9 != 1)) {
        uVar7 = *(undefined4 *)(param_1 + 0xb4);
        uVar11 = *(undefined4 *)(param_1 + 0xb8);
        uVar12 = *(undefined4 *)(param_1 + 0xc0);
        uVar23 = FUN_6016759c(*(undefined4 *)(param_1 + 0xbc));
        uVar24 = FUN_6016759c(uVar12);
        iVar8 = DAT_60015398;
        uVar23 = FUN_601675d8((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),(int)uVar24,
                              (int)((ulonglong)uVar24 >> 0x20));
        puVar5[3] = uVar23;
        uVar23 = FUN_6016759c(uVar7);
        uVar24 = FUN_6016759c(uVar11);
        uVar24 = FUN_601675d8((int)uVar23,(int)((ulonglong)uVar23 >> 0x20),(int)uVar24,
                              (int)((ulonglong)uVar24 >> 0x20));
        puVar5[4] = uVar24;
      }
      *(char *)(puVar5 + 5) = *param_1;
      *(undefined4 *)((int)puVar5 + 0x2c) = *(undefined4 *)(param_1 + 4);
      *(undefined2 *)(puVar5 + 6) = *(undefined2 *)(param_1 + 0xd0);
      *(undefined2 *)((int)puVar5 + 0x32) = *(undefined2 *)(param_1 + 0x1c);
      FUN_60110c8c(iVar8 + 0x40,puVar5 + 3);
      FUN_60110c78(iVar8 + 0x40,puVar6 + 8);
      fVar4 = DAT_60014e9c;
      fVar17 = DAT_60014e98;
      fVar16 = *(float *)(puVar6 + 8) * DAT_60014e98;
      fVar18 = *(float *)((int)puVar6 + 0x44) * DAT_60014e9c;
      unaff_r4[0x72] = *(int *)(puVar6 + 9) * 1000;
      uVar7 = VectorFloatToUnsigned(fVar16,3);
      unaff_r4[0x6d] = uVar7;
      uVar11 = VectorFloatToUnsigned(fVar18,3);
      *unaff_r4 = uVar7;
      unaff_r4[0x85] = uVar11;
      *(short *)(unaff_r4 + 0x8b) = (short)(int)fVar18;
      if (*param_1 == '\x01') {
        if (*(int *)(param_1 + 0x9c) != 0x7fffffff) {
          VectorSignedToFloat(*(int *)(param_1 + 0x9c),(byte)(in_fpscr >> 0x16) & 3);
        }
        *(int *)(puVar5 + 7) = (int)uVar24;
        FUN_6010fb00(iVar8 + 0x88,puVar5 + 7);
        FUN_6010faec(iVar8 + 0x88,(int)puVar6 + 0x4c);
        fVar16 = *(float *)(puVar6 + 10);
        fVar18 = *(float *)((int)puVar6 + 0x54);
        unaff_r4[0x89] = (int)(*(float *)((int)puVar6 + 0x4c) * fVar17);
        unaff_r4[0x87] = (int)(fVar16 * fVar17);
        unaff_r4[0x88] = (int)(fVar18 * fVar17);
        cVar2 = param_1[0xd9];
        *(uint *)((int)puVar5 + 0x3c) = (uint)unaff_r4[0x72] / 1000;
        *(char *)((int)puVar5 + 0x41) = param_1[0x91];
        *(char *)(puVar5 + 8) = cVar2;
        FUN_60110ee0(iVar8 + 0xa0);
        FUN_60110eae(iVar8 + 0xa0,puVar6 + 0xb);
        if (*(char *)(puVar6 + 0xf) == '\x06') {
          for (iVar9 = 0; iVar9 != 6; iVar9 = iVar9 + 1) {
            unaff_r4[iVar9 + 0x78] = *(int *)((int)puVar6 + iVar9 * 4 + 0x58) * 1000;
          }
        }
        else {
          for (iVar9 = 0; iVar9 != 6; iVar9 = iVar9 + 1) {
            unaff_r4[iVar9 + 0x78] = 0xffffffff;
          }
        }
        *(undefined2 *)(unaff_r4 + 0x98) = *(undefined2 *)((int)puVar6 + 0x7c);
        *(undefined4 *)((int)puVar5 + 0x44) = unaff_r4[0xb2];
        FUN_601111ce(iVar8 + 0xe0,(undefined4 *)((int)puVar5 + 0x44));
        FUN_601111c4(iVar8 + 0xe0,puVar6 + 0x10);
        uVar7 = DAT_60014ea4;
        uVar13 = 0xffff;
        *(short *)((int)unaff_r4 + 0x22a) = (short)(int)(*(float *)(puVar6 + 0x10) / fVar4);
        uVar11 = VectorUnsignedToFloat
                           ((uint)*(ushort *)(param_1 + 0x114),(byte)(in_fpscr >> 0x16) & 3);
        coprocessor_function2(10,0,0,in_cr0,in_cr1,in_cr0);
        *(undefined4 *)(puVar5 + 9) = uVar11;
        FUN_6001c894(uVar11,(int)((ulonglong)uVar24 >> 0x20),uVar7,iVar8 + 0xe4,puVar5 + 9);
        FUN_6001c880(iVar8 + 0xe4,(int)puVar6 + 0x84);
        fVar18 = *(float *)((int)puVar6 + 0x84);
        fVar19 = *(float *)(puVar6 + 0x11);
        fVar20 = *(float *)((int)puVar6 + 0x8c);
        uVar7 = unaff_r4[0xad];
        uVar11 = unaff_r4[0xaf];
        uVar12 = unaff_r4[0xb0];
        *(undefined4 *)(puVar5 + 10) = unaff_r4[0xae];
        *(undefined4 *)((int)puVar5 + 0x54) = uVar11;
        *(undefined4 *)(puVar5 + 0xb) = uVar12;
        fVar16 = DAT_60014ea8;
        uVar21 = (undefined2)(int)fVar18;
        if (NAN(fVar18) || NAN(DAT_60014ea8)) {
          uVar21 = 0xffff;
        }
        *(undefined2 *)(unaff_r4 + 0x8e) = uVar21;
        uVar21 = (undefined2)(int)fVar19;
        uVar1 = in_fpscr & 0xfffffff | (uint)(fVar20 < fVar16) << 0x1f;
        uVar14 = uVar1 | (uint)(NAN(fVar20) || NAN(fVar16)) << 0x1c;
        if (NAN(fVar19) || NAN(fVar16)) {
          uVar21 = 0xffff;
        }
        *(undefined2 *)(unaff_r4 + 0x8d) = uVar21;
        uVar21 = (undefined2)(int)fVar20;
        if ((byte)(uVar1 >> 0x1f) != ((byte)(uVar14 >> 0x1c) & 1)) {
          uVar21 = 0xffff;
        }
        *(undefined2 *)((int)unaff_r4 + 0x236) = uVar21;
        *(undefined4 *)((int)puVar5 + 0x4c) = uVar7;
        FUN_601112bc(iVar8 + 0xfc,(undefined4 *)((int)puVar5 + 0x4c));
        FUN_60111298(iVar8 + 0xfc,puVar6 + 0x12);
        fVar16 = DAT_60014eac;
        uVar7 = VectorFloatToUnsigned(*(float *)(puVar6 + 0x15) * fVar17,3);
        unaff_r4[0xa0] = uVar7;
        uVar7 = VectorFloatToUnsigned(*(float *)((int)puVar6 + 0xac) * fVar17,3);
        fVar19 = *(float *)((int)puVar6 + 0x94);
        fVar20 = *(float *)(puVar6 + 0x13);
        fVar22 = *(float *)((int)puVar6 + 0x9c);
        unaff_r4[0xa1] = uVar7;
        fVar18 = *(float *)(puVar6 + 0x12);
        *(uint *)((int)puVar5 + 0x5c) = (uint)unaff_r4[0x72] / 1000;
        *(char *)(puVar5 + 0xc) = param_1[0xd8];
        *(short *)(unaff_r4 + 0x94) = (short)(int)(fVar18 * fVar16);
        *(short *)((int)unaff_r4 + 0x252) = (short)(int)(fVar19 * fVar16);
        *(short *)(unaff_r4 + 0x93) = (short)(int)(fVar20 * fVar16);
        *(short *)((int)unaff_r4 + 0x24e) = (short)(int)(fVar22 * fVar16);
        FUN_60111506(iVar8 + 0x11c);
        FUN_601114ca(iVar8 + 0x11c,puVar6 + 0x16);
        if (*(char *)(puVar6 + 0x1a) == '\x05') {
          for (iVar8 = 0; iVar8 != 5; iVar8 = iVar8 + 1) {
            unaff_r4[iVar8 + 0x73] = *(int *)((int)puVar6 + iVar8 * 4 + 0xb0) * 1000;
          }
        }
        else {
          for (iVar8 = 0; iVar8 != 5; iVar8 = iVar8 + 1) {
            unaff_r4[iVar8 + 0x73] = 0xffffffff;
          }
        }
        iVar8 = DAT_60015398;
        *(undefined1 *)(unaff_r4 + 0x99) = *(undefined1 *)((int)puVar6 + 0xd4);
        iVar9 = iVar8 + 0x158;
        *(undefined2 *)((int)unaff_r4 + 0x25e) = *(undefined2 *)((int)puVar6 + 0xd5);
        *(undefined4 *)((int)puVar5 + 0x65) = *(undefined4 *)(param_1 + 0xf9);
        *(char *)((int)puVar5 + 100) = param_1[0xf8];
        FUN_6010fdca(iVar9,(char *)((int)puVar5 + 100));
        FUN_6010fdbc(iVar9,puVar6 + 0x1b);
        fVar16 = *(float *)(puVar6 + 0x1b);
        uVar10 = 0xffff;
        iVar8 = iVar8 + 0x188;
        uVar1 = uVar14 & 0xfffffff | (uint)(fVar16 < 0.0) << 0x1f | (uint)(fVar16 == 0.0) << 0x1e;
        uVar14 = uVar1 | (uint)NAN(fVar16) << 0x1c;
        bVar3 = (byte)(uVar1 >> 0x18);
        if (!(bool)(bVar3 >> 6 & 1) && bVar3 >> 7 == ((byte)(uVar14 >> 0x1c) & 1)) {
          uVar10 = (ushort)(int)(fVar16 * fVar17) | 0x8000;
        }
        *(ushort *)(unaff_r4 + 0x92) = uVar10;
        *(undefined4 *)((int)unaff_r4 + 0x265) = *(undefined4 *)((int)puVar6 + 0xdc);
        *(uint *)((int)puVar5 + 0x6c) = (uint)unaff_r4[0x72] / 1000;
        *(undefined2 *)((int)puVar5 + 0x72) = *(undefined2 *)(unaff_r4 + 0xa5);
        *(undefined2 *)(puVar5 + 0xe) = *(undefined2 *)(param_1 + 0xd4);
        *(char *)((int)puVar5 + 0x74) = param_1[0x92];
        FUN_60111924(iVar8);
        FUN_601118e4(iVar8,puVar6 + 0x1c);
        if (*(char *)(puVar6 + 0x20) == '\a') {
          for (iVar8 = 0; iVar8 != 7; iVar8 = iVar8 + 1) {
            unaff_r4[iVar8 + 0x7e] = *(int *)((int)puVar6 + iVar8 * 4 + 0xe0) * 1000;
          }
        }
        else {
          for (iVar8 = 0; iVar8 != 7; iVar8 = iVar8 + 1) {
            unaff_r4[iVar8 + 0x7e] = 0xffffffff;
          }
        }
        uVar10 = *(ushort *)(puVar6 + 0x22);
        uVar21 = *(undefined2 *)((int)puVar6 + 0x112);
        fVar16 = *(float *)((int)puVar6 + 0x104);
        fVar18 = *(float *)(puVar6 + 0x21);
        fVar19 = *(float *)((int)puVar6 + 0x10c);
        *(ushort *)(unaff_r4 + 0x8c) = uVar10;
        *(undefined2 *)((int)unaff_r4 + 0x232) = uVar21;
        uVar21 = (undefined2)(int)fVar16;
        if (NAN(fVar16)) {
          uVar21 = 0xffff;
        }
        *(undefined2 *)((int)unaff_r4 + 0x242) = uVar21;
        uVar21 = (undefined2)(int)(fVar18 * fVar4);
        uVar1 = uVar14 & 0xfffffff | (uint)(fVar19 < 0.0) << 0x1f;
        uVar14 = uVar1 | (uint)NAN(fVar19) << 0x1c;
        if (NAN(fVar18)) {
          uVar21 = 0xffff;
        }
        *(undefined2 *)((int)unaff_r4 + 0x246) = uVar21;
        uVar21 = (undefined2)(int)(fVar19 * 10.0);
        uVar23 = CONCAT62((int6)((ulonglong)uVar24 >> 0x10),uVar21);
        if ((byte)(uVar1 >> 0x1f) != ((byte)(uVar14 >> 0x1c) & 1)) {
          uVar21 = 0xffff;
        }
        *(undefined2 *)(unaff_r4 + 0x91) = uVar21;
        if (uVar10 != 0xffff) {
          uVar13 = (undefined2)((((uint)unaff_r4[0x72] / 1000) * (uint)uVar10) / 1000);
        }
        *(undefined2 *)(unaff_r4 + 0xa6) = uVar13;
        iVar8 = DAT_60015398;
        iVar9 = DAT_60015398 + 0x1f0;
        if (unaff_r4[1] != -1) {
          VectorUnsignedToFloat(unaff_r4[1],(byte)(uVar14 >> 0x16) & 3);
        }
        uVar7 = (undefined4)uVar23;
        *(undefined4 *)(puVar5 + 0xf) = uVar7;
        FUN_60111c16(iVar9,puVar5 + 0xf);
        FUN_60111c0c(iVar9,(int)puVar6 + 0x114);
        fVar16 = *(float *)((int)puVar6 + 0x114) * fVar4;
        uVar11 = VectorFloatToUnsigned(fVar16,3);
        unaff_r4[0x86] = uVar11;
        fVar18 = (float)VectorSignedToFloat(*(undefined4 *)(param_1 + 0xa4),
                                            (byte)(uVar14 >> 0x16) & 3);
        *(float *)((int)puVar5 + 0x7c) = fVar18 / 10.0;
        *(short *)((int)unaff_r4 + 0x22e) = (short)(int)fVar16;
        FUN_60111c4c(iVar8 + 500,(int)puVar5 + 0x7c);
        FUN_60111c3a(iVar8 + 500,puVar6 + 0x23);
        fVar16 = DAT_600153a8;
        fVar18 = *(float *)(puVar6 + 0x24);
        *(char *)((int)unaff_r4 + 0x262) = (char)(int)*(float *)((int)puVar6 + 0x11c);
        *(char *)((int)unaff_r4 + 0x263) = (char)(int)fVar18;
        fVar18 = (float)VectorSignedToFloat((int)*(short *)(unaff_r4 + 0xa3),
                                            (byte)(uVar14 >> 0x16) & 3);
        *(float *)((int)puVar5 + 0x84) = (fVar18 * fVar16) / fVar4;
        FUN_6010feb2(iVar8 + 0x218,(int)puVar5 + 0x84);
        FUN_6010fe98(iVar8 + 0x218,(int)puVar6 + 300);
        uVar11 = unaff_r4[0x6d];
        iVar9 = *(int *)(param_1 + 0x9c);
        *(undefined4 *)(puVar5 + 0x11) = *(undefined4 *)(param_1 + 4);
        fVar18 = (float)VectorUnsignedToFloat(uVar11,(byte)(uVar14 >> 0x16) & 3);
        fVar20 = *(float *)((int)puVar6 + 0x134);
        fVar19 = *(float *)(puVar6 + 0x26);
        fVar22 = *(float *)(puVar6 + 0x27);
        *(float *)((int)puVar5 + 0x8c) = fVar18 / fVar17;
        fVar17 = *(float *)((int)puVar6 + 300);
        *(short *)(unaff_r4 + 0x95) = (short)(int)((fVar20 * fVar4) / fVar16);
        *(short *)(unaff_r4 + 0x96) = (short)(int)((fVar17 * fVar4) / fVar16);
        *(short *)((int)unaff_r4 + 0x256) = (short)(int)((fVar22 * fVar4) / fVar16);
        *(short *)((int)unaff_r4 + 0x25a) = (short)(int)((fVar19 * fVar4) / fVar16);
        if (iVar9 != 0x7fffffff) {
          VectorSignedToFloat(iVar9,(byte)(uVar14 >> 0x16) & 3);
        }
        *(undefined4 *)(puVar5 + 0x12) = uVar7;
        FUN_601125a4(iVar8 + 0x238,puVar5 + 0x11);
        FUN_60112594(iVar8 + 0x238,(int)puVar6 + 0x13c);
        fVar17 = *(float *)(puVar6 + 0x28);
        *(short *)((int)unaff_r4 + 0x23a) = (short)(int)*(float *)((int)puVar6 + 0x13c);
        *(short *)(unaff_r4 + 0x8f) = (short)(int)-fVar17;
      }
      uVar7 = 0;
    }
  }
  else {
    uVar7 = 0xffffffff;
  }
  return uVar7;
}

