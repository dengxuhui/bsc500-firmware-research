
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000c258(int param_1,int param_2)

{
  bool bVar1;
  undefined1 uVar2;
  byte bVar3;
  int iVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined1 *puVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined8 uVar13;
  undefined4 local_70;
  undefined4 uStack_6c;
  undefined4 local_68;
  undefined4 uStack_64;
  undefined4 local_60 [2];
  undefined8 local_58;
  undefined8 local_50;
  undefined8 local_48;
  undefined8 local_40;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  
  if ((param_1 != 0) && (param_2 != 0)) {
    ZeroBytes(&local_58,0x20);
    local_70 = *(undefined4 *)(param_1 + 0xbc);
    uStack_6c = *(undefined4 *)(param_1 + 0xc0);
    uStack_64 = *(undefined4 *)(param_1 + 0xb8);
    local_68 = *(undefined4 *)(param_1 + 0xb4);
    local_38 = local_70;
    local_34 = uStack_6c;
    local_30 = local_68;
    local_2c = uStack_64;
    iVar4 = FUN_6011d9b4();
    if (iVar4 == 1) {
      local_60[0] = *(undefined4 *)(param_1 + 0x9c);
    }
    else {
      local_60[0] = FUN_6015616c();
    }
    iVar4 = FUN_60167080();
    if ((*(char *)(iVar4 + 0x16) == '\0') &&
       ((iVar6 = FUN_60166dd0((undefined4 *)(param_1 + 0xbc)), iVar6 == 1 ||
        (iVar6 = FUN_60166dd0((undefined4 *)(param_1 + 0xb4)), iVar6 == 1)))) {
      ZeroBytes(&local_58,0x20);
    }
    else {
      puVar5 = (undefined4 *)FUN_600168ac();
      uVar8 = puVar5[1];
      uVar11 = puVar5[2];
      uVar10 = puVar5[3];
      uVar13 = FUN_6016759c(*puVar5);
      uVar9 = (undefined4)((ulonglong)DAT_6000c4b0 >> 0x20);
      uVar12 = (undefined4)DAT_6000c4b0;
      local_58 = FUN_601675d8((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),uVar12,uVar9);
      uVar13 = FUN_6016759c(uVar8);
      local_50 = FUN_601675d8((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),uVar12,uVar9);
      uVar13 = FUN_6016759c(uVar11);
      local_48 = FUN_601675d8((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),uVar12,uVar9);
      uVar13 = FUN_6016759c(uVar10);
      local_40 = FUN_601675d8((int)uVar13,(int)((ulonglong)uVar13 >> 0x20),uVar12,uVar9);
    }
    if (*(char *)(iVar4 + 0x16) != '\0') {
      puVar5 = (undefined4 *)FUN_6015e450();
      local_38 = puVar5[2];
      local_34 = puVar5[3];
      local_30 = *puVar5;
      local_2c = puVar5[1];
      local_70 = puVar5[2];
      uStack_6c = puVar5[3];
      local_68 = *puVar5;
      uStack_64 = puVar5[1];
      FUN_601323d4(local_60,0);
    }
    FUN_60017c04(&local_58);
    FUN_60018ce4(&local_58);
    FUN_6001a694(&local_70);
    puVar5 = (undefined4 *)FUN_60163b60();
    uVar2 = FUN_60167258();
    *(undefined1 *)(puVar5 + 0xe) = uVar2;
    *(undefined1 *)(puVar5 + 5) = *(undefined1 *)(param_1 + 0xcc);
    puVar5[4] = (int)*(short *)(param_2 + 0x32e);
    uVar9 = *(undefined4 *)(param_1 + 0xb8);
    uVar10 = *(undefined4 *)(param_1 + 0xbc);
    uVar8 = *(undefined4 *)(param_1 + 8);
    *puVar5 = *(undefined4 *)(param_1 + 0xb4);
    puVar5[1] = uVar9;
    puVar5[2] = uVar10;
    iVar4 = DAT_6000c4b8;
    puVar5[3] = *(undefined4 *)(param_1 + 0xc0);
    uVar9 = *(undefined4 *)(iVar4 + 0xb3c);
    puVar5[6] = *(undefined4 *)(iVar4 + 0xb38);
    puVar5[7] = uVar9;
    puVar5[10] = uVar8;
    *(byte *)(puVar5 + 0xb) = ~*(byte *)(iVar4 + 0xb40) & 1;
    *(byte *)((int)puVar5 + 0x31) = *(byte *)(iVar4 + 0xb40) >> 7;
    *(byte *)((int)puVar5 + 0x32) = (byte)(((uint)*(byte *)(iVar4 + 0xb40) << 0x1d) >> 0x1f);
    *(byte *)((int)puVar5 + 0x2d) = *(byte *)(iVar4 + 0xa88) & 1;
    *(byte *)((int)puVar5 + 0x2e) = (byte)(((uint)*(byte *)(iVar4 + 0xa88) << 0x1e) >> 0x1f);
    puVar5[8] = (*(int *)(iVar4 + 0xb40) << 0x15) >> 0x1f;
    bVar3 = FUN_600168b8();
    *(byte *)((int)puVar5 + 0x35) = bVar3 ^ 1;
    *(byte *)((int)puVar5 + 0x2f) = (byte)((uint)(*(int *)(iVar4 + 0xb40) << 0x13) >> 0x1f);
    *(byte *)((int)puVar5 + 0x36) = (byte)((uint)(*(int *)(iVar4 + 0xb40) << 0x14) >> 0x1f);
    uVar2 = FUN_60167458(0xc);
    *(undefined1 *)((int)puVar5 + 0x37) = uVar2;
    uVar8 = DAT_6000c4bc;
    *(byte *)(puVar5 + 0xc) = (byte)(((uint)*(byte *)(iVar4 + 0xb40) << 0x1e) >> 0x1f);
    iVar4 = FUN_60168220(uVar8);
    CopyBytes((int)puVar5 + 0x9d,uVar8,iVar4 + 1);
    uVar8 = DAT_6000c4c0;
    iVar4 = FUN_60168220(DAT_6000c4c0);
    CopyBytes((int)puVar5 + 0x39,uVar8,iVar4 + 1);
    puVar7 = (undefined1 *)FUN_60163b48();
    iVar4 = FUN_60160de0(0xe);
    puVar7[0xd] = iVar4 == 0;
    uVar2 = FUN_6015e15c();
    puVar7[1] = uVar2;
    uVar2 = FUN_60149038();
    *puVar7 = uVar2;
    return;
  }
  if ((*DAT_6000c4c4 & 1) != 0) {
    software_bkpt(0);
  }
  bVar1 = (bool)isCurrentModePrivileged();
  if (bVar1) {
    isIRQinterruptsEnabled();
  }
  disableIRQinterrupts();
                    /* WARNING: Subroutine does not return */
  FUN_6016804c(_DAT_6000c4c8,"navi_input",0x10d);
}

