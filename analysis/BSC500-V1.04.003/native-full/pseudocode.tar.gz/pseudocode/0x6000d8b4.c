
void FUN_6000d8b4(int param_1)

{
  if (param_1 != 0) {
    ZeroBytes(param_1,0xd0);
    FUN_6015c4f0(param_1 + 0xd0,0x4a,0xff);
    *(undefined4 *)(param_1 + 0x9c) = 0x7fffffff;
    FUN_6001a03c();
    FUN_60164f14();
    return;
  }
  return;
}

