
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60010538(void)

{
  int iVar1;
  undefined4 local_44;
  undefined4 uStack_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined4 local_28;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined2 local_c;
  
  local_14 = DAT_600105a0;
  local_18 = DAT_600105a4;
  local_1c = DAT_600105a8;
  local_20 = DAT_600105ac;
  local_c = 0x501;
  local_10 = DAT_600105b0;
  local_24 = DAT_600105b4;
  local_28 = DAT_600105b8;
  local_2c = DAT_600105bc;
  local_30 = DAT_600105c0;
  local_34 = DAT_600105c4;
  local_38 = DAT_600105c8;
  local_3c = _DAT_600105cc;
  FUN_6001b58c(&local_20,&local_3c);
  thunk_FUN_6004ae20();
  local_44 = 0;
  uStack_40 = 0;
  iVar1 = FUN_60160fd0(3,&uStack_40,&local_44);
  if (iVar1 == 0) {
    FUN_60148a34("0:/iGPSPORT/Workouts/Aerobic Training.fit",3,1);
  }
  return;
}

