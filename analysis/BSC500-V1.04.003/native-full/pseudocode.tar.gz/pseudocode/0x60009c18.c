
void FUN_60009c18(uint param_1,int param_2)

{
  if ((param_1 < 8) && (param_2 != 0)) {
    *(int *)(*(int *)(DAT_60009c2c + param_1 * 4 + 4) + 0x10) = param_2;
  }
  return;
}

