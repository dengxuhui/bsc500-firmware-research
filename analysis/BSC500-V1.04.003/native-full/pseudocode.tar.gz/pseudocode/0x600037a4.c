
bool FUN_600037a4(void)

{
  int *piVar1;
  int iVar2;
  char *local_2c;
  undefined1 auStack_28 [16];
  undefined4 local_18;
  undefined4 local_14;
  
  ZeroBytes(auStack_28,0x20);
  local_14 = 0xe;
  local_2c = "router_task";
  local_18 = 0x1000;
  iVar2 = FUN_601566b4(DAT_600037ec,0,&local_2c);
  piVar1 = DAT_600037f0;
  *DAT_600037f0 = iVar2;
  FUN_60156808();
  return *piVar1 != 0;
}

