
undefined4 FUN_60018448(uint param_1,undefined4 *param_2)

{
  byte *pbVar1;
  byte *pbVar2;
  uint uVar3;
  
  uVar3 = (uint)*DAT_6001846c;
  pbVar1 = DAT_60018470;
  do {
    pbVar2 = pbVar1;
    if (uVar3 == 0) {
      return 3;
    }
    uVar3 = uVar3 - 1;
    pbVar1 = pbVar2 + 8;
  } while (*pbVar2 != param_1);
  *param_2 = *(undefined4 *)(pbVar2 + 4);
  return 0;
}

