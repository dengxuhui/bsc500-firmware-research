
undefined4 FUN_60010d38(void)

{
  return *DAT_60010d40;
}

