
void FUN_6000081c(undefined4 param_1,undefined4 param_2)

{
  undefined8 uVar1;
  
  uVar1 = CONCAT44(param_2,param_1);
  do {
    FUN_60000802();
    uVar1 = FUN_6012cbf0((int)uVar1,(int)((ulonglong)uVar1 >> 0x20));
  } while( true );
}

