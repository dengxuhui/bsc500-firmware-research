
undefined1 FUN_6000e4f8(void)

{
  return *(undefined1 *)(DAT_6000e500 + 2);
}

