
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60006ec0(int param_1,int param_2,int param_3)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  bool bVar7;
  int iVar8;
  undefined4 local_34;
  undefined4 uStack_30;
  undefined4 local_2c;
  undefined4 uStack_28;
  
  iVar2 = DAT_60007004;
  if (*(int *)(DAT_60007004 + 4) == 0) {
    FUN_60167f3c(0,DAT_60007010,1,DAT_60007014,DAT_60007050,DAT_60007008,0x75);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar3 = FUN_6015cb64();
  if (iVar3 != param_1) {
    FUN_60167f3c(0,DAT_60007010,1,DAT_60007014,DAT_6000700c,DAT_60007008,0x7c);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar3 = FUN_6016825e(*(undefined4 *)(iVar2 + 4),5000);
  if (iVar3 == 0) {
    bVar1 = false;
    bVar7 = false;
    local_2c = 0;
    uStack_28 = 0;
    local_34 = 0;
    uStack_30 = 0;
    for (iVar3 = 0; iVar3 != 4; iVar3 = iVar3 + 1) {
      iVar8 = iVar2 + iVar3 * 4;
      piVar5 = *(int **)(iVar8 + 8);
      if (piVar5 == (int *)0x0 && !bVar7) {
        local_34 = FUN_6013a3fc(param_1);
        piVar5 = (int *)FUN_60161f90(0x14,10);
        *piVar5 = param_1;
        piVar5[1] = param_2;
        iVar6 = FUN_60168494(&local_34);
        piVar5[2] = iVar6;
        piVar5[3] = param_3;
        piVar5[4] = 0;
        *(int **)(iVar8 + 8) = piVar5;
        bVar7 = true;
      }
      else if ((piVar5 != (int *)0x0) && (bVar7)) {
        bVar1 = (bool)(bVar1 | *piVar5 == param_1);
      }
    }
    FUN_601682ae(*(undefined4 *)(iVar2 + 4));
    if (bVar1) {
      FUN_60167f3c(0,DAT_60007010,1,DAT_60007014,"!repeat && \"reapt\"",DAT_60007008,0x98);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    if (!bVar7) {
      FUN_60167f3c(0,DAT_60007010,1,DAT_60007014,"find && \"register overflow\"",DAT_60007008,0x99);
      FUN_6013dd48();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    uVar4 = 1;
  }
  else {
    FUN_60167f3c(3,DAT_60007018,1,_DAT_6000701c,DAT_60007008);
    uVar4 = 0;
  }
  return uVar4;
}

