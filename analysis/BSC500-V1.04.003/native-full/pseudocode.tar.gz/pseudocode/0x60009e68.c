
void FUN_60009e68(int param_1)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  iVar1 = DAT_6000a000;
  if ((param_1 == 0x6e) && (*(int *)(DAT_6000a000 + 0x14) != 0)) {
    iVar2 = FUN_6015982e();
    if (iVar2 != 0) {
      FUN_60159828(iVar2,0,0,0);
      uVar3 = FUN_600217fc();
      FUN_60159838(uVar3,0x1b,iVar2);
    }
    FUN_6001ccd0(iVar1 + 0x14);
  }
  if (*(char *)(iVar1 + 2) != '\x01') {
    return;
  }
  *(undefined1 *)(iVar1 + 2) = 0;
  FUN_60164e80(1);
  return;
}

