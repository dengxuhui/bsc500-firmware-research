
undefined4 FUN_60006bf8(void)

{
  FUN_60156878(DAT_60006c04);
  return 1;
}

