
void FUN_60000f40(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = DAT_60000f60;
  if (param_1 - 1U >> 0x18 == 0) {
    DAT_60000f60[1] = param_1 - 1U;
    *DAT_60000f64 = 0xe0;
    puVar1[2] = 0;
    *puVar1 = 7;
    return;
  }
  return;
}

