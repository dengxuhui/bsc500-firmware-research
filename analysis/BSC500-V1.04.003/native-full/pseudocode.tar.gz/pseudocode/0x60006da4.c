
undefined4 FUN_60006da4(undefined4 *param_1)

{
  FUN_60163e70(*param_1,param_1[2],0);
  return 1;
}

