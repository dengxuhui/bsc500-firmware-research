
void thunk_FUN_6001be54(undefined4 param_1,undefined4 param_2)

{
  FUN_60139d78(7,param_1,param_2);
  FUN_6015de78();
  return;
}

