
undefined4 FUN_6000bf56(undefined4 *param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  if (param_1 != (undefined4 *)0x0) {
    iVar2 = param_1[1];
    iVar3 = param_1[2];
    FUN_6015cb64();
    iVar1 = FUN_60139e84();
    *(undefined4 **)(iVar1 + 0x10) = param_1;
    FUN_6016825e(*(undefined4 *)(iVar1 + 8),5000);
    if (iVar3 == 0) {
      if (0 < (int)*param_1) {
        (*(code *)*param_1)(iVar2);
      }
    }
    else if (0 < (int)*param_1) {
      (*(code *)*param_1)(iVar2,iVar3);
    }
    *(undefined4 *)(iVar1 + 0x10) = 0;
    FUN_601682ae(*(undefined4 *)(iVar1 + 8));
    if (iVar2 != 0) {
      FUN_60139eac(iVar2);
    }
  }
  return 1;
}

