
void FUN_60006d08(void)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  
  uVar1 = *DAT_60006d30;
  uVar2 = *DAT_60006d34;
  uVar3 = FUN_60154888();
  FUN_601546c8(uVar3,0,CONCAT22(uVar1,uVar2));
  FUN_60164914(DAT_60006d38,0);
  return;
}

