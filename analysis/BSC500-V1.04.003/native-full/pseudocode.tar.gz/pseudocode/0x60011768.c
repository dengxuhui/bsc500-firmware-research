
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60011768(undefined2 *param_1)

{
  char cVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  char *pcVar5;
  undefined4 uVar6;
  uint uVar7;
  bool bVar8;
  undefined1 auStack_238 [12];
  uint local_22c;
  undefined1 auStack_224 [4];
  undefined1 auStack_220 [80];
  char local_1d0 [36];
  undefined4 local_1ac;
  undefined4 local_1a8;
  int local_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  char local_dc [56];
  undefined2 local_a4;
  undefined1 local_a2;
  undefined4 local_a0;
  undefined4 local_9c;
  undefined1 local_30;
  undefined2 local_2c;
  undefined1 local_2a;
  undefined1 local_29;
  undefined1 local_28;
  undefined4 local_24;
  undefined2 *local_20;
  undefined4 local_1c;
  
  local_20 = (undefined2 *)0x0;
  local_1c = 0;
  ZeroBytes(&local_a4,0x84);
  *(undefined4 *)(_DAT_600118f0 + 4) = 0;
  ZeroBytes(&local_148,0xa4);
  iVar3 = FUN_60119330(*(undefined4 *)(param_1 + 2),*param_1,&local_148);
  if (iVar3 == 0) {
    pcVar5 = "[FILE_CAP] Decode request failed\r\n";
    goto LAB_600117b2;
  }
  ZeroBytes(auStack_224,0xdc);
  iVar3 = FUN_6002aed0(auStack_224);
  if (iVar3 == 0) {
    FUN_60168578(_DAT_60011918,auStack_220,local_1ac,local_1a8);
    FUN_60168578("[FILE_CAP] Local MD5: %s\r\n",local_1d0);
    uVar4 = FUN_60168220(local_dc);
    if (uVar4 == 0) {
      pcVar5 = "[FILE_CAP] Request has no MD5, skip MD5 check\r\n";
    }
    else {
      FUN_60168578(DAT_60011968,local_dc);
      iVar3 = FUN_60163bc6(local_dc,local_1d0,0x21);
      FUN_60168578(_DAT_6001196c,iVar3);
      if (iVar3 != 0) {
        FUN_60168578(DAT_6001198c);
        uVar6 = DAT_60011994;
        uVar7 = 0;
        while( true ) {
          bVar8 = 0x1e < uVar7;
          if (uVar7 < 0x20) {
            bVar8 = uVar4 <= uVar7;
          }
          if (bVar8) break;
          cVar1 = local_1d0[uVar7];
          cVar2 = local_dc[uVar7];
          if (cVar2 != cVar1) {
            FUN_60168578(uVar6,uVar7,cVar2,cVar2,cVar1,cVar1);
          }
          uVar7 = uVar7 + 1;
        }
        FUN_60168578(DAT_60011990);
        goto LAB_600117ac;
      }
      pcVar5 = "[FILE_CAP] MD5 matched!\r\n";
    }
    FUN_60168578(pcVar5);
  }
  else {
LAB_600117ac:
    local_1a8 = 0;
  }
  local_a4 = 0x215;
  local_28 = 1;
  local_30 = 1;
  local_2a = 1;
  local_a0 = uStack_144;
  local_9c = uStack_140;
  local_a2 = (undefined1)local_148;
  local_2c = 0x101;
  local_29 = local_148 == 5;
  uVar6 = DAT_6001199c;
  if (local_148 == 5) {
    uVar6 = DAT_60011998;
  }
  local_24 = local_1a8;
  FUN_60168578(uVar6);
  iVar3 = FUN_6013a780(&local_1c,&local_20,0x6e);
  if (iVar3 != 0) {
    FUN_60168578(DAT_600119a0);
    return 1;
  }
  FUN_601648d4(auStack_238,local_1c,0x640);
  iVar3 = FUN_60164868(auStack_238,DAT_600119a4,&local_a4);
  pcVar5 = DAT_600119a8;
  if (iVar3 != 0) {
    *local_20 = (short)local_22c;
    FUN_6012c348();
    uVar6 = FUN_6015f2e8(local_1c,*local_20);
    FUN_6013a800(0x15,0,2,0,local_22c & 0xffff,uVar6);
    return 1;
  }
LAB_600117b2:
  FUN_60168578(pcVar5);
  FUN_60129ec8(0x15,0,2,0);
  return 1;
}

