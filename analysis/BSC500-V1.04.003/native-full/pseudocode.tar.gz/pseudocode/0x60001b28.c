
void FUN_60001b28(undefined4 param_1)

{
  undefined4 *puVar1;
  
  puVar1 = DAT_60001b3c;
  FUN_60167d0c();
  *puVar1 = param_1;
  FUN_60167d14();
  return;
}

