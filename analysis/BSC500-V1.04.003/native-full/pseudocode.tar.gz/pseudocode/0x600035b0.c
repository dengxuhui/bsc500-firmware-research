
undefined1 FUN_600035b0(void)

{
  return *(undefined1 *)(DAT_600035b8 + 1);
}

