
void FUN_600166a4(void)

{
  byte bVar1;
  undefined1 uVar2;
  byte bVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  short sVar8;
  int iVar9;
  
  iVar4 = FUN_60163e34(0);
  FUN_60023c60(*(undefined1 *)(iVar4 + 200));
  bVar3 = *(byte *)(iVar4 + 200);
  iVar5 = FUN_6011f6a4();
  sVar8 = 0;
  for (iVar9 = 0; (uint)bVar3 * 0x18 != iVar9; iVar9 = iVar9 + 0x18) {
    uVar2 = *(undefined1 *)(iVar4 + 0xcc + iVar9);
    *(short *)(iVar5 + 0x20) = sVar8;
    *(undefined1 *)(iVar5 + 0x24) = uVar2;
    iVar6 = iVar4 + 0xcc + iVar9;
    bVar1 = *(byte *)(iVar6 + 1);
    *(undefined4 *)(iVar5 + 0x18) = *(undefined4 *)(iVar6 + 4);
    uVar7 = *(undefined4 *)(iVar6 + 8);
    *(uint *)(iVar5 + 0x14) = (uint)bVar1;
    *(byte *)(iVar5 + 0x23) = bVar1;
    uVar2 = *(undefined1 *)(iVar6 + 0xc);
    iVar6 = *(int *)(iVar6 + 0x10);
    *(undefined4 *)(iVar5 + 0x1c) = uVar7;
    *(undefined1 *)(iVar5 + 0x22) = uVar2;
    *(int *)(iVar5 + 0x10) = iVar6 * 1000;
    FUN_60033048(iVar9 == 0);
    sVar8 = sVar8 + 1;
  }
  return;
}

