
void FUN_60003bdc(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_6011c240("pm_low_prio",DAT_60003bfc,3);
  *(undefined4 *)(DAT_60003c00 + 0xc) = uVar1;
  return;
}

