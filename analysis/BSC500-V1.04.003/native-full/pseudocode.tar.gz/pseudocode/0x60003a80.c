
undefined4 FUN_60003a80(undefined4 param_1,undefined4 param_2)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 local_28;
  int *local_24;
  undefined4 local_1c;
  
  piVar1 = DAT_60003b14;
  piVar2 = (int *)*DAT_60003b14;
  if ((code *)piVar2[1] != (code *)0x0) {
    (*(code *)piVar2[1])();
    piVar2 = (int *)*piVar1;
  }
  (**(code **)(*piVar2 + 8))(&local_28,piVar2,0);
  if (local_24 == (int *)0x0) {
    cVar3 = '\r';
  }
  else {
    (**(code **)(*local_24 + 0x10))(local_24,0,1,6,local_28);
    (**(code **)(*local_24 + 0x20))(local_24,param_1);
    (**(code **)(*local_24 + 0x20))(local_24,param_2);
    (**(code **)(*(int *)*piVar1 + 0xc))((int *)*piVar1,&local_28);
    (**(code **)(*local_24 + 0x70))(local_24,&local_1c);
    cVar3 = (char)local_24[5];
  }
  (**(code **)(*(int *)*piVar1 + 0x10))((int *)*piVar1,&local_28);
  FUN_601675ca(*piVar1,cVar3,6);
  if (*(code **)(*piVar1 + 8) != (code *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  if (cVar3 != '\0') {
    local_1c = 0xffffffff;
  }
  return local_1c;
}

