
void FUN_6000b61c(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = DAT_6000b634;
  if (param_1 != (undefined4 *)0x0) {
    param_1[2] = DAT_6000b638;
    param_1[3] = uVar1;
    *(undefined1 *)(param_1 + 1) = 0xff;
    *param_1 = 0xffffffff;
  }
  return;
}

