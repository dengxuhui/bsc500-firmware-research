
void FUN_6000e2cc(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_6011c240("pm_ride_task",DAT_6000e2f0,3);
  *(undefined4 *)(DAT_6000e2f4 + 0xc) = uVar1;
  return;
}

