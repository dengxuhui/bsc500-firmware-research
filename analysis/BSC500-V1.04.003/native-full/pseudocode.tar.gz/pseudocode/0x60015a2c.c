
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60015a2c(undefined4 param_1,ushort *param_2,undefined4 *param_3,undefined4 *param_4,
                int param_5)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined1 auStack_48 [36];
  
  iVar4 = thunk_FUN_60162e34(100);
  FUN_60167214(iVar4,100);
  *param_2 = 0;
  iVar5 = FUN_6015c8a2(DAT_60015b80,param_1);
  puVar3 = DAT_60015b84;
  uVar2 = DAT_60015b80;
  if (iVar5 == 0) {
    while (*param_2 < 499) {
      iVar5 = FUN_6015c834(uVar2,puVar3);
      if (iVar5 != 0) goto LAB_60015a58;
      if (*(char *)((int)puVar3 + 0x16) != '.') {
        iVar5 = 0;
        if (*(char *)((int)puVar3 + 0x16) == '\0') goto LAB_60015a58;
        uVar8 = *puVar3;
        iVar5 = FUN_6001cc80(uVar8);
        if (iVar5 == 0) {
          if (param_5 != 0) {
            FUN_601681f4(iVar4,DAT_60015b88,param_1,(int)puVar3 + 0x16);
            FUN_6015c57c(iVar4);
          }
        }
        else {
          FUN_60167214(iVar4,100);
          uVar6 = FUN_60163b68(iVar4,(int)puVar3 + 0x16,100);
          iVar5 = FUN_60023a2c(uVar6,auStack_48);
          if (iVar5 != 0) {
            if (*param_2 < 199) {
              uVar6 = FUN_60164ff4(auStack_48);
              uVar7 = (uint)*param_2;
              param_3[uVar7] = uVar6;
              if (param_4 != (undefined4 *)0x0) {
                param_4[uVar7] = uVar8;
              }
              FUN_60023a7c(param_3,param_4,uVar7 + 1 & 0xffff);
              *param_2 = *param_2 + 1;
            }
            else {
              if (*param_2 == 199) {
                FUN_6015d9f4(param_3 + 1,param_3,0x31c);
                FUN_6015d9f4(param_4 + 1,param_4,0x31c);
              }
              *param_2 = 200;
              uVar6 = FUN_60164ff4(auStack_48);
              *param_3 = uVar6;
              if (param_4 != (undefined4 *)0x0) {
                *param_4 = uVar8;
              }
              FUN_60023b18(param_3,param_4,200);
            }
          }
        }
      }
    }
    iVar5 = 0;
  }
LAB_60015a58:
  if (iVar4 == 0) {
    if ((*DAT_60015b8c & 1) != 0) {
      software_bkpt(0);
    }
    bVar1 = (bool)isCurrentModePrivileged();
    if (bVar1) {
      isIRQinterruptsEnabled();
    }
    disableIRQinterrupts();
                    /* WARNING: Subroutine does not return */
    FUN_6016804c(_DAT_60015b90,"exf_scan_activity_filename_sorted_oldest",0x2ba);
  }
  thunk_FUN_60166c0c(iVar4);
  return iVar5;
}

