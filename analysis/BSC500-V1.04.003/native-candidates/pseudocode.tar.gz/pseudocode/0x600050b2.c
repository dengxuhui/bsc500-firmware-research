
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_600050b2(undefined4 param_1,uint param_2)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  uint unaff_r4;
  int *piVar4;
  int unaff_r5;
  undefined4 unaff_r7;
  int *piVar5;
  
  *(char *)(unaff_r5 + 0xc) = (char)param_2;
  *(undefined4 *)((unaff_r4 >> 9) + 0xa0) = 0x20;
  *(undefined4 *)unaff_r7 = unaff_r7;
  uRam0000002c = (undefined1)unaff_r7;
  *(undefined4 *)((unaff_r4 >> 9) + 0x100) = 0x20;
  iVar2 = FUN_60164eb0(7);
  uVar1 = _DAT_60005160;
  piVar4 = (int *)(iVar2 + 4);
  uVar3 = FUN_6015de24(_DAT_60005160,piVar4);
  func_0x60168578(&UNK_60005164,uVar3,uVar1);
  FUN_6015de60(uVar3);
  func_0x60168578(&UNK_60005194);
  piVar5 = piVar4;
  while (piVar5 = (int *)*piVar5, piVar5 != piVar4) {
    param_2 = piVar5[4];
    func_0x60168578(&UNK_600051c0,uVar3,0x10,piVar5 + -5,param_2,piVar5[6],piVar5[5]);
  }
  return (ulonglong)param_2 << 0x20;
}

