
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d850(undefined4 *param_1,int *param_2)

{
  undefined4 *puVar1;
  
  puVar1 = _DAT_6000d870;
  FUN_600185d0(*_DAT_6000d870,_DAT_6000d870 + 1);
  *param_1 = puVar1[1];
  *param_2 = puVar1[1] - puVar1[3];
  return;
}

