
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600009c8(void)

{
  char cVar1;
  bool bVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  
  iVar3 = _DAT_600009fc;
  iVar4 = FUN_6015f970(*(undefined4 *)(_DAT_600009fc + 0xc));
  iVar5 = FUN_6015f970(*(undefined1 *)(iVar3 + iVar4 + -1 + 0x18));
  iVar4 = *(int *)(_DAT_60000a00 + (iVar5 + (iVar4 + -1) * 8) * 8 + -8);
  *(int *)(iVar3 + 8) = iVar4 + -0x1c;
  *_DAT_60167ee4 = iVar4 + 8;
  cVar1 = isThreadModePrivileged();
  isUsingMainStack();
  bVar2 = (bool)isCurrentModePrivileged();
  if (bVar2) {
    setThreadModePrivileged(cVar1 == '\x01');
    bVar2 = (bool)isThreadMode();
    if (bVar2) {
      cVar1 = isUsingMainStack();
      setStackMode(cVar1 == '\x01');
    }
  }
  *_DAT_60167ee0 = 0;
  *_DAT_60167edc = 1;
  *_DAT_60167eec = *_DAT_60167eec | 0xff0000;
  *_DAT_60167ee8 = 0x10000000;
  bVar2 = (bool)isCurrentModePrivileged();
  if (bVar2) {
    setMainStackPointer(*(undefined4 *)*_DAT_60167ef0);
  }
  enableFIQinterrupts();
  enableIRQinterrupts();
  return *(undefined4 *)*_DAT_60167ef0;
}

