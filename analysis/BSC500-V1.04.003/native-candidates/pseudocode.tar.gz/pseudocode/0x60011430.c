
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60011430(int param_1)

{
  int iVar1;
  uint uVar2;
  
  iVar1 = _DAT_6001144c;
  uVar2 = 0x1ff8;
  if (param_1 + *_DAT_60011448 < 0x1ff8) {
    uVar2 = param_1 + *_DAT_60011448;
  }
  *_DAT_60011448 = uVar2;
  *(uint *)(iVar1 + 4) = uVar2;
  return;
}

