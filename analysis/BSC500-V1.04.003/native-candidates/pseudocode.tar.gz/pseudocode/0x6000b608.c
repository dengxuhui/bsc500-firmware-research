
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000b608(int *param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar2 = *_DAT_6000b618;
  iVar1 = _DAT_6000b618[2];
  *param_1 = iVar2;
  *param_2 = iVar2 - iVar1;
  return;
}

