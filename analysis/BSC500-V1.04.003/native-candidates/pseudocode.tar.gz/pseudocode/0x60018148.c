
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018148(void)

{
  int iVar1;
  
  iVar1 = _DAT_6001817c;
  if (*(int *)(_DAT_6001817c + 4) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 4) = 0;
    FUN_6015c57c(_DAT_60018164);
    return;
  }
  return;
}

