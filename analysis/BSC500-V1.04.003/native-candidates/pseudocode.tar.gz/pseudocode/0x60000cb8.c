
void FUN_60000cb8(void)

{
  FUN_600e955c();
  FUN_6010f3b0();
  FUN_6013dd48();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

