
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60004dd4(void)

{
  uint uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  FUN_6000df90();
  uStack_c = 0;
  uStack_14 = 0;
  uStack_10 = 0;
  FUN_600521dc(&uStack_c,&uStack_10,&uStack_14);
  FUN_6015b134(_DAT_6000af30,uStack_14,uStack_c,uStack_10);
  return (ulonglong)uStack_14 << 0x20;
}

