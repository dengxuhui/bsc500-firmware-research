
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60006d08(void)

{
  undefined2 uVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  undefined *puVar12;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  undefined *puVar13;
  int iVar14;
  
  uVar1 = *_DAT_60006d30;
  uVar2 = *_DAT_60006d34;
  uVar3 = FUN_60154888();
  FUN_601546c8(uVar3,0,CONCAT22(uVar1,uVar2));
  uVar3 = _DAT_60006d38;
  iVar11 = FUN_6015982e();
  FUN_60159828(iVar11,uVar3,0,0);
  puVar12 = (undefined *)FUN_6015bd44();
  iVar7 = _DAT_6016493c;
  if ((puVar12 == (undefined *)0x0) && (iVar11 != 0)) {
    func_0x6011ed5c(iVar11);
  }
  else if (iVar11 == 0) {
    iVar11 = FUN_6015982e();
    FUN_60159828(iVar11,iVar7,0,0);
  }
  iVar10 = *(int *)(_DAT_60159870 + 8);
  puVar13 = puVar12;
  if (iVar10 == 0) {
    if (iVar11 != 0) {
      func_0x60139eac(iVar11);
      puVar13 = puVar12;
    }
  }
  else {
    iVar14 = iVar7;
    iVar9 = iVar11;
    iVar4 = FUN_60133088();
    uVar8 = _DAT_600570a8;
    uVar3 = _DAT_60057044;
    if (iVar4 != 0) {
      piVar5 = (int *)(iVar10 + 4);
      do {
        piVar5 = (int *)*piVar5;
        if (piVar5 == (int *)0x0) {
LAB_6005702c:
          FUN_601330ec();
          if (iVar11 != 0) {
LAB_60057036:
            func_0x60139eac(iVar11);
          }
          return CONCAT44(puVar13,1);
        }
        if (((undefined *)piVar5[1] == puVar12) && (*piVar5 == iVar7)) {
          puVar6 = (undefined4 *)FUN_60139e84(puVar12);
          if (puVar6 != (undefined4 *)0x0) {
            puVar13 = (undefined *)piVar5[3];
            iVar7 = FUN_60058f40(puVar6[1],piVar5[2],puVar6[3],iVar11,puVar13,iVar14,iVar9,unaff_r4,
                                 unaff_r5,unaff_r6);
            if (iVar7 == 0) {
              if (puVar6[1] != 0) {
                uVar3 = FUN_60052acc();
                uVar8 = FUN_6005b1e8(puVar6[1]);
                iVar9 = FUN_6012376e(puVar6[1]);
                func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057048,uVar3,uVar8,iVar9);
              }
              puVar13 = (undefined *)*puVar6;
              uVar3 = FUN_6013a3fc(puVar13);
              func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057074,puVar13,uVar3,iVar9);
            }
            else if (((puVar6[1] == 0) && (iVar11 != 0)) && (puVar6[3] != 0)) {
              func_0x60139eac(iVar11);
              FUN_601330ec();
              goto LAB_60057036;
            }
            goto LAB_6005702c;
          }
          puVar13 = &UNK_60057094;
          func_0x60167f3c(3,uVar3,1,uVar8);
        }
        piVar5 = piVar5 + 4;
      } while( true );
    }
  }
  return ZEXT48(puVar13) << 0x20;
}

