
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018550(void)

{
  int iVar1;
  undefined4 unaff_r6;
  
  func_0x601608ac(_DAT_60018578,0x24);
  iVar1 = FUN_60166758(&stack0xfffffff4,_DAT_6001857c,1);
  if (iVar1 != 0) {
    return;
  }
  FUN_601667bc(unaff_r6);
  FUN_6001e398(0);
  return;
}

