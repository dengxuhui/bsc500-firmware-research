
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001301c(void)

{
  int iVar1;
  int *piVar2;
  uint uVar3;
  undefined4 uStack00000000;
  undefined4 uStack00000004;
  undefined4 uStack00000008;
  undefined4 uStack0000000c;
  undefined4 uStack00000010;
  undefined4 uStack00000014;
  undefined4 uStack00000018;
  undefined4 uStack0000001c;
  undefined4 uStack00000024;
  undefined4 uStack0000002c;
  undefined4 uStack00000038;
  undefined4 uStack00000040;
  undefined4 uStack00000044;
  undefined4 uStack00000048;
  undefined4 uStack0000004c;
  undefined4 uStack00000054;
  undefined4 uStack00000058;
  undefined4 uStack0000005c;
  undefined4 uStack0000011c;
  undefined4 uStack00000120;
  undefined4 uStack00000124;
  undefined4 uStack00000128;
  undefined4 uStack0000012c;
  undefined4 uStack00000134;
  undefined4 uStack00000140;
  undefined4 uStack00000148;
  undefined4 uStack0000014c;
  undefined4 uStack00000154;
  undefined4 uStack00000158;
  undefined4 uStack00000160;
  undefined4 uStack00000168;
  undefined4 uStack0000016c;
  undefined4 uStack00000174;
  undefined4 uStack00000178;
  undefined4 uStack0000017c;
  undefined4 uStack00000180;
  undefined4 uStack00000184;
  undefined4 uStack00000188;
  undefined4 uStack0000018c;
  undefined4 uStack00000190;
  undefined4 uStack00000194;
  undefined4 uStack00000198;
  undefined4 uStack0000019c;
  undefined4 uStack000001a0;
  undefined4 uStack000001a4;
  undefined4 uStack000001a8;
  undefined4 uStack000001ac;
  undefined4 uStack000001b0;
  undefined4 uStack000001b4;
  
  iVar1 = _DAT_60013278;
  uStack000001b4 = 0x1c00;
  uStack000001ac = 0x1c00;
  uStack000001b0 = 0x1c00;
  uStack00000190 = 0x1015;
  uStack0000018c = 0x1010;
  uStack000001a8 = 0x141e;
  uStack00000188 = 0x424;
  uStack000001a4 = 0x8f4;
  uStack000001a0 = 0x101d;
  uStack0000019c = 0x4f4;
  uStack00000198 = 0x1407;
  uStack00000194 = 0x824;
  uStack00000180 = 0x824;
  uStack00000184 = 0x1405;
  uStack0000017c = 0x1016;
  uStack00000174 = 0x808;
  uStack00000178 = 0x424;
  uStack0000016c = 0x408;
  uStack0000005c = 0x824;
  uStack00000168 = 0x142d;
  uStack00000160 = 0xc06;
  uStack00000158 = 0x1414;
  uStack00000154 = 0x814;
  uStack0000014c = 0x1013;
  uStack00000148 = 0x414;
  uStack00000140 = 0x100b;
  uStack00000134 = 0x101b;
  uStack00000128 = 0x808;
  uStack0000012c = 0x1402;
  uStack00000124 = 0x1009;
  uStack00000120 = 0x1008;
  uStack0000011c = 0x408;
  uStack00000058 = 0xc15;
  uStack00000054 = 0xc10;
  uStack0000004c = 0x424;
  uStack00000048 = 0x814;
  uStack00000044 = 0xc13;
  uStack00000040 = 0x414;
  uStack00000038 = 0x1006;
  uStack0000002c = 0xc0b;
  uStack00000024 = 0x800;
  uStack0000001c = 0xc1b;
  uStack00000014 = 0x808;
  uStack00000018 = 0x400;
  uStack00000010 = 0xc09;
  uStack0000000c = 0xc08;
  uStack00000004 = 0x408;
  uStack00000008 = 0xc04;
  uStack00000000 = 0x44c;
  *(undefined4 *)(_DAT_60013278 + 0x100) = 0;
  *(undefined4 *)(iVar1 + 0x100) = 0x110;
  piVar2 = (int *)(iVar1 + 0x108);
  for (uVar3 = 0; uVar3 = uVar3 & 0xff, uVar3 < 0x22; uVar3 = uVar3 + 1) {
    *piVar2 = *(int *)(&stack0x00000348 + uVar3 * 8) +
              *(int *)(&stack0x0000034c + uVar3 * 8) * 0x10000;
    piVar2 = piVar2 + 1;
  }
  *(int *)(iVar1 + 0x100) = *(int *)(iVar1 + 0x100) + 0x66000;
  piVar2 = (int *)(iVar1 + 400);
  for (uVar3 = 0; uVar3 = uVar3 & 0xff, uVar3 < 0x1b; uVar3 = uVar3 + 1) {
    *piVar2 = *(int *)(&stack0x00000230 + uVar3 * 8) +
              *(int *)(&stack0x00000234 + uVar3 * 8) * 0x10000;
    piVar2 = piVar2 + 1;
  }
  *(undefined4 *)(iVar1 + 0x104) = 0;
  *(undefined4 *)(iVar1 + 0x104) = 0x204;
  piVar2 = (int *)(iVar1 + 0x1fc);
  for (uVar3 = 0; uVar3 = uVar3 & 0xff, uVar3 < 0x14; uVar3 = uVar3 + 1) {
    *piVar2 = *(int *)(&stack0x00000118 + uVar3 * 8) +
              *(int *)((int)&stack0x0000011c + uVar3 * 8) * 0x10000;
    piVar2 = piVar2 + 1;
  }
  *(int *)(iVar1 + 0x104) = *(int *)(iVar1 + 0x104) + 0x97000;
  piVar2 = (int *)(iVar1 + 0x254);
  for (uVar3 = 0; uVar3 = uVar3 & 0xff, uVar3 < 0xe; uVar3 = uVar3 + 1) {
    *piVar2 = *(int *)((int)&stack0x00000000 + uVar3 * 8) +
              *(int *)((int)&stack0x00000004 + uVar3 * 8) * 0x10000;
    piVar2 = piVar2 + 1;
  }
  return;
}

