
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60011710(byte *param_1)

{
  byte bVar1;
  undefined4 uVar2;
  undefined1 *puVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  
  if (param_1 == (byte *)0x0) {
    uVar5 = 0x40;
  }
  else if (*_DAT_60011764 == '\0') {
    uVar5 = 0xca;
  }
  else {
    uVar5 = 0;
    *_DAT_60011764 = '\0';
    bVar1 = *param_1;
    uVar2 = FUN_60163ca0();
    puVar3 = (undefined1 *)FUN_60163ce0(0xe0e,(ushort)bVar1 * 0x100 + 0xe,uVar2,0xe);
    *puVar3 = 9;
    uVar2 = *(undefined4 *)(param_1 + 6);
    uVar4 = *(undefined4 *)(param_1 + 10);
    *(undefined4 *)(puVar3 + 2) = *(undefined4 *)(param_1 + 2);
    *(undefined4 *)(puVar3 + 6) = uVar2;
    *(undefined4 *)(puVar3 + 10) = uVar4;
    FUN_60163ca4();
  }
  return uVar5;
}

