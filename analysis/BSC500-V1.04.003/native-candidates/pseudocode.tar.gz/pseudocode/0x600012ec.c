
/* WARNING: Possible PIC construction at 0x60001306: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60001344: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6000130a) */
/* WARNING: Removing unreachable block (ram,0x60001316) */
/* WARNING: Removing unreachable block (ram,0x60001330) */
/* WARNING: Removing unreachable block (ram,0x60001334) */
/* WARNING: Removing unreachable block (ram,0x60001356) */
/* WARNING: Removing unreachable block (ram,0x60001360) */
/* WARNING: Removing unreachable block (ram,0x6000133e) */
/* WARNING: Removing unreachable block (ram,0x60001348) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_600012ec(void)

{
  undefined1 uVar1;
  bool bVar2;
  undefined4 *puVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  int extraout_r1;
  undefined4 uVar9;
  undefined4 in_r3;
  int unaff_r5;
  undefined4 *puVar10;
  undefined1 auStack_b4 [4];
  int iStack_b0;
  undefined1 auStack_ac [64];
  undefined1 uStack_6c;
  undefined1 uStack_6b;
  byte bStack_68;
  byte bStack_67;
  byte bStack_66;
  byte bStack_65;
  undefined1 auStack_64 [12];
  undefined1 auStack_58 [8];
  int aiStack_50 [10];
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  
  piVar4 = piRam60001380;
  if ((int *)*piRam60001380 == piRam60001380) {
    return (uint)*piRam60001380;
  }
  uStack_18 = in_r3;
  uVar6 = FUN_60167d0c();
  iVar7 = FUN_60163aac();
  uVar9 = uRam600013ac;
  if (iVar7 == 0) {
    bVar2 = (bool)isCurrentModePrivileged();
    if (bVar2) {
      enableIRQinterrupts((uVar6 & 1) == 1);
    }
    return uVar6;
  }
  func_0x60168578(0x60001384,uRam600013ac);
  FUN_6016804c(0x600013b0,uVar9,0x99);
  uRam00000015 = SUB41(piVar4,0);
  *(int **)(unaff_r5 + 0x34) = piVar4;
  puVar10 = *(undefined4 **)(unaff_r5 + 100);
  uVar1 = *(undefined1 *)((int)piVar4 + 0x5b);
  *(undefined1 *)(piVar4[5] + 0xc) = 0;
  puVar3 = puRam0000009f;
  uRam0000006f = 0;
  uRam0000006c = SUB41(puVar10,0);
  puRam0000009f[8] = puRam0000009f[0x18];
  *(undefined1 *)((int)piVar4 + 0xd) = 0x5b;
  puVar3[0x11] = 0x5b;
  *(short *)(extraout_r1 + 0x5b) = (short)extraout_r1;
  uVar9 = *puVar3;
  uStack_28 = puVar3[1];
  uStack_24 = puVar3[2];
  uStack_20 = puVar3[3];
  *puVar10 = uStack_20;
  uStack_1c = 0x6000137f;
  uVar6 = FUN_60134a3c(uStack_20,extraout_r1,uVar9,uVar1);
  aiStack_50[0] = _DAT_60001558;
  if ((uVar6 & 0xfe000000) != 0x10000000) {
    if ((uVar6 & 0xfc000000) == 0x64000000) {
      aiStack_50[0] = _DAT_60001558 + 0x1000;
    }
    else if ((uVar6 & 0xf8000000) == 0x68000000) {
      aiStack_50[0] = _DAT_60001558 + 0x2000;
    }
    else {
      if ((uVar6 & 0xfe000000) != 0x12000000) {
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      aiStack_50[0] = _DAT_60001558 + 0x40000;
    }
  }
  iVar7 = FUN_60134816(aiStack_50);
  if (iVar7 == 0) {
    iVar7 = FUN_60134a46(aiStack_50,0x1000,auStack_ac,0x40);
    if (iVar7 == 0) {
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    iVar8 = FUN_600f5ed6(6,&bStack_68,4,auStack_ac,iVar7);
    puVar5 = _DAT_6000155c;
    if (iVar8 == 0) {
      _DAT_6000155c[9] = _DAT_6000155c[9] & 0xffffffe1 | 0x16;
    }
    else {
      _DAT_6000155c[3] = _DAT_6000155c[3] & 0xfffffe1f | (uint)bStack_68 << 5;
      puVar5[9] = puVar5[9] & 0xffffffe1 | (bStack_67 & 0xf) << 1;
      puVar5[9] = puVar5[9] & 0xffe1ffff | (bStack_67 & 0xf0) << 0xd;
      *puVar5 = *puVar5 & 0xffffc3ff | (uint)bStack_66 << 10;
      puVar5[4] = puVar5[4] & 0xfffffe1f | (uint)bStack_65 << 5;
    }
    iVar8 = FUN_600f5ed6(3,&iStack_b0,4,auStack_ac,iVar7);
    if ((iVar8 == 0) || (iStack_b0 == 0x3ff || iStack_b0 == 0)) {
      iStack_b0 = 0x1ea;
    }
    FUN_601633bc(iStack_b0);
    iVar8 = FUN_600f5ed6(4,auStack_b4,4,auStack_ac,iVar7);
    if (iVar8 != 0) {
      FUN_60163310(0,auStack_b4,4);
    }
    iVar8 = FUN_600f5ed6(5,auStack_58,8,auStack_ac,iVar7);
    if (iVar8 != 0) {
      FUN_60163310(1,auStack_58,8);
    }
    iVar8 = FUN_600f5ed6(9,auStack_64,0xc,auStack_ac,iVar7);
    if (iVar8 != 0) {
      FUN_60163310(4,auStack_64,0xc);
    }
    iVar7 = FUN_600f5ed6(0x14,&uStack_6c,2,auStack_ac,iVar7);
    if (iVar7 == 0) {
      uStack_6b = 0;
      *_DAT_60001560 = 0;
    }
    else {
      *_DAT_60001560 = uStack_6c;
    }
    uVar9 = _DAT_60001568;
    *_DAT_60001564 = uStack_6b;
    iVar7 = FUN_60134a46(aiStack_50,0x2000,uVar9,0x100);
    if (iVar7 != 0) {
      iVar7 = FUN_60134a46(aiStack_50,0x3000,_DAT_6000156c,0x100);
      if (iVar7 != 0) {
        return 0;
      }
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

