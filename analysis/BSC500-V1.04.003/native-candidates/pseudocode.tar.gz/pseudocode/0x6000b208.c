
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000b208(void)

{
  undefined4 uVar1;
  int iVar2;
  
  uVar1 = _DAT_6000b214;
  iVar2 = _DAT_6000b220 + 0x18;
  FUN_6012c99c();
  FUN_6015d388(iVar2,uVar1,0);
  return 0;
}

