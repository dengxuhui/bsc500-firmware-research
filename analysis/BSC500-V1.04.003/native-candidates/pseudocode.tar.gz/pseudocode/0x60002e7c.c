
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60002e7c(void)

{
  int iVar1;
  undefined4 uVar2;
  byte bVar3;
  undefined2 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  uint auStack_3c [8];
  
  iVar1 = _DAT_60002f8c;
  if (*(int *)(_DAT_60002f8c + 8) + 1U < 2) {
    iVar5 = FUN_600069b8();
    if (iVar5 != 0) {
      func_0x60134ac8(auStack_3c,0,0x20);
      func_0x6015f784(auStack_3c,iVar5,0x1f);
      uVar6 = FUN_6001b628(auStack_3c,&UNK_60002f90);
      uVar7 = FUN_60168220(auStack_3c);
      if (uVar6 == uVar7) {
        bVar3 = 0;
        uVar7 = 0;
        iVar5 = 0;
        while (bVar3 < uVar6) {
          uVar9 = (uint)*(byte *)((int)auStack_3c + (uint)bVar3);
          bVar3 = bVar3 + 1;
          uVar10 = uVar9 + uVar7 * 0x10;
          iVar11 = ((iVar5 << 4 | uVar7 >> 0x1c) + (uint)CARRY4(uVar9,uVar7 * 0x10)) -
                   (uint)(uVar10 < 0x30);
          uVar10 = uVar10 - 0x30;
          if (9 < uVar9 - 0x30) {
            iVar11 = iVar5;
            uVar10 = uVar7;
          }
          uVar8 = uVar9 + uVar10 * 0x10;
          uVar7 = uVar8 - 0x37;
          iVar5 = ((iVar11 << 4 | uVar10 >> 0x1c) + (uint)CARRY4(uVar9,uVar10 * 0x10)) -
                  (uint)(uVar8 < 0x37);
          if (5 < uVar9 - 0x41) {
            uVar7 = uVar10;
            iVar5 = iVar11;
          }
        }
        *(int *)(iVar1 + 4) = iVar5;
        *(uint *)(iVar1 + 8) = uVar7;
        goto LAB_60002f2e;
      }
    }
    FUN_60004dfa(iVar1 + 4,iVar1 + 8);
  }
LAB_60002f2e:
  uVar2 = _DAT_60002fa4;
  *(undefined2 *)(iVar1 + 0x10) = 100;
  *(undefined4 *)(iVar1 + 0x14) = uVar2;
  uVar4 = FUN_6000495c();
  *(undefined2 *)(iVar1 + 0x18) = uVar4;
  func_0x60168578(&UNK_60002fa8,uVar4);
  func_0x60168578(&UNK_60002fbc,*(undefined4 *)(iVar1 + 0x14));
  auStack_3c[0] = 100;
  *_DAT_60002fcc = *(undefined2 *)(iVar1 + 0x18);
  iVar5 = FUN_6016243c(&UNK_60002fd0,&UNK_60002fe8,auStack_3c);
  uVar6 = auStack_3c[0];
  if (auStack_3c[0] < 100) {
    uVar6 = 100;
  }
  uVar4 = (undefined2)uVar6;
  if (iVar5 == 0) {
    uVar4 = 100;
  }
  *(undefined2 *)(iVar1 + 0x1e) = uVar4;
  uVar4 = FUN_6001de30(0);
  *(undefined2 *)(iVar1 + 0x1c) = uVar4;
  return;
}

