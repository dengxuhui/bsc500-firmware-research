
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_6000a618(void)

{
  int iVar1;
  undefined *puVar2;
  int iVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  undefined *puVar11;
  int iVar12;
  
  iVar1 = FUN_6015982e();
  FUN_60159828(iVar1,5,0,0);
  puVar2 = (undefined *)FUN_6015bd44();
  iVar6 = _DAT_6000a63c;
  if ((puVar2 == (undefined *)0x0) && (iVar1 != 0)) {
    func_0x6011ed5c(iVar1);
  }
  else if (iVar1 == 0) {
    iVar1 = FUN_6015982e();
    FUN_60159828(iVar1,iVar6,0,0);
  }
  iVar10 = *(int *)(_DAT_60159870 + 8);
  puVar11 = puVar2;
  if (iVar10 == 0) {
    if (iVar1 != 0) {
      func_0x60139eac(iVar1);
      puVar11 = puVar2;
    }
  }
  else {
    iVar12 = iVar6;
    iVar9 = iVar1;
    iVar3 = FUN_60133088();
    uVar8 = _DAT_600570a8;
    uVar7 = _DAT_60057044;
    if (iVar3 != 0) {
      piVar4 = (int *)(iVar10 + 4);
      do {
        piVar4 = (int *)*piVar4;
        if (piVar4 == (int *)0x0) {
LAB_6005702c:
          FUN_601330ec();
          if (iVar1 != 0) {
LAB_60057036:
            func_0x60139eac(iVar1);
          }
          return CONCAT44(puVar11,1);
        }
        if (((undefined *)piVar4[1] == puVar2) && (*piVar4 == iVar6)) {
          puVar5 = (undefined4 *)FUN_60139e84(puVar2);
          if (puVar5 != (undefined4 *)0x0) {
            puVar11 = (undefined *)piVar4[3];
            iVar6 = FUN_60058f40(puVar5[1],piVar4[2],puVar5[3],iVar1,puVar11,iVar12,iVar9,unaff_r4,
                                 unaff_r5,unaff_r6);
            if (iVar6 == 0) {
              if (puVar5[1] != 0) {
                uVar7 = FUN_60052acc();
                uVar8 = FUN_6005b1e8(puVar5[1]);
                iVar9 = FUN_6012376e(puVar5[1]);
                func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057048,uVar7,uVar8,iVar9);
              }
              puVar11 = (undefined *)*puVar5;
              uVar7 = FUN_6013a3fc(puVar11);
              func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057074,puVar11,uVar7,iVar9);
            }
            else if (((puVar5[1] == 0) && (iVar1 != 0)) && (puVar5[3] != 0)) {
              func_0x60139eac(iVar1);
              FUN_601330ec();
              goto LAB_60057036;
            }
            goto LAB_6005702c;
          }
          puVar11 = &UNK_60057094;
          func_0x60167f3c(3,uVar7,1,uVar8);
        }
        piVar4 = piVar4 + 4;
      } while( true );
    }
  }
  return ZEXT48(puVar11) << 0x20;
}

