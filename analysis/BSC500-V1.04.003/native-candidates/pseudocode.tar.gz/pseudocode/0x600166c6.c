
undefined4 FUN_600166c6(int param_1,uint *param_2)

{
  ushort uVar1;
  undefined4 uVar2;
  
  if (param_1 == 0) {
    uVar2 = 0;
  }
  else {
    uVar2 = 1;
    uVar1 = func_0x60137ef6(param_1 + -4,1);
    *param_2 = (uint)uVar1;
    if (uVar1 == 0) {
      func_0x6015e008(param_1 + -4);
      uVar2 = 1;
    }
  }
  return uVar2;
}

