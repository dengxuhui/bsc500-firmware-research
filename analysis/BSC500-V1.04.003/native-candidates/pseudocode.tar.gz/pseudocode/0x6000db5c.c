
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000db5c(undefined4 param_1)

{
  char *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 auStack_34 [32];
  int iStack_14;
  
  pcVar1 = _DAT_6000dbc8;
  if (*_DAT_6000dbc8 == '\x01') {
    iStack_14 = 0;
    ZeroBytes(auStack_34,0x20);
    iVar2 = FUN_60161ef4(*(undefined4 *)(pcVar1 + 4),auStack_34,0x20,&iStack_14);
    uVar3 = 0xffffffff;
    if ((iVar2 == 0) && (iStack_14 == 0x20)) {
      CopyBytes(param_1,auStack_34,0x20);
      iVar2 = *(int *)(pcVar1 + 0xc);
      uVar3 = 0;
      *(uint *)(pcVar1 + 0xc) = iVar2 + 1U;
      if (iVar2 + 1U < *(uint *)(pcVar1 + 8)) {
        return 0;
      }
    }
    FUN_601608f8();
  }
  else {
    uVar3 = 1;
  }
  return uVar3;
}

