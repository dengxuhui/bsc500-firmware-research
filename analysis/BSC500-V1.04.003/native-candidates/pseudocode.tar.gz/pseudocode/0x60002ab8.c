
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_60002ab8(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined1 auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  ZeroBytes(auStack_30,0x20);
  uStack_3c = 0;
  uStack_38 = 0;
  uStack_44 = _DAT_60002b0c;
  uStack_40 = 0;
  uStack_34 = _DAT_60002b0c;
  uVar2 = FUN_60165194(0xffff,0,&uStack_44);
  iVar1 = _DAT_60002b10;
  *(undefined4 *)(_DAT_60002b10 + 8) = uVar2;
  uStack_1c = 0x31;
  uStack_20 = 0xc00;
  uVar2 = FUN_601566b4(_DAT_60002b14,0,&uStack_34);
  *(undefined4 *)(iVar1 + 4) = uVar2;
  FUN_60156808();
  return *(int *)(iVar1 + 4) != 0;
}

