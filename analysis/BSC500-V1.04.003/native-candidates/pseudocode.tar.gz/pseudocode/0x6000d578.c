
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000d578(void)

{
  char cVar1;
  char cVar2;
  byte bVar3;
  int iVar4;
  
  bVar3 = 0;
  iVar4 = 5;
  do {
    if (iVar4 == 0) {
      func_0x60168578(&UNK_6000d5c0);
      return 0;
    }
    cVar1 = FUN_6013679c(5);
    cVar2 = FUN_6013679c(7);
    if ((cVar1 == '\0') && (cVar2 != '\0')) {
      bVar3 = bVar3 + 1;
      if (1 < bVar3) {
        *_DAT_6000d5bc = 1;
        return 1;
      }
    }
    FUN_60165070(10);
    iVar4 = iVar4 + -1;
  } while( true );
}

