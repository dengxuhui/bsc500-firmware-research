
int FUN_6001928c(uint param_1,int param_2,uint param_3,undefined4 param_4)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  
  iVar1 = FUN_6016087c();
  if (iVar1 == 0) {
LAB_60019370:
    iVar5 = 0;
  }
  else {
    if (param_3 == 0) {
      return 0;
    }
    if (*(char *)(iVar1 + 0x20) != '\0') {
      return 0;
    }
    uVar6 = *(uint *)(iVar1 + 0x14);
    FUN_6015f000(param_2,param_3);
    iVar8 = 0;
    uVar9 = param_1 - uVar6;
    if (param_1 < uVar6) {
      uVar9 = param_1;
    }
    if ((*(char *)(iVar1 + 0x21) != '\0') && ((uVar9 & 1) != 0)) {
      iVar8 = 1;
      FUN_60134a28(iVar1,uVar9,param_2,1,param_4);
      param_3 = param_3 - 1;
      param_2 = param_2 + 1;
      uVar9 = uVar9 + 1;
    }
    if ((int)param_3 < 1) {
      return iVar8;
    }
    iVar5 = 0x100 << (uint)*(byte *)(iVar1 + 0x21);
    uVar6 = iVar5 - 1U & uVar9;
    if (0 < (int)uVar6) {
      uVar6 = iVar5 - uVar6;
      if ((int)param_3 < (int)uVar6) {
        uVar6 = param_3;
      }
      if ((*(byte *)(iVar1 + 0x21) != 0) && ((uVar6 & 1) != 0)) {
        iVar5 = FUN_60134a1e(iVar1,uVar9,param_2,uVar6 & 0xfffffffe);
        FUN_60134a28(iVar1,iVar5 + uVar9,param_2 + iVar5,0,param_4);
        return iVar8 + uVar6;
      }
      uVar2 = FUN_60134a1e(iVar1,uVar9,param_2,uVar6);
      if (uVar2 != uVar6) goto LAB_60019370;
      iVar8 = iVar8 + uVar6;
      param_3 = param_3 - uVar6;
      param_2 = param_2 + uVar6;
      uVar9 = uVar9 + uVar6;
    }
    iVar7 = 0;
    while( true ) {
      iVar4 = param_2 + iVar7;
      iVar3 = uVar9 + iVar7;
      if ((int)param_3 < iVar5) break;
      FUN_60134a1e(iVar1,iVar3,iVar4,iVar5);
      iVar7 = iVar7 + iVar5;
      param_3 = param_3 - iVar5;
    }
    iVar8 = iVar8 + iVar7;
    iVar5 = iVar8;
    if (0 < (int)param_3) {
      if (((param_3 & 1) == 0) || (*(char *)(iVar1 + 0x21) == '\0')) {
        uVar9 = FUN_60134a1e(iVar1,iVar3,iVar4,param_3);
        iVar5 = 0;
        if (uVar9 == param_3) {
          iVar5 = iVar8 + param_3;
        }
      }
      else {
        iVar5 = FUN_60134a1e(iVar1,iVar3,iVar4,param_3 & 0xfffffffe);
        FUN_60134a28(iVar1,iVar5 + uVar9 + iVar7,iVar5 + param_2 + iVar7,0);
        iVar5 = iVar8 + param_3;
      }
    }
  }
  return iVar5;
}

