
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006c80(undefined4 *param_1)

{
  undefined4 *puVar1;
  
  puVar1 = _DAT_60006c8c;
  *_DAT_60006c8c = *param_1;
  puVar1[1] = param_1[1];
  return;
}

