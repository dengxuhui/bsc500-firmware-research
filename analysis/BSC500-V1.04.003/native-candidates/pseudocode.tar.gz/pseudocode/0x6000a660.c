
/* WARNING: Possible PIC construction at 0x6000a672: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6000a676) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a660(void)

{
  int iVar1;
  int *piVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  int *piStack_28;
  int iStack_14;
  int iStack_10;
  int iStack_c;
  
  iVar1 = _DAT_60161478;
  iStack_14 = _DAT_6000a680 + 0x11;
  iStack_10 = _DAT_6000a680 + 0x31;
  iStack_c = _DAT_6000a680 + 0x51;
  piStack_28 = &iStack_14;
  FUN_60001d60(_DAT_60161478,&UNK_6000a684,&piStack_28);
  piVar2 = _DAT_6016147c;
  if (*_DAT_6016147c != _DAT_60161480) {
    *_DAT_6016147c = _DAT_60161480;
    piVar2[1] = 0;
  }
  puVar3 = _DAT_60161484;
  if ((*_DAT_60161484 < 0x1ff8) && (uVar4 = *(uint *)(iVar1 + 8), uVar4 != 0)) {
    uVar5 = 0x1ff8;
    if (uVar4 < 0x1ff8) {
      uVar5 = uVar4;
    }
    piVar2[1] = uVar5;
    *puVar3 = uVar5;
  }
  return;
}

