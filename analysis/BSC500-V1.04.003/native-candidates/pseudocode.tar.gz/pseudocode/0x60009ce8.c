
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009ce8(void)

{
  int *piVar1;
  ushort *puVar2;
  ushort *puVar3;
  ushort uVar4;
  ushort uVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  uint uVar9;
  uint uVar10;
  char *pcVar11;
  uint uVar12;
  
  uVar10 = 0;
  iVar8 = _DAT_60009e1c;
  do {
    if (uVar10 == 3) {
      return;
    }
    pcVar11 = (char *)(iVar8 + uVar10 * 0x28);
    piVar1 = (int *)(pcVar11 + 0x10);
    if (*piVar1 == 0) {
LAB_60009d56:
      if (pcVar11[10] != '\0') {
        FUN_60133d38(*(undefined4 *)(pcVar11 + 0x14));
        FUN_60133d0c(uVar10 & 0xff);
        pcVar11[10] = '\0';
        func_0x60168578(&UNK_60009e20);
      }
    }
    else {
      if (*(char *)(iVar8 + uVar10 * 0x28) == '\0') {
        iVar6 = FUN_6013f31e(*(undefined4 *)(pcVar11 + 0x14));
        if (iVar6 == 0) {
          FUN_60161fcc(*(undefined4 *)(pcVar11 + 0x14),pcVar11 + 0x1c,0);
          *pcVar11 = '\x01';
        }
      }
      if (*piVar1 == 0) goto LAB_60009d56;
      if ((*pcVar11 == '\0') || (pcVar11[1] != '\0')) {
        if (pcVar11[2] != '\0') {
          FUN_60133d0c(uVar10 & 0xff);
        }
      }
      else {
        puVar2 = (ushort *)(pcVar11 + 0x1c);
        uVar7 = (uint)*puVar2;
        puVar3 = (ushort *)(pcVar11 + 0x22);
        uVar9 = (uint)*puVar3;
        if (uVar9 < uVar7) {
          uVar4 = *(ushort *)(pcVar11 + 0xc);
          uVar12 = (uint)uVar4;
          do {
            uVar7 = uVar7 - (uVar9 & 0xffff);
            uVar5 = (ushort)uVar7;
            if ((int)uVar12 < (int)uVar7) {
              uVar5 = uVar4;
            }
            iVar8 = FUN_600f6674(*piVar1,*(int *)(pcVar11 + 0x24) + (uVar9 & 0xffff),uVar5);
            if (iVar8 != 0) {
              FUN_60163840(*(undefined4 *)(pcVar11 + 0x18));
              FUN_6016507e(*(undefined4 *)(pcVar11 + 0x18),200,pcVar11);
              uVar7 = (uint)*puVar2;
              uVar9 = (uint)*puVar3;
              break;
            }
            if ((int)uVar12 < (int)uVar7) {
              uVar7 = uVar12;
            }
            uVar9 = *puVar3 + uVar7;
            uVar7 = (uint)*puVar2;
            *puVar3 = (ushort)uVar9;
          } while ((uVar9 & 0xffff) < uVar7);
        }
        iVar8 = _DAT_60009e1c;
        if (uVar7 <= (uVar9 & 0xffff)) {
          pcVar11[2] = '\0';
          pcVar11[1] = '\x01';
          FUN_60163840(*(undefined4 *)(pcVar11 + 0x18));
          FUN_6016507e(*(undefined4 *)(pcVar11 + 0x18),5000,pcVar11);
        }
      }
      if (*piVar1 == 0) goto LAB_60009d56;
    }
    uVar10 = uVar10 + 1;
  } while( true );
}

