
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_6000af0c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_c = 0;
  uStack_14 = 0;
  uStack_10 = 0;
  FUN_600521dc(&uStack_c,&uStack_10,&uStack_14,param_4,param_1);
  uVar1 = 0;
  FUN_6015b134(_DAT_6000af30,uStack_14,uStack_c,uStack_10);
  return CONCAT44(uStack_14,uVar1);
}

