
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000f40(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = _DAT_60000f60;
  if (param_1 - 1U >> 0x18 == 0) {
    _DAT_60000f60[1] = param_1 - 1U;
    *_DAT_60000f64 = 0xe0;
    puVar1[2] = 0;
    *puVar1 = 7;
    return;
  }
  return;
}

