
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600153ac(int param_1)

{
  ZeroBytes(param_1 + 0xa8c,0x18);
  *(undefined2 *)(param_1 + 0xa9c) = 0x102;
  *(undefined4 *)(param_1 + 0xa94) = _DAT_600153d8;
  *(undefined2 *)(param_1 + 0xa90) = 0x604;
  *(undefined4 *)(param_1 + 0xa8c) = _DAT_600153dc;
  return;
}

