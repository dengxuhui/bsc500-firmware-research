
/* WARNING: Possible PIC construction at 0x60000d94: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x60000d98) */
/* WARNING: Removing unreachable block (ram,0x60000daa) */
/* WARNING: Removing unreachable block (ram,0x60000dac) */
/* WARNING: Removing unreachable block (ram,0x60000dfc) */
/* WARNING: Removing unreachable block (ram,0x60000e0c) */
/* WARNING: Removing unreachable block (ram,0x60000e00) */
/* WARNING: Removing unreachable block (ram,0x60000e06) */
/* WARNING: Removing unreachable block (ram,0x60000e08) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000d18(int param_1,uint param_2,undefined4 param_3,int param_4)

{
  ushort uVar1;
  undefined2 uVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined4 *puVar9;
  uint extraout_r2;
  int extraout_r3;
  int iVar10;
  int unaff_r4;
  int unaff_r5;
  int unaff_r6;
  int unaff_r7;
  uint uVar11;
  int unaff_r8;
  int *piVar12;
  int unaff_lr;
  int *piVar13;
  int iStack_18;
  
  piVar12 = &iStack_18;
  iStack_18 = param_4;
  iVar5 = FUN_60167d0c();
  iVar6 = FUN_60163aac();
  if (iVar6 == 0) {
    uVar11 = param_2 & 0xfffffffc;
    func_0x60167d14(iVar5);
    iVar5 = iRam60000db0;
    if ((0x30 < uVar11) &&
       (puVar9 = (undefined4 *)(param_1 + 3U & 0xfffffffc), puVar9 <= (undefined4 *)(uVar11 - 0x30))
       ) {
      *(uint *)(iRam60000db0 + 8) = (uVar11 - (int)puVar9) + -0x30;
      *(undefined4 **)(iVar5 + 0xc) = puVar9;
      puVar9[2] = 0;
      puVar9[1] = (uVar11 - (int)puVar9) + -0x18;
      *puVar9 = 0x1ea0;
      *(uint *)(iVar5 + 0x10) = uVar11 - 0x18;
      FUN_60162cd4();
      func_0x60167ef4(iVar5 + 0x2c,0x60000db4,1,0);
      *(undefined4 *)(iVar5 + 0x14) = *(undefined4 *)(iVar5 + 0xc);
      *(undefined4 *)(iVar5 + 0x18) = 0;
      return;
    }
    uVar7 = 0x60000dbc;
    iVar6 = param_1;
    iVar10 = iStack_18;
    param_1 = unaff_r5;
    iVar5 = unaff_r6;
    piVar12 = (int *)register0x00000054;
  }
  else {
    unaff_lr = 0x60000d99;
    uVar7 = uRam60000da4;
    iVar6 = iRam60000da8;
    param_2 = extraout_r2;
    iVar10 = extraout_r3;
    unaff_r4 = iRam60000da8;
  }
  iVar3 = _DAT_60168628;
  piVar12[-4] = unaff_lr;
  piVar12[-5] = unaff_r8;
  piVar12[-6] = unaff_r7;
  piVar12[-7] = iVar5;
  piVar12[-8] = param_1;
  piVar12[-9] = unaff_r4;
  piVar13 = piVar12 + -10;
  *piVar13 = iVar10;
  piVar12[-3] = iVar6;
  piVar12[-2] = param_2;
  piVar12[-1] = iVar10;
  if (*(int *)(_DAT_60168628 + 8) == 0) {
    *piVar13 = (int)(piVar12 + -3);
    if (*(int *)(_DAT_60168628 + 4) == 0) {
      uVar11 = FUN_6012ef90(_DAT_6016862c,0xff,uVar7,*piVar13);
      iVar5 = *(int *)(iVar3 + 4);
      if (iVar5 == 0) {
        FUN_60154ab4(_DAT_6016862c);
      }
      else {
        uVar1 = *(ushort *)(iVar5 + 0x20);
        *(ushort *)(iVar5 + 0x20) = uVar1 | 0x40;
        uVar8 = 0xff;
        if (uVar11 < 0xff) {
          uVar8 = uVar11;
        }
        FUN_6015ef88(iVar5,0,_DAT_6016862c,uVar8);
        *(ushort *)(*(int *)(iVar3 + 4) + 0x20) = uVar1;
      }
    }
    else {
      uVar2 = *(undefined2 *)(*(int *)(_DAT_60168628 + 4) + 0x20);
      iVar5 = FUN_6001a8b4();
      if ((iVar5 == 0) || (iVar5 = FUN_6015b3f4(), iVar5 != 0)) {
        uVar4 = _DAT_6016862c;
        uVar8 = FUN_6012ef90(_DAT_6016862c,0xff,uVar7,*piVar13);
        iVar5 = *(int *)(iVar3 + 4);
        *(ushort *)(iVar5 + 0x20) = (*(ushort *)(iVar5 + 0x20) & 0xf7bf) + 0x40;
        uVar11 = 0xff;
        if (uVar8 < 0xff) {
          uVar11 = uVar8;
        }
        FUN_6015ef88(iVar5,0,uVar4,uVar11);
        *(undefined2 *)(*(int *)(iVar3 + 4) + 0x20) = uVar2;
      }
      else {
        FUN_6001a8bc(uVar7,*piVar13);
      }
    }
  }
  return;
}

