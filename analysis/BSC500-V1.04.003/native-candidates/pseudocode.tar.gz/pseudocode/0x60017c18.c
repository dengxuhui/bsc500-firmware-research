
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60017c18(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  int *piVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  int iVar15;
  
  puVar9 = _DAT_60017e68;
  puVar8 = _DAT_60017e50;
  _DAT_60017e50[0xd] = _DAT_60017ddc;
  puVar8[0xe] = 300;
  uVar2 = _DAT_60017de0;
  puVar9[0x15] = 0;
  puVar9[0x12] = 0;
  puVar9[6] = 0;
  puVar9[4] = 0;
  puVar9[2] = 0;
  *puVar9 = 0;
  puVar8[0xc] = uVar2;
  FUN_6013a776(puVar8 + 0xc);
  puVar3 = _DAT_60017de4;
  _DAT_60017de4[0x18] = 0x3f800000;
  FUN_6013a76e(puVar3 + 0x12);
  uVar2 = _DAT_60017de8;
  puVar8[0x14] = 0x14;
  puVar8[0x11] = 100;
  puVar8[0x10] = uVar2;
  FUN_6013a760(puVar8 + 0x10);
  uVar7 = _DAT_60017dfc;
  uVar5 = _DAT_60017df4;
  uVar2 = _DAT_60017df0;
  puVar4 = _DAT_60017dec;
  _DAT_60017dec[0x21] = _DAT_60018044;
  puVar4[0x22] = uVar5;
  uVar6 = _DAT_60017df8;
  puVar4[0x23] = uVar2;
  puVar4[5] = uVar7;
  puVar4[6] = uVar6;
  uVar6 = _DAT_60017e04;
  uVar2 = _DAT_60017e00;
  puVar4[7] = uVar5;
  puVar4[8] = 0x32;
  *puVar4 = uVar6;
  puVar4[1] = uVar2;
  puVar4[2] = uVar5;
  puVar4[3] = 0x32;
  FUN_6013a752();
  puVar8[0x16] = _DAT_60017e08;
  puVar8[0x1a] = 8;
  puVar8[0x17] = 0x14;
  FUN_6013a744();
  uVar2 = _DAT_60017e0c;
  puVar3[4] = 8;
  *puVar3 = uVar2;
  puVar3[1] = 0x14;
  FUN_6013a744(puVar3);
  iVar12 = _DAT_60017e1c;
  piVar10 = _DAT_60017e10;
  _DAT_60017e10[8] = _DAT_60017e14;
  piVar10[0xc] = _DAT_60017e18;
  piVar10[0x11] = 0;
  piVar10[0xf] = 100;
  piVar10[9] = iVar12;
  piVar10[10] = 0x78;
  FUN_6013a6e6();
  FUN_6013a6f4(puVar9 + 0x18);
  FUN_6013a6f4(puVar9 + 0x1b);
  iVar15 = _DAT_60017e2c;
  iVar12 = _DAT_60017e28;
  iVar11 = _DAT_60017e20;
  iVar13 = _DAT_60017e24;
  for (iVar14 = 0; iVar14 != 0x208; iVar14 = iVar14 + 0x34) {
    *(int *)(iVar12 + iVar14) = iVar11;
    *(int *)(iVar15 + iVar14) = iVar13;
    iVar13 = iVar13 + 0x5a0;
    iVar11 = iVar11 + 0x5a0;
  }
  piVar10[7] = 10;
  piVar10[3] = 10;
  piVar10[4] = iVar12;
  *piVar10 = iVar15;
  puVar3[6] = piVar10;
  puVar3[0xb] = 0;
  puVar3[7] = puVar9 + 0x12;
  puVar3[8] = 2;
  FUN_6013a6de();
  puVar9[8] = _DAT_60017de0;
  puVar9[9] = 300;
  uVar6 = _DAT_60017e38;
  puVar9[10] = _DAT_60017de8;
  puVar9[0xb] = 100;
  puVar9[0xc] = _DAT_60017e08;
  puVar9[0xd] = 0x14;
  uVar5 = _DAT_60017e30;
  puVar9[0xe] = uVar2;
  puVar9[0xf] = 0x14;
  *puVar8 = uVar5;
  puVar8[1] = 0x32;
  puVar4 = _DAT_60017e34;
  puVar8[2] = 0;
  *puVar4 = uVar6;
  puVar4[1] = 0x78;
  iVar12 = _DAT_60017e3c;
  for (iVar15 = 0; iVar15 != 0x40; iVar15 = iVar15 + 0x10) {
    *(int *)((int)puVar4 + iVar15 + 0x34) = iVar12;
    *(undefined4 *)((int)puVar4 + iVar15 + 0x40) = 100;
    iVar12 = iVar12 + 800;
  }
  puVar1 = puVar3 + 0xc;
  *puVar1 = puVar4 + 0xd;
  puVar3[0x11] = 0;
  puVar3[0xd] = puVar9 + 0x12;
  puVar3[0xe] = 4;
  FUN_6013a6d6(puVar1);
  piVar10[0x12] = (int)puVar1;
  iVar12 = _DAT_60017e40;
  piVar10[0x17] = 100;
  piVar10[0x13] = (int)(puVar9 + 10);
  piVar10[0x14] = iVar12;
  FUN_6013a6c4(piVar10 + 0x12);
  puVar9[0x10] = iVar12;
  puVar9[0x11] = 0;
  puVar8[6] = puVar8 + 3;
  puVar8[7] = puVar3 + 6;
  puVar8[8] = puVar9 + 0xc;
  if (puVar8 + 6 != (undefined4 *)0x0) {
    piVar10 = (int *)puVar8[7];
    if (piVar10 != (int *)0x0) {
      if (piVar10 != (int *)0x0) {
        iVar15 = 0;
        piVar10[3] = 0;
        piVar10[4] = 0;
        for (iVar12 = piVar10[2]; iVar12 != 0; iVar12 = iVar12 + -1) {
          if (*piVar10 != 0) {
            iVar11 = *piVar10 + iVar15;
            *(undefined4 *)(iVar11 + 4) = 0;
            *(undefined4 *)(iVar11 + 8) = 0;
          }
          iVar15 = iVar15 + 0x10;
        }
      }
      return;
    }
    return;
  }
  return;
}

