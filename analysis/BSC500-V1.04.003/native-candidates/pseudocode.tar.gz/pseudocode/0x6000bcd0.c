
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000bcd0(void)

{
  undefined4 uVar1;
  uint3 in_r3;
  uint uVar2;
  bool bVar3;
  undefined4 uStack_14;
  
  uStack_14 = (uint)in_r3;
  uVar1 = func_0x60166f2c(_DAT_6000bd10);
  uVar2 = 0;
  do {
    FUN_60165124(uVar1,0x1c,(int)&uStack_14 + 3);
    if (uStack_14._3_1_ == '\0') break;
    FUN_60167188(10);
    bVar3 = uVar2 < 0x13;
    uVar2 = uVar2 + 1;
  } while (bVar3);
  FUN_60165124(uVar1,0x16,0);
  return;
}

