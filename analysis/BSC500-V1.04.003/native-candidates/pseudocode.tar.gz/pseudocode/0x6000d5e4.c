
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d5e4(void)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = _DAT_6000d64c;
  FUN_6013bc48(0);
  puVar1 = (undefined4 *)*puVar1;
  *puVar1 = 0;
  puVar1[1] = 0;
  puVar1[2] = 0;
  iVar2 = *_DAT_6013bc68;
  *_DAT_6013bc68 = iVar2 + -1;
  if (iVar2 + -1 != 0) {
    return;
  }
  enableIRQinterrupts();
  return;
}

