
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016098(void)

{
  int *piVar1;
  int *piVar2;
  ushort uVar3;
  char *pcVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  int iVar8;
  
  pcVar4 = (char *)FUN_60164940();
  iVar5 = FUN_60164fe0();
  iVar6 = FUN_60117f68();
  if (iVar6 != 0) {
    FUN_6001c9ec(0);
  }
  iVar6 = FUN_601673b8();
  if ((iVar6 == 0) || (iVar6 = FUN_60117f68(), piVar2 = _DAT_60016160, iVar6 != 0)) {
    piVar2 = _DAT_60016160;
    *_DAT_60016160 = *(int *)(pcVar4 + 0x14);
    piVar2[1] = 0;
  }
  else {
    if (*pcVar4 != '\0') {
      if (iVar5 != 0) {
        uVar3 = *(ushort *)(pcVar4 + 4);
        iVar8 = *(int *)(pcVar4 + 0x14);
        iVar6 = *_DAT_60016160;
        piVar1 = _DAT_60016160 + 1;
        *_DAT_60016160 = iVar8;
        uVar7 = (iVar8 - iVar6) * (uVar3 / 10) + *piVar1;
        uVar3 = *(ushort *)(iVar5 + 0x8ac);
        piVar2[1] = uVar7;
        while( true ) {
          if ((uVar7 <= *(uint *)(iVar5 + (uint)uVar3 * 8 + 0xd4)) ||
             (((uint)*(ushort *)(iVar5 + 200) <= (uint)uVar3 &&
              (*(uint *)(iVar5 + (uint)*(ushort *)(iVar5 + 200) * 8 + 0xc4) < uVar7)))) break;
          uVar3 = uVar3 + 1;
          *(ushort *)(iVar5 + 0x8ac) = uVar3;
        }
        FUN_6001c9ec();
        uVar3 = *(ushort *)(iVar5 + 0x8ae);
        uVar7 = piVar2[1];
        while ((*(uint *)(iVar5 + (uint)uVar3 * 8 + 0x588) < uVar7 &&
               (((uint)uVar3 < (uint)*(ushort *)(iVar5 + 0x57c) ||
                (uVar7 <= *(uint *)(iVar5 + (uint)*(ushort *)(iVar5 + 0x57c) * 8 + 0x578)))))) {
          uVar3 = uVar3 + 1;
          *(ushort *)(iVar5 + 0x8ae) = uVar3;
        }
      }
      return 0;
    }
    *_DAT_60016160 = *(int *)(pcVar4 + 0x14);
  }
  return 0xffffffff;
}

