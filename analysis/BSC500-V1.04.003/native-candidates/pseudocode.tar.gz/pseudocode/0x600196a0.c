
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_600196a0(void)

{
  code *pcVar1;
  code *pcVar2;
  int iVar3;
  
  iVar3 = FUN_60023390(_DAT_600196f8);
  if (iVar3 != 0) {
    return iVar3;
  }
  FUN_600e986c();
  pcVar1 = _DAT_600196fc;
  (*_DAT_600196fc)(0x32);
  FUN_600eb500();
  (*pcVar1)(0x32);
  FUN_600e986c();
  pcVar2 = _DAT_60019704;
  (*_DAT_60019704)(_DAT_60019700);
  (*pcVar2)(_DAT_60019708);
  (*pcVar2)(_DAT_6001970c);
  (*pcVar1)(0x32);
  FUN_600eb500();
  (*pcVar1)(300);
  iVar3 = FUN_600233b0(_DAT_60019710,_DAT_60019714,_DAT_60019718,_DAT_6001971c,0);
  thunk_FUN_600263c4();
  return iVar3;
}

