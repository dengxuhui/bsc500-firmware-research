
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000495c(void)

{
  return *_DAT_60004964;
}

