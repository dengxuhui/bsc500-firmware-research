
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600182e4(void)

{
  return *(undefined4 *)(_DAT_600182ec + 0x34);
}

