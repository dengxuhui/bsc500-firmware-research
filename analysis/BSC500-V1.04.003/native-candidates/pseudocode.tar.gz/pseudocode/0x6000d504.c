
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined2 FUN_6000d504(void)

{
  int iVar1;
  
  iVar1 = FUN_60163b60();
  if (*(char *)(iVar1 + 0x33) != '\0') {
    return *(undefined2 *)(_DAT_6001ddf4 + 0x30);
  }
  return 0;
}

