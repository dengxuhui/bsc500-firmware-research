
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60003bdc(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_6011c240(&UNK_60003bf0,_DAT_60003bfc,3);
  *(undefined4 *)(_DAT_60003c00 + 0xc) = uVar1;
  return;
}

