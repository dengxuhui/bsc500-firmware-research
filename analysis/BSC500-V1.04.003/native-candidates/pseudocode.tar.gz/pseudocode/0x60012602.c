
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60012602(void)

{
  ulonglong uVar1;
  float fVar2;
  uint *puVar3;
  int iVar4;
  uint *puVar5;
  code *pcVar6;
  uint uVar7;
  undefined4 uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  int unaff_r5;
  uint in_fpscr;
  float fVar12;
  float fVar13;
  undefined4 uVar14;
  undefined8 uVar15;
  undefined8 uVar16;
  int in_stack_0000025c;
  int in_stack_0000043c;
  
  FUN_60134a32(0x14);
  *(uint *)(unaff_r5 + 0xc) = *(uint *)(unaff_r5 + 0xc) & 0xfffffffb;
  *(uint *)(unaff_r5 + 0xc) = *(uint *)(unaff_r5 + 0xc) | 4;
  iVar9 = _DAT_600126e8;
  do {
  } while ((*(uint *)(unaff_r5 + 0xc) & 1) == 0);
  uVar10 = *(uint *)(unaff_r5 + 0x10);
  *(uint *)(unaff_r5 + 0xc) = *(uint *)(unaff_r5 + 0xc) & 0xfffffffb;
  *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) & 0xf03fffff;
  *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) | 0xfc00000;
  FUN_60134a32(0x14);
  *(uint *)(unaff_r5 + 0xc) = *(uint *)(unaff_r5 + 0xc) | 4;
  do {
  } while ((*(uint *)(unaff_r5 + 0xc) & 1) == 0);
  *(uint *)(unaff_r5 + 0xc) = *(uint *)(unaff_r5 + 0xc) & 0xfffffffb;
  *(uint *)(unaff_r5 + 4) = *(uint *)(unaff_r5 + 4) & 0xff7fffff;
  uVar15 = FUN_6016759c(0x6c000 / ((*(uint *)(unaff_r5 + 0x10) & 0xffff) - (uVar10 & 0xffff)));
  fVar2 = _UNK_600126fc;
  iVar9 = _DAT_600126f8;
  uVar1 = (ulonglong)_UNK_600126f0 >> 0x20;
  uVar14 = (undefined4)_UNK_600126f0;
  for (iVar11 = 0; iVar4 = _DAT_600128a0, puVar3 = _DAT_6001289c, iVar11 != 0x14;
      iVar11 = iVar11 + 1) {
    *(int *)(_DAT_600126e4 + 0x50) = *(int *)(_DAT_600126e4 + 0x50) + 1;
    fVar12 = (float)VectorSignedToFloat(*(int *)(_DAT_60012d80 + iVar11 * 4) * 3 + iVar9 + 0x12c0,
                                        (byte)(in_fpscr >> 0x16) & 3);
    uVar16 = FUN_60166bb4(fVar12 * fVar2);
    uVar16 = FUN_601682c8((int)uVar16,(int)((ulonglong)uVar16 >> 0x20),uVar14,(int)uVar1);
    FUN_601678fc((int)uVar16,(int)((ulonglong)uVar16 >> 0x20),(int)uVar15,
                 (int)((ulonglong)uVar15 >> 0x20));
    uVar8 = func_0x6015e530();
    *(undefined4 *)(&stack0x00000008 + iVar11 * 4) = uVar8;
  }
  _DAT_6001289c[0x14] = 1000;
  puVar3[1] = puVar3[1] | 0x800000;
  puVar3[4] = puVar3[4] & 0xffff;
  puVar3[4] = puVar3[4] | 0x43800000;
  *(uint *)(iVar4 + 0x9c) = *(uint *)(iVar4 + 0x9c) & 0xfffff801;
  *(uint *)(iVar4 + 0x9c) = *(uint *)(iVar4 + 0x9c) | 0x10;
  *(uint *)(iVar4 + 0x9c) = *(uint *)(iVar4 + 0x9c) & 0xfffffffe;
  *puVar3 = *puVar3 & 0xffff807f;
  *puVar3 = *puVar3 | in_stack_0000025c << 7;
  *puVar3 = *puVar3 & 0xffc07fff;
  *puVar3 = *puVar3 | in_stack_0000043c << 0xf;
  *(uint *)(iVar4 + 0x98) = *(uint *)(iVar4 + 0x98) & 0xf03fffff;
  *(undefined4 *)(iVar4 + 0x98) = *(undefined4 *)(iVar4 + 0x98);
  *(uint *)(iVar4 + 0x98) = *(uint *)(iVar4 + 0x98) & 0xffdfffff;
  FUN_60134a32(0x14);
  puVar3[3] = puVar3[3] | 4;
  iVar11 = _DAT_600128a0;
  do {
  } while ((puVar3[3] & 1) == 0);
  uVar10 = puVar3[4];
  puVar3[3] = puVar3[3] & 0xfffffffb;
  *(uint *)(iVar11 + 0x98) = *(uint *)(iVar11 + 0x98) & 0xf03fffff;
  *(uint *)(iVar11 + 0x98) = *(uint *)(iVar11 + 0x98) | 0xfc00000;
  FUN_60134a32(0x14);
  puVar3[3] = puVar3[3] | 4;
  fVar2 = _UNK_600128a4;
  do {
  } while ((puVar3[3] & 1) == 0);
  puVar3[3] = puVar3[3] & 0xfffffffb;
  iVar11 = 0;
  fVar12 = (float)VectorSignedToFloat(0x6c000 / ((puVar3[4] & 0xffff) - (uVar10 & 0xffff)),
                                      (byte)(in_fpscr >> 0x16) & 3);
  for (; puVar3 = _DAT_6001289c, iVar11 != 0x14; iVar11 = iVar11 + 1) {
    _DAT_6001289c[0x14] = _DAT_6001289c[0x14] + 1;
    fVar13 = (float)VectorSignedToFloat(*(int *)(_DAT_60012d80 + iVar11 * 4 + 0x50) * 3 + iVar9,
                                        (byte)(in_fpscr >> 0x16) & 3);
    uVar14 = VectorFloatToUnsigned((fVar13 * fVar2 + 1.0) * fVar12,3);
    *(undefined4 *)(&stack0x00000058 + iVar11 * 4) = uVar14;
  }
  _DAT_6001289c[5] = _DAT_6001289c[5] & 0xfff7ffff;
  for (iVar9 = 0; pcVar6 = _DAT_60012d8c, iVar9 != 0xa0; iVar9 = iVar9 + 4) {
    *(int *)((int)puVar3 + iVar9 + 0x54) =
         *(int *)(&stack0x000003c8 + iVar9) * 0x100 + *(int *)(&stack0x00000008 + iVar9) * 0x10000 +
         *(int *)(&stack0x000001e8 + iVar9);
    *(int *)((int)puVar3 + iVar9 + 0x2a0) =
         *(int *)(&stack0x00000328 + iVar9) * 0x1000000 +
         *(int *)(&stack0x00000148 + iVar9) * 0x10000 + *(int *)(&stack0x000000a8 + iVar9) +
         *(int *)(&stack0x00000288 + iVar9) * 0x100;
  }
  puVar3[9] = puVar3[9] & 0xffe1ffff;
  puVar3[9] = puVar3[9] | 0x1c0000;
  puVar3[2] = puVar3[2] | 0x10;
  puVar3[10] = puVar3[10] | 0xf800;
  puVar3[9] = puVar3[9] | 0x410000;
  puVar3[9] = puVar3[9] | 0x8000;
  puVar3[10] = puVar3[10] | 0x30000;
  puVar3[0x41] = puVar3[0x41] | 0x300;
  (*pcVar6)(0x14);
  puVar3[9] = puVar3[9] & 0xfffffdff;
  (*pcVar6)(2);
  puVar3[9] = puVar3[9] | 0x200;
  (*pcVar6)(0x14);
  puVar3[0x41] = puVar3[0x41] & 0xfffffffe;
  puVar3[0x41] = puVar3[0x41] | 1;
  do {
  } while (-1 < (int)(puVar3[0x41] << 0x1e));
  puVar3[9] = puVar3[9] & 0xffffc3ff;
  puVar3[9] = puVar3[9] & 0xffffbfff;
  puVar3[9] = puVar3[9] | (puVar3[0x41] & 0x78) << 7;
  puVar5 = _DAT_60012d7c;
  puVar3[9] = puVar3[9] | (puVar3[0x41] & 4) << 0xc;
  puVar3[0x41] = puVar3[0x41] & 0xfffffffe;
  puVar3[9] = puVar3[9] & 0xffff7fff;
  puVar3[9] = puVar3[9] & 0xffbfffff;
  puVar3[0x41] = puVar3[0x41] & 0xfffffdff;
  puVar3[2] = puVar3[2] & 0xffffffef;
  puVar3[2] = puVar3[2] & 0xfffeffff;
  puVar3[0x3d] = puVar3[0x3d] | 1;
  puVar3[0x3d] = puVar3[0x3d] | 2;
  puVar3[6] = puVar3[6] & 0xffffbfff;
  puVar3[1] = puVar3[1] & 0xff7fffff;
  puVar5[0x27] = puVar5[0x27] | 1;
  puVar5[0x26] = puVar5[0x26] | 0x200000;
  *puVar3 = *puVar3 & 0xfffffffe;
  puVar3[2] = puVar3[2] & 0xfffff7ff;
  puVar3[2] = puVar3[2] & 0xfffffbff;
  puVar3[9] = puVar3[9] | 1;
  puVar3[10] = puVar3[10] | 0x400;
  puVar3[3] = puVar3[3] | 2;
  puVar3[0x11] = puVar3[0x11] | 0x400;
  *puVar3 = *puVar3 & 0xf7ffffff;
  puVar3[3] = puVar3[3] & 0xfffff7ff;
  puVar3[0xc] = puVar3[0xc] | 0x2000;
  puVar3[0x10] = puVar3[0x10] | 8;
  puVar3[0x10] = puVar3[0x10] | 0x2000;
  puVar3[0x10] = puVar3[0x10] & 0xffffefff;
  puVar3[0x40] = puVar3[0x40] & 0xfc3fffff;
  puVar3[0x10] = puVar3[0x10] | 0x4000;
  puVar3[0x10] = puVar3[0x10] & 0xffffffbf;
  puVar3[0x10] = puVar3[0x10] | 0x40;
  puVar3[0x40] = puVar3[0x40] | 0x200000;
  puVar5 = _DAT_60012d7c;
  do {
  } while (-1 < (int)(puVar3[0x40] << 0xb));
  puVar3[0x10] = puVar3[0x10] & 0xfffff07f;
  puVar3[0x10] = puVar3[0x40] >> 0x13 & 0xf80 | puVar3[0x10];
  puVar3[0x10] = puVar3[0x10] | 0x1000;
  puVar3[0x40] = puVar3[0x40] & 0xffdfffff;
  puVar3[0x10] = puVar3[0x10] & 0xfffffff7;
  puVar3[0xc] = puVar3[0xc] & 0xffffdfff;
  puVar3[0xd] = puVar3[0xd] & 0xffff9fff;
  puVar3[0xd] = puVar3[0xd] | 0x6000;
  puVar3[2] = puVar3[2] & 0xfffffeff;
  puVar3[2] = puVar3[2] & 0xfffffdff;
  puVar5[0x26] = puVar5[0x26] & 0x8fffffff;
  puVar5[0x26] = puVar5[0x26] | 0x10000000;
  FUN_6001c044();
  FUN_60156f2c();
  puVar5[0x24] = puVar5[0x24] & 0xfffffe00;
  puVar5[0x24] = puVar5[0x24] | 0xff;
  puVar3[0x11] = puVar3[0x11] | 0x400;
  puVar3[0xb] = puVar3[0xb] & 0xffc3ffff;
  puVar3[0xb] = puVar3[0xb] | 0x340000;
  puVar3[2] = puVar3[2] & 0xff7fffff;
  puVar3[2] = puVar3[2] | 0x800000;
  puVar3[0xe] = puVar3[0xe] & 0xffffffdf;
  puVar3[0xe] = puVar3[0xe];
  puVar3[2] = puVar3[2] & 0xfdffffff;
  uVar10 = _DAT_60012d90;
  puVar5[7] = puVar5[7] & 0xfffffc00;
  puVar5[7] = puVar5[7] & 0xfff003ff;
  puVar5[7] = puVar5[7] & 0x800fffff;
  puVar5[7] = puVar5[7] | 0x168;
  puVar5[7] = puVar5[7] | 0x8800;
  puVar5[7] = puVar5[7] | 0xb000000;
  puVar5[0x20] = puVar5[0x20] & 0xff81ffff;
  puVar5[0x20] = puVar5[0x20] | 0x1e0000;
  puVar5[5] = puVar5[5] & 0xfffffc00;
  puVar5[5] = puVar5[5] | 0xa6;
  puVar5[0x29] = puVar5[0x29] & 0xfffe0000;
  puVar5[0x2a] = puVar5[0x2a] & 0xfffe0000;
  uVar7 = _DAT_60012d94;
  puVar5[0x29] = puVar5[0x29] | uVar10;
  puVar5[0x2a] = puVar5[0x2a] | uVar7;
  puVar5[4] = puVar5[4] | 0x800000;
  puVar5[4] = puVar5[4] | 0x100000;
  puVar5[4] = puVar5[4] | 0x100;
  puVar5[0x10] = puVar5[0x10] | 0x8000000;
  puVar5[0x10] = puVar5[0x10] | 0x8000;
  puVar5[0x10] = puVar5[0x10] | 0x30;
  puVar5[0x11] = puVar5[0x11] | 0x9000000;
  puVar5[0x11] = puVar5[0x11] | 0x8000;
  puVar5[0x11] = puVar5[0x11];
  puVar5[2] = _DAT_60012d98;
  puVar5[3] = puVar5[3] | 0xaa00;
  *puVar5 = *puVar5 & 0xf0003fff;
  *puVar5 = *puVar5 | 0xc000000;
  puVar5[0x24] = puVar5[0x24] & 0xfffc01ff;
  puVar5[0x24] = puVar5[0x24] | 0x1fe00;
  puVar5[0x28] = puVar5[0x28] & 0xfffff8ff;
  puVar5[0x28] = puVar5[0x28] | 0x600;
  puVar5[5] = puVar5[5] & 0xfff003ff;
  puVar5[5] = puVar5[5] | 0x2a800;
  puVar5[3] = puVar5[3] & 0xffffff00;
  puVar5[3] = puVar5[3] | 8;
  puVar3[0xc] = puVar3[0xc] & 0xfffffffc;
  puVar3[0xc] = puVar3[0xc] | 3;
  return;
}

