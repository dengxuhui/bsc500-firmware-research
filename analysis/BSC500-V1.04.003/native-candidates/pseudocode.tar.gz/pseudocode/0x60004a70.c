
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60004a70(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  bool bVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 uVar4;
  
  func_0x60161424(&UNK_60004ac8);
  func_0x60161424(_DAT_60004ae4);
  FUN_6016252c();
  uVar3 = 0;
  bVar1 = (bool)isCurrentModePrivileged();
  if (bVar1) {
    uVar3 = getCurrentExceptionNumber();
    uVar3 = uVar3 & 0x1f;
  }
  if (uVar3 == 0) {
    uVar4 = getProcessStackPointer();
  }
  else {
    uVar4 = getMainStackPointer();
  }
  FUN_60004968(uVar4);
  func_0x60161424(&UNK_60004ae8,param_2,param_3,param_1);
  func_0x60161424(_DAT_60004ae4);
  if ((*_DAT_60004b24 & 1) == 0) {
    FUN_60006a90();
    FUN_60167d0c();
    bVar1 = (bool)isCurrentModePrivileged();
    if (bVar1) {
      isIRQinterruptsEnabled();
    }
    bVar1 = (bool)isCurrentModePrivileged();
    if (bVar1) {
      enableIRQinterrupts(1);
    }
    FUN_60134a64(2);
    FUN_60134a5a(1);
    puVar2 = _DAT_60164a44;
    if ((int)(*_DAT_60164a44 << 0x1d) < 0) {
      *_DAT_60164a44 = *_DAT_60164a44 & 0xfffffffb;
      FUN_60134a32(_DAT_60164a48);
    }
    *puVar2 = *puVar2 | 4;
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  software_bkpt(0);
  return;
}

