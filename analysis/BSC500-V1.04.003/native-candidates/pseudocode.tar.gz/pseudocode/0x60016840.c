
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016840(void)

{
  short sVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  short *psVar5;
  
  iVar2 = FUN_6016708c();
  uVar3 = FUN_6015c500();
  iVar4 = FUN_60161014(iVar2,uVar3);
  if (uVar3 < 5) {
    psVar5 = (short *)(iVar2 * 0x5a4 + uVar3 * 0x38 + _DAT_600169ec + 0xd7c);
    do {
      if (iVar4 == 0) {
        return 0;
      }
      sVar1 = *psVar5;
      iVar4 = iVar4 + -1;
      psVar5 = psVar5 + 1;
    } while (sVar1 != 0xb1d);
  }
  else {
    psVar5 = (short *)((short)uVar3 * 0x36 + iVar2 * 0x5a4 + _DAT_600169ec + 0xd86);
    do {
      if (iVar4 == 0) {
        return 0;
      }
      sVar1 = *psVar5;
      iVar4 = iVar4 + -1;
      psVar5 = psVar5 + 1;
    } while (sVar1 != 0xb1d);
  }
  return 1;
}

