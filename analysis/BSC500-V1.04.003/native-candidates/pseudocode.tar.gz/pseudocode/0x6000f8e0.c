
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_6000f8e0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  
  iVar1 = _DAT_6000f8f4;
  *(undefined4 *)(_DAT_6000f8f4 + 0x154) = 0;
  *(undefined2 *)(iVar1 + 6) = 0x801;
  uVar3 = FUN_60165098(&UNK_60019ee4,0,0,param_4,iVar1,0x801,param_3,param_4);
  uVar2 = _DAT_60019f04;
  uVar4 = _DAT_60019f00;
  iVar1 = _DAT_60019ef0;
  uVar5 = 0x1000;
  uVar6 = 8;
  *(undefined4 *)(_DAT_60019ef0 + 0xc) = uVar3;
  uVar4 = FUN_6001fd8c(&UNK_60019ef4,uVar4,0,uVar2,0x1000,8,10);
  *(undefined4 *)(iVar1 + 0x10) = uVar4;
  return CONCAT44(uVar6,uVar5);
}

