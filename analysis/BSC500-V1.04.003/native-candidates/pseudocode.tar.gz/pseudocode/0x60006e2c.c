
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006e2c(undefined4 param_1)

{
  *_DAT_60006e34 = param_1;
  return;
}

