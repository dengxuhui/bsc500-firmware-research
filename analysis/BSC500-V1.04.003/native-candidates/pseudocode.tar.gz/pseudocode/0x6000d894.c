
void FUN_6000d894(int *param_1,int *param_2)

{
  int iStack_18;
  int iStack_14;
  
  iStack_18 = 0;
  iStack_14 = 0;
  FUN_600186a0(&iStack_14,&iStack_18);
  *param_1 = iStack_14;
  *param_2 = iStack_14 - iStack_18;
  return;
}

