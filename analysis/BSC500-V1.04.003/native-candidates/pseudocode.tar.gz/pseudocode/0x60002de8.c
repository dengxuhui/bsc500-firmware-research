
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60002de8(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  int *piVar3;
  uint uVar4;
  int iStack_14;
  
  uVar1 = _DAT_60002e60;
  iStack_14 = 0;
  FUN_6015baa0(_DAT_60002e60,&iStack_14,4,param_4,param_3);
  iVar2 = _DAT_60002e64;
  if (iStack_14 == _DAT_60002e64) {
    FUN_6015baa0(uVar1,_DAT_60002e68,0x2000);
  }
  if (*_DAT_60002e68 == iVar2) {
    uVar4 = _DAT_60002e68[1];
    piVar3 = _DAT_60002e68 + 2;
    if (0x1fff < uVar4) {
      uVar4 = 0x2000;
    }
    *_DAT_60002e6c = uVar4;
    iVar2 = FUN_60006b70(_DAT_60002e70 + 8,&UNK_60002e74,piVar3);
    if (iVar2 == 0) {
      FUN_6015c650(uVar1,0x2000);
    }
    ZeroBytes(_DAT_60002e68,0x2000);
    return 1;
  }
  ZeroBytes(_DAT_60002e68,0x2000);
  *_DAT_60002e6c = 0;
  return 0;
}

