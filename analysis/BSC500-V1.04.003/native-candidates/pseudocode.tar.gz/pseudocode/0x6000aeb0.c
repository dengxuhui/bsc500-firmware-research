
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000aeb0(int param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = _DAT_6000af00;
  uVar2 = 0xffffffff;
  if ((param_1 != 0) && (param_2 != 0)) {
    FUN_600163ec(param_1,param_2,_DAT_6000af00 + 0x14,param_4,param_4);
    FUN_60016258(param_1,param_2,_DAT_6000af04);
    uVar2 = _DAT_6000af08;
    FUN_600164d0(param_1,param_2,_DAT_6000af08);
    FUN_60016164(param_1,param_2,uVar2,iVar1);
    FUN_60016194(param_1,param_2,iVar1 + 0x38);
    uVar2 = 0;
  }
  return uVar2;
}

