
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000c4d8(void)

{
  int iVar1;
  undefined4 in_r3;
  undefined4 uVar2;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  if (*_DAT_6000c4e8 != 0) {
    return 0;
  }
  uStack_10 = 0;
  uStack_c = in_r3;
  iVar1 = FUN_60166758(&uStack_c,_DAT_60017ed4,1);
  if (iVar1 == 0) {
    uVar2 = FUN_60161ef4(uStack_c,_DAT_60017ed8,0xf4,&uStack_10);
    FUN_601667bc(uStack_c);
  }
  else {
    uVar2 = 0xffffffff;
  }
  return uVar2;
}

