
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6000b63c(void)

{
  return (*(byte *)(_DAT_6000b648 + 1) & 3) >> 1;
}

