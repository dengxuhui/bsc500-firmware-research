
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60007430(uint *param_1)

{
  int *piVar1;
  int iVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  int aiStack_34 [4];
  
  piVar1 = _DAT_60007684;
  iVar2 = *_DAT_60007684;
  if (iVar2 == 0) {
    aiStack_34[2] = 0;
    aiStack_34[3] = 0;
    aiStack_34[1] = 1;
    aiStack_34[0] = _DAT_60007688;
    iVar2 = FUN_60168494(aiStack_34);
    *piVar1 = iVar2;
  }
  FUN_6016825e(iVar2,0xffffffff);
  puVar3 = (undefined4 *)piVar1[1];
  while (puVar4 = puVar3, puVar4 != (undefined4 *)0x0) {
    puVar3 = (undefined4 *)puVar4[0xb];
    if (((puVar4[6] & *param_1 & 0xdfffffff) != 0) || ((*param_1 & puVar4[7] & 0xbfffffff) != 0)) {
      aiStack_34[0] = 0;
      iVar2 = (*(code *)puVar4[3])(param_1,aiStack_34);
      if (iVar2 != 0) {
        if (((*(short *)((int)puVar4 + 0x22) != 0) && (aiStack_34[0] != 0)) &&
           (iVar2 = FUN_60162c04(*puVar4,0,0), iVar2 != 0)) {
          *(int *)(iVar2 + 8) = aiStack_34[0];
          FUN_600167f8();
        }
        for (puVar4 = puVar4 + 10; puVar4 = (undefined4 *)*puVar4, puVar4 != (undefined4 *)0x0;
            puVar4 = puVar4 + 1) {
          if (((code *)*puVar4 != (code *)0x0) && (aiStack_34[0] != 0)) {
            (*(code *)*puVar4)();
          }
        }
      }
    }
  }
  if (*piVar1 != 0) {
    func_0x601682ae();
  }
  return;
}

