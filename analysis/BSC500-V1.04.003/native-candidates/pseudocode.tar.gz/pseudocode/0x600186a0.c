
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600186a0(undefined4 *param_1,undefined4 *param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  undefined4 uStack_14;
  
  piVar1 = _DAT_600186e4;
  iVar2 = *_DAT_600186e4;
  uStack_14 = param_4;
  if (iVar2 == 0) {
    iVar2 = FUN_60165098(_DAT_600186e8,1,0,param_4,param_3);
    *piVar1 = iVar2;
    if (iVar2 == 0) goto LAB_600186c2;
  }
  func_0x601668f8(iVar2,0xffffffff);
LAB_600186c2:
  FUN_600239c0(piVar1[1],&uStack_14);
  if (*piVar1 != 0) {
    func_0x60166af4();
  }
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0x40000;
  }
  if (param_2 != (undefined4 *)0x0) {
    *param_2 = uStack_14;
  }
  return;
}

