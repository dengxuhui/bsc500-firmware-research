
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60017edc(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined2 uStack_24;
  undefined1 uStack_22;
  undefined1 uStack_21;
  undefined1 uStack_20;
  undefined1 uStack_1d;
  undefined1 uStack_11;
  
  iVar1 = FUN_6015f704();
  uVar2 = 0;
  if ((iVar1 == 1) && (iVar1 = FUN_60161a98(), iVar1 != 0)) {
    func_0x60168578(&UNK_60017f38);
    *_DAT_60017f58 = 0;
    FUN_60166858(&uStack_21,0x11,0xff);
    uStack_1d = 0;
    uStack_22 = 0;
    uStack_20 = 10;
    uStack_24 = 0x703;
    uStack_11 = FUN_60160db4(&uStack_24,0x13);
    FUN_6015e018(&uStack_24);
    uVar2 = 1;
  }
  return uVar2;
}

