
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60004b98(int *param_1,int param_2)

{
  code *pcVar1;
  int *piVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 extraout_r1;
  undefined4 *extraout_r2;
  undefined4 unaff_r4;
  undefined4 *unaff_r5;
  
  pcVar1 = pcRam60004c04;
  if (param_1 == (int *)0x0) {
    FUN_6016804c(&UNK_60004c34,_DAT_60004c30,0x2b);
  }
  else if (param_2 != 0) {
    piVar3 = (int *)(*pcRam60004c04)(4);
    *piVar3 = iRam60004c08 + 8;
    uVar4 = (*pcVar1)(4);
    FUN_600f5a7c();
    piVar5 = (int *)(*pcVar1)(0x20);
    ZeroBytes(piVar5 + 1,0x14);
    piVar5[6] = 0;
    piVar5[7] = 0;
    *piVar5 = iRam60004c0c + 8;
    (**(code **)(*param_1 + 0x14))(param_1,uVar4);
    piVar2 = _DAT_60004c10;
    piVar5[3] = param_2;
    piVar5[4] = (int)piVar3;
    piVar5[5] = (int)param_1;
    *piVar2 = (int)piVar5;
    return piVar5;
  }
  FUN_6016804c(&UNK_60004c14,_DAT_60004c30,0x2c);
  *extraout_r2 = unaff_r4;
  *unaff_r5 = extraout_r1;
  *unaff_r5 = extraout_r1;
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

