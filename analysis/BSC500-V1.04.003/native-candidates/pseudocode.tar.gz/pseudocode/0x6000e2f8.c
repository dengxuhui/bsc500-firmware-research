
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6000e2f8(void)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = (uint)*(byte *)(_DAT_6000e318 + 0x328);
  if ((uVar1 < 0xb) && (uVar1 = 1 << uVar1, (uVar1 & 0x418) != 0)) {
    if (_DAT_6000e31c < _UNK_60059ad8) {
      iVar2 = func_0x601671d4(_UNK_60059adc,_DAT_6000e31c,0,0x27);
      if (iVar2 == 0) {
        return 0;
      }
      func_0x60168578(&UNK_60059ae0);
    }
    else {
      func_0x60168578(&UNK_60059b10);
    }
    return 0xffffffff;
  }
  return uVar1;
}

