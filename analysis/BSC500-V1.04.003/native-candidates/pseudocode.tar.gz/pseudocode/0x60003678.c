
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_60003678(void)

{
  int *piVar1;
  int iVar2;
  undefined *puStack_2c;
  undefined1 auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  ZeroBytes(auStack_28,0x20);
  uStack_14 = 0xf;
  puStack_2c = &UNK_600036b4;
  uStack_18 = 0x1000;
  iVar2 = FUN_601566b4(_DAT_600036c0,0,&puStack_2c);
  piVar1 = _DAT_600036c4;
  *_DAT_600036c4 = iVar2;
  FUN_60156808();
  return *piVar1 != 0;
}

