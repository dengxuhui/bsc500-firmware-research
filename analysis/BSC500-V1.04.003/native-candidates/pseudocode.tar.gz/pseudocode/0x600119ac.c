
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4
FUN_600119ac(undefined4 param_1,undefined4 param_2,undefined2 *param_3,undefined4 param_4,
            int param_5)

{
  int *piVar1;
  int *piVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  undefined *puVar8;
  int *piVar9;
  undefined1 auStack_98 [128];
  
  piVar1 = _DAT_60011c7c;
  if (_DAT_60011c7c[1] == 0) {
    ZeroBytes(auStack_98,0x80);
    piVar2 = _DAT_60011c80;
    ZeroBytes(_DAT_60011c80,0xa4);
    iVar6 = FUN_60119330(*(undefined4 *)(param_3 + 2),*param_3,piVar2);
    piVar2 = _DAT_60011c80;
    if (iVar6 == 0) goto LAB_60011c02;
    FUN_6001dabc(auStack_98,_DAT_60011c80);
    iVar6 = FUN_6001d51c(piVar2);
    if (iVar6 == 0) goto LAB_60011bf4;
    if (*piVar2 == 5) {
      func_0x60168578(&UNK_60011c84,auStack_98,piVar2[0x27],piVar2[1]);
      if ((piVar2[0x27] == 0) || (*piVar2 != 5)) {
        func_0x60168578(&UNK_60011cb8);
        if (*piVar2 == 5) {
          FUN_6015c57c(auStack_98);
          FUN_6015c57c(_DAT_60011cd8);
        }
        iVar6 = FUN_601194e8(auStack_98,piVar2 + 3);
        if (iVar6 == 0) {
          func_0x60168578(_DAT_60011d10);
          goto LAB_60011be4;
        }
        FUN_601195d8(iVar6,piVar2[1]);
        if (*piVar2 == 5) {
          iVar5 = FUN_60168220(piVar2 + 0x1b);
          if (iVar5 != 0) {
            FUN_600f9ad4(iVar6,piVar2 + 0x1b);
          }
          func_0x60168578(_DAT_60011cdc);
          iVar5 = FUN_600221fc(iVar6);
          if (iVar5 == 0) {
            FUN_6001d490(iVar6,1);
            puVar8 = _DAT_60011d08;
          }
          else {
            puVar8 = &UNK_60011ce0;
          }
          func_0x60168578(puVar8);
        }
        func_0x60168578(_DAT_60011d0c,iVar6);
      }
      else {
        func_0x60168578(_DAT_60011d14);
        iVar6 = FUN_6001cd6c(auStack_98,piVar2 + 3,piVar2[0x27]);
        if (iVar6 == 0) {
          func_0x60168578(_DAT_60011d48);
          FUN_6015c57c(auStack_98);
          FUN_6015c57c(_DAT_60011cd8);
LAB_60011be4:
          piVar1[1] = 0;
          goto LAB_60011be8;
        }
        func_0x60168578(_DAT_60011d18);
        FUN_6001d490(iVar6,1);
        FUN_601195d8(iVar6,piVar2[1]);
        piVar9 = piVar2 + 0x1b;
        iVar5 = FUN_60168220(piVar9);
        if (iVar5 != 0) {
          FUN_600f9ad4(iVar6,piVar9);
          func_0x60168578(_DAT_60011d1c,piVar2[0x27],piVar9);
        }
      }
      piVar1[1] = iVar6;
    }
    else {
      iVar6 = FUN_601194e8(auStack_98,piVar2 + 3);
      piVar1[1] = iVar6;
      if (iVar6 == 0) {
LAB_60011be8:
        iVar6 = FUN_6015d9c4();
        if ((*piVar2 == 0xd) && (iVar6 == 0)) {
LAB_60011bf4:
          FUN_60127660(0x15,0,3,0);
          return 1;
        }
LAB_60011c02:
        FUN_60129ec8(0x15,0,3,0);
        return 1;
      }
    }
    func_0x60168578(&UNK_60011d20,auStack_98);
    FUN_601195d8(piVar1[1],piVar2[1]);
    iVar6 = *piVar2;
    if (iVar6 == 5) {
      FUN_600f9ad4(piVar1[1],piVar2 + 0x1b);
      FUN_6001d38c(piVar1[1]);
      if ((char)piVar2[0x28] != '\0') {
        func_0x60168578(_DAT_60011d30);
        FUN_6001d3d8(piVar1[1]);
      }
      iVar6 = *piVar2;
    }
    if (iVar6 == 7) {
      FUN_6015d63c(auStack_98,2,2);
    }
  }
  if (param_5 != 0) {
    FUN_6001d084(piVar1[1],param_4);
  }
  uVar3 = FUN_60129b9c(piVar1[1]);
  uVar4 = FUN_601233d4(piVar1[1]);
  if (uVar3 < uVar4) {
    return 0;
  }
  iVar6 = FUN_6001cefc(piVar1 + 1);
  if (iVar6 == 0) {
    FUN_6015c57c(piVar1[1]);
    FUN_6015c57c(_DAT_60011cd8);
    FUN_60129ec8(0x15,0,3,0);
  }
  else {
    if (*_DAT_60011c80 == 5) {
      func_0x60168578(_DAT_60011d34);
      FUN_6015c57c(_DAT_60011cd8);
    }
    FUN_60127660(0x15,0,3,0);
  }
  piVar2 = _DAT_60011c80;
  iVar6 = *_DAT_60011c80;
  if (iVar6 == 6) {
    FUN_6015d6c8(0);
    iVar6 = *piVar2;
  }
  switch(iVar6) {
  case 1:
    uVar7 = 2;
    goto code_r0x60011b28;
  case 2:
    FUN_6015defc(0);
    uVar7 = 3;
code_r0x60011b28:
    FUN_60164948(uVar7);
code_r0x60011b2c:
    iVar6 = FUN_6015a144(_UNK_60011d38);
    if (iVar6 == 0) {
      uVar7 = 0;
      iVar6 = _UNK_60011d3c;
code_r0x60011b6c:
      FUN_60164914(iVar6,uVar7);
    }
    else {
      FUN_6014c2a8(0);
    }
    break;
  case 3:
  case 4:
  case 6:
  case 8:
  case 0xc:
    goto code_r0x60011b2c;
  case 7:
    FUN_6001de10(1);
    break;
  case 0xf:
    iVar6 = FUN_6002a088(auStack_98);
    *piVar1 = iVar6;
    if (iVar6 != 0) {
      FUN_60163e70(_UNK_60011d40,iVar6,_UNK_60011d44);
    }
    break;
  case 0x11:
    uVar7 = FUN_60029cb0(auStack_98);
    iVar6 = _UNK_60011d3c + 0xd;
    goto code_r0x60011b6c;
  }
  return 1;
}

