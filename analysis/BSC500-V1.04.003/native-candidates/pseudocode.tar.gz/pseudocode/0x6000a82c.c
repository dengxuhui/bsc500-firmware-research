
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a82c(void)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  
  cVar2 = FUN_60164b7c();
  pcVar1 = _DAT_6000a864;
  if (cVar2 == '\0') {
    _DAT_6000a864[1] = '\0';
  }
  else if (((*_DAT_6000a864 == '\x01') && (_DAT_6000a864[1] == '\0')) &&
          (iVar3 = *(int *)(_DAT_6000a864 + 4), *(uint *)(_DAT_6000a864 + 4) = iVar3 + 1U,
          2 < iVar3 + 1U)) {
    FUN_60019568(*(undefined4 *)(pcVar1 + 8));
    pcVar1[4] = '\0';
    pcVar1[5] = '\0';
    pcVar1[6] = '\0';
    pcVar1[7] = '\0';
    pcVar1[1] = '\x01';
    return;
  }
  return;
}

