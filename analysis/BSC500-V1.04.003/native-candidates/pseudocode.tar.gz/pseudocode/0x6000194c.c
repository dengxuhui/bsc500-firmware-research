
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000194c(int param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined1 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 extraout_r2;
  int extraout_r3;
  int unaff_r6;
  
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 0x54) = param_4;
    uVar7 = uRam600019a8;
    uVar6 = uRam600019a4;
    uVar5 = uRam600019a0;
    uVar4 = uRam6000199c;
    uVar3 = uRam60001998;
    uVar2 = uRam60001994;
    *(undefined4 *)(param_1 + 0x24) = 0;
    *(undefined4 *)(param_1 + 0x28) = 0;
    *(undefined4 *)(param_1 + 0x2c) = uVar7;
    *(undefined4 *)(param_1 + 0x30) = uVar6;
    *(undefined4 *)(param_1 + 0x34) = uVar5;
    *(undefined4 *)(param_1 + 0x38) = uVar4;
    *(undefined4 *)(param_1 + 0x3c) = uVar3;
    *(undefined4 *)(param_1 + 0x40) = uVar2;
    *(undefined1 *)(param_1 + 0x1c) = 0;
    func_0x601637f8(param_1,param_2,param_3);
    *(undefined4 *)(param_1 + 0x44) = uRam600019ac;
    return;
  }
  FUN_6016804c(0x600019b0,0x600019c4,0x488,param_4,param_4);
  uRam0000009c = 0;
  uRam00000098 = 0x98;
  uRam00000093 = extraout_r2;
  *(int *)(unaff_r6 + 0x54) = extraout_r3;
  uVar1 = (undefined1)*(int *)(unaff_r6 + 0x14);
  *(undefined1 *)(*(int *)(unaff_r6 + 0x14) + 0x20) = uVar1;
  iVar8 = _DAT_60001b3c;
  *(undefined1 *)(_DAT_60001b3c + 0x11) = uVar1;
  *(int *)(iVar8 + 0x54) = extraout_r3;
  uRam00000041 = uRam00000084;
  *(char *)(extraout_r3 + 9) = (char)*(undefined2 *)(iVar8 + 0x93);
  uRam000000b4 = 0x93;
  uRam000000a0 = (undefined1)uRam00000041;
  *(undefined4 *)(iVar8 + 0x54) = 0x40;
  return;
}

