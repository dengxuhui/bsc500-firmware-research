
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000fe6c(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined1 *puVar3;
  
  uVar1 = _DAT_6000fff4;
  puVar3 = _DAT_6000ffec;
  *(undefined4 *)(_DAT_6000ffec + 4) = 0;
  *(undefined4 *)(puVar3 + 8) = 0;
  *puVar3 = 0;
  FUN_60049afc(uVar1);
  uVar1 = _DAT_6000fec8;
  *(undefined4 *)(puVar3 + 0x34) = _DAT_6000fec4;
  *(undefined4 *)(puVar3 + 0x2c) = 100;
  *(undefined4 *)(puVar3 + 0x28) = uVar1;
  FUN_60049834(puVar3 + 0x28);
  uVar1 = _DAT_6000fed0;
  *(undefined4 *)(puVar3 + 0x3c) = _DAT_6000fecc;
  *(undefined4 *)(puVar3 + 0x40) = 300;
  *(undefined4 *)(puVar3 + 0x38) = uVar1;
  FUN_60049af4(puVar3 + 0x38);
  *(undefined4 *)(puVar3 + 0x20) = 300;
  uVar2 = _DAT_6000fed4;
  *(undefined4 *)(puVar3 + 0x1c) = _DAT_6000fed4;
  FUN_6004983c(puVar3 + 0x1c);
  *(undefined4 *)(puVar3 + 0xc) = uVar1;
  *(undefined4 *)(puVar3 + 0x10) = 0;
  *(undefined4 *)(puVar3 + 0x14) = uVar2;
  *(undefined4 *)(puVar3 + 0x18) = 0;
  *puVar3 = 1;
  return;
}

