
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000c148(void)

{
  int iVar1;
  int *piVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  undefined4 *puStack_20;
  undefined4 uStack_c;
  
  uStack_c = FUN_600182e4();
  iVar1 = _DAT_60161478;
  puStack_20 = &uStack_c;
  FUN_60001d60(_DAT_60161478,&UNK_6000c15c,&puStack_20);
  piVar2 = _DAT_6016147c;
  if (*_DAT_6016147c != _DAT_60161480) {
    *_DAT_6016147c = _DAT_60161480;
    piVar2[1] = 0;
  }
  puVar3 = _DAT_60161484;
  if ((*_DAT_60161484 < 0x1ff8) && (uVar4 = *(uint *)(iVar1 + 8), uVar4 != 0)) {
    uVar5 = 0x1ff8;
    if (uVar4 < 0x1ff8) {
      uVar5 = uVar4;
    }
    piVar2[1] = uVar5;
    *puVar3 = uVar5;
  }
  return;
}

