
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60008bf8(void)

{
  *_DAT_60008c2c = 1;
  return 0;
}

