
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000f20(uint param_1)

{
  uint uVar1;
  
  if ((param_1 & 0xfffffffb) != 0) {
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  uVar1 = *_DAT_60000f60 & 0xfffffffb;
  if (param_1 == 4) {
    uVar1 = *_DAT_60000f60 | 4;
  }
  *_DAT_60000f60 = uVar1;
  return;
}

