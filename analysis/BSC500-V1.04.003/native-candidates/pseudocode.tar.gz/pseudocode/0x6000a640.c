
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a640(void)

{
  FUN_6001928c(_DAT_6000a658,_DAT_6000a65c,0x2000);
  (*(code *)0x20440)(10);
  return;
}

