
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000904(void)

{
  undefined4 *puVar1;
  undefined4 *puVar2;
  
  FUN_60000cdc();
  FUN_6014157c();
  FUN_60000b30();
  FUN_601415d0();
  FUN_60000d18(_DAT_60000954,_DAT_60000958);
  FUN_60000cc8();
  FUN_60000ce0();
  FUN_60160620(&UNK_6000095c);
  func_0x60168578(&UNK_60000968,*_DAT_60000964 >> 0x18,(*_DAT_60000964 & 0xffffff) >> 0x10,
                  (*_DAT_60000964 & 0xffff) >> 8);
  puVar1 = _DAT_60000b58;
  for (puVar2 = _DAT_60000b54; puVar2 < puVar1; puVar2 = puVar2 + 1) {
    (*(code *)*puVar2)();
  }
  return;
}

