
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000b5c(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  code *pcVar2;
  uint *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  uint uVar11;
  bool bVar12;
  
  pcVar1 = _DAT_60000c34;
  if (*_DAT_60000c34 != '\0') {
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  *_DAT_60000c34 = '\x01';
  *(int *)(pcVar1 + 8) = param_1 + 0x4c;
  func_0x6007db44(pcVar1 + 0x24,param_1,0x48,param_4,param_4);
  pcVar2 = _DAT_60000c3c;
  uVar5 = _DAT_60000c38;
  (*_DAT_60000c3c)(_DAT_60000c38);
  uVar6 = getProcessStackPointer();
  uVar7 = getMainStackPointer();
  (*pcVar2)(_DAT_60000c40,uVar6,uVar7);
  (*pcVar2)(uVar5);
  (*pcVar2)(_DAT_60000c44,*(undefined4 *)(pcVar1 + 8));
  (*pcVar2)(_DAT_60000c48,*(undefined4 *)(param_1 + 0x44));
  (*pcVar2)(_DAT_60000c4c,*(undefined4 *)(param_1 + 0x28));
  (*pcVar2)(_DAT_60000c50,*(undefined4 *)(param_1 + 0x2c));
  (*pcVar2)(_DAT_60000c54,*(undefined4 *)(param_1 + 0x30));
  (*pcVar2)(_DAT_60000c58,*(undefined4 *)(param_1 + 0x34));
  (*pcVar2)(_DAT_60000c5c,*(undefined4 *)(param_1 + 0x38));
  (*pcVar2)(_DAT_60000c60,*(undefined4 *)(param_1 + 0x3c));
  (*pcVar2)(_DAT_60000c64,*(undefined4 *)(param_1 + 0x40));
  (*pcVar2)(uVar5);
  iVar4 = FUN_60163aac();
  if (iVar4 == 0) {
    uVar5 = FUN_60163ab8();
    func_0x60161424(&UNK_60000c7c,uVar5);
  }
  else {
    func_0x60161424(&UNK_60000c68);
  }
  FUN_6013dd48();
  puVar3 = _DAT_60000c98;
  _DAT_60000c98[1] = 0;
  DataSynchronizationBarrier(0xf);
  uVar8 = *puVar3;
  uVar9 = (uVar8 & 0x1fff) >> 3;
  uVar8 = (uVar8 & 0xfffffff) >> 0xd;
  do {
    uVar11 = uVar9 << 0x1e;
    iVar4 = uVar9 + 1;
    do {
      uVar10 = uVar11 | (uVar8 & 0x1ff) << 5;
      uVar11 = uVar11 + 0xc0000000;
      iVar4 = iVar4 + -1;
      puVar3[0x7b] = uVar10;
    } while (iVar4 != 0);
    bVar12 = uVar8 != 0;
    uVar8 = uVar8 - 1;
  } while (bVar12);
  DataSynchronizationBarrier(0xf);
  InstructionSynchronizationBarrier(0xf);
  return;
}

