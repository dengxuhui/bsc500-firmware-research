
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009110(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 uVar2;
  
  iVar1 = _DAT_60009158;
  *(undefined4 *)(_DAT_60009158 + 4) = param_1;
  if (*(int *)(iVar1 + 8) == 0) {
    uVar2 = FUN_60165194(1,1,0,param_4,param_3,param_4);
    *(undefined4 *)(iVar1 + 8) = uVar2;
  }
  if (*(int *)(iVar1 + 0xc) == 0) {
    uVar2 = FUN_60165194(1,1,0);
    *(undefined4 *)(iVar1 + 0xc) = uVar2;
  }
  if (*(int *)(iVar1 + 0x10) == 0) {
    uVar2 = FUN_60165194(1,0,0);
    *(undefined4 *)(iVar1 + 0x10) = uVar2;
  }
  func_0x60167f3c(7,_DAT_6000917c,1,&UNK_60009180,&UNK_6000915c);
  return;
}

