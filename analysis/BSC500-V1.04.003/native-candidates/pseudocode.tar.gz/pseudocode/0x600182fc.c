
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

char FUN_600182fc(void)

{
  char *pcVar1;
  code *pcVar2;
  char cVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  char cStack_25;
  undefined1 auStack_24 [4];
  undefined4 uStack_20;
  undefined1 auStack_1c [4];
  undefined4 uStack_18;
  int iStack_14;
  
  pcVar1 = _DAT_600183ec;
  if (*_DAT_600183ec == '\0') {
    uStack_20 = 0;
    cStack_25 = '\0';
    iVar4 = FUN_6012f44c();
    iVar5 = FUN_60166758(&uStack_20,_DAT_600183f0,1);
    if (iVar5 == 0) {
      FUN_60161ef4(uStack_20,&cStack_25,1,auStack_24);
      FUN_601667bc(uStack_20);
      pcVar2 = _DAT_6001842c;
      if ((iVar4 == 0x68) || (cStack_25 != 'h')) {
        (*_DAT_6001842c)(_DAT_600183f4);
        (*pcVar2)(_DAT_600183fc);
        (*pcVar2)(_DAT_600183f0);
        (*pcVar2)(_DAT_60018430);
      }
      else {
        uStack_18 = 0;
        iStack_14 = 0;
        iVar4 = FUN_60166758(&iStack_14,_DAT_600183f4,1);
        if (iVar4 == 0) {
          uVar6 = FUN_6016506c();
          *(undefined4 *)(pcVar1 + 8) = uVar6;
          uVar6 = FUN_60162e34();
          *(undefined4 *)(pcVar1 + 4) = uVar6;
          uVar6 = FUN_60161ef4(iStack_14,uVar6,*(undefined4 *)(pcVar1 + 8),auStack_1c);
          func_0x60168578(_DAT_600183f8,_DAT_600183f4,uVar6);
          FUN_601667bc(iStack_14);
          iVar4 = FUN_60166758(&uStack_18,_DAT_600183fc,1);
          if (iVar4 == 0) {
            uVar6 = FUN_6016506c(uStack_18);
            *(undefined4 *)(pcVar1 + 0x10) = uVar6;
            uVar6 = FUN_60162e34();
            *(undefined4 *)(pcVar1 + 0xc) = uVar6;
            uVar6 = FUN_60161ef4(uStack_18,uVar6,*(undefined4 *)(pcVar1 + 0x10),auStack_1c);
            func_0x60168578(_DAT_600183f8,_DAT_600183fc,uVar6);
            FUN_601667bc(uStack_18);
            func_0x60168578(&UNK_60018400,*(undefined4 *)(pcVar1 + 8),*(undefined4 *)(pcVar1 + 0x10)
                           );
          }
          *pcVar1 = '\x01';
        }
        else if (iStack_14 != 0) {
          FUN_601667bc();
        }
      }
    }
    cVar3 = *pcVar1;
  }
  else {
    cVar3 = '\x01';
  }
  return cVar3;
}

