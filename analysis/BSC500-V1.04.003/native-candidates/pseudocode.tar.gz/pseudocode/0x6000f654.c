
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000f654(int param_1,int param_2)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 *puVar4;
  bool bVar5;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  
  piVar1 = _DAT_6000f75c;
  iVar2 = *_DAT_6000f75c;
  if (iVar2 == 0) {
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_28 = 1;
    uStack_2c = _DAT_6000f760;
    iVar2 = FUN_60168494(&uStack_2c);
    *piVar1 = iVar2;
  }
  FUN_6016825e(iVar2,0xffffffff);
  iVar2 = piVar1[1];
  while (iVar2 != 0) {
    iVar3 = *(int *)(iVar2 + 0x30);
    bVar5 = iVar2 == param_1;
    puVar4 = (undefined4 *)(param_1 + 0x2c);
    iVar2 = iVar3;
    if (bVar5) {
      for (; puVar4 = (undefined4 *)*puVar4, puVar4 != (undefined4 *)0x0; puVar4 = puVar4 + 1) {
        if ((code *)*puVar4 != (code *)0x0) {
          (*(code *)*puVar4)(*(undefined4 *)(param_2 + 8));
        }
      }
    }
  }
  if (*piVar1 != 0) {
    func_0x601682ae();
  }
  return;
}

