
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60004b28(int param_1,int param_2)

{
  short sVar1;
  code *pcVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  int *piVar7;
  undefined4 extraout_r1;
  int *extraout_r2;
  int extraout_r3;
  int extraout_r3_00;
  int unaff_r4;
  int iVar8;
  int unaff_r5;
  int iVar9;
  undefined4 *puVar10;
  int unaff_r6;
  int *unaff_r7;
  int *piVar11;
  undefined4 in_stack_00000394;
  int in_stack_0000039c;
  
  if (param_1 != 0) {
    if (param_2 != 0) {
      *(int *)(param_1 + 8) = param_2;
    }
    return (int *)(param_1 + 4);
  }
  uVar3 = FUN_6016804c(uRam60004b3c,0x60004b40,0xae);
  *unaff_r7 = unaff_r6;
  *(char *)(unaff_r4 + 9) = (char)unaff_r5;
  *(undefined4 *)(unaff_r6 + 0x34) = uVar3;
  *(int **)(extraout_r3 + 0x34) = unaff_r7;
  iVar9 = *(int *)(*(int *)(unaff_r5 + 0x14) + 100);
  sVar1 = *(short *)(unaff_r6 + iVar9);
  *(int *)(sVar1 + 0x44) = in_stack_0000039c;
  sVar1 = *(short *)(sVar1 + iVar9);
  iVar4 = *(int *)(unaff_r6 + 0x74);
  *(char *)(unaff_r6 + 0x11) = (char)extraout_r3;
  *(int **)(extraout_r3 + 0x34) = unaff_r7;
  *(int *)(sVar1 + 0x34) = in_stack_0000039c;
  iVar8 = *(int *)(unaff_r6 + 0x14);
  piVar11 = *(int **)(iVar9 + 100);
  if (iVar4 != 0) {
    piVar11 = (int *)(iVar4 + 4);
    if (in_stack_0000039c != 0) {
      *piVar11 = in_stack_0000039c;
    }
    return piVar11;
  }
  piVar5 = (int *)FUN_6016804c(uRam60004b74,0x60004b78,0xa5);
  *piVar11 = unaff_r6;
  *(char *)(iVar8 + 9) = (char)iVar9;
  *(int **)(unaff_r6 + 0x34) = piVar5;
  *(int **)(extraout_r3_00 + 0x34) = piVar11;
  iVar4 = *(int *)(*(int *)(iVar9 + 0x14) + 100);
  sVar1 = *(short *)(unaff_r6 + iVar4);
  *(undefined4 *)(sVar1 + 0x44) = in_stack_00000394;
  iVar8 = (int)*(short *)(sVar1 + iVar4);
  *(char *)(unaff_r6 + 9) = (char)piVar5;
  puVar10 = (undefined4 *)(int)*(short *)(iVar8 + iVar4);
  *(int *)(iVar8 + 0x24) = extraout_r3_00;
  *(int **)(extraout_r3_00 + 0x14) = piVar11;
  *(char *)(iVar8 + 0x11) = (char)extraout_r3_00;
  pcVar2 = pcRam60004c04;
  iVar4 = puVar10[0x1d];
  if (piVar5 == (int *)0x0) {
    FUN_6016804c(&UNK_60004c34,_DAT_60004c30,0x2b);
  }
  else if (iVar4 != 0) {
    piVar6 = (int *)(*pcRam60004c04)(4);
    *piVar6 = iRam60004c08 + 8;
    uVar3 = (*pcVar2)(4);
    FUN_600f5a7c();
    piVar7 = (int *)(*pcVar2)(0x20);
    ZeroBytes(piVar7 + 1,0x14);
    piVar7[6] = 0;
    piVar7[7] = 0;
    *piVar7 = iRam60004c0c + 8;
    (**(code **)(*piVar5 + 0x14))(piVar5,uVar3);
    piVar11 = _DAT_60004c10;
    piVar7[3] = iVar4;
    piVar7[4] = (int)piVar6;
    piVar7[5] = (int)piVar5;
    *piVar11 = (int)piVar7;
    return piVar7;
  }
  FUN_6016804c(&UNK_60004c14,_DAT_60004c30,0x2c);
  *extraout_r2 = iVar8;
  *puVar10 = extraout_r1;
  *puVar10 = extraout_r1;
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

