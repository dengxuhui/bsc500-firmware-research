
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600018e4(int param_1,uint param_2)

{
  short sVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined1 uVar8;
  uint uVar9;
  uint uVar10;
  int iVar11;
  undefined2 extraout_r2;
  undefined4 extraout_r2_00;
  int extraout_r3;
  int extraout_r3_00;
  int unaff_r4;
  int unaff_r5;
  int iVar12;
  int unaff_r6;
  uint uVar13;
  undefined4 unaff_r7;
  undefined8 uVar14;
  
  if (param_1 == 0) {
    uVar14 = FUN_6016804c(uRam60001930,0x60001934,0xab);
    iVar11 = (int)uVar14;
    *(short *)(unaff_r4 + 0x28) = (short)unaff_r4;
    *(undefined4 *)unaff_r7 = unaff_r7;
    *(char *)(extraout_r3 + 1) = (char)unaff_r7;
    sVar1 = *(short *)(unaff_r5 * 2);
    iVar12 = (int)sVar1;
    *(int *)(unaff_r6 + 0x54) = extraout_r3;
    *(int *)(iVar12 + 0x54) = unaff_r4;
    *(char *)(unaff_r4 + 0x11) = (char)extraout_r3;
    *(char *)(extraout_r3 + 0xd) = (char)unaff_r7;
    *(int *)(iVar12 + 0x54) = unaff_r4;
    *(char *)(unaff_r4 + 1) = (char)sVar1;
    *(undefined4 *)(iVar12 + 0x44) = *(undefined4 *)(extraout_r3 + 0x54);
    if (iVar11 != 0) {
      *(int *)(iVar11 + 0x54) = extraout_r3;
      uVar7 = uRam600019a8;
      uVar6 = uRam600019a4;
      uVar5 = uRam600019a0;
      uVar4 = uRam6000199c;
      uVar3 = uRam60001998;
      uVar2 = uRam60001994;
      *(undefined4 *)(iVar11 + 0x24) = 0;
      *(undefined4 *)(iVar11 + 0x28) = 0;
      *(undefined4 *)(iVar11 + 0x2c) = uVar7;
      *(undefined4 *)(iVar11 + 0x30) = uVar6;
      *(undefined4 *)(iVar11 + 0x34) = uVar5;
      *(undefined4 *)(iVar11 + 0x38) = uVar4;
      *(undefined4 *)(iVar11 + 0x3c) = uVar3;
      *(undefined4 *)(iVar11 + 0x40) = uVar2;
      *(undefined1 *)(iVar11 + 0x1c) = 0;
      func_0x601637f8(iVar11,(int)((ulonglong)uVar14 >> 0x20),extraout_r2,0,extraout_r3);
      *(undefined4 *)(iVar11 + 0x44) = uRam600019ac;
      return;
    }
    FUN_6016804c(0x600019b0,0x600019c4,0x488);
    uRam0000009c = 0;
    uRam00000098 = 0x98;
    uRam00000093 = extraout_r2_00;
    *(int *)(unaff_r6 + 0x54) = extraout_r3_00;
    uVar8 = (undefined1)*(int *)(unaff_r6 + 0x14);
    *(undefined1 *)(*(int *)(unaff_r6 + 0x14) + 0x20) = uVar8;
    iVar11 = _DAT_60001b3c;
    *(undefined1 *)(_DAT_60001b3c + 0x11) = uVar8;
    *(int *)(iVar11 + 0x54) = extraout_r3_00;
    uRam00000041 = uRam00000084;
    *(char *)(extraout_r3_00 + 9) = (char)*(undefined2 *)(iVar11 + 0x93);
    uRam000000b4 = 0x93;
    uRam000000a0 = (undefined1)uRam00000041;
    *(undefined4 *)(iVar11 + 0x54) = 0x40;
    return;
  }
  if (*(code **)(param_1 + 0x6c) == (code *)0x0) {
    uVar9 = (uint)*(byte *)(param_1 + 0x70);
    do {
      if ((int)uVar9 < 1) {
        uVar8 = 1;
        goto LAB_60001920;
      }
      uVar13 = uVar9 - 1;
      uVar10 = FUN_60167b58(*(undefined4 *)(*(int *)(param_1 + 0x74) + uVar9 * 8 + -8));
      uVar9 = uVar13;
    } while (param_2 < uVar10);
    uVar8 = *(undefined1 *)(*(int *)(param_1 + 0x74) + uVar13 * 8 + 4);
  }
  else {
    uVar8 = (**(code **)(param_1 + 0x6c))(param_2);
  }
LAB_60001920:
  *(undefined1 *)(param_1 + 0x5e) = uVar8;
  return;
}

