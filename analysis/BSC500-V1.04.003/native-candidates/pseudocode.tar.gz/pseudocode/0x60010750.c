
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4
FUN_60010750(undefined4 *param_1,undefined4 *param_2,int param_3,int *param_4,int *param_5)

{
  uint uVar1;
  byte bVar2;
  undefined4 *puVar3;
  code *pcVar4;
  undefined1 *puVar5;
  int iVar6;
  undefined4 uVar7;
  int iVar8;
  undefined4 uVar9;
  uint in_fpscr;
  uint uVar10;
  float fVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 uVar14;
  int iVar15;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  undefined4 extraout_s1_03;
  undefined4 extraout_s1_04;
  float fVar16;
  float fVar17;
  float fVar18;
  float fVar19;
  int iVar20;
  float fVar21;
  undefined8 in_d6;
  undefined8 in_d7;
  undefined8 uVar22;
  undefined8 uVar23;
  undefined4 uStack_5c;
  undefined8 uStack_58;
  
  uStack_5c = (undefined4)((ulonglong)in_d6 >> 0x20);
  uStack_58 = in_d7;
  iVar6 = func_0x60166dd0();
  if ((iVar6 == 0) && (iVar6 = func_0x60166dd0(param_2), puVar3 = _DAT_60010b00, iVar6 == 0)) {
    fVar16 = (float)VectorSignedToFloat(_DAT_60010b00[1],(byte)(in_fpscr >> 0x16) & 3);
    fVar11 = (float)VectorSignedToFloat(*_DAT_60010b00,(byte)(in_fpscr >> 0x16) & 3);
    fVar21 = (float)VectorSignedToFloat(param_1[1],(byte)(in_fpscr >> 0x16) & 3);
    fVar17 = (float)VectorSignedToFloat(*param_1,(byte)(in_fpscr >> 0x16) & 3);
    uVar22 = FUN_60166bb4(ABS(fVar17 / fVar21 - fVar11 / fVar16));
    uVar7 = (undefined4)((ulonglong)_UNK_60010ac8 >> 0x20);
    uVar9 = (undefined4)_UNK_60010ac8;
    iVar6 = FUN_60167bc4((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),uVar9,uVar7);
    if (iVar6 == 0) {
      fVar11 = (float)VectorSignedToFloat(param_2[1],(byte)(in_fpscr >> 0x16) & 3);
      fVar16 = (float)VectorSignedToFloat(*param_2,(byte)(in_fpscr >> 0x16) & 3);
      fVar16 = fVar16 / fVar11;
    }
    else {
      fVar18 = (float)VectorSignedToFloat(puVar3[3],(byte)(in_fpscr >> 0x16) & 3);
      fVar11 = (float)VectorSignedToFloat(puVar3[2],(byte)(in_fpscr >> 0x16) & 3);
      fVar19 = (float)VectorSignedToFloat(param_2[1],(byte)(in_fpscr >> 0x16) & 3);
      fVar16 = (float)VectorSignedToFloat(*param_2,(byte)(in_fpscr >> 0x16) & 3);
      fVar16 = fVar16 / fVar19;
      uVar22 = FUN_60166bb4(ABS(fVar16 - fVar11 / fVar18));
      iVar6 = FUN_60167bc4((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),uVar9,uVar7);
      if (iVar6 != 0) goto LAB_6001076e;
    }
    uVar22 = FUN_601673c4(((*(int *)(param_3 + 0x14) * 0x16f + *(int *)(param_3 + 0xc) +
                           (uint)(*(int *)(param_3 + 0x10) * 0x113) / 9) -
                          (((*(int *)(param_3 + 0x10) + 9U) / 0xc + *(int *)(param_3 + 0x14)) * 7 >>
                          2)) + _DAT_60010b04);
    uVar22 = FUN_601682c8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)_UNK_60010ad0,
                          (int)((ulonglong)_UNK_60010ad0 >> 0x20));
    uVar23 = FUN_60166bb4(fVar16 / _UNK_60010b08);
    FUN_601682c8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                 (int)((ulonglong)uVar23 >> 0x20));
    uVar7 = FUN_601672d4();
    fVar11 = (float)FUN_6001b658(uVar7);
    fVar11 = (float)FUN_60127be0(fVar16 + fVar11 + _UNK_60010b0c);
    FUN_600237b8(uVar7,&uStack_58,&uStack_5c,(int)&uStack_58 + 4);
    fVar16 = (float)FUN_60021718(fVar11 - (float)uStack_58);
    uVar22 = FUN_60166bb4(uStack_58._4_4_);
    FUN_601675d8((int)_UNK_60010ad8,(int)((ulonglong)_UNK_60010ad8 >> 0x20),(int)uVar22,
                 (int)((ulonglong)uVar22 >> 0x20));
    fVar11 = (float)FUN_601672d4();
    uVar22 = FUN_60166bb4(fVar11 + _UNK_60010b10);
    uVar9 = (undefined4)((ulonglong)_UNK_60010ae0 >> 0x20);
    uVar14 = (undefined4)_UNK_60010ae0;
    uVar7 = FUN_601678fc((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),uVar14,uVar9);
    pcVar4 = _DAT_60010b14;
    uVar12 = (*_DAT_60010b14)(uVar7);
    uVar22 = FUN_60166bb4(fVar17 / fVar21);
    uVar7 = FUN_601678fc((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),uVar14,uVar9);
    uVar13 = (*pcVar4)(uVar7);
    uVar22 = FUN_60166bb4(uStack_5c);
    uVar9 = FUN_601678fc((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),uVar14,uVar9);
    uVar14 = (*pcVar4)(uVar9);
    uVar22 = FUN_601678fc(uVar13,extraout_s1_00,uVar14,extraout_s1_01);
    uVar22 = FUN_60165558(uVar12,extraout_s1,(int)uVar22,(int)((ulonglong)uVar22 >> 0x20));
    uVar7 = FUN_6015dac8(uVar7);
    uVar9 = FUN_6015dac8(uVar9);
    uVar23 = FUN_601678fc(uVar7,extraout_s1_02,uVar9,extraout_s1_03);
    FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)uVar23,
                 (int)((ulonglong)uVar23 >> 0x20));
    fVar11 = (float)FUN_601672d4();
    uVar7 = FUN_60166bb4();
    fVar16 = fVar16 / -15.0 + 12.0;
    uVar1 = in_fpscr & 0xfffffff | (uint)(fVar11 < 1.0) << 0x1f;
    uVar10 = uVar1 | (uint)NAN(fVar11) << 0x1c;
    if ((byte)(uVar1 >> 0x1f) == ((byte)(uVar10 >> 0x1c) & 1)) {
      iVar6 = -1;
      fVar11 = _UNK_60010b18;
    }
    else {
      uVar1 = in_fpscr & 0xfffffff | (uint)(fVar11 < -1.0) << 0x1f | (uint)(fVar11 == -1.0) << 0x1e;
      uVar10 = uVar1 | (uint)NAN(fVar11) << 0x1c;
      bVar2 = (byte)(uVar1 >> 0x18);
      if ((bool)(bVar2 >> 6 & 1) || bVar2 >> 7 != ((byte)(uVar10 >> 0x1c) & 1)) {
        iVar6 = 1;
        fVar11 = 12.0;
      }
      else {
        uVar7 = FUN_60023d30(uVar7);
        uVar22 = FUN_601678fc(uVar7,extraout_s1_04,(int)_UNK_60010ae8,
                              (int)((ulonglong)_UNK_60010ae8 >> 0x20));
        FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)_UNK_60010af0,
                     (int)((ulonglong)_UNK_60010af0 >> 0x20));
        fVar11 = (float)FUN_601672d4();
        iVar6 = 0;
      }
    }
    puVar5 = _DAT_60010b5c;
    fVar17 = (fVar16 + fVar11) * _UNK_60010b1c;
    fVar11 = (fVar16 - fVar11) * _UNK_60010b1c;
    *(int *)(_DAT_60010b5c + 0xc) = (int)fVar17;
    *(int *)(puVar5 + 8) = (int)fVar11;
    iVar20 = (int)fVar17;
    iVar15 = (int)fVar11;
    iVar8 = _DAT_60010b20;
    if ((iVar6 == -1) || (iVar8 = _DAT_60010b24, iVar6 == 1)) {
      iVar15 = iVar15 + iVar8;
      iVar20 = iVar20 + iVar8;
      *(int *)(puVar5 + 8) = iVar15;
      *(int *)(puVar5 + 0xc) = iVar20;
    }
    fVar16 = (float)VectorSignedToFloat(param_2[1],(byte)(uVar10 >> 0x16) & 3);
    fVar11 = (float)VectorSignedToFloat(*param_2,(byte)(uVar10 >> 0x16) & 3);
    uVar22 = FUN_60166bb4(fVar11 / fVar16);
    FUN_601675d8((int)uVar22,(int)((ulonglong)uVar22 >> 0x20),(int)_UNK_60010af8,
                 (int)((ulonglong)_UNK_60010af8 >> 0x20));
    iVar6 = FUN_60167a50();
    *(int *)(puVar5 + 4) = iVar6 * 900;
    uVar7 = param_1[1];
    *puVar3 = *param_1;
    puVar3[1] = uVar7;
    uVar7 = param_2[1];
    puVar3[2] = *param_2;
    puVar3[3] = uVar7;
    uVar7 = 1;
    *puVar5 = 1;
    *param_4 = iVar15;
    *param_5 = iVar20;
  }
  else {
LAB_6001076e:
    uVar7 = 0;
  }
  return uVar7;
}

