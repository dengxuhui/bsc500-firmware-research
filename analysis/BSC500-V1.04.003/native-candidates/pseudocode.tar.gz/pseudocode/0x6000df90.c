
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000df90(void)

{
  undefined4 uVar1;
  uint *puVar2;
  ushort uVar3;
  int iVar4;
  int iVar5;
  undefined4 uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  uint uVar10;
  int *piVar11;
  int *piVar12;
  undefined1 auStack_13c [4];
  undefined1 auStack_138 [4];
  undefined1 auStack_134 [97];
  undefined4 uStack_d3;
  undefined2 uStack_6e;
  undefined1 auStack_6c [64];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  
  uStack_2c = 0;
  uStack_28 = 0;
  uVar3 = FUN_60147734(_DAT_6000e214,_DAT_6000e218,0,0,0,0);
  uVar9 = (uint)uVar3;
  func_0x60167f3c(6,_DAT_6000e21c,1,&UNK_6000e220,uVar9);
  iVar4 = _DAT_6000e22c;
  if (uVar9 != 0) {
    FUN_60161fb8(_DAT_6000e22c);
    FUN_601340d8(iVar4,_DAT_6000e214,_DAT_6000e218,0,0,0,0,0,uVar9 - 1);
    uVar1 = _DAT_6000e21c;
    piVar11 = (int *)(iVar4 + 8);
    uVar6 = _DAT_6000e244;
    piVar12 = piVar11;
    while (piVar12 = (int *)*piVar12, piVar12 != piVar11) {
      ZeroBytes(auStack_6c,0x40);
      ZeroBytes((int)&uStack_d3 + 3,100);
      ZeroBytes(auStack_134,100);
      CopyBytes(auStack_6c,piVar12[-2],piVar12[-1]);
      iVar4 = FUN_60168220(auStack_6c);
      func_0x60167f3c(6,uVar1,1,&UNK_6000e230,auStack_6c);
      func_0x601681f4(auStack_134,_DAT_6000e240,uVar6,auStack_6c);
      iVar5 = FUN_60166758(&uStack_28,auStack_134,1);
      if (iVar5 == 0) {
        iVar5 = FUN_6016506c(uStack_28);
        puVar2 = _DAT_6000e248;
        if (iVar5 == 0x400) {
          FUN_60161ef4(uStack_28,_DAT_6000e248,0x400,auStack_138);
          FUN_601667bc(uStack_28);
          func_0x60167f3c(6,uVar1,1,&UNK_6000e24c,auStack_6c,*puVar2,(short)puVar2[0xfc]);
          *(undefined2 *)((int)&uStack_6e + iVar4) = 0;
          func_0x601681f4(auStack_134,_DAT_6000e240,_DAT_6000e268,auStack_6c);
          if (((ushort)puVar2[0xfc] < 0x3ed) &&
             (iVar5 = FUN_60166758(&uStack_28,auStack_134,2), puVar2 = _DAT_6000e248, iVar5 == 0)) {
            uVar9 = *_DAT_6000e248;
            uVar6 = FUN_6016506c(uStack_28);
            func_0x60167f3c(6,uVar1,1,&UNK_6000e26c,uVar9,uVar6);
            uVar10 = *puVar2;
            uVar9 = FUN_6016506c(uStack_28);
            puVar2 = _DAT_6000e248;
            if (uVar10 <= uVar9) {
              uVar9 = *_DAT_6000e248;
              uVar6 = FUN_6016506c(uStack_28);
              func_0x60167f3c(6,uVar1,1,&UNK_6000e290,uVar9,uVar6);
              FUN_60163c98(uStack_28,0);
              FUN_60164ed8(uStack_28,(int)puVar2 + 0x3f2,0xe,auStack_13c);
              FUN_60163c98(uStack_28,*puVar2);
              FUN_60164ed8(uStack_28,puVar2 + 1,(short)puVar2[0xfc],auStack_13c);
              uVar9 = puVar2[0xfc];
              uVar8 = *puVar2;
              uVar10 = FUN_6016506c(uStack_28);
              if (uVar8 + (ushort)uVar9 < uVar10) {
                FUN_60163c98(uStack_28,*_DAT_6000e248 + (uint)(ushort)_DAT_6000e248[0xfc]);
                FUN_60163c68(uStack_28);
                uVar6 = FUN_6016506c(uStack_28);
                func_0x60167f3c(6,uVar1,1,&UNK_6000e2b0,uVar6);
              }
              FUN_601667bc(uStack_28);
            }
          }
        }
        iVar5 = (int)&uStack_d3 + 3;
        func_0x6007db44(iVar5,auStack_134,100);
        iVar7 = FUN_60168220(iVar5);
        *(undefined4 *)(iVar5 + iVar7 + -3) = _DAT_6000e2c0;
        iVar5 = FUN_60166758(&uStack_2c,iVar5,1);
        if (iVar5 == 0) {
          FUN_601667bc(uStack_2c);
          *(undefined1 *)((int)&uStack_d3 + iVar7 + 2) = 0x69;
          *(undefined1 *)((int)&uStack_d3 + iVar7 + 3) = 0x74;
          *(undefined1 *)((int)&uStack_d3 + iVar7) = 0x74;
          *(undefined1 *)((int)&uStack_d3 + iVar7 + 1) = 0x66;
          FUN_60162054(auStack_134);
        }
      }
      uVar6 = _DAT_6000e244;
      *(undefined2 *)((int)&uStack_6e + iVar4) = 0x7062;
      func_0x601681f4(auStack_134,_DAT_6000e240,_DAT_6000e244,auStack_6c);
      func_0x60167f3c(6,uVar1,1,_DAT_6000e2c4,auStack_134);
      FUN_60163bbe(auStack_134);
    }
    FUN_601607f4(_DAT_6000e22c);
  }
  FUN_600187a0();
  return;
}

