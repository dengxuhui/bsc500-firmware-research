
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60002ddc(void)

{
  *_DAT_60002de4 = 1;
  return;
}

