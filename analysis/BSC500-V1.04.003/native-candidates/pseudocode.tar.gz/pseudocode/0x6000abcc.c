
/* WARNING: Possible PIC construction at 0x6000abde: Changing call to branch */
/* WARNING: Possible PIC construction at 0x6000abee: Changing call to branch */
/* WARNING: Possible PIC construction at 0x6000ac00: Changing call to branch */
/* WARNING: Possible PIC construction at 0x6000ac1c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x6000ac3c: Changing call to branch */
/* WARNING: Possible PIC construction at 0x6000ac4c: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6000ac40) */
/* WARNING: Removing unreachable block (ram,0x6000ac20) */
/* WARNING: Removing unreachable block (ram,0x6000ac2c) */
/* WARNING: Removing unreachable block (ram,0x6000ac4a) */
/* WARNING: Removing unreachable block (ram,0x6000ac30) */
/* WARNING: Removing unreachable block (ram,0x6000ac46) */
/* WARNING: Removing unreachable block (ram,0x6000ac38) */
/* WARNING: Removing unreachable block (ram,0x6000ac04) */
/* WARNING: Removing unreachable block (ram,0x6000ac12) */
/* WARNING: Removing unreachable block (ram,0x6000ac18) */
/* WARNING: Removing unreachable block (ram,0x6000ac0e) */
/* WARNING: Removing unreachable block (ram,0x6000abf2) */
/* WARNING: Removing unreachable block (ram,0x6000abe2) */
/* WARNING: Removing unreachable block (ram,0x6000abfc) */
/* WARNING: Removing unreachable block (ram,0x6000abfe) */
/* WARNING: Removing unreachable block (ram,0x6000abec) */
/* WARNING: Removing unreachable block (ram,0x6000ac50) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000abcc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  int *piVar2;
  uint *puVar3;
  undefined *puVar4;
  uint uVar5;
  uint uVar6;
  undefined4 *puStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  
  iVar1 = _DAT_60161478;
  if (*(char *)(_DAT_6000ac5c + 0xf) == '\x01') {
    uStack_28 = 0x6000abe3;
    puVar4 = &UNK_6000ac60;
  }
  else {
    uStack_28 = 0x6000ac21;
    puVar4 = _DAT_6000ace0;
  }
  iStack_2c = _DAT_6000ac5c;
  if (puVar4 != (undefined *)0x0) {
    puStack_38 = &uStack_24;
    uStack_34 = param_3;
    uStack_30 = param_2;
    uStack_24 = param_2;
    uStack_20 = param_3;
    uStack_1c = param_4;
    uStack_18 = param_4;
    FUN_60001d60(_DAT_60161478,puVar4,&puStack_38);
    piVar2 = _DAT_6016147c;
    if (*_DAT_6016147c != _DAT_60161480) {
      *_DAT_6016147c = _DAT_60161480;
      piVar2[1] = 0;
    }
    puVar3 = _DAT_60161484;
    if ((*_DAT_60161484 < 0x1ff8) && (uVar5 = *(uint *)(iVar1 + 8), uVar5 != 0)) {
      uVar6 = 0x1ff8;
      if (uVar5 < 0x1ff8) {
        uVar6 = uVar5;
      }
      piVar2[1] = uVar6;
      *puVar3 = uVar6;
    }
  }
  return;
}

