
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000a514(int param_1)

{
  int iVar1;
  undefined *puVar2;
  
  iVar1 = FUN_600182f0();
  if (iVar1 != 0) {
    *_DAT_6000a564 = (char)param_1;
    if (param_1 == 0) {
      puVar2 = &UNK_6000a568;
    }
    else {
      iVar1 = FUN_6012f44c();
      func_0x60168578(&UNK_6000a584,iVar1);
      if ((iVar1 != 0x68) && (iVar1 = FUN_600182fc(), iVar1 != 0)) {
        FUN_60139e58(1);
        FUN_6012f458();
        FUN_60139e80();
        FUN_600159e0();
        return 1;
      }
      puVar2 = &UNK_6000a5a4;
    }
    func_0x60168578(puVar2);
  }
  return 0;
}

