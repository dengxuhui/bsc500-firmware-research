
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000b218(void)

{
  FUN_6012c99c(_DAT_6000b220 + 0x18);
  return 0;
}

