
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60005398(undefined4 param_1,uint param_2)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  int *piVar6;
  int *piVar7;
  int *piVar8;
  
  iVar3 = FUN_60164eb0(2);
  uVar2 = _DAT_60005424;
  piVar8 = (int *)(iVar3 + 4);
  uVar4 = FUN_6015de24(_DAT_60005424,piVar8);
  func_0x60168578(&UNK_60005428,uVar4,uVar2);
  FUN_6015de60(uVar4);
  func_0x60168578(&UNK_60005444);
  uVar2 = _DAT_6000546c;
  piVar6 = piVar8;
  while (piVar6 = (int *)*piVar6, piVar6 != piVar8) {
    piVar1 = piVar6 + 2;
    piVar7 = (int *)*piVar1;
    param_2 = (uint)*(ushort *)(piVar6 + 4);
    uVar5 = FUN_6015dd58(piVar1);
    if (piVar7 == piVar1) {
      func_0x60168578(&UNK_60005470,uVar4,0x10,piVar6 + -5,param_2,uVar5);
    }
    else {
      func_0x60168578(&UNK_6000545c,uVar4,0x10,piVar6 + -5,param_2,uVar5);
      FUN_6015dd6c(piVar1);
      func_0x60168578(uVar2);
    }
  }
  return (ulonglong)param_2 << 0x20;
}

