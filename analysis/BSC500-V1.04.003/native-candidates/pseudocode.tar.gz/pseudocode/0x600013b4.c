
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600013b4(void)

{
  uint *puVar1;
  undefined4 uVar2;
  uint uVar3;
  int iVar4;
  int iVar5;
  undefined1 auStack_9c [4];
  int iStack_98;
  undefined1 auStack_94 [64];
  undefined1 uStack_54;
  undefined1 uStack_53;
  byte bStack_50;
  byte bStack_4f;
  byte bStack_4e;
  byte bStack_4d;
  undefined1 auStack_4c [12];
  undefined1 auStack_40 [8];
  int aiStack_38 [10];
  
  uVar3 = FUN_60134a3c();
  aiStack_38[0] = _DAT_60001558;
  if ((uVar3 & 0xfe000000) != 0x10000000) {
    if ((uVar3 & 0xfc000000) == 0x64000000) {
      aiStack_38[0] = _DAT_60001558 + 0x1000;
    }
    else if ((uVar3 & 0xf8000000) == 0x68000000) {
      aiStack_38[0] = _DAT_60001558 + 0x2000;
    }
    else {
      if ((uVar3 & 0xfe000000) != 0x12000000) {
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      aiStack_38[0] = _DAT_60001558 + 0x40000;
    }
  }
  iVar4 = FUN_60134816(aiStack_38);
  if (iVar4 != 0) {
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar4 = FUN_60134a46(aiStack_38,0x1000,auStack_94,0x40);
  if (iVar4 == 0) {
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar5 = FUN_600f5ed6(6,&bStack_50,4,auStack_94,iVar4);
  puVar1 = _DAT_6000155c;
  if (iVar5 == 0) {
    _DAT_6000155c[9] = _DAT_6000155c[9] & 0xffffffe1 | 0x16;
  }
  else {
    _DAT_6000155c[3] = _DAT_6000155c[3] & 0xfffffe1f | (uint)bStack_50 << 5;
    puVar1[9] = puVar1[9] & 0xffffffe1 | (bStack_4f & 0xf) << 1;
    puVar1[9] = puVar1[9] & 0xffe1ffff | (bStack_4f & 0xf0) << 0xd;
    *puVar1 = *puVar1 & 0xffffc3ff | (uint)bStack_4e << 10;
    puVar1[4] = puVar1[4] & 0xfffffe1f | (uint)bStack_4d << 5;
  }
  iVar5 = FUN_600f5ed6(3,&iStack_98,4,auStack_94,iVar4);
  if ((iVar5 == 0) || (iStack_98 == 0x3ff || iStack_98 == 0)) {
    iStack_98 = 0x1ea;
  }
  FUN_601633bc(iStack_98);
  iVar5 = FUN_600f5ed6(4,auStack_9c,4,auStack_94,iVar4);
  if (iVar5 != 0) {
    FUN_60163310(0,auStack_9c,4);
  }
  iVar5 = FUN_600f5ed6(5,auStack_40,8,auStack_94,iVar4);
  if (iVar5 != 0) {
    FUN_60163310(1,auStack_40,8);
  }
  iVar5 = FUN_600f5ed6(9,auStack_4c,0xc,auStack_94,iVar4);
  if (iVar5 != 0) {
    FUN_60163310(4,auStack_4c,0xc);
  }
  iVar4 = FUN_600f5ed6(0x14,&uStack_54,2,auStack_94,iVar4);
  if (iVar4 == 0) {
    uStack_53 = 0;
    *_DAT_60001560 = 0;
  }
  else {
    *_DAT_60001560 = uStack_54;
  }
  uVar2 = _DAT_60001568;
  *_DAT_60001564 = uStack_53;
  iVar4 = FUN_60134a46(aiStack_38,0x2000,uVar2,0x100);
  if (iVar4 != 0) {
    iVar4 = FUN_60134a46(aiStack_38,0x3000,_DAT_6000156c,0x100);
    if (iVar4 != 0) {
      return 0;
    }
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

