
/* WARNING: Removing unreachable block (ram,0x6011ed5c) */
/* WARNING: Removing unreachable block (ram,0x60139ec8) */
/* WARNING: Removing unreachable block (ram,0x60139ee6) */
/* WARNING: Removing unreachable block (ram,0x60139eb0) */
/* WARNING: Removing unreachable block (ram,0x60139ebe) */
/* WARNING: Removing unreachable block (ram,0x60139ee8) */
/* WARNING: Removing unreachable block (ram,0x60139ef4) */
/* WARNING: Removing unreachable block (ram,0x60139ef6) */
/* WARNING: Removing unreachable block (ram,0x60139ef8) */
/* WARNING: Removing unreachable block (ram,0x60139efc) */
/* WARNING: Removing unreachable block (ram,0x60139f00) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60007770(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  uVar1 = _DAT_60007778;
  uStack_18 = param_3;
  uStack_14 = param_4;
  iVar2 = FUN_6005c9e8();
  if (iVar2 == 0) {
    iVar3 = FUN_60129540();
    iVar2 = 0;
    if (iVar3 != 0) {
      uStack_18 = uVar1;
      uStack_14 = 0;
      FUN_6015e16c(_DAT_6015976c,&uStack_18);
      iVar2 = FUN_6005b118();
    }
  }
  return iVar2;
}

