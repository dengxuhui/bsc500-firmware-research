
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_600089d8(void)

{
  ushort uVar1;
  char *pcVar2;
  undefined2 *puVar3;
  int iVar4;
  ushort *puVar5;
  int iVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  undefined *puVar14;
  uint uVar15;
  uint uVar16;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  undefined *puVar17;
  int iVar18;
  
  pcVar2 = _DAT_60008a8c;
  if (*_DAT_60008a8c == '\0') {
    uVar15 = 0xffff;
    if ((*_DAT_60008a94 != 0xffff) || (puVar5 = (ushort *)0x0, *_DAT_60008a98 != 0)) {
      FUN_6004fdb8();
      *_DAT_6012e274 = 0;
      puVar3 = _DAT_6012e278;
      *_DAT_6012e278 = 0xffff;
      return CONCAT44(0xffff,puVar3);
    }
  }
  else {
    iVar4 = FUN_6015c548(*(undefined4 *)(_DAT_60008a8c + 0xc4),0);
    if (((iVar4 == 0) || (*(short *)(pcVar2 + 0xd0) == -1)) ||
       (*(short *)(_DAT_60008a90 + 0x288) == 0x7fff)) {
      uVar15 = (uint)*_DAT_60008a94;
      puVar5 = _DAT_60008a94;
    }
    else {
      uVar15 = FUN_6001b394(*(undefined2 *)(pcVar2 + 0xc4),*(short *)(pcVar2 + 0xd0),
                            (int)*(short *)(_DAT_60008a90 + 0x288));
      puVar5 = _DAT_60008a94;
      *_DAT_60008a94 = (ushort)uVar15;
    }
    if (uVar15 != 0xffff) {
      uVar1 = *_DAT_60008a98;
      puVar5 = _DAT_60008a98;
      if ((short)uVar1 < 1) {
        if (((uVar1 != 0xffff) && (49999 < *(uint *)(_DAT_60008a90 + 0x1b4))) &&
           (*(uint *)(_DAT_60008a90 + 0x1c8) <= _DAT_60008a9c)) {
          uVar16 = (uint)*(ushort *)(pcVar2 + 0x1c);
          iVar4 = uVar15 - uVar16;
          if (uVar15 < uVar16) {
            iVar4 = uVar16 - uVar15;
          }
          if (uVar16 * 5 <= (uint)(iVar4 * 1000) && iVar4 * 1000 + uVar16 * -5 != 0) {
            *_DAT_60008a98 = 0xffff;
            uVar9 = _DAT_60008aa0;
            iVar13 = FUN_6015982e();
            FUN_60159828(iVar13,uVar9,0,uVar15);
            puVar14 = (undefined *)FUN_6015bd44();
            iVar4 = _DAT_6016493c;
            if ((puVar14 == (undefined *)0x0) && (iVar13 != 0)) {
              func_0x6011ed5c(iVar13);
            }
            else if (iVar13 == 0) {
              iVar13 = FUN_6015982e();
              FUN_60159828(iVar13,iVar4,0,0);
            }
            iVar12 = *(int *)(_DAT_60159870 + 8);
            puVar17 = puVar14;
            if (iVar12 == 0) {
              if (iVar13 != 0) {
                func_0x60139eac(iVar13);
                puVar17 = puVar14;
              }
            }
            else {
              iVar18 = iVar4;
              iVar11 = iVar13;
              iVar6 = FUN_60133088();
              uVar10 = _DAT_600570a8;
              uVar9 = _DAT_60057044;
              if (iVar6 != 0) {
                piVar7 = (int *)(iVar12 + 4);
                do {
                  piVar7 = (int *)*piVar7;
                  if (piVar7 == (int *)0x0) {
LAB_6005702c:
                    FUN_601330ec();
                    if (iVar13 != 0) {
LAB_60057036:
                      func_0x60139eac(iVar13);
                    }
                    return CONCAT44(puVar17,1);
                  }
                  if (((undefined *)piVar7[1] == puVar14) && (*piVar7 == iVar4)) {
                    puVar8 = (undefined4 *)FUN_60139e84(puVar14);
                    if (puVar8 != (undefined4 *)0x0) {
                      puVar17 = (undefined *)piVar7[3];
                      iVar4 = FUN_60058f40(puVar8[1],piVar7[2],puVar8[3],iVar13,puVar17,iVar18,
                                           iVar11,unaff_r4,unaff_r5,unaff_r6);
                      if (iVar4 == 0) {
                        if (puVar8[1] != 0) {
                          uVar9 = FUN_60052acc();
                          uVar10 = FUN_6005b1e8(puVar8[1]);
                          iVar11 = FUN_6012376e(puVar8[1]);
                          func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057048,uVar9,uVar10,iVar11);
                        }
                        puVar17 = (undefined *)*puVar8;
                        uVar9 = FUN_6013a3fc(puVar17);
                        func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057074,puVar17,uVar9,iVar11);
                      }
                      else if (((puVar8[1] == 0) && (iVar13 != 0)) && (puVar8[3] != 0)) {
                        func_0x60139eac(iVar13);
                        FUN_601330ec();
                        goto LAB_60057036;
                      }
                      goto LAB_6005702c;
                    }
                    puVar17 = &UNK_60057094;
                    func_0x60167f3c(3,uVar9,1,uVar10);
                  }
                  piVar7 = piVar7 + 4;
                } while( true );
              }
            }
            return ZEXT48(puVar17) << 0x20;
          }
        }
      }
      else {
        uVar15 = (int)(short)uVar1 - 1;
        *_DAT_60008a98 = (ushort)uVar15;
      }
    }
  }
  return CONCAT44(uVar15,puVar5);
}

