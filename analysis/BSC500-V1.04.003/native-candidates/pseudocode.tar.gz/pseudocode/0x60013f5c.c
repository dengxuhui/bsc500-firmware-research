
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60013f5c(int param_1,int param_2)

{
  undefined1 *puVar1;
  undefined2 uVar2;
  undefined1 uVar3;
  ushort uVar4;
  short sVar5;
  int iVar6;
  int iVar7;
  undefined1 *puVar8;
  int iVar9;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  uint in_fpscr;
  undefined4 uVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  float fVar18;
  uint in_s14;
  undefined8 uStack_38;
  
  if (*_DAT_60014254 == '\0') {
    return 0xffffffff;
  }
  if (param_1 == 0) {
    return 0xffffffff;
  }
  if (param_2 == 0) {
    return 0xffffffff;
  }
  uStack_38._0_4_ = in_s14;
  if (*_DAT_60014254 == '\x01') {
    FUN_60043e50(param_1);
    FUN_60043e80(param_1);
    FUN_60043eb4(param_1);
  }
  FUN_6001c0c0(param_1,param_2);
  puVar8 = _DAT_60014260;
  iVar7 = _DAT_6001425c;
  iVar6 = _DAT_60014258;
  puVar1 = (undefined1 *)(_DAT_60014258 + 0x28);
  *puVar1 = *(undefined1 *)(param_1 + 0xda);
  FUN_6001c048(iVar7,puVar1,puVar8);
  fVar16 = _UNK_60014264;
  uVar13 = *(undefined4 *)(param_2 + 0x2ac);
  iVar9 = *(int *)(param_1 + 0xa0);
  *(undefined1 *)(param_2 + 0x29b) = *puVar8;
  *(undefined4 *)(iVar6 + 0x44) = *(undefined4 *)(param_1 + 4);
  fVar14 = (float)VectorUnsignedToFloat(uVar13,(byte)(in_fpscr >> 0x16) & 3);
  *(float *)(iVar6 + 0x48) = fVar14 / fVar16;
  fVar14 = _DAT_60014268;
  if (iVar9 == 0x7fffffff) {
    *(float *)(iVar6 + 0x4c) = _DAT_60014268;
    *(float *)(iVar6 + 0x50) = fVar14;
  }
  else {
    iVar9 = FUN_6011d9b4();
    if (iVar9 == 1) {
      uVar13 = *(undefined4 *)(param_1 + 0x9c);
    }
    else {
      uVar13 = FUN_6015616c();
      fVar14 = (float)VectorSignedToFloat(uVar13,(byte)(in_fpscr >> 0x16) & 3);
      *(float *)(iVar6 + 0x50) = fVar14 / fVar16;
      uVar13 = FUN_60023340();
    }
    fVar14 = (float)VectorSignedToFloat(uVar13,(byte)(in_fpscr >> 0x16) & 3);
    *(float *)(iVar6 + 0x4c) = fVar14 / fVar16;
  }
  FUN_6001dea8(iVar7 + 0x6c,iVar6 + 0x44,puVar8 + 0xc);
  fVar14 = _UNK_6001426c;
  fVar15 = *(float *)(puVar8 + 0xc);
  uVar13 = *(undefined4 *)(puVar8 + 0x10);
  fVar17 = *(float *)(puVar8 + 0x14);
  fVar18 = *(float *)(puVar8 + 0x18);
  *(float *)(param_2 + 0x2b4) = fVar15;
  *(undefined4 *)(param_2 + 0x2b8) = uVar13;
  uVar13 = *(undefined4 *)(param_1 + 4);
  *(float *)(param_2 + 700) = fVar17;
  *(float *)(param_2 + 0x2c0) = fVar18;
  *(undefined4 *)(iVar6 + 0x5c) = uVar13;
  *(short *)(param_2 + 0x288) = (short)(int)(fVar15 * fVar14);
  *(short *)(param_2 + 0x28a) = (short)(int)(fVar17 * fVar14);
  *(short *)(param_2 + 0x2b0) = (short)(int)(fVar18 * fVar16);
  uStack_38 = (ulonglong)(uint)uStack_38;
  iVar9 = FUN_601323d4((int)&uStack_38 + 4,0);
  if (iVar9 == 0) {
    iVar9 = *(int *)(param_1 + 0x9c);
    fVar15 = _DAT_60014268;
    if (iVar9 == 0x7fffffff) goto LAB_600140c2;
  }
  else {
    iVar9 = uStack_38._4_4_;
  }
  fVar15 = (float)VectorSignedToFloat(iVar9,(byte)(in_fpscr >> 0x16) & 3);
  fVar15 = fVar15 / fVar16;
LAB_600140c2:
  *(float *)(iVar6 + 0x60) = fVar15;
  FUN_60023b50(iVar7 + 0x224,iVar6 + 0x5c,puVar8 + 0x50);
  fVar16 = _UNK_60014270;
  fVar15 = (*(float *)(puVar8 + 0x54) * _UNK_60014270) / _UNK_60014274;
  *(short *)(param_2 + 0x28c) =
       (short)(int)((*(float *)(puVar8 + 0x50) * _UNK_60014270) / _UNK_60014274);
  *(short *)(param_2 + 0x28e) = (short)(int)fVar15;
  fVar15 = (float)VectorUnsignedToFloat(*(undefined4 *)(param_2 + 4),(byte)(in_fpscr >> 0x16) & 3);
  sVar5 = *(short *)(param_2 + 0x288);
  *(float *)(iVar6 + 0x34) = fVar15 / fVar16;
  fVar16 = (float)VectorSignedToFloat((int)sVar5,(byte)(in_fpscr >> 0x16) & 3);
  *(undefined4 *)(iVar6 + 0x2c) = *(undefined4 *)(param_1 + 4);
  *(float *)(iVar6 + 0x30) = fVar16 / fVar14;
  uVar13 = FUN_6002026c(iVar7 + 0xc,(undefined4 *)(iVar6 + 0x2c));
  uVar2 = *(undefined2 *)(param_2 + 10);
  *(undefined4 *)(puVar8 + 4) = uVar13;
  *(undefined4 *)(param_2 + 0x2c4) = uVar13;
  *(undefined4 *)(iVar6 + 0x3c) = uVar13;
  *(undefined2 *)(iVar6 + 0x40) = uVar2;
  *(undefined1 *)(iVar6 + 0x42) = *(undefined1 *)(param_2 + 0xe);
  *(undefined4 *)(iVar6 + 0x38) = *(undefined4 *)(param_1 + 4);
  uVar13 = FUN_6001c1fc(iVar7 + 0x20,(undefined4 *)(iVar6 + 0x38));
  uVar3 = *(undefined1 *)(param_1 + 0xd8);
  *(undefined4 *)(puVar8 + 8) = uVar13;
  *(undefined4 *)(param_2 + 0x2c8) = uVar13;
  *(undefined1 *)(iVar6 + 0x54) = uVar3;
  FUN_6001e146(iVar7 + 0x104,(undefined1 *)(iVar6 + 0x54),puVar8 + 0x1c);
  *(undefined1 *)(param_2 + 0x29a) = puVar8[0x1c];
  *(undefined2 *)(iVar6 + 0x56) = *(undefined2 *)(param_1 + 0xd4);
  FUN_6002001a(iVar7 + 0x110,(undefined2 *)(iVar6 + 0x56));
  FUN_6001ff9c(iVar7 + 0x110,puVar8 + 0x1e);
  uVar4 = *(ushort *)(puVar8 + 0x1e);
  *(undefined2 *)(param_2 + 0x292) = *(undefined2 *)(puVar8 + 0x22);
  uVar2 = *(undefined2 *)(puVar8 + 0x26);
  *(ushort *)(param_2 + 0x290) = uVar4;
  *(undefined2 *)(param_2 + 0x294) = uVar2;
  if ((*(ushort *)(param_2 + 0x296) == 0xffff) || (*(ushort *)(param_2 + 0x296) < uVar4)) {
    *(ushort *)(param_2 + 0x296) = uVar4;
  }
  uVar13 = *(undefined4 *)(puVar8 + 0x3a);
  uVar10 = *(undefined4 *)(puVar8 + 0x3e);
  uVar11 = *(undefined4 *)(puVar8 + 0x42);
  uVar12 = *(undefined4 *)(puVar8 + 0x46);
  *(undefined2 *)(param_2 + 0x302) = *(undefined2 *)(puVar8 + 0x34);
  *(undefined4 *)(param_2 + 0x304) = *(undefined4 *)(puVar8 + 0x36);
  *(undefined4 *)(param_2 + 0x308) = uVar13;
  *(undefined4 *)(param_2 + 0x30c) = uVar10;
  *(undefined4 *)(param_2 + 0x310) = uVar11;
  *(undefined4 *)(param_2 + 0x314) = uVar12;
  *(undefined1 *)(iVar6 + 0x58) = *(undefined1 *)(param_2 + 0x10);
  FUN_60020122(iVar7 + 0x1d0,(undefined1 *)(iVar6 + 0x58));
  FUN_6002010c(iVar7 + 0x1d0,puVar8 + 0x4a);
  *(undefined1 *)(param_2 + 0x29d) = puVar8[0x4a];
  *(undefined2 *)(param_2 + 0x29e) = *(undefined2 *)(puVar8 + 0x4b);
  *(undefined2 *)(iVar6 + 0x5a) = *(undefined2 *)(param_1 + 0xd4);
  FUN_600201f6(iVar7 + 0x210,(undefined2 *)(iVar6 + 0x5a),puVar8 + 0x4d);
  *(undefined1 *)(param_2 + 0x29c) = puVar8[0x4d];
  return 0;
}

