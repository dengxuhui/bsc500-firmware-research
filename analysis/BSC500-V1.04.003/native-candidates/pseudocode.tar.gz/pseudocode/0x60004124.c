
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void InitializeBacklight(void)

{
  char *pcVar1;
  code *pcVar2;
  undefined2 uVar3;
  int iVar4;
  undefined *puVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  byte bVar9;
  int iVar10;
  char acStack_7c [67];
  char cStack_39;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  
  func_0x60168578(&UNK_600043d4);
  uVar7 = _DAT_60004430;
  bVar9 = 0;
  uStack_28 = 0;
  func_0x60168578(&UNK_60004404,_DAT_60004430);
  iVar4 = FUN_60166758(&uStack_28,uVar7,1);
  if (iVar4 == 0) {
    func_0x60168578(_DAT_6000445c);
    pcVar1 = _DAT_60004460;
    _DAT_60004460[3] = '\0';
    ZeroBytes(acStack_7c,0x40);
    iVar4 = 0;
    while (bVar9 < 0x14) {
      iVar10 = FUN_60161ef4(uStack_28,&cStack_39,1,&iStack_38);
      if ((iVar10 != 0) || (iStack_38 == 0)) {
        if ((0 < iVar4) && ((byte)pcVar1[3] < 0x14)) {
          acStack_7c[iVar4] = '\0';
          iVar4 = SplitCsvFields(acStack_7c,&uStack_34,2);
          if (iVar4 == 2) {
            uVar3 = FUN_6016811c(uStack_34);
            bVar9 = pcVar1[3];
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 6) = uVar3;
            uVar3 = FUN_6016811c(uStack_30);
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 8) = uVar3;
            pcVar1[3] = bVar9 + 1;
          }
        }
        break;
      }
      if (cStack_39 == '\r' || cStack_39 == '\n') {
        if (0 < iVar4) {
          acStack_7c[iVar4] = '\0';
          iVar10 = SplitCsvFields(acStack_7c,&uStack_34,2);
          iVar4 = 0;
          if (iVar10 == 2) {
            uVar3 = FUN_6016811c(uStack_34);
            bVar9 = pcVar1[3];
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 6) = uVar3;
            uVar3 = FUN_6016811c(uStack_30);
            *(undefined2 *)(pcVar1 + (uint)bVar9 * 4 + 8) = uVar3;
            iVar4 = 0;
            pcVar1[3] = bVar9 + 1;
          }
        }
      }
      else if (iVar4 < 0x3f) {
        acStack_7c[iVar4] = cStack_39;
        iVar4 = iVar4 + 1;
      }
      bVar9 = pcVar1[3];
    }
    FUN_601667bc(uStack_28);
    puVar5 = _DAT_60004464;
    if (pcVar1[3] == '\0') goto LAB_6000414c;
    *pcVar1 = '\x01';
    func_0x60168578(_DAT_60004468);
    uVar7 = _DAT_6000446c;
    for (uVar8 = 0; uVar8 < (byte)pcVar1[3]; uVar8 = uVar8 + 1) {
      func_0x60168578(uVar7,uVar8,*(undefined2 *)(pcVar1 + uVar8 * 4 + 6),
                      *(undefined2 *)(pcVar1 + uVar8 * 4 + 8));
    }
  }
  else {
    puVar5 = &UNK_60004434;
LAB_6000414c:
    func_0x60168578(puVar5);
  }
  uVar7 = _DAT_60004474;
  bVar9 = 0;
  uStack_28 = 0;
  func_0x60168578(_DAT_60004470,_DAT_60004474);
  iVar4 = FUN_60166758(&uStack_28,uVar7,1);
  uVar7 = _DAT_60004478;
  if (iVar4 == 0) {
    func_0x60168578(_DAT_6000447c);
    pcVar1 = _DAT_60004460;
    _DAT_60004460[4] = '\0';
    ZeroBytes(acStack_7c,0x40);
    iVar4 = _DAT_60004484;
    iVar10 = 0;
    while (bVar9 < 0x32) {
      iVar6 = FUN_60161ef4(uStack_28,&cStack_39,1,&iStack_38);
      if ((iVar6 != 0) || (iStack_38 == 0)) {
        if ((0 < iVar10) && ((byte)pcVar1[4] < 0x32)) {
          acStack_7c[iVar10] = '\0';
          iVar10 = SplitCsvFields(acStack_7c,&uStack_34,3);
          pcVar2 = _DAT_60004480;
          if (iVar10 == 3) {
            uVar7 = (*_DAT_60004480)(uStack_34);
            bVar9 = pcVar1[4];
            *(undefined4 *)(iVar4 + (uint)bVar9 * 8) = uVar7;
            iVar10 = iVar4 + (uint)bVar9 * 8;
            uVar3 = (*pcVar2)(uStack_30);
            *(undefined2 *)(iVar10 + 4) = uVar3;
            uVar3 = (*pcVar2)(uStack_2c);
            *(undefined2 *)(iVar10 + 6) = uVar3;
            pcVar1[4] = bVar9 + 1;
          }
        }
        break;
      }
      if (cStack_39 == '\r' || cStack_39 == '\n') {
        if (0 < iVar10) {
          acStack_7c[iVar10] = '\0';
          iVar6 = SplitCsvFields(acStack_7c,&uStack_34,3);
          iVar10 = 0;
          if (iVar6 == 3) {
            uVar7 = (*_DAT_60004480)(uStack_34);
            pcVar2 = _DAT_60004480;
            bVar9 = pcVar1[4];
            *(undefined4 *)(iVar4 + (uint)bVar9 * 8) = uVar7;
            iVar10 = iVar4 + (uint)bVar9 * 8;
            uVar3 = (*pcVar2)(uStack_30);
            *(undefined2 *)(iVar10 + 4) = uVar3;
            uVar3 = (*_DAT_60004480)(uStack_2c);
            *(undefined2 *)(iVar10 + 6) = uVar3;
            iVar10 = 0;
            pcVar1[4] = bVar9 + 1;
          }
        }
      }
      else if (iVar10 < 0x3f) {
        acStack_7c[iVar10] = cStack_39;
        iVar10 = iVar10 + 1;
      }
      bVar9 = pcVar1[4];
    }
    FUN_601667bc(uStack_28);
    uVar7 = _DAT_60004488;
    if (pcVar1[4] != '\0') {
      pcVar1[1] = '\x01';
      func_0x60168578(_DAT_6000448c);
      uVar7 = _DAT_60004490;
      for (uVar8 = 0; uVar8 < (byte)pcVar1[4]; uVar8 = uVar8 + 1) {
        iVar10 = iVar4 + uVar8 * 8;
        func_0x60168578(uVar7,uVar8,*(undefined4 *)(iVar4 + uVar8 * 8),*(undefined2 *)(iVar10 + 4),
                        *(undefined2 *)(iVar10 + 6));
      }
      goto LAB_60004176;
    }
  }
  func_0x60168578(uVar7);
LAB_60004176:
  if ((*_DAT_60004460 != '\0') || (uVar7 = _DAT_60004494, _DAT_60004460[1] == '\x01')) {
    _DAT_60004460[2] = '\x01';
    uVar7 = _DAT_60004498;
  }
  func_0x60168578(uVar7);
  return;
}

