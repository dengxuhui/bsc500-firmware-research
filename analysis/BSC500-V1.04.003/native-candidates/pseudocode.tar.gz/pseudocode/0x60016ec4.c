
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_60016ec4(short *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  int iVar3;
  uint uVar4;
  
  puVar2 = (undefined4 *)FUN_601597fc(_DAT_60016f44);
  if (puVar2 == (undefined4 *)0x0) {
    FUN_60163730(&UNK_60016f64,_DAT_60016f60,0x9b);
LAB_60016f38:
    FUN_60163730(&UNK_60016f4c,_DAT_60016f60,0xa3);
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  if (*(int *)(param_1 + 0x1e) == 0) {
    iVar3 = FUN_6015f71c(*(undefined4 *)(param_1 + 0x24));
    if (iVar3 == 0) goto LAB_60016f38;
    (**(code **)(param_1 + 0x20))(param_1,iVar3);
    *(int *)(param_1 + 0x1e) = iVar3;
  }
  func_0x601608ac(puVar2,8);
  *puVar2 = param_1;
  piVar1 = _DAT_60016f48;
  uVar4 = *(uint *)(param_1 + 8);
  iVar3 = *_DAT_60016f48;
  *_DAT_60016f48 = (int)puVar2;
  if (((int)(uVar4 << 0x1e) < 0) &&
     (*(uint *)(*(int *)(param_1 + 6) + 0xc) < (uint)((int)param_1[1] * (int)*param_1))) {
    *(uint *)(param_1 + 8) = uVar4 & 0xfffffffd;
  }
  *piVar1 = iVar3;
  if (iVar3 == 0) {
    *piVar1 = (int)puVar2;
  }
  iVar3 = FUN_6015bb78();
  if (iVar3 == 0) {
    FUN_6015bb80(*piVar1);
  }
  return puVar2;
}

