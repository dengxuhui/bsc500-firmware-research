
/* WARNING: Possible PIC construction at 0x60009b74: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x60009b78) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009b20(void)

{
  int iVar1;
  int *piVar2;
  undefined *puVar3;
  uint uVar4;
  uint extraout_r2;
  uint uVar5;
  uint extraout_r3;
  uint uVar6;
  uint unaff_r4;
  uint unaff_r5;
  uint unaff_r7;
  undefined4 unaff_lr;
  uint *puVar7;
  undefined8 uVar8;
  uint uStack_48;
  uint uStack_44;
  uint uStack_40;
  uint uStack_3c;
  uint uStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  uint uStack_28;
  uint uStack_24;
  
  uVar8 = FUN_60161a98();
  iVar1 = _DAT_60161478;
  uVar4 = (uint)((ulonglong)uVar8 >> 0x20);
  if ((int)uVar8 == 0) {
    puVar3 = &UNK_60009b8c;
    uVar5 = extraout_r2;
    uVar6 = extraout_r3;
  }
  else {
    uVar4 = (uint)*_DAT_60009b9c;
    uStack_2c = (uint)*(byte *)(_DAT_60009bac + 0x18);
    uStack_44 = (uint)*(byte *)(_DAT_60009ba4 + 0x18);
    uStack_40 = (uint)*(byte *)(_DAT_60009ba4 + 0x19);
    uStack_3c = (uint)*(byte *)(_DAT_60009ba4 + 0x1b);
    uStack_38 = (uint)*(byte *)(_DAT_60009ba8 + 0x18);
    unaff_r4 = (uint)*(byte *)(_DAT_60009ba8 + 0x19);
    unaff_r7 = (uint)*(byte *)(_DAT_60009ba8 + 0x1b);
    uVar5 = (uint)*(byte *)(_DAT_60009ba0 + 0x24);
    uVar6 = (uint)*(byte *)(_DAT_60009ba0 + 0x25);
    uStack_48 = (uint)*(byte *)(_DAT_60009ba0 + 0x27);
    uStack_28 = (uint)*(byte *)(_DAT_60009bac + 0x19);
    unaff_r5 = (uint)*(byte *)(_DAT_60009bac + 0x1b);
    unaff_lr = 0x60009b79;
    puVar3 = &UNK_60009bb0;
    register0x00000054 = (BADSPACEBASE *)&uStack_48;
    uStack_34 = unaff_r4;
    uStack_30 = unaff_r7;
    uStack_24 = unaff_r5;
  }
  *(undefined4 *)((int)register0x00000054 + -0x10) = unaff_lr;
  *(uint *)((int)register0x00000054 + -0x14) = unaff_r7;
  *(uint *)((int)register0x00000054 + -0x18) = unaff_r5;
  *(uint *)((int)register0x00000054 + -0x1c) = unaff_r4;
  puVar7 = (uint *)((int)register0x00000054 + -0x20);
  *puVar7 = uVar6;
  *(uint *)((int)register0x00000054 + -0xc) = uVar4;
  *(uint *)((int)register0x00000054 + -8) = uVar5;
  *(uint *)((int)register0x00000054 + -4) = uVar6;
  if (puVar3 != (undefined *)0x0) {
    *puVar7 = (uint)((int)register0x00000054 + -0xc);
    FUN_60001d60(_DAT_60161478,puVar3,puVar7);
    piVar2 = _DAT_6016147c;
    if (*_DAT_6016147c != _DAT_60161480) {
      *_DAT_6016147c = _DAT_60161480;
      piVar2[1] = 0;
    }
    puVar7 = _DAT_60161484;
    if ((*_DAT_60161484 < 0x1ff8) && (uVar4 = *(uint *)(iVar1 + 8), uVar4 != 0)) {
      uVar5 = 0x1ff8;
      if (uVar4 < 0x1ff8) {
        uVar5 = uVar4;
      }
      piVar2[1] = uVar5;
      *puVar7 = uVar5;
    }
  }
  return;
}

