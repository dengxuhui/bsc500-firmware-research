
void FUN_6000db24(void)

{
  return;
}

