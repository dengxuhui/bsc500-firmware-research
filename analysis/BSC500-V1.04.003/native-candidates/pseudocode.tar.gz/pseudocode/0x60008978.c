
/* WARNING: Removing unreachable block (ram,0x60016d18) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60008978(void)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  int *piVar6;
  
  FUN_6016572c(_DAT_600089c0,1,_DAT_600089c4);
  FUN_6016507e(_DAT_600089c8,1000,0);
  uVar1 = _DAT_600089cc;
  FUN_6015f550(_DAT_600089cc);
  FUN_6015f564(uVar1);
  FUN_60166868(_DAT_600089d0);
  iVar4 = _DAT_600089d4;
  FUN_60166898(_DAT_600089d4);
  FUN_601678a8(iVar4 + 0x18);
  piVar5 = _DAT_60011470;
  piVar2 = (int *)(iVar4 + 0x30);
  if (_DAT_60011470 == (int *)0x0) {
    return (int *)0x0;
  }
  if (piVar2 == (int *)0x0) {
    return _DAT_60011470;
  }
  iVar3 = _DAT_60011470[2];
  if (iVar3 == 0) {
    iVar3 = FUN_60168494(0);
    piVar5[2] = iVar3;
    if (iVar3 == 0) goto code_r0x60016cf2;
  }
  FUN_6016825e(iVar3,0xffffffff);
code_r0x60016cf2:
  piVar6 = (int *)*piVar5;
  if (piVar6 != piVar5) {
    for (; piVar6 != piVar5; piVar6 = (int *)*piVar6) {
      if (((piVar6 + -2 == piVar2) && (piVar6[2] != 0)) &&
         (iVar3 = FUN_60168418(piVar6[-2],*piVar2), iVar3 == 0)) goto code_r0x60016d2e;
    }
  }
  iVar3 = iVar4 + 0x38;
  *(int *)(iVar4 + 0x3c) = iVar3;
  *(uint *)(iVar4 + 0x34) = (uint)*(byte *)(iVar4 + 0x34);
  piVar2 = (int *)piVar5[1];
  *piVar2 = iVar3;
  *(int **)(iVar4 + 0x38) = piVar5;
  *(int **)(iVar4 + 0x3c) = piVar2;
  piVar5[1] = iVar3;
code_r0x60016d2e:
  iVar4 = piVar5[2];
  if (iVar4 == 0) {
    return (int *)0x0;
  }
  if (iVar4 != 0) {
    iVar4 = func_0x60165418(iVar4 + 4);
    piVar5 = (int *)0x0;
    if (iVar4 != 0) {
      piVar5 = (int *)0xfffffffd;
    }
    return piVar5;
  }
  return (int *)0xfffffffc;
}

