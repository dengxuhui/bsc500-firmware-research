
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60018700 */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_600186ec(undefined8 *param_1,undefined8 *param_2)

{
  int iVar1;
  undefined4 uVar2;
  float fVar3;
  undefined8 uStack_30;
  undefined8 uStack_28;
  undefined8 uStack_20;
  undefined8 uStack_18;
  
  if ((((param_1 != (undefined8 *)0x0) && (param_2 != (undefined8 *)0x0)) &&
      (iVar1 = FUN_60137930((int)*param_1,(int)((ulonglong)*param_1 >> 0x20),(int)param_1[1],
                            0xffffffff), iVar1 != 0)) &&
     (iVar1 = FUN_60137930((int)*param_2,(int)((ulonglong)*param_2 >> 0x20),(int)param_2[1]),
     iVar1 != 0)) {
    fVar3 = (float)*param_1;
    FUN_60161ad0(fVar3,(int)((ulonglong)*param_1 >> 0x20),(int)param_1[1],
                 (int)((ulonglong)param_1[1] >> 0x20),(int)*param_2,
                 (int)((ulonglong)*param_2 >> 0x20),(int)param_2[1]);
    uVar2 = _DAT_60018790;
    if ((1.0 <= fVar3) && ((int)(fVar3 * _UNK_60018784) <= _DAT_60018a70)) {
      *_DAT_60018788 = -(~(int)(fVar3 * _UNK_60018784) >> 0x1f);
      uStack_30 = *param_1;
      uStack_28 = param_1[1];
      uStack_20 = *param_2;
      uStack_18 = param_2[1];
      uVar2 = FUN_60020be0(&uStack_30,2,2,uVar2,1,0,_DAT_6001878c);
      return uVar2;
    }
  }
  return 0xffffffff;
}

