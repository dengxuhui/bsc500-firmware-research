
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001107c(byte *param_1,float param_2)

{
  char *pcVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  byte *pbVar6;
  byte *pbVar7;
  int iVar8;
  char *pcVar9;
  char *pcVar10;
  int iVar11;
  float fVar12;
  float fStack_2c;
  byte *pbStack_28;
  float afStack_24 [2];
  
  pcVar1 = _DAT_600501bc;
  afStack_24[0] = (float)(uint)*param_1;
  if (afStack_24[0] == 0.0) {
code_r0x600110a6:
    *_DAT_60011114 = 0;
    return 0;
  }
  if (afStack_24[0] != 1.4013e-45) {
    return 0;
  }
  switch(param_1[0x30]) {
  case 0:
    goto code_r0x600110a6;
  case 1:
    uVar2 = 0;
    if ((uint)((uint)((ulonglong)*(uint *)(param_1 + 0x28) * 100) <= *(uint *)((int)param_2 + 0x40))
        <= (uint)-(int)((ulonglong)*(uint *)(param_1 + 0x28) * 100 >> 0x20)) goto code_r0x6001110c;
    if ((uint)(*(int *)(param_1 + 8) - *(int *)(_DAT_60011114 + 8)) < 0x1389) {
code_r0x6001110a:
      uVar2 = 0;
      goto code_r0x6001110c;
    }
    *(int *)(_DAT_60011114 + 8) = *(int *)(param_1 + 8);
    break;
  case 2:
    fStack_2c = param_2;
    pbStack_28 = param_1;
    if (*_DAT_600501bc == '\0') {
      if (param_1[0xcc] != 0) {
        iVar8 = func_0x60166dd0(param_1 + 0xb4);
        if ((iVar8 == 0) && (iVar8 = func_0x60166dd0(param_1 + 0xb4), iVar8 == 0)) {
          uVar2 = *(undefined4 *)(param_1 + 0xb8);
          *(undefined4 *)((int)param_2 + 0x318) = *(undefined4 *)(param_1 + 0xb4);
          *(undefined4 *)((int)param_2 + 0x31c) = uVar2;
          pcVar1[0] = '\x01';
          pcVar1[1] = '\0';
          uVar2 = *(undefined4 *)(param_1 + 0xc0);
          *(undefined4 *)((int)param_2 + 800) = *(undefined4 *)(param_1 + 0xbc);
          *(undefined4 *)((int)param_2 + 0x324) = uVar2;
        }
      }
    }
    else if (*(char *)((int)param_2 + 0x329) != '\0') {
      pbVar6 = param_1 + 0xbc;
      iVar11 = (int)param_2 + 800;
      pbVar7 = param_1 + 0xb4;
      iVar8 = (int)param_2 + 0x318;
      if (_DAT_600501bc[1] == '\x01') {
        fStack_2c = 0.0;
        pbStack_28 = (byte *)0x0;
        if (((*(char *)(_DAT_600501c0 + 0xcc) != '\0') &&
            (iVar3 = func_0x60166dd0(pbVar7), iVar3 == 0)) &&
           (iVar3 = func_0x60166dd0(pbVar6), iVar3 == 0)) {
          pcVar10 = pcVar1 + 0x10;
          iVar3 = func_0x60166dd0(pcVar10);
          if (iVar3 == 0) {
            pcVar9 = pcVar1 + 0x18;
            iVar3 = func_0x60166dd0(pcVar9);
            if (iVar3 == 0) {
              FUN_6015ce30(pcVar1 + 4,pcVar10,pcVar9,iVar8,iVar11);
              FUN_6015ce30(&pbStack_28,pcVar10,pcVar9,pbVar7,pbVar6);
            }
          }
          FUN_6015ce30(&fStack_2c,pbVar7,pbVar6,iVar8,iVar11);
          if ((*(int *)(pcVar1 + 0x10) != *(int *)pbVar7) &&
             (*(int *)(pcVar1 + 0x18) != *(int *)pbVar6)) {
            uVar2 = *(undefined4 *)(param_1 + 0xb8);
            uVar4 = *(undefined4 *)pbVar6;
            uVar5 = *(undefined4 *)(param_1 + 0xc0);
            *(undefined4 *)(pcVar1 + 0x10) = *(undefined4 *)pbVar7;
            *(undefined4 *)(pcVar1 + 0x14) = uVar2;
            *(undefined4 *)(pcVar1 + 0x18) = uVar4;
            *(undefined4 *)(pcVar1 + 0x1c) = uVar5;
          }
          if ((fStack_2c == 0.0) || ((float)pbStack_28 == 0.0)) {
            iVar8 = 0;
          }
          else {
            iVar8 = FUN_6005cf1e(pbStack_28,*(undefined4 *)(pcVar1 + 4));
          }
          if (fStack_2c < _UNK_600501c8) {
LAB_60050170:
            pcVar1[1] = '\0';
            return 1;
          }
          if ((iVar8 < 2000) && (fVar12 = *(float *)(pcVar1 + 4), _UNK_600501c8 < fVar12)) {
            if ((fStack_2c * fStack_2c < fVar12 * fVar12 + (float)pbStack_28 * (float)pbStack_28) &&
               (fVar12 * fVar12 < fStack_2c * fStack_2c + (float)pbStack_28 * (float)pbStack_28))
            goto LAB_60050170;
          }
        }
      }
      else {
        afStack_24[0] = 0.0;
        if (((*(char *)(_DAT_600501c0 + 0xcc) != '\0') &&
            (iVar3 = func_0x60166dd0(pbVar7), iVar3 == 0)) &&
           (iVar3 = func_0x60166dd0(pbVar6), iVar3 == 0)) {
          FUN_6015ce30(afStack_24,pbVar7,pbVar6,iVar8,iVar11);
          if (_UNK_600501c4 < afStack_24[0]) {
            pcVar1[1] = '\x01';
          }
        }
      }
    }
    return 0;
  case 3:
    uVar2 = 0;
    if (*(uint *)((int)param_2 + 0x44) < (uint)(*(int *)(param_1 + 0x2c) * 1000))
    goto code_r0x6001110c;
    if ((uint)(*(int *)(param_1 + 8) - *(int *)(_DAT_60011114 + 0xc)) < 0x1389)
    goto code_r0x6001110a;
    *(int *)(_DAT_60011114 + 0xc) = *(int *)(param_1 + 8);
    break;
  default:
    return 0;
  }
  uVar2 = 1;
code_r0x6001110c:
  *_DAT_60011114 = 0;
  return uVar2;
}

