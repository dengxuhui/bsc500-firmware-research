
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000b59c(void)

{
  char *pcVar1;
  int iVar2;
  char *pcVar3;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  
  pcVar1 = _DAT_6000b600;
  if (*_DAT_6000b600 != '\0') {
    pcVar3 = _DAT_6000b600 + 4;
    iVar2 = func_0x60166dd0(pcVar3);
    if (iVar2 == 0) {
      iVar2 = func_0x60166dd0(pcVar1 + 0xc);
      if (iVar2 == 0) {
        uStack_40 = *(undefined4 *)(pcVar1 + 0x38);
        uStack_34 = *(undefined4 *)(pcVar1 + 0x24);
        uStack_30 = *(undefined4 *)(pcVar1 + 0x28);
        uStack_38 = *(undefined4 *)(pcVar1 + 0x30);
        uStack_3c = *(undefined4 *)(pcVar1 + 0x34);
        iStack_2c = *(int *)(pcVar1 + 0x2c) + 2000;
        iVar2 = FUN_601648ec(&uStack_40);
        if (iVar2 != 0) {
          FUN_60010750(pcVar3,pcVar1 + 0xc,&uStack_40,_DAT_6000b604 + 0xa78,_DAT_6000b604 + 0xa7c);
          FUN_600169a4();
          return 1;
        }
      }
    }
  }
  return 0;
}

