
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a764(void)

{
  int *piVar1;
  
  piVar1 = (int *)thunk_FUN_60161ab0(0xc,_DAT_6000a780);
  if (piVar1 != (int *)0x0) {
    *piVar1 = _DAT_6000a784 + 8;
    piVar1[1] = 1;
    piVar1[2] = 0;
  }
  return;
}

