
/* WARNING: Removing unreachable block (ram,0x60016d18) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60011468(int *param_1)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int *piVar4;
  
  piVar2 = _DAT_60011470;
  if (_DAT_60011470 == (int *)0x0) {
    return (int *)0x0;
  }
  if (param_1 == (int *)0x0) {
    return _DAT_60011470;
  }
  iVar1 = _DAT_60011470[2];
  if (iVar1 == 0) {
    iVar1 = FUN_60168494(0);
    piVar2[2] = iVar1;
    if (iVar1 == 0) goto code_r0x60016cf2;
  }
  FUN_6016825e(iVar1,0xffffffff);
code_r0x60016cf2:
  piVar4 = (int *)*piVar2;
  if (piVar4 != piVar2) {
    for (; piVar4 != piVar2; piVar4 = (int *)*piVar4) {
      if (((piVar4 + -2 == param_1) && (piVar4[2] != 0)) &&
         (iVar1 = FUN_60168418(piVar4[-2],*param_1), iVar1 == 0)) goto code_r0x60016d2e;
    }
  }
  piVar4 = param_1 + 2;
  param_1[3] = (int)piVar4;
  param_1[1] = (uint)*(byte *)(param_1 + 1);
  puVar3 = (undefined4 *)piVar2[1];
  *puVar3 = piVar4;
  param_1[2] = (int)piVar2;
  param_1[3] = (int)puVar3;
  piVar2[1] = (int)piVar4;
code_r0x60016d2e:
  iVar1 = piVar2[2];
  if (iVar1 == 0) {
    return (int *)0x0;
  }
  if (iVar1 != 0) {
    iVar1 = func_0x60165418(iVar1 + 4);
    piVar2 = (int *)0x0;
    if (iVar1 != 0) {
      piVar2 = (int *)0xfffffffd;
    }
    return piVar2;
  }
  return (int *)0xfffffffc;
}

