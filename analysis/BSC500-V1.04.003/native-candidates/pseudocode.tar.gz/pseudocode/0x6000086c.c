
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Instruction at (ram,0x60168084) overlaps instruction at (ram,0x60168082)
    */
/* WARNING: Removing unreachable block (ram,0x6016813c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_6000086c(void)

{
  bool bVar1;
  bool bVar2;
  byte bVar3;
  byte *pbVar4;
  uint uVar5;
  undefined1 uVar6;
  undefined4 *puVar7;
  int iVar8;
  int iVar9;
  int extraout_r1;
  undefined4 extraout_r2;
  int extraout_r2_00;
  int extraout_r3;
  int unaff_r4;
  int iVar10;
  int unaff_r5;
  uint unaff_r6;
  undefined4 uVar11;
  undefined4 *unaff_r7;
  undefined4 unaff_r8;
  char *unaff_r9;
  undefined1 *puVar12;
  undefined1 *puVar13;
  undefined8 in_d24;
  undefined8 uVar14;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  int iStack_18;
  undefined4 uStack_14;
  
  uVar14 = FUN_60167f4a(0x6000089c,uRam600008a4,0,0x1000);
  iVar10 = (int)uVar14;
  if (iVar10 == 0) {
    uVar11 = FUN_6016804c(0x600008a8,0x600008b8,0x153);
    *(int *)(unaff_r5 + 0x14) = unaff_r5;
    iVar10 = *(int *)(unaff_r5 + 100);
    uStack_1c = unaff_r6 >> 0xc;
    *(undefined4 *)uVar11 = uVar11;
    *(undefined2 *)(*(int *)(unaff_r6 + 0x14) + 100) = 100;
    *(char *)(iVar10 + unaff_r5 + -0x21) = (char)unaff_r6;
    *(char *)(unaff_r6 + 0x11) = (char)extraout_r2;
    *(undefined4 **)(uStack_1c + 0x14) = unaff_r7;
    *(undefined1 *)(unaff_r6 + 1) = 100;
    *(uint *)(*(int *)(unaff_r5 + -0xd) + 0x14) = uStack_1c;
    pbVar4 = _DAT_600008fc;
    iStack_18 = *(int *)(unaff_r5 + -0xd) << 1;
    uStack_14 = 0x6000089b;
    puVar7 = (undefined4 *)(uint)*_DAT_600008fc;
    if ((puVar7 == (undefined4 *)0x0) &&
       (uStack_20 = extraout_r2, puVar7 = (undefined4 *)FUN_60000abc((int)&uStack_1c + 3,&uStack_20)
       , puVar7 == (undefined4 *)0x0)) {
      if ((byte)(uStack_1c._3_1_ - 1U) < 3) {
        *pbVar4 = uStack_1c._3_1_ + 1;
      }
      puVar7 = _DAT_60000900;
      *_DAT_60000900 = uStack_20;
      return puVar7;
    }
    return puVar7;
  }
  puVar12 = &stack0xfffffff8;
  if (iVar10 == 0) {
    FUN_6016804c(uRam60168048,uRam6016803c,0x10f,0x14);
LAB_60167fec:
    FUN_6016804c(0x60168004,uRam6016803c,0x110);
  }
  else {
    unaff_r4 = iVar10;
    if ((*(byte *)(iVar10 + 0x3c) & 0xf) != 0) goto LAB_60167fec;
    iVar8 = FUN_601631fc(iVar10,(int)((ulonglong)uVar14 >> 0x20),0xf);
    if (iVar8 == 1) {
      *(undefined1 *)(iVar10 + 0x3c) = 2;
      bVar3 = *(byte *)(iVar10 + 0x3e);
      *(byte *)(iVar10 + 0x3d) = bVar3;
      *(byte *)(iVar10 + 0x3f) = bVar3 >> 3;
      *(char *)(iVar10 + 0x40) = (char)(1 << (bVar3 & 7));
      *(int *)(iVar10 + 0x44) = 1 << (uint)(bVar3 >> 3);
      FUN_60165744(iVar10);
      if (*piRam60168044 != 0) {
        func_0x60163a08();
      }
      return (undefined4 *)0x0;
    }
  }
  uVar6 = FUN_6016804c(uRam60168040,uRam6016803c,0x111);
  *(undefined1 *)(unaff_r5 + 0x10) = uVar6;
  *(undefined1 *)(unaff_r5 + 9) = uVar6;
  *(int *)(unaff_r4 + 0x14) = unaff_r5;
  *(char *)(unaff_r7 + 3) = (char)unaff_r6;
  *(int *)(unaff_r6 + 0x14) = unaff_r4;
  *(char *)(extraout_r2_00 + extraout_r1) = (char)extraout_r2_00;
  *(char *)(extraout_r3 + extraout_r1) = (char)unaff_r7;
  *(undefined2 *)(extraout_r1 * 2) = 0x26;
  *(char *)(extraout_r2_00 + extraout_r1) = (char)extraout_r3;
  *(char *)(extraout_r1 + 0x26) = (char)extraout_r1;
  uVar5 = _DAT_601681a0;
  *(short *)(_DAT_601681a0 + 0x26) = (short)extraout_r1;
  *(char *)(extraout_r2_00 + extraout_r1) = (char)extraout_r2_00;
  *(char *)(extraout_r3 + extraout_r1) = (char)unaff_r7;
  *(undefined2 *)(extraout_r1 * 2) = 0x3d;
  uVar11 = uRam6016815c;
  bVar1 = 0xffffffc2 < uVar5 - 0x20;
  bVar2 = CARRY4(uVar5 + 0x1d,(uint)(0x1f < uVar5));
  iVar8 = uVar5 + 0x1d + (uint)(0x1f < uVar5);
  iVar10 = (int)*(short *)(iVar8 + 0x3d);
  *(char *)(extraout_r1 * 2) = (char)extraout_r1;
  iVar9 = 0x3d;
  if (bVar1 || bVar2) {
    *unaff_r7 = uVar11;
    if (bVar1 || bVar2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *unaff_r7 = uVar11;
    *unaff_r7 = uVar11;
    puVar12 = &stack0xfffffff0;
    uVar11 = 0;
    FUN_60004a70(0);
    unaff_r8 = FUN_60167d0c();
    unaff_r9 = _DAT_601680c8;
    if (*_DAT_601680c8 == '\x01') {
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    iVar9 = *(int *)(_DAT_601680c8 + 4);
    *_DAT_601680c8 = '\x01';
    iVar10 = extraout_r2_00;
    iVar8 = extraout_r1;
    puVar13 = &stack0xfffffff0;
    if (iVar9 == 0) goto LAB_6016808e;
    func_0x60166fac(iVar9);
  }
  else {
    VectorShiftLeft(in_d24,3,0x10,1);
  }
  func_0x60166e68(iVar9,0x43);
  puVar13 = puVar12;
LAB_6016808e:
  FUN_6013dd48();
  func_0x60168578(&UNK_601680cc,iVar8,iVar10,uVar11);
  func_0x60168578(&UNK_60168104,unaff_r8);
  FUN_60130f7c();
  if (*(code **)(unaff_r9 + 0xc) != (code *)0x0) {
    (**(code **)(unaff_r9 + 0xc))(uVar11,iVar8,iVar10);
  }
  FUN_60167e94();
  do {
  } while (puVar13[7] == '\0');
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

