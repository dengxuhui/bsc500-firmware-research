
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6000af68(void)

{
  return (*(uint *)(_DAT_6000af80 + 0x14) & 0x1ff) >> 8;
}

