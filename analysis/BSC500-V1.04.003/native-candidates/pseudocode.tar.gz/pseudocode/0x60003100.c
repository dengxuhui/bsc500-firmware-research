
/* WARNING: Possible PIC construction at 0x600031ec: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60003424: Changing call to branch */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60003100(undefined4 param_1,int param_2,int param_3,uint param_4,uint param_5)

{
  code *UNRECOVERED_JUMPTABLE;
  int iVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint unaff_r4;
  uint uVar9;
  uint uVar10;
  int unaff_r5;
  uint uVar11;
  byte bVar12;
  uint unaff_r6;
  uint uVar13;
  uint uVar14;
  undefined4 unaff_lr;
  ulonglong in_d0;
  uint uVar15;
  ulonglong uVar16;
  undefined8 uVar17;
  ulonglong uVar18;
  ulonglong uVar19;
  longlong lVar20;
  longlong lVar21;
  longlong lVar22;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  int iStack_38;
  uint uStack_34;
  uint uStack_30;
  uint uStack_2c;
  int iStack_28;
  
  uStack_30 = param_2 + 1;
  if (param_2 == 0) {
    uStack_30 = 7;
  }
  iStack_28 = param_3;
  iVar1 = FUN_60167bb6();
  uStack_2c = param_5;
  if ((iVar1 == 0) && (iVar1 = FUN_60167ba8(), iVar1 == 0)) {
    uVar16 = FUN_601682c8();
    uVar9 = 1;
  }
  else {
    iVar1 = FUN_60167b9a();
    uStack_34 = param_4;
    iVar2 = FUN_60167bc4();
    param_4 = uStack_34;
    uVar9 = (uint)(iVar1 != 0 && iVar2 != 0);
    uVar16 = FUN_601682c8();
    if (uVar9 == 0) {
      uVar16 = in_d0;
    }
  }
  uVar15 = (uint)(uVar16 >> 0x20);
  uVar7 = (uint)uVar16;
  uVar3 = (uVar15 & 0x7fffffff) >> 0x14;
  if (uVar3 == 0x7ff) {
    if ((iStack_28 != 0) && ((param_4 & 1) == 0)) {
      uVar6 = 0;
      uVar3 = iStack_28 + ((int)(param_4 << 0x1d | uVar15) >> 0x1f) + 0xfdU & 0xff;
      unaff_lr = 0x600031f1;
      unaff_r4 = uVar9;
      unaff_r5 = (int)in_d0;
      unaff_r6 = uVar7;
      register0x00000054 = (BADSPACEBASE *)&uStack_40;
      goto SUB_600ff010;
    }
    if ((longlong)uVar16 < 0) {
      uVar4 = 0x2d;
    }
    else {
      if (-1 < (int)(param_4 << 0x1d)) goto LAB_6000336e;
      uVar4 = 0x2b;
    }
    FUN_60116830(param_1,uVar4);
LAB_6000336e:
    UNRECOVERED_JUMPTABLE = _DAT_600034e0;
    if (uVar7 == 0 && (uVar16 & 0xfffff00000000) == 0) {
      if (uStack_2c == 0) {
        (*_DAT_600034e0)(param_1,0x69);
        (*UNRECOVERED_JUMPTABLE)(param_1,0x6e);
        uVar4 = 0x66;
      }
      else {
        (*_DAT_600034e0)(param_1,0x49);
        (*UNRECOVERED_JUMPTABLE)(param_1,0x4e);
        uVar4 = 0x46;
      }
    }
    else if (uStack_2c == 0) {
      (*_DAT_600034e0)(param_1,0x6e);
      (*UNRECOVERED_JUMPTABLE)(param_1,0x61);
      uVar4 = 0x6e;
    }
    else {
      (*_DAT_600034e0)(param_1,0x4e);
      (*UNRECOVERED_JUMPTABLE)(param_1,0x41);
      uVar4 = 0x4e;
    }
                    /* WARNING: Could not recover jumptable at 0x60003450. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (*UNRECOVERED_JUMPTABLE)(param_1,uVar4);
    return;
  }
  uVar14 = 0x33 - (uVar15 >> 0x14);
  uVar6 = 0;
  uVar5 = 0;
  if ((uVar7 != 0 || (uVar16 & 0xfffff00000000) != 0) || uVar3 != 0) {
    uVar6 = (uVar15 & 0xfffff) + 0x100000;
    uVar5 = uVar7;
  }
  uVar3 = uVar14 & 0xff;
  if (0x40 < uVar3) {
    return;
  }
  uStack_34 = uVar9;
  uVar17 = FUN_60158804(uVar5,uVar6,uVar3);
  iStack_38 = (int)((ulonglong)uVar17 >> 0x20);
  uStack_2c = (uint)uVar17;
  uVar17 = FUN_60158128(uStack_2c,iStack_38,uVar3);
  uVar6 = uVar6 & ~(uint)((ulonglong)uVar17 >> 0x20);
  iVar1 = 0;
  for (uVar5 = uVar5 & ~(uint)uVar17; (uVar5 != 0 || uVar6 != 0 && ((uVar5 & 1) == 0));
      uVar5 = (uint)(uVar9 != 0) << 0x1f | uVar5 >> 1) {
    uVar9 = uVar6 & 1;
    uVar6 = uVar6 >> 1;
    iVar1 = iVar1 + 1;
  }
  uVar3 = 0;
  uVar9 = 1;
  for (bVar12 = 0; (uint)bVar12 < (uStack_30 & 0xff); bVar12 = bVar12 + 1) {
    uVar18 = (ulonglong)uVar9;
    uVar9 = (uint)(uVar18 * 10);
    uVar3 = (int)(uVar18 * 10 >> 0x20) + uVar3 * 10;
  }
  uVar11 = (uint)((ulonglong)uVar3 * (ulonglong)uVar6);
  uVar13 = (uint)((ulonglong)uVar9 * (ulonglong)uVar5 >> 0x20);
  lVar21 = CONCAT44(uVar11,uVar13);
  lVar22 = (ulonglong)uVar9 * (ulonglong)uVar6;
  uVar7 = (uint)((ulonglong)lVar22 >> 0x20);
  lVar20 = lVar22 + lVar21;
  uVar8 = (uint)((ulonglong)lVar20 >> 0x20);
  lVar21 = (ulonglong)uVar3 * (ulonglong)uVar5 + lVar22 + lVar21;
  uVar10 = (uint)((ulonglong)uVar3 * (ulonglong)uVar5 >> 0x20);
  uVar14 = uVar14 - iVar1 & 0xff;
  uStack_3c = param_1;
  uVar18 = FUN_60158128((int)((ulonglong)lVar21 >> 0x20),
                        (int)((ulonglong)uVar3 * (ulonglong)uVar6 >> 0x20) +
                        (uint)(CARRY4(uVar7,uVar11) ||
                              CARRY4(uVar7 + uVar11,(uint)CARRY4(uVar13,(uint)lVar22))) +
                        (uint)(CARRY4(uVar8,uVar10) ||
                              CARRY4(uVar8 + uVar10,
                                     (uint)CARRY4((uint)((ulonglong)uVar3 * (ulonglong)uVar5),
                                                  (uint)lVar20))),0x40 - uVar14);
  uVar19 = FUN_60158804((int)((ulonglong)uVar9 * (ulonglong)uVar5),(int)lVar21,uVar14);
  uVar18 = uVar18 | uVar19;
  lVar20 = FUN_60162a88((int)uVar18,(int)(uVar18 >> 0x20),10,0);
  param_1 = uStack_3c;
  lVar21 = lVar20 + 1;
  lVar22 = uVar18 + lVar20 * -10;
  if ((uint)-(int)((ulonglong)lVar22 >> 0x20) < (uint)((uint)lVar22 < 5)) {
    lVar21 = lVar20;
  }
  iVar1 = iStack_38;
  if (((uStack_2c == 1 && iStack_38 == 0) & uStack_34) != 0) {
    iVar1 = 0;
    uStack_2c = 0;
  }
  uVar9 = uStack_30 - 1;
  if (10 < (uStack_30 - 1 & 0xff)) {
    uVar9 = uStack_30 - 0xb;
    while( true ) {
      if ((uVar9 & 0xff) == 0) break;
      lVar21 = FUN_60162a88((int)lVar21,(int)((ulonglong)lVar21 >> 0x20),10,0);
      uVar9 = uVar9 - 1;
    }
    uStack_30 = 10;
    uVar9 = uStack_30;
  }
  uStack_30 = uVar9;
  uVar9 = uStack_2c;
  lVar22 = CONCAT44(iVar1,uStack_2c);
  iVar2 = (int)lVar21;
  uVar7 = 0;
  while( true ) {
    uVar6 = uStack_30;
    if (lVar22 == 0) break;
    lVar22 = FUN_60162a88((int)lVar22,(int)((ulonglong)lVar22 >> 0x20),10,0);
    uVar7 = uVar7 + 1;
  }
  if ((iVar2 == 0 && uVar9 == 0) && ((int)((ulonglong)lVar21 >> 0x20) == 0 && iVar1 == 0)) {
    uVar7 = 1;
  }
  if ((uVar7 & 0xff) == 0) {
    uVar7 = 1;
  }
  if (((iStack_28 != 0) && ((param_4 & 1) == 0)) &&
     (uVar3 = ((~((param_4 << 0x1d | uVar15) >> 0x1f) + iStack_28) - (uStack_30 & 0xff)) -
              (uVar7 & 0xff), 0 < (int)uVar3)) {
    uVar6 = (param_4 & 3) >> 1;
    uVar3 = uVar3 & 0xff;
    unaff_lr = 0x60003429;
    unaff_r4 = uVar9;
    unaff_r5 = iVar2;
    unaff_r6 = uVar7;
    register0x00000054 = (BADSPACEBASE *)&uStack_40;
    goto SUB_600ff010;
  }
  if ((longlong)uVar16 < 0) {
    uVar4 = 0x2d;
LAB_60003462:
    FUN_60116830(param_1,uVar4);
  }
  else if ((int)(param_4 << 0x1d) < 0) {
    uVar4 = 0x2b;
    goto LAB_60003462;
  }
  uStack_40 = 0;
  FUN_6011140c(param_1,uStack_2c,0,0);
  FUN_60116830(param_1,0x2e);
  uStack_40 = 0;
  FUN_6011140c(param_1,iVar2,uVar6 & 0xff,0);
  if ((((param_4 & 1) == 0) || (iStack_28 == 0)) ||
     (uVar3 = ((~((param_4 << 0x1d | uVar15) >> 0x1f) + iStack_28) - (uVar6 & 0xff)) -
              (uVar7 & 0xff), (int)uVar3 < 1)) {
    return;
  }
  uVar3 = uVar3 & 0xff;
  uVar6 = 0;
SUB_600ff010:
  *(undefined4 *)((int)register0x00000054 + -4) = unaff_lr;
  *(uint *)((int)register0x00000054 + -8) = unaff_r6;
  *(int *)((int)register0x00000054 + -0xc) = unaff_r5;
  *(uint *)((int)register0x00000054 + -0x10) = unaff_r4;
  uVar4 = 0x20;
  if (uVar6 != 0) {
    uVar4 = 0x30;
  }
  for (; (uVar3 & 0xff) != 0; uVar3 = uVar3 - 1) {
    FUN_60116830(param_1,uVar4);
  }
  return;
}

