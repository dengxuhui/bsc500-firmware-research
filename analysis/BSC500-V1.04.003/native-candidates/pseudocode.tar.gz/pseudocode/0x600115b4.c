
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600115b4(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  undefined4 uStack_14;
  
  iVar1 = _DAT_600116f0;
  iVar2 = _DAT_60011650;
  uStack_14 = param_4 & 0xffff;
  if (param_1 == 0) {
    uVar5 = (uint)*(ushort *)(_DAT_600116f0 + 0x18);
    if (uVar5 == 0) {
      if (*(char *)(_DAT_600116f0 + 10) == '\0') {
        if (*(char *)(_DAT_600116f0 + 2) == '\0') {
          uVar5 = 0x14;
          *(undefined2 *)(_DAT_600116f0 + 0x18) = 0x14;
        }
        else {
          uVar5 = 0;
          iVar4 = _DAT_600116f0 + 0x46;
          *(undefined1 *)(_DAT_600116f0 + 2) = 0;
          CopyBytes(iVar2,iVar4,0x14,param_4,param_3);
        }
        *(short *)(iVar1 + 0x12) = *(short *)(iVar1 + 0x12) + 0x14;
        *(undefined1 *)(iVar1 + 10) = 1;
      }
      else {
        uVar5 = 0;
      }
    }
    if (uVar5 < *(ushort *)(iVar1 + 0x12)) {
      uVar3 = *(ushort *)(iVar1 + 0x12) - uVar5;
      if ((int)(uint)*_DAT_600116f8 < (int)uVar3) {
        uVar3 = (uint)*_DAT_600116f8;
      }
      uStack_14 = CONCAT22((short)uVar3,(undefined2)uStack_14);
      iVar2 = FUN_6012ea18(_DAT_60011650 + uVar5,(int)&uStack_14 + 2,0x6e);
      if (iVar2 == 0) {
        uVar5 = (uint)*(ushort *)(iVar1 + 0x18) + (uStack_14 >> 0x10);
        *(short *)(iVar1 + 0x18) = (short)uVar5;
      }
      else {
        uVar5 = (uint)*(ushort *)(iVar1 + 0x18);
      }
    }
    uVar3 = (uint)*(ushort *)(iVar1 + 0x12);
    if ((uVar5 & 0xffff) < uVar3) {
      return;
    }
    *(undefined1 *)(iVar1 + 10) = 0;
    *(undefined2 *)(iVar1 + 0x18) = 0;
    *(undefined1 *)(iVar1 + 7) = 0;
  }
  else {
    *(undefined1 *)(_DAT_600116f0 + 10) = 0;
    *(undefined2 *)(iVar1 + 0x18) = 0;
    *(undefined1 *)(iVar1 + 7) = 0;
    uVar3 = (uint)*(ushort *)(iVar1 + 0x12);
  }
  ZeroBytes(_DAT_60011650,uVar3);
  *(undefined2 *)(_DAT_600116f0 + 0x12) = 0;
  return;
}

