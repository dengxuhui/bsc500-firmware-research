
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d5ec(void)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  uint uVar4;
  undefined2 uStack_2e;
  undefined1 auStack_2c [20];
  
  uVar1 = _DAT_6000d64c;
  uVar4 = 0;
  while( true ) {
    iVar2 = FUN_6013f31e(uVar1);
    if (3 < uVar4) {
      return;
    }
    if (iVar2 != 0) break;
    ZeroBytes(auStack_2c,0x14);
    iVar2 = FUN_60161fcc(uVar1,auStack_2c,0);
    if (iVar2 == 0) {
      uStack_2e = 0x14;
      uVar3 = FUN_600563c8(auStack_2c);
      iVar2 = FUN_6012ea18(auStack_2c,&uStack_2e,uVar3);
      if (iVar2 != 0) {
        FUN_6015e16c(_DAT_6000d64c,auStack_2c);
        return;
      }
      uVar4 = uVar4 + 1;
    }
  }
  return;
}

