
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600142a8(int param_1)

{
  int iVar1;
  char *pcVar2;
  undefined4 uVar3;
  uint uVar4;
  uint uVar5;
  undefined2 auStack_44 [8];
  byte bStack_34;
  undefined2 uStack_32;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  byte bStack_28;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  byte bStack_18;
  
  pcVar2 = _DAT_600143c0;
  iVar1 = _DAT_600143a8;
  uVar3 = 0xffffffff;
  if (param_1 != 0) {
    if (*_DAT_600143c0 == '\x01') {
      FUN_60133e3a(_DAT_600143a8);
      FUN_60133efe(iVar1 + 0x40);
      FUN_60133e20(iVar1 + 0x88);
      uStack_20 = 0;
      uStack_1c = 0;
      bStack_18 = *(byte *)(param_1 + 0x72);
      uVar5 = (uint)bStack_18;
      for (uVar4 = 0; uVar5 != uVar4; uVar4 = uVar4 + 1) {
        *(undefined1 *)((int)&uStack_20 + uVar4) = *(undefined1 *)(*(int *)(param_1 + 0x6c) + uVar4)
        ;
      }
      FUN_60133f20(iVar1 + 0xa0,&uStack_20);
      FUN_60133f88(iVar1 + 0xe0);
      FUN_60133f90(iVar1 + 0xe4);
      uStack_30 = 0;
      uStack_2c = 0;
      bStack_28 = *(byte *)(param_1 + 0x71);
      uVar5 = (uint)bStack_28;
      for (uVar4 = 0; uVar5 != uVar4; uVar4 = uVar4 + 1) {
        *(undefined1 *)((int)&uStack_30 + uVar4) = *(undefined1 *)(*(int *)(param_1 + 0x68) + uVar4)
        ;
      }
      FUN_60133fa0(iVar1 + 0x104,&uStack_30);
      FUN_60133e5c(iVar1 + 0x140);
      ZeroBytes(auStack_44,0x14);
      bStack_34 = *(byte *)(param_1 + 0x70);
      uVar4 = (uint)bStack_34;
      for (uVar5 = 0; uVar4 != uVar5; uVar5 = uVar5 + 1) {
        auStack_44[uVar5] = *(undefined2 *)(*(int *)(param_1 + 100) + uVar5 * 2);
      }
      uStack_32 = *(undefined2 *)(param_1 + 0x1e);
      FUN_60134004(iVar1 + 0x170,auStack_44);
      FUN_601340a4(iVar1 + 0x1d8);
      FUN_601340ac(iVar1 + 0x1dc);
      FUN_60133e98(iVar1 + 500);
      FUN_60133ea8(iVar1 + 0x200);
      FUN_601340c6(iVar1 + 0x220);
      *pcVar2 = '\x02';
      uVar3 = 0;
    }
  }
  return uVar3;
}

