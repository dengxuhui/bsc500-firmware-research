
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600035a4(void)

{
  *_DAT_600035ac = 1;
  return;
}

