
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600008cc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  int iVar2;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  pcVar1 = _DAT_600008fc;
  if ((*_DAT_600008fc == '\0') &&
     (uStack_10 = param_3, uStack_c = param_4, iVar2 = FUN_60000abc((int)&uStack_c + 3,&uStack_10),
     iVar2 == 0)) {
    if ((byte)(uStack_c._3_1_ - 1U) < 3) {
      *pcVar1 = uStack_c._3_1_ + '\x01';
    }
    *_DAT_60000900 = uStack_10;
    return;
  }
  return;
}

