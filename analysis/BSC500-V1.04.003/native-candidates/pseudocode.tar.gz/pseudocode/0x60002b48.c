
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60002b48(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 uVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined *puVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  piVar2 = _DAT_60002be4;
  iVar4 = *_DAT_60002be4;
  uStack_28 = param_1;
  uStack_24 = param_2;
  uStack_20 = param_3;
  uStack_1c = param_4;
  if (iVar4 == 0) {
    uStack_1c = 0;
    uStack_24 = 0;
    uStack_20 = 0;
    uStack_28 = _DAT_60002be8;
    iVar4 = FUN_60168494(&uStack_28);
    *piVar2 = iVar4;
  }
  FUN_6016825e(iVar4,0xffffffff);
  puVar3 = _DAT_60002bec;
  FUN_60167214((int)_DAT_60002bec + 0x19,0x4b);
  uVar6 = _DAT_60002bf0[1];
  uVar7 = _DAT_60002bf0[2];
  uVar9 = _DAT_60002bf0[3];
  uVar10 = _DAT_60002bf0[4];
  uVar8 = _DAT_60002bf0[5];
  uVar1 = *(undefined1 *)(_DAT_60002bf0 + 6);
  *puVar3 = *_DAT_60002bf0;
  puVar3[1] = uVar6;
  puVar3[2] = uVar7;
  puVar3[3] = uVar9;
  puVar3[4] = uVar10;
  *(undefined1 *)(puVar3 + 6) = uVar1;
  puVar3[5] = uVar8;
  iVar4 = FUN_60166758(piVar2 + 1,puVar3,3);
  if (iVar4 == 0) {
    func_0x60168578(&UNK_60002c18,_DAT_60002bec);
    iVar4 = FUN_601667bc(piVar2[1]);
    puVar5 = _DAT_60002c34;
    if (iVar4 == 0) {
      if (*piVar2 != 0) {
        func_0x601682ae();
      }
      FUN_60004fe0();
      return 1;
    }
  }
  else {
    puVar5 = &UNK_60002bf4;
  }
  func_0x60168578(puVar5,_DAT_60002bec);
  if (*piVar2 != 0) {
    func_0x601682ae();
  }
  return 0;
}

