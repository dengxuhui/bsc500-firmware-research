
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60018098(void)

{
  int iVar1;
  
  if (*(char *)(_DAT_600182ec + 0x30) == '\x04') {
    iVar1 = _DAT_6001f8d8 + 0x18;
    FUN_6015d1e4(_DAT_6001f8d4 + 0x18,iVar1);
    return iVar1;
  }
  return 0;
}

