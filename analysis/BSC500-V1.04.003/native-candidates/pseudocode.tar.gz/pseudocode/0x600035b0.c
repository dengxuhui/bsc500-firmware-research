
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_600035b0(void)

{
  return *(undefined1 *)(_DAT_600035b8 + 1);
}

