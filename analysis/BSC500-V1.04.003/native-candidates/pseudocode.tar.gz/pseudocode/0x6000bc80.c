
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000bc80(void)

{
  return _DAT_6000bc84;
}

