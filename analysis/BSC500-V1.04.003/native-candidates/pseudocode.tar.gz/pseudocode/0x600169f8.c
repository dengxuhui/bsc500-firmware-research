
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600169f8(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_60162e34(0x1000);
  *_DAT_60016a14 = uVar1;
  (*(code *)0x219ea)(uVar1,0,0x1000);
  return;
}

