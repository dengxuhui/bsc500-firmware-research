
undefined4 FUN_60006eb4(void)

{
  return 1;
}

