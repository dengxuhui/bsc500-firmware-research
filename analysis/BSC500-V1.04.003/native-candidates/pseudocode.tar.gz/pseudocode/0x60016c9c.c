
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int thunk_FUN_6001be18(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  
  FUN_60139d78(1,param_1,param_2);
  if (*(int *)(_DAT_6015de88 + 4) == 0) {
    return _DAT_6015de88;
  }
  if (*(int *)(_DAT_6015de88 + 8) != 0) {
    iVar1 = func_0x60166af4(*(int *)(_DAT_6015de88 + 8) + 4);
    iVar2 = 0;
    if (iVar1 != 0) {
      iVar2 = -1;
    }
    return iVar2;
  }
  return -4;
}

