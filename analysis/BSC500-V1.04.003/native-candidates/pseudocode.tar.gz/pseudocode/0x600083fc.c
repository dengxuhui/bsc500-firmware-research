
/* WARNING: Possible PIC construction at 0x60008446: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60008470: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x60008474) */
/* WARNING: Removing unreachable block (ram,0x60167194) */
/* WARNING: Removing unreachable block (ram,0x601671ba) */
/* WARNING: Removing unreachable block (ram,0x601671bc) */
/* WARNING: Removing unreachable block (ram,0x601671be) */
/* WARNING: Removing unreachable block (ram,0x601671c0) */
/* WARNING: Removing unreachable block (ram,0x601671c4) */
/* WARNING: Removing unreachable block (ram,0x6004016c) */
/* WARNING: Removing unreachable block (ram,0x60045fa0) */
/* WARNING: Removing unreachable block (ram,0x60045fb4) */
/* WARNING: Removing unreachable block (ram,0x60045fb6) */
/* WARNING: Removing unreachable block (ram,0x60045fdc) */
/* WARNING: Removing unreachable block (ram,0x60045fea) */
/* WARNING: Removing unreachable block (ram,0x6004601a) */
/* WARNING: Removing unreachable block (ram,0x6004601e) */
/* WARNING: Removing unreachable block (ram,0x60046024) */
/* WARNING: Removing unreachable block (ram,0x60046026) */
/* WARNING: Removing unreachable block (ram,0x6004602a) */
/* WARNING: Removing unreachable block (ram,0x60045ffe) */
/* WARNING: Removing unreachable block (ram,0x60046014) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600083fc(void)

{
  ushort uVar1;
  undefined2 uVar2;
  char *pcVar3;
  int iVar4;
  int iVar5;
  undefined *puVar6;
  undefined4 extraout_r2;
  undefined4 extraout_r2_00;
  undefined4 uVar7;
  int extraout_r3;
  int extraout_r3_00;
  uint unaff_r4;
  uint uVar8;
  uint uVar9;
  undefined1 *unaff_r5;
  char *unaff_r6;
  undefined4 unaff_r7;
  undefined4 unaff_r8;
  undefined4 unaff_lr;
  int *piVar10;
  undefined1 auStack_50 [64];
  
  pcVar3 = _DAT_600084a0;
  if (-1 < (int)((uint)(byte)_DAT_600084a0[0x14] << 0x1c)) {
    return;
  }
  uVar8 = *(uint *)(_DAT_600084a4 + 4);
  iVar5 = FUN_6011f77c();
  if (iVar5 == 0) {
    uVar7 = extraout_r2;
    iVar5 = extraout_r3;
    if (*pcVar3 == '\0') {
      *(uint *)(pcVar3 + 0x18) = uVar8;
      *pcVar3 = '\x01';
      puVar6 = &UNK_600084a8;
      uVar9 = uVar8;
    }
    else {
      if (uVar8 - *(int *)(pcVar3 + 0x18) < _DAT_600084d4) {
        return;
      }
      unaff_lr = 0x60008475;
      puVar6 = &UNK_600084d8;
      uVar9 = (uVar8 - *(int *)(pcVar3 + 0x18)) / 1000;
      unaff_r4 = uVar8;
      unaff_r6 = pcVar3;
      register0x00000054 = (BADSPACEBASE *)auStack_50;
    }
  }
  else {
    if (*pcVar3 != '\x01' || *(int *)(pcVar3 + 0x18) == 0) {
      pcVar3[0x18] = '\0';
      pcVar3[0x19] = '\0';
      pcVar3[0x1a] = '\0';
      pcVar3[0x1b] = '\0';
      *pcVar3 = '\0';
      FUN_601488a0(0);
      return;
    }
    uVar9 = (uVar8 - *(int *)(pcVar3 + 0x18)) / 1000;
    func_0x60164dec(auStack_50,0x40,&UNK_60008500,uVar9);
    FUN_60118b7c(auStack_50);
    unaff_lr = 0x6000844b;
    puVar6 = &UNK_60008518;
    uVar7 = extraout_r2_00;
    iVar5 = extraout_r3_00;
    unaff_r4 = uVar9;
    unaff_r5 = auStack_50;
    unaff_r6 = pcVar3;
    register0x00000054 = (BADSPACEBASE *)auStack_50;
  }
  iVar4 = _DAT_60168628;
  *(undefined4 *)((int)register0x00000054 + -0x10) = unaff_lr;
  *(undefined4 *)((int)register0x00000054 + -0x14) = unaff_r8;
  *(undefined4 *)((int)register0x00000054 + -0x18) = unaff_r7;
  *(char **)((int)register0x00000054 + -0x1c) = unaff_r6;
  *(undefined1 **)((int)register0x00000054 + -0x20) = unaff_r5;
  *(uint *)((int)register0x00000054 + -0x24) = unaff_r4;
  piVar10 = (int *)((int)register0x00000054 + -0x28);
  *piVar10 = iVar5;
  *(uint *)((int)register0x00000054 + -0xc) = uVar9;
  *(undefined4 *)((int)register0x00000054 + -8) = uVar7;
  *(int *)((int)register0x00000054 + -4) = iVar5;
  if (*(int *)(_DAT_60168628 + 8) == 0) {
    *piVar10 = (int)((int)register0x00000054 + -0xc);
    if (*(int *)(_DAT_60168628 + 4) == 0) {
      uVar8 = FUN_6012ef90(_DAT_6016862c,0xff,puVar6,*piVar10);
      iVar5 = *(int *)(iVar4 + 4);
      if (iVar5 == 0) {
        FUN_60154ab4(_DAT_6016862c);
      }
      else {
        uVar1 = *(ushort *)(iVar5 + 0x20);
        *(ushort *)(iVar5 + 0x20) = uVar1 | 0x40;
        uVar9 = 0xff;
        if (uVar8 < 0xff) {
          uVar9 = uVar8;
        }
        FUN_6015ef88(iVar5,0,_DAT_6016862c,uVar9);
        *(ushort *)(*(int *)(iVar4 + 4) + 0x20) = uVar1;
      }
    }
    else {
      uVar2 = *(undefined2 *)(*(int *)(_DAT_60168628 + 4) + 0x20);
      iVar5 = FUN_6001a8b4();
      if ((iVar5 == 0) || (iVar5 = FUN_6015b3f4(), iVar5 != 0)) {
        uVar7 = _DAT_6016862c;
        uVar9 = FUN_6012ef90(_DAT_6016862c,0xff,puVar6,*piVar10);
        iVar5 = *(int *)(iVar4 + 4);
        *(ushort *)(iVar5 + 0x20) = (*(ushort *)(iVar5 + 0x20) & 0xf7bf) + 0x40;
        uVar8 = 0xff;
        if (uVar9 < 0xff) {
          uVar8 = uVar9;
        }
        FUN_6015ef88(iVar5,0,uVar7,uVar8);
        *(undefined2 *)(*(int *)(iVar4 + 4) + 0x20) = uVar2;
      }
      else {
        FUN_6001a8bc(puVar6,*piVar10);
      }
    }
  }
  return;
}

