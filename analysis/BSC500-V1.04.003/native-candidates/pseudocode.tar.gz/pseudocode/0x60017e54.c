
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60017e54(void)

{
  int iVar1;
  
  iVar1 = _DAT_60017e68;
  if (*(int *)(_DAT_60017e68 + 0x48) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 0x48) = 0;
  }
  return;
}

