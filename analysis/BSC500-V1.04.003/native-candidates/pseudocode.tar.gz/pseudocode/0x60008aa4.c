
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_60008aa4(void)

{
  return *(undefined1 *)(_DAT_60008b7c + 1);
}

