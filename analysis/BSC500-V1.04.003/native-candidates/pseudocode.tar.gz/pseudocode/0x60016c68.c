
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016c68(void)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 uStack_24;
  int *piStack_20;
  undefined4 uStack_18;
  
  *(undefined2 *)(_DAT_60016c94 + 1) = 0;
  piVar1 = _DAT_6002352c;
  piVar2 = (int *)*_DAT_6002352c;
  if ((code *)piVar2[1] != (code *)0x0) {
    (*(code *)piVar2[1])();
    piVar2 = (int *)*piVar1;
  }
  (**(code **)(*piVar2 + 8))(&uStack_24,piVar2,0);
  if (piStack_20 == (int *)0x0) {
    cVar3 = '\r';
  }
  else {
    (**(code **)(*piStack_20 + 0x10))(piStack_20,0,1,5,uStack_24);
    (**(code **)(*piStack_20 + 0x20))(piStack_20,4);
    (**(code **)(*(int *)*piVar1 + 0xc))((int *)*piVar1,&uStack_24);
    (**(code **)(*piStack_20 + 0x70))(piStack_20,&uStack_18);
    cVar3 = (char)piStack_20[5];
  }
  (**(code **)(*(int *)*piVar1 + 0x10))((int *)*piVar1,&uStack_24);
  FUN_601675ca(*piVar1,cVar3,5);
  if (*(code **)(*piVar1 + 8) != (code *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  if (cVar3 != '\0') {
    uStack_18 = 0xffffffff;
  }
  return uStack_18;
}

