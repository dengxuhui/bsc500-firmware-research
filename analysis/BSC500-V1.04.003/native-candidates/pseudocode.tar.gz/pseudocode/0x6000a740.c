
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000a740(uint param_1)

{
  undefined4 uVar1;
  
  if (param_1 < 6) {
    *(char *)(_DAT_6000a760 + 0x2b) = (char)param_1;
    uVar1 = 0;
  }
  else {
    uVar1 = 5;
  }
  return uVar1;
}

