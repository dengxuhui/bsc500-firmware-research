
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_6000309e(undefined4 param_1)

{
  undefined4 uVar1;
  char *unaff_r6;
  uint uStack00000000;
  undefined4 uStack00000004;
  
  *(undefined4 *)(unaff_r6 + 0xc) = param_1;
  uStack00000000 = 0x18;
  uStack00000004 = 10;
  uVar1 = FUN_60167f4a(&UNK_600030f4,_DAT_600030fc,0,0x800);
  *(undefined4 *)(unaff_r6 + 0x10) = uVar1;
  FUN_60167f8c();
  while (*unaff_r6 == '\0') {
    FUN_60167188(5);
  }
  return (ulonglong)uStack00000000 << 0x20;
}

