
/* WARNING: Removing unreachable block (ram,0x60166dce) */
/* WARNING: Removing unreachable block (ram,0x60166dda) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

char * FUN_60011edc(char *param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  byte bVar2;
  char cVar3;
  int *piVar4;
  undefined4 *puVar5;
  int iVar6;
  char *pcVar7;
  undefined4 uVar8;
  short *psVar9;
  uint *puVar10;
  char *extraout_r1;
  char *pcVar11;
  short *psVar12;
  uint uVar13;
  undefined4 uVar14;
  char *pcVar15;
  int iVar16;
  uint uVar17;
  short *psVar18;
  uint uVar19;
  byte *pbVar20;
  undefined4 *puVar21;
  int *piVar22;
  int *piVar23;
  uint *puVar24;
  uint *puVar25;
  char cVar26;
  undefined8 uVar27;
  uint auStack_2c [6];
  
  if (param_1 == (char *)0x0) {
    return (char *)0x0;
  }
  puVar24 = auStack_2c + 5;
  if (param_1 == (char *)0x0) {
    return (char *)0x0;
  }
  auStack_2c[5] = param_4;
  puVar5 = (undefined4 *)FUN_60167d0c(param_1,1);
  iVar6 = FUN_60163aac();
  cVar26 = '\0';
  if (iVar6 == 0) {
    func_0x60167d14(puVar5);
    puVar21 = puRam60166d70;
    cVar26 = ((uint)param_1 & 3) == 0;
    if (!(bool)cVar26) goto LAB_60166d30;
    pcVar7 = (char *)puRam60166d70[3];
    pcVar11 = pcVar7;
    if ((pcVar7 <= param_1) && (pcVar11 = (char *)puRam60166d70[4], param_1 < pcVar11)) {
      if ((code *)puRam60166d70[1] != (code *)0x0) {
        (*(code *)puRam60166d70[1])(param_1);
        pcVar7 = (char *)puVar21[3];
        pcVar11 = (char *)puVar21[4];
      }
      if (param_1 < pcVar7) {
        return pcVar7;
      }
      if (pcVar11 <= param_1) {
        return pcVar7;
      }
      puVar5 = puVar21 + 0xb;
      func_0x601668f8(puVar5,0xffffffff);
      psVar18 = (short *)(param_1 + -0x18);
      if ((*(short *)(param_1 + -0x16) == 0) || (*psVar18 != 0x1ea0)) {
        func_0x60168578(0x60166d78);
        func_0x60168578(0x60166d94,psVar18,*(undefined2 *)(param_1 + -0x16),
                        *(undefined2 *)(param_1 + -0x18));
        cVar26 = '\x01';
        puVar25 = puVar24;
        if (*(short *)(param_1 + -0x16) == 0) goto LAB_60166d54;
      }
      cVar26 = *psVar18 == 0x1ea0;
      if (!(bool)cVar26) goto LAB_60166d3c;
      cVar26 = *(short *)(puVar21[3] + *(int *)(param_1 + -0x14)) == 0x1ea0;
      if (!(bool)cVar26) goto LAB_60166d48;
      param_1[-0xffffffff00000018] = -0x60;
      param_1[-0xffffffff00000017] = '\x1e';
      param_1[-0xffffffff00000016] = '\0';
      param_1[-0xffffffff00000015] = '\0';
      uVar8 = FUN_60127558();
      *(undefined4 *)(param_1 + -4) = uVar8;
      if (psVar18 < (short *)puVar21[5]) {
        puVar21[5] = psVar18;
      }
      if ((short *)puVar21[6] == psVar18) {
        psVar9 = (short *)puVar21[3];
        psVar12 = psVar18;
        while ((psVar9 != psVar12 && (psVar12[1] == 0))) {
          psVar12 = (short *)(*(int *)(psVar12 + 4) + (int)psVar9);
          puVar21[6] = psVar12;
        }
        if ((psVar12[1] == 0) && (psVar9 == psVar12)) {
          puVar21[6] = 0;
        }
      }
      else {
        psVar9 = (short *)puVar21[3];
      }
      uVar13 = puVar21[9];
      puVar21[7] = (int)psVar18 + puVar21[7] + (-(int)psVar9 - *(int *)(param_1 + -0x14));
      puVar10 = *(uint **)(param_1 + -0xc);
      goto SUB_60166af4;
    }
    cVar26 = pcVar11 == param_1;
    FUN_6016804c(uRam60166d74,uRam60166d64,0x2b2);
  }
  uVar8 = uRam60166d64;
  func_0x60168578(uRam60166d60,uRam60166d64);
  uVar14 = 0x2ae;
  iVar6 = iRam60166d68;
  while( true ) {
    FUN_6016804c(iVar6,uVar8,uVar14);
LAB_60166d30:
    FUN_6016804c(uRam60166d6c,uRam60166d64,0x2b0);
LAB_60166d3c:
    FUN_6016804c(uRam60166dc4,uRam60166d64,0x2d1);
LAB_60166d48:
    FUN_6016804c(uRam60166dc8,uRam60166d64,0x2d3);
    puVar25 = puVar24;
LAB_60166d54:
    uVar27 = FUN_6016804c(uRam60166dcc,uRam60166d64,0x2d0);
    iVar6 = (int)((ulonglong)uVar27 >> 0x20);
    puVar10 = (uint *)uVar27;
    uVar13 = *puVar25;
    uVar19 = puVar25[1];
    psVar18 = (short *)puVar25[2];
    puVar21 = (undefined4 *)puVar25[3];
    puVar24 = puVar25 + 4;
    *puVar21 = psVar18;
    if (cVar26 == '\0') break;
    *puVar21 = psVar18;
    uVar17 = (uint)puVar5 | uVar13;
    puVar10[1] = uVar19;
    if (uVar17 == 0) {
      if (1 < uVar19) {
        iVar6 = iVar6 / (int)uVar19;
        if (iVar6 < 0) {
          iVar6 = -iVar6;
        }
        if (iVar6 < 0x169) {
          return (char *)0x0;
        }
      }
      *puVar10 = uVar13;
      puVar10[1] = 1;
      return (char *)0x1;
    }
    *puVar21 = psVar18;
    puVar25[0x38] = uVar17;
    *puVar21 = psVar18;
    iVar16 = *(int *)(psVar18 + 0x3a);
    *(undefined4 *)(iVar16 + 0x60) = 0;
    *(uint *)(psVar18 + 0x2a) = uVar13;
    *(uint *)(iVar16 + 0x14) = uVar13;
    *(int *)(iVar16 + 0x14) = iVar16;
    *(int *)(psVar18 + 10) = iVar16;
    *(undefined4 *)(iVar16 + 0x20) = 100;
    iVar16 = *(int *)(uVar17 + 0x74);
    uVar8 = *(undefined4 *)(iVar16 + 0x34);
    *(uint *)(uVar17 + 0x54) = uVar17;
    puVar5 = (undefined4 *)0x78;
    *(undefined1 *)(iVar16 + 0x14) = 0x54;
    *(undefined4 *)(psVar18 + 0x2a) = uVar8;
    pbVar20 = *(byte **)(iVar16 + 0x44);
    *(int *)(iVar16 + 0x74) = iVar6;
    *(undefined4 *)(iVar16 + 0x40) = 0x78;
    uRam0000008c = 0x78;
    puVar21 = *(undefined4 **)(iVar16 + 0x14);
    *(int *)(iVar16 + 0x54) = iVar16;
    bVar1 = *pbVar20;
    bVar2 = *pbVar20;
    if (iVar6 != 0) {
      *puVar21 = pbVar20;
      *puVar21 = pbVar20;
      piVar4 = _DAT_60166e60;
      puVar25[3] = 0x60166d61;
      puVar25[2] = (uint)puVar21;
      puVar25[1] = (uint)pbVar20;
      *puVar25 = 0x78;
      puVar25[-1] = (uint)bVar2;
      iVar16 = *_DAT_60166e60;
      if (iVar16 == 0) {
        puVar25[-3] = 0;
        puVar25[-2] = 0;
        puVar25[-4] = 1;
        puVar25[-5] = _DAT_60166e64;
        iVar16 = FUN_60168494(puVar25 + -5);
        *piVar4 = iVar16;
      }
      FUN_6016825e(iVar16,0xffffffff);
      piVar23 = (int *)piVar4[1];
      while (piVar22 = piVar23, piVar22 != (int *)0x0) {
        piVar23 = (int *)piVar22[0xb];
        if ((*piVar22 == bVar1 + 0x25) && ((code *)piVar22[4] != (code *)0x0)) {
          (*(code *)piVar22[4])(iVar6);
        }
      }
      pcVar11 = (char *)0x0;
      if (*piVar4 != 0) {
        pcVar11 = (char *)func_0x601682ae();
      }
      return pcVar11;
    }
    uVar14 = 0xae;
    cVar26 = '\0';
    uVar8 = 0;
    iVar6 = bVar1 + 0x25;
  }
SUB_60166af4:
  puVar21[9] = uVar13 - (int)puVar10;
  FUN_60120fe4(psVar18);
  uVar13 = puVar24[2];
  uVar19 = puVar24[3];
  puVar24[5] = puVar24[5];
  puVar24[4] = puVar24[4];
  puVar24[3] = uVar13;
  puVar24[2] = puVar24[1];
  if (puVar5 == (undefined4 *)0x0) {
    FUN_6016804c(_DAT_60166b60,uRam60166b58,0x1b5,*puVar24);
  }
  else {
    iVar6 = FUN_601631fc();
    if (iVar6 == 2) {
      if ((code *)*puRam60166b5c != (code *)0x0) {
        (*(code *)*puRam60166b5c)(puVar5);
      }
      uVar8 = FUN_60167d0c();
      if ((undefined4 *)puVar5[7] == puVar5 + 7) {
        *(short *)(puVar5 + 9) = *(short *)(puVar5 + 9) + 1;
        func_0x60167d14(uVar8);
      }
      else {
        FUN_6013a15a();
        func_0x60167d14(uVar8);
        func_0x60163a08();
      }
      return (char *)0x0;
    }
  }
  FUN_6016804c(uRam60166b54,uRam60166b58,0x1b6);
  **(uint **)(uVar13 + 4) = uVar19;
  pcVar11 = (char *)(uVar13 + 0x1c);
  **(undefined4 **)(uVar13 + 0x18) = *(undefined4 *)(uVar13 + 0x14);
  do {
    pcVar11 = pcVar11 + 1;
    pcVar7 = pcVar11;
    pcVar15 = extraout_r1;
    do {
      cVar26 = *pcVar15;
      cVar3 = *pcVar7;
      if (cVar3 == '\0') break;
      pcVar7 = pcVar7 + 1;
      pcVar15 = pcVar15 + 1;
    } while (cVar3 == cVar26);
    pcVar7 = pcVar11;
    if ((cVar26 == '\0') || (pcVar7 = (char *)0x0, cVar3 == '\0')) {
      return pcVar7;
    }
  } while( true );
}

