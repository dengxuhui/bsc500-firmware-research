
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6000b268(void)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  undefined4 unaff_r4;
  undefined4 unaff_lr;
  
  iVar3 = _DAT_6000b2b4;
  bVar1 = *(byte *)(_DAT_6000b2b4 + 1);
  if (bVar1 == 0 && *(char *)(_DAT_6000b2b0 + 0xcc) == '\0') {
    *(undefined1 *)(_DAT_6000b2b4 + 1) = 1;
    uVar2 = FUN_6012d794();
    if ((uVar2 == 0) && (uVar2 = (uint)*(byte *)(iVar3 + 4), uVar2 == 0)) {
      FUN_601489b8(_DAT_6000b2b8);
      *(undefined1 *)(iVar3 + 4) = 1;
      return 1;
    }
    return uVar2;
  }
  if (*(char *)(_DAT_6000b2b0 + 0xcc) == '\0') {
    return (uint)bVar1;
  }
  if (bVar1 != 0) {
    *(undefined1 *)(_DAT_6000b2b4 + 1) = 0;
    uVar2 = FUN_6012d794();
    if (uVar2 != 0) {
      return uVar2;
    }
    if (_DAT_6000b2b8 + 1U < _UNK_60059ad8) {
      iVar3 = func_0x601671d4(_UNK_60059adc,_DAT_6000b2b8 + 1U,0,0x27,unaff_r4,unaff_lr);
      if (iVar3 == 0) {
        return 0;
      }
      func_0x60168578(&UNK_60059ae0);
    }
    else {
      func_0x60168578(&UNK_60059b10);
    }
    return 0xffffffff;
  }
  return 0;
}

