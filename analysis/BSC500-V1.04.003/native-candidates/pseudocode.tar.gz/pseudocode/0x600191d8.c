
/* WARNING: Removing unreachable block (ram,0x60113dec) */
/* WARNING: Removing unreachable block (ram,0x60113cde) */
/* WARNING: Removing unreachable block (ram,0x60113cf0) */
/* WARNING: Removing unreachable block (ram,0x60113d04) */
/* WARNING: Removing unreachable block (ram,0x60113d0a) */
/* WARNING: Removing unreachable block (ram,0x60113d0e) */
/* WARNING: Removing unreachable block (ram,0x60113d9e) */
/* WARNING: Removing unreachable block (ram,0x601139e8) */
/* WARNING: Removing unreachable block (ram,0x60113bd2) */
/* WARNING: Removing unreachable block (ram,0x60113be2) */
/* WARNING: Removing unreachable block (ram,0x60113bf6) */
/* WARNING: Removing unreachable block (ram,0x60113bfe) */
/* WARNING: Removing unreachable block (ram,0x60113c02) */
/* WARNING: Removing unreachable block (ram,0x60113c90) */
/* WARNING: Removing unreachable block (ram,0x60113e44) */
/* WARNING: Removing unreachable block (ram,0x60113e54) */
/* WARNING: Removing unreachable block (ram,0x60113e68) */
/* WARNING: Removing unreachable block (ram,0x60113e74) */
/* WARNING: Removing unreachable block (ram,0x60113e78) */
/* WARNING: Removing unreachable block (ram,0x60113f02) */
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60113b04 */
/* WARNING: Removing unreachable block (ram,0x60113e12) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_600191d8(undefined4 param_1,undefined4 param_2,int param_3,uint param_4)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  undefined4 *puVar10;
  uint uVar11;
  bool bVar12;
  uint uVar13;
  uint uVar14;
  bool bVar15;
  undefined1 auStack_70 [24];
  undefined1 auStack_58 [24];
  undefined1 auStack_40 [28];
  
  iVar1 = _DAT_600191e8;
  piVar2 = (int *)(_DAT_600191e8 + 0x18);
  if (piVar2 == (int *)0x0) {
    return 0xffffffff;
  }
  if (param_3 == 0) {
    return 0xffffffff;
  }
  iVar3 = *piVar2;
  uVar7 = *(uint *)(iVar3 + 0x14);
  if (uVar7 - 1 < param_4) {
LAB_601139ca:
    uVar4 = 0xffffffff;
  }
  else {
    uVar8 = *(uint *)(_DAT_600191e8 + 0x2c);
    if (uVar8 < uVar7) {
      *(undefined4 *)(_DAT_600191e8 + 0x34) = 0;
      uVar14 = param_4 - (uVar8 >> 1);
      if (param_4 < uVar8 >> 1) {
        uVar14 = 0;
      }
      uVar13 = param_4 + (uVar8 >> 1) + (uVar8 & 1);
      if (uVar7 < uVar13) {
        uVar13 = uVar7;
      }
      uVar11 = uVar13;
      if (uVar13 - uVar14 < uVar8) {
        uVar8 = uVar8 - (uVar13 - uVar14);
        bVar15 = uVar8 <= uVar14;
        uVar11 = uVar14 - uVar8;
        uVar14 = 0;
        if (bVar15) {
          uVar14 = uVar11;
        }
        uVar11 = uVar13 + uVar8;
        if (uVar7 < uVar13 + uVar8) {
          uVar11 = uVar7;
        }
      }
      ZeroBytes(auStack_40,0x18);
      ZeroBytes(auStack_58,0x18);
      ZeroBytes(auStack_70,0x18);
      bVar15 = false;
      uVar8 = 0;
      for (uVar7 = 0; uVar7 < (*(int **)(iVar1 + 0x1c))[1] + 1U; uVar7 = uVar7 + 1) {
        uVar13 = uVar11;
        uVar9 = uVar14;
        if (uVar7 == 0) {
LAB_60113a9a:
          if (uVar9 == 0) {
            iVar3 = FUN_6013028a(*piVar2,0,auStack_58);
            if (iVar3 != 0) goto LAB_601139ca;
            iVar3 = FUN_600f312c((int)auStack_58._0_8_,param_2,(int)auStack_58._8_8_,param_3);
            if (iVar3 == 1) {
              *(uint *)(*(int *)(iVar1 + 0x28) + *(int *)(iVar1 + 0x34) * 8) = uVar8;
              goto LAB_60113b14;
            }
LAB_60113b18:
            bVar12 = false;
          }
          else {
            iVar3 = FUN_6013028a(*piVar2,uVar9 - 1,auStack_58);
            if (iVar3 != 0) goto LAB_601139ca;
            iVar3 = FUN_600f312c((int)auStack_58._0_8_,param_2,(int)auStack_58._8_8_,param_3);
            if (iVar3 != 1) goto LAB_60113b18;
            iVar3 = *(int *)(iVar1 + 0x20);
            *(uint *)(*(int *)(iVar1 + 0x28) + *(int *)(iVar1 + 0x34) * 8) = uVar8;
            FUN_60156244(iVar3 + uVar8 * 0x18,auStack_58);
            uVar8 = uVar8 + 1;
            if (*(uint *)(iVar1 + 0x2c) <= uVar8) break;
LAB_60113b14:
            bVar12 = true;
          }
          for (; uVar9 < uVar13; uVar9 = uVar9 + 1) {
            iVar3 = FUN_6013028a(*piVar2,uVar9,auStack_40);
            if (iVar3 != 0) goto LAB_601139ca;
            iVar3 = FUN_600f312c((int)auStack_40._0_8_,param_2,(int)auStack_40._8_8_,param_3);
            if (bVar12) {
              FUN_60156244(*(int *)(iVar1 + 0x20) + uVar8 * 0x18,auStack_40);
              uVar8 = uVar8 + 1;
              if (*(uint *)(iVar1 + 0x2c) <= uVar8) {
                iVar3 = *(int *)(iVar1 + 0x34);
                *(uint *)(*(int *)(iVar1 + 0x28) + iVar3 * 8 + 4) = uVar8;
                *(int *)(iVar1 + 0x34) = iVar3 + 1;
                goto LAB_60113f08;
              }
              if (iVar3 != 1) {
                iVar5 = *(int *)(iVar1 + 0x34);
                *(uint *)(*(int *)(iVar1 + 0x28) + iVar5 * 8 + 4) = uVar8;
                uVar6 = iVar5 + 1;
                *(uint *)(iVar1 + 0x34) = uVar6;
                if (*(uint *)(iVar1 + 0x30) <= uVar6) goto LAB_60113f08;
              }
            }
            else if (iVar3 == 1) {
              iVar5 = *(int *)(iVar1 + 0x20);
              *(uint *)(*(int *)(iVar1 + 0x28) + *(int *)(iVar1 + 0x34) * 8) = uVar8;
              FUN_60156244(iVar5 + uVar8 * 0x18,auStack_58);
              if (*(uint *)(iVar1 + 0x2c) <= uVar8 + 1) goto LAB_60113f08;
              FUN_60156244(*(int *)(iVar1 + 0x20) + (uVar8 + 1) * 0x18,auStack_40);
              uVar8 = uVar8 + 2;
              if (*(uint *)(iVar1 + 0x2c) <= uVar8) goto LAB_60113ccc;
            }
            bVar12 = iVar3 == 1;
            FUN_60156244(auStack_58,auStack_40);
            bVar15 = bVar12;
          }
          if (bVar15) {
LAB_60113ccc:
            iVar3 = *(int *)(iVar1 + 0x34);
            *(uint *)(*(int *)(iVar1 + 0x28) + iVar3 * 8 + 4) = uVar8;
            uVar13 = iVar3 + 1;
            *(uint *)(iVar1 + 0x34) = uVar13;
            if (*(uint *)(iVar1 + 0x30) <= uVar13) break;
            bVar15 = true;
          }
          if (*(uint *)(iVar1 + 0x2c) <= uVar8) break;
        }
        else {
          iVar3 = FUN_6012fb3c(param_3,**(int **)(iVar1 + 0x1c) + (uVar7 - 1) * 0x30);
          if (iVar3 != 0) {
            iVar3 = **(int **)(iVar1 + 0x1c) + (uVar7 - 1) * 0x30;
            uVar9 = *(uint *)(iVar3 + 0x28);
            uVar13 = *(uint *)(iVar3 + 0x2c);
            if ((uVar11 < uVar13) || (uVar9 < uVar14)) {
              if (uVar13 <= uVar11) {
                uVar13 = uVar14;
              }
              if (uVar14 <= uVar9) {
                uVar9 = uVar11;
              }
              goto LAB_60113a9a;
            }
          }
        }
      }
    }
    else if (*(int *)(_DAT_600191e8 + 0x34) != 1) {
      uVar8 = 0;
      while( true ) {
        if (uVar7 <= uVar8) {
          puVar10 = *(undefined4 **)(iVar1 + 0x28);
          *(undefined4 *)(iVar1 + 0x34) = 1;
          *puVar10 = 0;
          puVar10[1] = uVar7;
          return 0;
        }
        iVar3 = FUN_6013028a(iVar3,uVar8,*(int *)(iVar1 + 0x20) + uVar8 * 0x18);
        if (iVar3 != 0) break;
        iVar3 = *piVar2;
        uVar8 = uVar8 + 1;
        uVar7 = *(uint *)(iVar3 + 0x14);
      }
      goto LAB_601139ca;
    }
LAB_60113f08:
    uVar4 = 0;
  }
  return uVar4;
}

