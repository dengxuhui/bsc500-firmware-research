
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000eab4(void)

{
  undefined1 auStack_2c [36];
  
  FUN_60131124(auStack_2c);
  FUN_60163c70(auStack_2c,*(undefined4 *)(_DAT_6000eae0 + 0xa74));
  FUN_6003de30(auStack_2c);
  CopyBytes(_DAT_6000eae4,auStack_2c,0x24);
  return;
}

