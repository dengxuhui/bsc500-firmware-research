
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000a39c(void)

{
  FUN_6004ac24();
  if (*_DAT_6000a3b4 == '\x02') {
    *_DAT_6000a3b4 = '\x01';
  }
  return 0;
}

