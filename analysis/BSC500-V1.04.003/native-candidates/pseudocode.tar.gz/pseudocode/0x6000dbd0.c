
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x6000deb8 */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_6000dbd0(void)

{
  byte bVar1;
  byte bVar2;
  byte *pbVar3;
  undefined1 *puVar4;
  int iVar5;
  int *piVar6;
  undefined4 *puVar7;
  undefined4 uVar8;
  int iVar9;
  int iVar10;
  int iVar11;
  uint uVar12;
  undefined4 uVar13;
  uint uVar14;
  undefined8 *puVar15;
  uint uVar16;
  undefined8 *puVar17;
  uint uVar18;
  undefined8 *puVar19;
  undefined4 uVar20;
  bool bVar21;
  uint in_fpscr;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr8;
  float fVar22;
  float fVar23;
  undefined4 uVar24;
  undefined4 uVar25;
  float fVar26;
  undefined4 uVar27;
  undefined4 in_s3;
  undefined4 uVar28;
  undefined8 uVar29;
  undefined8 uVar30;
  undefined8 uVar31;
  undefined8 uVar32;
  
  iVar5 = FUN_60167080();
  pbVar3 = _DAT_6000df40;
  bVar1 = *(byte *)(iVar5 + 0x16);
  uVar18 = (uint)bVar1;
  if (*_DAT_6000df40 != uVar18) {
    if (uVar18 - 1 < 2) {
      _DAT_6000df44[1] = 1;
      func_0x60168578(&UNK_6000df68);
      FUN_6014abfa(0);
      FUN_6014abf6();
      FUN_60149558();
      FUN_60160828(0);
    }
    else {
      iVar10 = FUN_60167080();
      puVar4 = _DAT_6000df44;
      if ((_DAT_6000df44[1] == '\x01') && (*(char *)(iVar10 + 0x15) != '\0')) {
        FUN_60162cb8();
        bVar2 = *pbVar3;
        func_0x60168578(&UNK_6000df48);
        if (bVar2 == 2) {
          FUN_60018a74();
        }
        iVar10 = FUN_60167458(9);
        if (iVar10 != 0) {
          FUN_60160828(1);
        }
        iVar10 = FUN_6016518c();
        FUN_601650fc(10,0);
        FUN_60165180(*(undefined2 *)(iVar10 + 8));
        FUN_60163e70(_DAT_6000df60,0,0);
        ZeroBytes(puVar4 + 4,0x1c);
        *puVar4 = 0;
        FUN_601607a8();
        FUN_601607bc();
        FUN_60164914(_DAT_6000df64,0);
      }
      puVar4[1] = 0;
    }
    *pbVar3 = bVar1;
    uVar18 = (uint)*(byte *)(iVar5 + 0x16);
  }
  if (uVar18 == 0) {
    return;
  }
  if (uVar18 == 2) {
    FUN_6001896c();
  }
  fVar22 = (float)VectorUnsignedToFloat
                            (*(undefined4 *)(*(int *)(pbVar3 + 8) + 0x1b4),
                             (byte)(in_fpscr >> 0x16) & 3);
  fVar22 = fVar22 / _UNK_6000df88;
  piVar6 = (int *)FUN_60018098();
  if ((piVar6 == (int *)0x0) || (piVar6[2] == 0)) {
    piVar6 = (int *)FUN_60162278();
    uVar31 = _UNK_6000df38;
    uVar29 = _UNK_6000df38;
    if ((piVar6 != (int *)0x0) &&
       ((puVar19 = (undefined8 *)*piVar6, puVar19 != (undefined8 *)0x0 && (1 < (uint)piVar6[1])))) {
      iVar10 = piVar6[1] - 1;
      iVar9 = 0;
      iVar5 = 0;
      do {
        if (iVar10 == iVar5) {
          puVar19 = puVar19 + iVar10 * 3;
          puVar15 = puVar19;
          break;
        }
        puVar17 = (undefined8 *)((int)puVar19 + iVar9);
        if ((*(float *)(puVar17 + 2) <= fVar22) && (fVar22 < *(float *)(puVar17 + 5))) {
          puVar19 = puVar17;
          puVar15 = puVar17 + 3;
          break;
        }
        iVar11 = iVar5 + 1;
        bVar21 = iVar5 != 0;
        iVar9 = iVar9 + 0x18;
        iVar5 = iVar11;
      } while ((bVar21) || (puVar15 = puVar19, *(float *)(puVar17 + 2) <= fVar22));
      fVar26 = *(float *)(puVar15 + 2);
      fVar23 = _UNK_6000df8c;
      if ((*(float *)(puVar19 + 2) < *(float *)(puVar15 + 2)) &&
         (coprocessor_function2(10,8,0,in_cr8,in_cr0,in_cr1), fVar26 = _UNK_6000df8c,
         fVar23 = fVar22, 1.0 < fVar22)) {
        fVar23 = 1.0;
      }
      uVar29 = puVar15[1];
      uVar30 = puVar19[1];
      uVar13 = (undefined4)((ulonglong)*puVar19 >> 0x20);
      uVar20 = (undefined4)*puVar19;
      uVar31 = FUN_60165558(uVar20,uVar13,fVar26,in_s3,_UNK_6000df8c,(int)*puVar15,
                            (int)((ulonglong)*puVar15 >> 0x20),uVar20,uVar13);
      uVar32 = FUN_60166bb4(fVar23);
      uVar8 = (undefined4)((ulonglong)uVar32 >> 0x20);
      uVar31 = FUN_601678fc((int)uVar31,(int)((ulonglong)uVar31 >> 0x20),(int)uVar32,uVar8);
      uVar31 = FUN_601682c8(uVar20,uVar13,(int)uVar31,(int)((ulonglong)uVar31 >> 0x20));
      uVar13 = (undefined4)((ulonglong)uVar30 >> 0x20);
      uVar20 = (undefined4)uVar30;
      uVar29 = FUN_60165558((int)uVar29,(int)((ulonglong)uVar29 >> 0x20),uVar20,uVar13);
      uVar29 = FUN_601678fc((int)uVar29,(int)((ulonglong)uVar29 >> 0x20),(int)uVar32,uVar8);
      uVar29 = FUN_601682c8(uVar20,uVar13,(int)uVar29,(int)((ulonglong)uVar29 >> 0x20));
    }
  }
  else {
    iVar5 = *piVar6;
    puVar19 = (undefined8 *)0x0;
    for (iVar10 = 0; puVar15 = puVar19, iVar10 != piVar6[2]; iVar10 = iVar10 + 1) {
      uVar18 = *(uint *)(piVar6[1] + iVar10 * 8);
      uVar12 = *(uint *)(piVar6[1] + iVar10 * 8 + 4);
      if (uVar12 <= uVar18) {
        return;
      }
      while (uVar14 = uVar18 & 0xff, uVar14 < uVar12) {
        puVar19 = (undefined8 *)(iVar5 + uVar14 * 0x18);
        if (((*(float *)(puVar19 + 2) <= fVar22) &&
            (puVar15 = (undefined8 *)(iVar5 + (uVar14 + 1) * 0x18), fVar22 < *(float *)(puVar15 + 2)
            )) || ((uVar16 = uVar18 + 1, uVar14 = uVar18 & 0xff, uVar18 = uVar16, uVar14 == 0 &&
                   (puVar15 = puVar19, fVar22 < *(float *)(puVar19 + 2))))) goto LAB_6000dda0;
      }
      puVar19 = (undefined8 *)(iVar5 + uVar12 * 0x18);
    }
LAB_6000dda0:
    if (puVar19 == (undefined8 *)0x0) {
      return;
    }
    if (puVar15 == (undefined8 *)0x0) {
      return;
    }
    fVar23 = *(float *)(puVar19 + 2);
    fVar26 = _UNK_6000df8c;
    if (fVar23 < *(float *)(puVar15 + 2)) {
      fVar26 = (fVar22 - fVar23) / (*(float *)(puVar15 + 2) - fVar23);
    }
    uVar29 = puVar15[1];
    uVar30 = puVar19[1];
    uVar13 = (undefined4)((ulonglong)*puVar19 >> 0x20);
    uVar20 = (undefined4)*puVar19;
    uVar31 = FUN_60165558((int)*puVar15,(int)((ulonglong)*puVar15 >> 0x20),uVar20,uVar13);
    uVar32 = FUN_60166bb4(fVar26);
    uVar8 = (undefined4)((ulonglong)uVar32 >> 0x20);
    uVar31 = FUN_601678fc((int)uVar31,(int)((ulonglong)uVar31 >> 0x20),(int)uVar32,uVar8);
    uVar31 = FUN_601682c8(uVar20,uVar13,(int)uVar31,(int)((ulonglong)uVar31 >> 0x20));
    uVar13 = (undefined4)((ulonglong)uVar30 >> 0x20);
    uVar20 = (undefined4)uVar30;
    uVar29 = FUN_60165558((int)uVar29,(int)((ulonglong)uVar29 >> 0x20),uVar20,uVar13);
    uVar29 = FUN_601678fc((int)uVar29,(int)((ulonglong)uVar29 >> 0x20),(int)uVar32,uVar8);
    uVar29 = FUN_601682c8(uVar20,uVar13,(int)uVar29,(int)((ulonglong)uVar29 >> 0x20));
  }
  uVar28 = (undefined4)((ulonglong)uVar29 >> 0x20);
  uVar27 = (undefined4)uVar29;
  fVar22 = (float)uVar31;
  uVar25 = (undefined4)((ulonglong)uVar31 >> 0x20);
  puVar7 = (undefined4 *)FUN_6015e450();
  uVar13 = *puVar7;
  uVar29 = FUN_6016759c(puVar7[2]);
  uVar20 = (undefined4)((ulonglong)_UNK_6001b1e0 >> 0x20);
  uVar24 = (undefined4)_UNK_6001b1e0;
  uVar8 = FUN_601675d8((int)uVar29,(int)((ulonglong)uVar29 >> 0x20),uVar24,uVar20);
  uVar29 = FUN_6016759c(uVar13);
  uVar13 = FUN_601675d8((int)uVar29,(int)((ulonglong)uVar29 >> 0x20),uVar24,uVar20);
  FUN_6015e318(uVar8,uVar25,uVar13,uVar28,fVar22,uVar25,uVar27,uVar28);
  iVar5 = FUN_60136c08(uVar8,uVar25,uVar13,uVar28,fVar22,uVar25,uVar27,uVar28);
  if (iVar5 == 0) {
    puVar7[4] = (int)(fVar22 + _UNK_6001b1e8) % 0x168;
  }
  uVar8 = _DAT_6001b1ec;
  puVar7[3] = _DAT_6001b1ec;
  *(undefined1 *)(puVar7 + 5) = 1;
  puVar7[1] = uVar8;
  FUN_601678fc(uVar27,uVar28,uVar24,uVar20);
  uVar8 = FUN_60167a50();
  *puVar7 = uVar8;
  FUN_601678fc(fVar22,uVar25,uVar24,uVar20);
  uVar8 = FUN_60167a50();
  puVar7[2] = uVar8;
  return;
}

