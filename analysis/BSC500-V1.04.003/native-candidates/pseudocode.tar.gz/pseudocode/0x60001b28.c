
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001b28(undefined4 param_1)

{
  bool bVar1;
  undefined4 *puVar2;
  uint uVar3;
  
  puVar2 = _DAT_60001b3c;
  uVar3 = FUN_60167d0c();
  *puVar2 = param_1;
  bVar1 = (bool)isCurrentModePrivileged();
  if (bVar1) {
    enableIRQinterrupts((uVar3 & 1) == 1);
  }
  return;
}

