
/* WARNING: Type propagation algorithm not settling */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600171a8(int param_1,int param_2,uint *param_3,uint *param_4)

{
  char cVar1;
  undefined8 uVar2;
  undefined1 *puVar3;
  int iVar4;
  uint uVar5;
  int *piVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  int iVar10;
  undefined1 *puVar11;
  uint uVar12;
  int iVar13;
  int iVar14;
  int *piVar15;
  int iVar16;
  uint uVar17;
  int iVar18;
  uint uVar19;
  int iVar20;
  undefined4 uVar21;
  bool bVar22;
  undefined4 uVar23;
  undefined4 uVar24;
  undefined8 uVar25;
  uint uStack_a8;
  int iStack_9c;
  uint uStack_88;
  uint uStack_78;
  uint uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  int aiStack_60 [4];
  int iStack_50;
  int iStack_4c;
  uint uStack_48;
  uint auStack_44 [5];
  
  uStack_64 = 0;
  uStack_6c = 0;
  uStack_68 = 0;
  if (param_1 == 0 || param_2 == 0) {
    return 0xffffffff;
  }
  if (param_3 == (uint *)0x0) {
    return 0xffffffff;
  }
  if (param_4 == (uint *)0x0) {
    return 0xffffffff;
  }
  iVar4 = FUN_600206c8(param_2);
  if (iVar4 == 0) {
    uVar5 = FUN_601668a4();
    iVar4 = _DAT_60017744;
    uVar19 = (uint)((uVar5 | 2) != 2);
    iVar16 = _DAT_60017744 + uVar19 * 0x10;
    uVar5 = *(uint *)(iVar16 + 0x164);
    if ((uVar5 <= *param_3) && (uVar17 = *(uint *)(iVar16 + 0x16c), *param_3 <= uVar17)) {
      uVar12 = *(uint *)(iVar16 + 0x168);
      if ((uVar12 <= *param_4) && (*param_4 <= *(uint *)(iVar16 + 0x170))) {
        for (iVar18 = 0; iVar18 != 4; iVar18 = iVar18 + 1) {
          aiStack_60[iVar18] =
               (param_4[iVar18] - uVar12) * ((uVar17 - uVar5) + 1) + (param_3[iVar18] - uVar5);
        }
        iVar18 = FUN_60166758(_DAT_60017744 + 0x160,_DAT_60017744,1);
        if (iVar18 == 0) {
          ZeroBytes(_DAT_60017748,0x4000);
          uVar2 = _UNK_60017610;
          iVar18 = 0;
          iVar4 = iVar4 + uVar19 * 0x18;
          uVar21 = 0;
          piVar6 = (int *)(iVar4 + 0x130);
          do {
            iVar9 = _DAT_60017744;
            if (iVar18 == 4) {
              FUN_601667bc(*(undefined4 *)(_DAT_60017744 + 0x160));
              return uVar21;
            }
            if ((((*(uint *)(iVar16 + 0x164) <= param_3[iVar18]) &&
                 (param_3[iVar18] <= *(uint *)(iVar16 + 0x16c))) &&
                (*(uint *)(iVar16 + 0x168) <= param_4[iVar18])) &&
               (param_4[iVar18] <= *(uint *)(iVar16 + 0x170))) {
              iVar13 = *piVar6 + aiStack_60[iVar18] * 5;
              if (*(char *)(_DAT_60017744 + 0x8a) < '\0') {
                iVar13 = iVar13 + 0x10;
              }
              FUN_60163c98(*(undefined4 *)(_DAT_60017744 + 0x160),iVar13);
              uVar21 = FUN_60161ef4(*(undefined4 *)(iVar9 + 0x160),&uStack_68,5,&uStack_6c);
              uVar25 = FUN_6012222c(&uStack_68);
              uVar5 = (uint)((ulonglong)uVar25 >> 0x20);
              uVar17 = (uVar5 & 0x7fffffff) >> 0x18;
              uVar19 = (uint)uVar25 >> 0x18 | uVar5 << 8;
              if (uVar17 <= *(uint *)(iVar4 + 0x13c) &&
                  (uint)(*(uint *)(iVar4 + 0x138) <= uVar19) <= uVar17 - *(uint *)(iVar4 + 0x13c)) {
                uVar21 = FUN_60161ef4(*(undefined4 *)(_DAT_60017744 + 0x160),&uStack_68,5,&uStack_6c
                                     );
                uVar25 = FUN_6012222c(&uStack_68);
                iVar9 = _DAT_60017744;
                uVar17 = (uint)((ulonglong)uVar25 >> 0x20);
                if (((uint)uVar25 >> 0x18 | uVar17 << 8) != uVar19 ||
                    ((uVar17 ^ uVar5) & 0x7fffffff) >> 0x18 != 0) {
                  FUN_60163c98(*(undefined4 *)(_DAT_60017744 + 0x160),*piVar6 + uVar19);
                  if (0x7fffffff < (uint)(int)*(char *)(iVar9 + 0x8a)) {
                    iVar13 = FUN_6015cbf2(*(undefined4 *)(iVar9 + 0x160));
                    FUN_60163c98(*(undefined4 *)(iVar9 + 0x160),iVar13 + 0x20);
                  }
                  uVar21 = FUN_60159a10(param_3[iVar18],*(undefined1 *)(iVar4 + 0x128));
                  uVar25 = FUN_60166bb4(uVar21);
                  uVar21 = (undefined4)((ulonglong)uVar2 >> 0x20);
                  uVar24 = (undefined4)uVar2;
                  FUN_601678fc((int)uVar25,(int)((ulonglong)uVar25 >> 0x20),uVar24,uVar21);
                  iVar13 = FUN_60167a50();
                  iVar20 = *(int *)(_DAT_60017744 + 0x2b0);
                  uVar23 = FUN_60159a60(param_4[iVar18],*(undefined1 *)(iVar4 + 0x128));
                  uVar25 = FUN_60166bb4(uVar23);
                  iVar9 = _DAT_60017744;
                  FUN_601678fc((int)uVar25,(int)((ulonglong)uVar25 >> 0x20),uVar24,uVar21);
                  iVar7 = FUN_60167a50();
                  iVar7 = iVar7 - *(int *)(iVar9 + 0x2ac);
                  iVar13 = iVar13 - iVar20;
                  FUN_6001ee88(param_1,iVar13,iVar7,iVar9);
                  FUN_60163c98(*(undefined4 *)(iVar9 + 0x160),uVar19 + *piVar6);
                  if (0x7fffffff < (uint)(int)*(char *)(iVar9 + 0x8a)) {
                    iVar20 = FUN_6015cbf2(*(undefined4 *)(iVar9 + 0x160));
                    FUN_60163c98(*(undefined4 *)(iVar9 + 0x160),iVar20 + 0x20);
                  }
                  iVar20 = _DAT_6001774c;
                  iVar14 = *(int *)(iVar9 + 0x160);
                  auStack_44[3] = 0;
                  auStack_44[4] = 0;
                  auStack_44[1] = 0;
                  auStack_44[2] = 0;
                  uStack_48 = 0;
                  auStack_44[0] = 0;
                  iStack_50 = 0;
                  iStack_4c = 0;
                  if (iVar14 != 0) {
                    uStack_78 = 0;
                    for (iVar8 = 0; iVar8 != 0xb; iVar8 = iVar8 + 1) {
                      uStack_78 = uStack_78 + *(int *)(iVar9 + iVar8 * 4 + 0x32c);
                    }
                    uVar5 = FUN_601668a4();
                    iStack_9c = FUN_6015cbf2(iVar14);
                    FUN_60161ef4(iVar14,iVar20,0x1fa0,auStack_44 + 4);
                    iVar9 = iVar9 + (uint)((uVar5 | 2) != 2) * 0x18;
                    iVar20 = 0;
                    uStack_70 = 0;
                    for (uVar5 = 0; iVar8 = _DAT_6001774c,
                        uVar5 < ((uint)*(byte *)(iVar9 + 0x12a) - (uint)*(byte *)(iVar9 + 0x129)) +
                                1; uVar5 = uVar5 + 1) {
                      iVar10 = FUN_6015a168(auStack_44 + 3,_DAT_6001774c + iVar20);
                      iVar8 = FUN_6015a168(auStack_44 + 2,iVar8 + iVar20 + iVar10);
                      iVar20 = iVar20 + iVar10 + iVar8;
                      uStack_70 = uStack_70 + auStack_44[3];
                    }
                    bVar22 = 9999 < auStack_44[3];
                    if (auStack_44[3] < 0x2711) {
                      bVar22 = 10000 < auStack_44[2];
                    }
                    if (!bVar22) {
                      iVar9 = FUN_6015a168(auStack_44 + 1,_DAT_6001774c + iVar20);
                      uVar19 = iVar20 + iVar9;
                      uVar21 = 0;
                      uStack_a8 = 0;
                      for (uVar5 = 0; iVar9 = _DAT_6001774c, uVar5 != uStack_70; uVar5 = uVar5 + 1)
                      {
                        if (*(char *)(_DAT_60017744 + 0x8a) < '\0') {
                          uVar19 = uVar19 + 0x20;
                        }
                        iVar20 = FUN_60158ee8(&iStack_4c,_DAT_6001774c + uVar19);
                        iVar8 = FUN_60158ee8(&iStack_50,iVar9 + uVar19 + iVar20);
                        iVar8 = iVar8 + uVar19 + iVar20;
                        iVar20 = iVar8 + 1;
                        uVar19 = 0xff;
                        iStack_4c = *(int *)(_DAT_60017744 + 0x2ac) + iVar7 + iStack_4c;
                        iStack_50 = iVar13 + *(int *)(_DAT_60017744 + 0x2b0) + iStack_50;
                        for (uVar17 = *(byte *)(iVar9 + iVar8) & 0xf; uVar17 != 0;
                            uVar17 = uVar17 - 1) {
                          iVar9 = FUN_6015a168(&uStack_48,_DAT_6001774c + iVar20);
                          iVar20 = iVar20 + iVar9;
                          if ((uStack_48 < 0xd) &&
                             (*(char *)(_DAT_60017744 + uStack_48 + 0x8e) != -1)) {
                            uVar19 = uStack_48;
                          }
                        }
                        if (((uVar19 & 0xff) < 0xd) &&
                           (uStack_a8 = FUN_6001ff38(*(undefined1 *)
                                                      (_DAT_60017744 + (uVar19 & 0xff) + 0x8e)),
                           uStack_a8 < 0xb)) {
                          bVar22 = uStack_70 < 0x3e9 || uStack_a8 < 3;
                        }
                        else {
                          bVar22 = false;
                        }
                        iVar9 = iVar20 + 1;
                        cVar1 = *(char *)(_DAT_6001774c + iVar20);
                        if (cVar1 < '\0') {
                          iVar20 = FUN_6015a168(auStack_44,_DAT_6001774c + iVar9);
                          uVar19 = auStack_44[0];
                          puVar3 = _DAT_60017750;
                          iVar8 = auStack_44[0] + 10;
                          uStack_88 = uStack_78 + iVar8;
                          if (0x4000 < uStack_88) break;
                          iVar9 = iVar9 + iVar20;
                          if ((bVar22) && (auStack_44[0] < 0x100)) {
                            iVar20 = _DAT_6001774c + iVar9;
                            puVar11 = _DAT_60017750 + 1;
                            *_DAT_60017750 = (char)auStack_44[0];
                            CopyBytes(puVar11,iVar20,auStack_44[0]);
                            uVar17 = 0;
                            *(int *)(puVar3 + uVar19 + 2) = iStack_4c;
                            puVar3[uVar19 + 1] = (char)uStack_a8;
                            *(int *)(puVar3 + uVar19 + 6) = iStack_50;
                            piVar15 = (int *)(_DAT_60017744 + 0x32c);
                            for (iVar20 = (uStack_a8 & 0xff) + 1; iVar20 != 0; iVar20 = iVar20 + -1)
                            {
                              iVar10 = *piVar15;
                              piVar15 = piVar15 + 1;
                              uVar17 = uVar17 + iVar10;
                            }
                            if (uVar17 < uStack_78) {
                              FUN_6015dda0(iVar8 + _DAT_60017748 + uVar17,_DAT_60017748 + uVar17,
                                           uStack_78 - uVar17);
                            }
                            CopyBytes(_DAT_60017748 + uVar17,_DAT_60017750,iVar8);
                            iVar20 = _DAT_6001774c;
                            iVar10 = _DAT_60017744 + (uStack_a8 & 0xff) * 4;
                            *(int *)(iVar10 + 0x32c) = *(int *)(iVar10 + 0x32c) + iVar8;
                            *(int *)(iVar10 + 0x358) = *(int *)(iVar10 + 0x358) + 1;
                          }
                          else {
                            uStack_88 = uStack_78;
                            iVar20 = _DAT_6001774c;
                          }
                        }
                        else {
                          uVar19 = 0;
                          auStack_44[0] = 0;
                          uStack_88 = uStack_78;
                          iVar20 = _DAT_6001774c;
                        }
                        iVar8 = FUN_6001ff6c(iVar20 + uVar19 + iVar9,cVar1);
                        uVar19 = iVar8 + uVar19 + iVar9;
                        if (0x1e74 < uVar19) {
                          ZeroBytes(iVar20,0x1fa0);
                          FUN_60163c98(iVar14,uVar19 + iStack_9c);
                          iStack_9c = FUN_6015cbf2(iVar14);
                          uVar21 = FUN_60161ef4(iVar14,iVar20,0x1fa0,auStack_44 + 4);
                          uVar19 = 0;
                        }
                        uStack_78 = uStack_88;
                      }
                      goto LAB_6001752e;
                    }
                    if (*_DAT_60017754 == 0) {
                      func_0x60168578(&UNK_60017758);
                      *_DAT_60017754 = 1;
                    }
                  }
                  uVar21 = 0xffffffff;
                }
              }
            }
LAB_6001752e:
            iVar18 = iVar18 + 1;
          } while( true );
        }
        goto LAB_600171ec;
      }
    }
    uVar21 = 0;
  }
  else {
LAB_600171ec:
    uVar21 = 0xffffffff;
  }
  return uVar21;
}

