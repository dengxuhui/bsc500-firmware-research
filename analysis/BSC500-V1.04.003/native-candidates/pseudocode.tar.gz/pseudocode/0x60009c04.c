
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009c04(uint param_1,int param_2)

{
  if ((param_1 < 8) && (param_2 != 0)) {
    *(int *)(*(int *)(_DAT_60009c2c + param_1 * 4 + 4) + 0xc) = param_2;
  }
  return;
}

