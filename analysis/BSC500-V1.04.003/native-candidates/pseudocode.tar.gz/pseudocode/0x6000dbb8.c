
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000dbb8(void)

{
  undefined1 *puVar1;
  
  puVar1 = _DAT_6000dbc8;
  *(undefined4 *)(_DAT_6000dbc8 + 4) = 0;
  *(undefined4 *)(puVar1 + 8) = 0;
  *(undefined4 *)(puVar1 + 0xc) = 0;
  *puVar1 = 0;
  return;
}

