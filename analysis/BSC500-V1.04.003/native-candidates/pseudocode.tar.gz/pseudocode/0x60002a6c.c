
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60002a6c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 *puVar1;
  int iVar2;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  puVar1 = _DAT_60002aa8;
  uStack_14 = param_2;
  uStack_10 = param_3;
  uStack_c = param_4;
  FUN_601678a8(_DAT_60002aa8 + 4);
  FUN_60006bf8();
  FUN_60160bc0(_UNK_60002ab0,_DAT_60002aac);
  FUN_60006980(&uStack_14);
  *puVar1 = (char)uStack_14;
  iVar2 = _DAT_60002ab4;
  *(short *)(_DAT_60002ab4 + 2) = (short)uStack_10;
  FUN_60162c50(0x84,0);
  *(undefined1 *)(iVar2 + 1) = 1;
  return 0;
}

