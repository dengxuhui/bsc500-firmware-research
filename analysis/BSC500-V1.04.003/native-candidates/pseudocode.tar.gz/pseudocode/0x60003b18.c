
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60003b18(void)

{
  code *UNRECOVERED_JUMPTABLE;
  
  FUN_60006a20(_DAT_60003b38,6,1);
  UNRECOVERED_JUMPTABLE = _DAT_60003b3c;
  (*_DAT_60003b3c)(0);
  (*UNRECOVERED_JUMPTABLE)(1);
                    /* WARNING: Could not recover jumptable at 0x60003b36. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)(2);
  return;
}

