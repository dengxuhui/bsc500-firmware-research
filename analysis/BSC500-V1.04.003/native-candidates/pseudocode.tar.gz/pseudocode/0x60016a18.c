
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60016a18(void)

{
  undefined4 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uStack_24;
  undefined *puStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined1 uStack_14;
  
  uVar3 = _DAT_60016a60;
  iVar2 = _DAT_60016a5c;
  uStack_14 = 0;
  puVar1 = (undefined4 *)(_DAT_60016a5c + 8);
  *puVar1 = 0;
  uStack_1c = _DAT_60016a68;
  uStack_18 = _DAT_60016a64;
  *(undefined4 *)(iVar2 + 0xc) = uVar3;
  *(undefined4 *)(iVar2 + 0x10) = 0x7000;
  puStack_20 = &UNK_60016a6c;
  uStack_24 = _DAT_60016bc0;
  ZeroBytes(iVar2 + 0x14,0x14);
  FUN_6001e030(puVar1,&uStack_24,iVar2 + 0x14);
  return;
}

