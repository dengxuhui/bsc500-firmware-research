
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000adc4(void)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  undefined4 uVar6;
  int extraout_r1;
  int extraout_r2;
  int extraout_r3;
  int unaff_r4;
  int unaff_r5;
  undefined4 unaff_r7;
  undefined4 in_cr14;
  int iVar7;
  ushort uStack_12;
  
  uStack_12 = 0;
  iVar2 = FUN_6012c09c();
  if (iVar2 == 0) {
    return 0;
  }
  iVar2 = thunk_FUN_60162e34(100);
  if (iVar2 == 0) {
    if ((*puRam6000ae94 & 1) != 0) {
      software_bkpt(0);
    }
    bVar1 = (bool)isCurrentModePrivileged();
    if (bVar1) {
      isIRQinterruptsEnabled();
    }
    disableIRQinterrupts();
    FUN_6016804c(0x6000aea0,uRam6000ae9c,0x58);
  }
  else {
    FUN_60167214(iVar2,100);
    iVar3 = thunk_FUN_60162e34(800);
    unaff_r4 = iVar2;
    if (iVar3 != 0) {
      ZeroBytes(iVar3,800);
      FUN_60015a2c(uRam6000ae8c,&uStack_12,iVar3,0,0);
      uVar6 = uRam6000ae90;
      uVar4 = (uint)uStack_12;
      if (uVar4 != 0) {
        while( true ) {
          FUN_60160afc(uVar6,*(undefined4 *)(iVar3 + uVar4 * 4 + -4),0,iVar2);
          iVar5 = FUN_60163bbe(iVar2);
          if (iVar5 == 0) {
            uStack_12 = uStack_12 - 1;
          }
          if ((uStack_12 == 0) || (iVar5 = FUN_6012c09c(), iVar5 == 0)) break;
          uVar4 = (uint)uStack_12;
        }
      }
      FUN_6015e9c0(iVar3);
      uVar6 = FUN_6015e9c0(iVar2);
      return uVar6;
    }
  }
  if ((*puRam6000ae94 & 1) != 0) {
    software_bkpt(0);
  }
  bVar1 = (bool)isCurrentModePrivileged();
  if (bVar1) {
    isIRQinterruptsEnabled();
  }
  disableIRQinterrupts();
  FUN_6016804c(uRam6000ae98,uRam6000ae9c,0x5d);
  iVar5 = (int)*(char *)(extraout_r2 + extraout_r3);
  coprocessor_loadlong(0,in_cr14,0);
  *(short *)(unaff_r4 + 0x32) = (short)extraout_r3;
  *(undefined4 *)unaff_r7 = unaff_r7;
  *(short *)(iVar5 + 0x32) = (short)extraout_r2;
  *(undefined4 *)unaff_r7 = unaff_r7;
  iVar3 = unaff_r5 + -0x21;
  *(undefined4 *)(unaff_r4 + 0x60) = 0x30;
  *(int *)(unaff_r5 + -0xd) = iVar5;
  *(int *)(unaff_r5 + 0x33) = iVar3;
  *(char *)(iVar5 + 0x11) = (char)extraout_r3;
  iVar2 = _DAT_6000af00;
  uVar6 = 0xffffffff;
  if (extraout_r1 != 0) {
    iVar7 = extraout_r3;
    FUN_600163ec(0x30,extraout_r1,_DAT_6000af00 + 0x14);
    FUN_60016258(0x30,extraout_r1,_DAT_6000af04);
    uVar6 = _DAT_6000af08;
    FUN_600164d0(0x30,extraout_r1,_DAT_6000af08);
    FUN_60016164(0x30,extraout_r1,uVar6,iVar2,iVar7,unaff_r4,iVar3,iVar5);
    FUN_60016194(0x30,extraout_r1,iVar2 + 0x38);
    uVar6 = 0;
  }
  return uVar6;
}

