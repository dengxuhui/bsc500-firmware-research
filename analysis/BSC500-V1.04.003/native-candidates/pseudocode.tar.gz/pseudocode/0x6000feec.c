
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000feec(void)

{
  char *pcVar1;
  int iVar2;
  undefined4 uVar3;
  uint in_fpscr;
  undefined8 uVar4;
  undefined8 uVar5;
  undefined1 auStack_58 [24];
  undefined1 auStack_40 [24];
  undefined8 uStack_28;
  undefined8 uStack_20;
  float fStack_18;
  
  pcVar1 = _DAT_6000ffec;
  if ((((*_DAT_6000ffec == '\x02') && (iVar2 = func_0x60166dd0(_DAT_6000ffec + 0x48), iVar2 != 1))
      && (iVar2 = func_0x60166dd0(pcVar1 + 0x50), iVar2 != 1)) &&
     (iVar2 = FUN_601614a4(*(undefined4 *)(pcVar1 + 0x58)), iVar2 != 0)) {
    fStack_18 = (float)VectorSignedToFloat(*(undefined4 *)(pcVar1 + 0x58),
                                           (byte)(in_fpscr >> 0x16) & 3);
    fStack_18 = fStack_18 / _UNK_6000fff0;
    uVar4 = FUN_6016759c(*(undefined4 *)(pcVar1 + 0x48));
    uVar5 = FUN_6016759c(*(undefined4 *)(pcVar1 + 0x4c));
    uStack_28 = FUN_601675d8((int)uVar4,(int)((ulonglong)uVar4 >> 0x20),(int)uVar5,
                             (int)((ulonglong)uVar5 >> 0x20));
    uVar4 = FUN_6016759c(*(undefined4 *)(pcVar1 + 0x50));
    uVar5 = FUN_6016759c(*(undefined4 *)(pcVar1 + 0x54));
    uStack_20 = FUN_601675d8((int)uVar4,(int)((ulonglong)uVar4 >> 0x20),(int)uVar5,
                             (int)((ulonglong)uVar5 >> 0x20));
    ZeroBytes(auStack_40,0x18);
    ZeroBytes(auStack_58,0x18);
    iVar2 = FUN_6001a7f6(_DAT_6000fff4,&uStack_28,auStack_40);
    if (iVar2 == 0) {
      iVar2 = FUN_6001a884(pcVar1 + 8,auStack_40);
      if (iVar2 != 0) {
        FUN_601667bc(*(undefined4 *)(pcVar1 + 8));
        pcVar1[8] = '\0';
        pcVar1[9] = '\0';
        pcVar1[10] = '\0';
        pcVar1[0xb] = '\0';
        FUN_60163bbe(_DAT_6000fff8);
        *pcVar1 = '\x01';
        goto LAB_6000ffb8;
      }
      iVar2 = FUN_6001a500(pcVar1 + 0x28,auStack_40,auStack_58);
      if (iVar2 == 0) {
        FUN_6001a6b0(pcVar1 + 0x38,auStack_58);
        FUN_6001a630(pcVar1 + 0x1c,auStack_58);
        return 0;
      }
    }
    uVar3 = 1;
  }
  else {
LAB_6000ffb8:
    uVar3 = 0xffffffff;
  }
  return uVar3;
}

