
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000b748(void)

{
  int iVar1;
  char cVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint uVar10;
  int iVar11;
  undefined1 auStack_3c [20];
  
  uVar3 = FUN_601667d0();
  iVar4 = FUN_60166a10();
  uVar5 = FUN_601667d6();
  iVar1 = _DAT_6000bc24;
  FUN_60166a1c(uVar3,uVar5,_DAT_6000bc24 + 0x14);
  iVar11 = iVar1 + 0x24;
  ZeroBytes(iVar11,0x50);
  iVar9 = _DAT_6000bc28;
  ZeroBytes(_DAT_6000bc28,0x50);
  iVar6 = func_0x6016717c();
  cVar2 = *(char *)(iVar1 + 0x14);
  if (((iVar4 == 0) || (cVar2 == '\r')) || (*(ushort *)(iVar1 + 0x1a) <= *(ushort *)(iVar1 + 0x18)))
  {
    uVar8 = 0;
    uVar7 = 0;
  }
  else {
    FUN_60165170();
    uVar7 = (uint)*(byte *)(iVar1 + 0x14);
    if (uVar7 - 6 < 7) {
                    /* WARNING: Could not recover jumptable at 0x6000b7be. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)(&UNK_6000b7c2 + (uint)*(byte *)(uVar7 + 0x6000b7bc) * 2))();
      return;
    }
    if (uVar7 - 6 < 5) {
                    /* WARNING: Could not recover jumptable at 0x6000b8f6. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)(&UNK_6000b8fa + (uint)*(byte *)(uVar7 + 0x6000b8f4) * 2))();
      return;
    }
    uVar7 = FUN_6016811c(iVar1 + 0x28,0);
    uVar8 = FUN_6016811c(iVar9 + 4);
    cVar2 = *(char *)(iVar1 + 0x14);
  }
  switch(cVar2) {
  case '\x06':
  case '\t':
    FormatRideField(iVar11,0x301,1);
    iVar9 = func_0x6016727c(iVar1 + 0x28,_UNK_6000bc34,3);
    if (iVar9 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_6016811c(iVar1 + 0x28);
    }
    if ((int)uVar8 <= (int)uVar7) {
      return;
    }
    if (((iVar9 != 0) && (uVar10 < uVar7)) && (*(int *)(iVar1 + 8) != 8)) {
      ZeroBytes(auStack_3c,0x14);
      FUN_600f816c(1,uVar10,auStack_3c);
      FUN_60163e70(_UNK_6000bc38 + 1,auStack_3c,0);
      uVar3 = 8;
      break;
    }
    if (((iVar9 != 0) && (uVar8 < uVar10)) && (*(int *)(iVar1 + 8) != 10)) {
      ZeroBytes(auStack_3c,0x14);
      FUN_600f816c(1,uVar10,auStack_3c);
      iVar9 = _UNK_6000bc38;
      goto code_r0x6000bb5e;
    }
code_r0x6000bc04:
    iVar9 = *(int *)(iVar1 + 0xc);
    goto code_r0x6000bc08;
  case '\a':
  case '\n':
    FormatRideField(iVar11,0x401,1);
    iVar9 = func_0x6016727c(iVar1 + 0x28,_UNK_6000bc34,3);
    if (iVar9 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_6016811c(iVar1 + 0x28);
    }
    if ((int)uVar8 <= (int)uVar7) {
      return;
    }
    if (((iVar9 == 0) || (uVar7 <= uVar10)) || (*(int *)(iVar1 + 8) == 9)) {
      if (((iVar9 == 0) || (uVar10 <= uVar8)) || (*(int *)(iVar1 + 8) == 0xb))
      goto code_r0x6000bc04;
      ZeroBytes(auStack_3c,0x14);
      FUN_600f816c(3,uVar10,auStack_3c);
      iVar9 = _UNK_6000bc38 + 2;
code_r0x6000bb96:
      FUN_60163e70(iVar9,auStack_3c,0);
      uVar3 = 0xb;
    }
    else {
      ZeroBytes(auStack_3c,0x14);
      FUN_600f816c(3,uVar10,auStack_3c);
      FUN_60163e70(_UNK_6000bc38 + 3,auStack_3c,0);
      uVar3 = 9;
    }
    break;
  default:
    goto LAB_6000bc1a;
  case '\v':
    FormatRideField(iVar11,0x101,1);
    iVar9 = func_0x6016727c(iVar1 + 0x28,_UNK_6000bc34,3);
    if (iVar9 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_6016811c(iVar1 + 0x28);
    }
    if ((int)uVar8 <= (int)uVar7) {
      return;
    }
    if (((iVar9 == 0) || (uVar7 <= uVar10)) || (*(int *)(iVar1 + 8) == 10)) {
      if (((iVar9 == 0) || (uVar10 <= uVar8)) || (*(int *)(iVar1 + 8) == 0xc))
      goto code_r0x6000bc04;
      ZeroBytes(auStack_3c,0x14);
      FUN_600f816c(4,uVar10,auStack_3c);
      FUN_60163e70(_UNK_6000bc38 + 4,auStack_3c,0);
      uVar3 = 0xc;
    }
    else {
      ZeroBytes(auStack_3c,0x14);
      FUN_600f816c(4,uVar10,auStack_3c);
      iVar9 = _UNK_6000bc38 + 5;
code_r0x6000bb5e:
      FUN_60163e70(iVar9,auStack_3c,0);
      uVar3 = 10;
    }
    break;
  case '\f':
    FormatRideField(iVar11,0x201,1);
    iVar9 = func_0x6016727c(iVar1 + 0x28,_UNK_6000bc34,3);
    if (iVar9 == 0) {
      uVar10 = 0;
    }
    else {
      uVar10 = FUN_6016811c(iVar1 + 0x28);
    }
    if ((int)uVar8 <= (int)uVar7) {
      return;
    }
    if (((iVar9 != 0) && (uVar10 < uVar7)) && (*(int *)(iVar1 + 8) != 0xb)) {
      ZeroBytes(auStack_3c,0x14);
      FUN_600f816c(2,uVar10,auStack_3c);
      iVar9 = _UNK_6000bc38 + 7;
      goto code_r0x6000bb96;
    }
    if (((iVar9 == 0) || (uVar10 <= uVar8)) || (*(int *)(iVar1 + 8) == 0xd)) goto code_r0x6000bc04;
    ZeroBytes(auStack_3c,0x14);
    FUN_600f816c(2,uVar10,auStack_3c);
    FUN_60163e70(_UNK_6000bc38 + 6,auStack_3c,0);
    uVar3 = 0xd;
  }
  *(undefined4 *)(iVar1 + 8) = uVar3;
  *(int *)(iVar1 + 0xc) = iVar6;
  iVar9 = iVar6;
code_r0x6000bc08:
  if (59999 < (uint)(iVar6 - iVar9)) {
    *(undefined4 *)(iVar1 + 8) = 0;
  }
LAB_6000bc1a:
  return;
}

