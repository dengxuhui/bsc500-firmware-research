
/* WARNING: Removing unreachable block (ram,0x601130b4) */
/* WARNING: Removing unreachable block (ram,0x6011308c) */
/* WARNING: Removing unreachable block (ram,0x6011315c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60018cbc(float param_1,uint *param_2)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  int iVar5;
  int iVar6;
  float *pfVar7;
  uint uVar8;
  uint uVar9;
  float *pfVar10;
  undefined4 in_cr0;
  undefined4 in_cr8;
  float fVar11;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  uint in_s14;
  float fVar16;
  undefined8 uStack_38;
  
  uVar1 = _DAT_601131ec;
  iVar5 = _DAT_60018cc8;
  piVar2 = (int *)(_DAT_60018cc8 + 0x18);
  if (piVar2 == (int *)0x0) {
    return 0xffffffff;
  }
  if (param_2 == (uint *)0x0) {
    return 0xffffffff;
  }
  param_2[7] = _DAT_601131ec;
  *param_2 = 0xffffffff;
  param_2[1] = 0xffffffff;
  iVar3 = 0;
  piVar4 = *(int **)(iVar5 + 0x20);
  param_2[2] = 0;
  iVar6 = piVar4[1];
  fVar16 = *(float *)(*piVar4 + iVar6 * 0x10 + -0xc);
  fVar11 = fVar16 - param_1;
  coprocessor_function2(10,0,0,in_cr0,in_cr0,in_cr8);
  for (; iVar6 != 0; iVar6 = iVar6 + -1) {
    pfVar7 = (float *)(*piVar4 + iVar3);
    if ((*pfVar7 <= fVar11) && (fVar11 <= pfVar7[1])) {
      uStack_38 = (ulonglong)in_s14;
      uVar8 = *(uint *)(iVar3 + *piVar4 + 8);
      uVar9 = *(uint *)(iVar3 + *piVar4 + 0xc);
      goto LAB_6011307a;
    }
    iVar3 = iVar3 + 0x10;
  }
  uVar8 = 0xffffffff;
LAB_6011305e:
  param_2[2] = uVar8;
  return 1;
LAB_6011307a:
  if (uVar9 <= uVar8) {
    return 1;
  }
  iVar3 = FUN_60116860(fVar16,*(undefined4 *)(iVar5 + 0x1c),uVar8,(int)&uStack_38 + 4);
  if (iVar3 != 0) {
    param_2[7] = uVar1;
    param_2[1] = 0xffffffff;
    param_2[2] = 0xffffffff;
    return 0xffffffff;
  }
  fVar11 = (float)uStack_38._4_4_[2];
  if (param_1 < fVar11) {
    param_2[7] = (uint)(fVar11 - param_1);
    piVar2 = (int *)*piVar2;
    param_2[1] = uVar8;
    uVar8 = *piVar2 - uVar8;
    goto LAB_6011305e;
  }
  fVar12 = (float)uStack_38._4_4_[3];
  if (param_1 <= fVar12) {
    pfVar10 = (float *)*uStack_38._4_4_;
    iVar5 = 0;
    pfVar7 = pfVar10;
    goto LAB_601130f6;
  }
  uVar8 = uVar8 + 1;
  goto LAB_6011307a;
LAB_601130f6:
  if (uStack_38._4_4_[1] + -1 == iVar5) {
    fVar16 = *pfVar10;
    fVar13 = pfVar10[3];
    iVar5 = 0;
LAB_60113130:
    fVar13 = pfVar10[iVar5 * 3 + 2] +
             ((param_1 - fVar16) * (pfVar10[iVar5 * 3 + 5] - pfVar10[iVar5 * 3 + 2])) /
             (fVar13 - fVar16);
    iVar5 = *piVar2;
    fVar15 = (float)uStack_38._4_4_[0xc];
    fVar14 = (float)uStack_38._4_4_[0xb];
    *param_2 = uVar8;
    fVar16 = *(float *)(iVar5 + 4);
    param_2[5] = (uint)(*(float *)(iVar5 + 8) + ((fVar11 - param_1) - fVar15));
    param_2[6] = (uint)(fVar16 - (fVar13 + fVar14));
    param_2[3] = (uint)(fVar12 - param_1);
    uVar9 = *(uint *)*piVar2;
    param_2[4] = (uint)((float)uStack_38._4_4_[8] - fVar13);
    if (uVar8 + 1 < uVar9) {
      param_2[1] = uVar8 + 1;
      uVar9 = uVar9 - uVar8;
    }
    else {
      param_2[1] = 0xffffffff;
      uVar9 = 1;
    }
    param_2[2] = uVar9;
    param_2[7] = uVar1;
    return 0;
  }
  fVar16 = *pfVar7;
  if ((fVar16 <= param_1) && (fVar13 = pfVar7[3], param_1 <= fVar13)) goto LAB_60113130;
  iVar5 = iVar5 + 1;
  pfVar7 = pfVar7 + 3;
  goto LAB_601130f6;
}

