
/* WARNING: Removing unreachable block (ram,0x60016d18) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60008614(void)

{
  undefined4 uVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int *piVar5;
  undefined4 unaff_r4;
  undefined1 *puVar6;
  int *piVar7;
  undefined4 unaff_lr;
  
  uVar1 = _DAT_6000866c;
  puVar6 = _DAT_60008664 + 0x18;
  *_DAT_60008664 = 0;
  FUN_6016572c(_DAT_60008668,1,uVar1);
  FUN_6016507e(puVar6,1000,0);
  uVar1 = _DAT_60008670;
  FUN_6015f550(_DAT_60008670);
  FUN_6015f564(uVar1);
  FUN_60166868(_DAT_60008674);
  iVar4 = _DAT_60008678;
  FUN_60166898(_DAT_60008678);
  FUN_60011468(iVar4 + 0x18);
  piVar2 = (int *)(iVar4 + 0x30);
  func_0x60167f3c(6,_DAT_601678ec,1,&UNK_601678f0,&UNK_601678cc,*piVar2,unaff_r4,unaff_lr);
  piVar5 = _DAT_601678f8;
  if (_DAT_601678f8 == (int *)0x0) {
    return (int *)0x0;
  }
  if (piVar2 == (int *)0x0) {
    return _DAT_601678f8;
  }
  iVar3 = _DAT_601678f8[2];
  if (iVar3 == 0) {
    iVar3 = FUN_60168494(0);
    piVar5[2] = iVar3;
    if (iVar3 == 0) goto code_r0x60016cf2;
  }
  FUN_6016825e(iVar3,0xffffffff);
code_r0x60016cf2:
  piVar7 = (int *)*piVar5;
  if (piVar7 != piVar5) {
    for (; piVar7 != piVar5; piVar7 = (int *)*piVar7) {
      if (((piVar7 + -2 == piVar2) && (piVar7[2] != 0)) &&
         (iVar3 = FUN_60168418(piVar7[-2],*piVar2), iVar3 == 0)) goto code_r0x60016d2e;
    }
  }
  iVar3 = iVar4 + 0x38;
  *(int *)(iVar4 + 0x3c) = iVar3;
  *(uint *)(iVar4 + 0x34) = (uint)*(byte *)(iVar4 + 0x34);
  piVar2 = (int *)piVar5[1];
  *piVar2 = iVar3;
  *(int **)(iVar4 + 0x38) = piVar5;
  *(int **)(iVar4 + 0x3c) = piVar2;
  piVar5[1] = iVar3;
code_r0x60016d2e:
  iVar4 = piVar5[2];
  if (iVar4 == 0) {
    return (int *)0x0;
  }
  if (iVar4 != 0) {
    iVar4 = func_0x60165418(iVar4 + 4);
    piVar5 = (int *)0x0;
    if (iVar4 != 0) {
      piVar5 = (int *)0xfffffffd;
    }
    return piVar5;
  }
  return (int *)0xfffffffc;
}

