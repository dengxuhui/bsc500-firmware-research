
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_6000f764(undefined1 *param_1,undefined1 *param_2)

{
  undefined1 uVar1;
  char cVar2;
  ushort uVar3;
  undefined4 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined2 uVar7;
  undefined4 uVar8;
  undefined1 *puVar9;
  int iVar10;
  undefined4 *unaff_r7;
  undefined4 uVar11;
  undefined4 uVar12;
  
  uVar4 = 2;
  if ((param_1 == (undefined1 *)0x0) || (param_2 == (undefined1 *)0x0)) goto LAB_6000f8b4;
  if ((param_1[1] == '\x04') && (*(int *)(param_2 + 0x88) == 0)) {
    return CONCAT44(param_2,2);
  }
  CopyBytes(param_1 + 8,param_2 + 8,0x20);
  *(undefined4 *)(param_1 + 0x58) = *(undefined4 *)(param_2 + 0x8c);
  param_1[0x28] = *param_2;
  uVar4 = *(undefined4 *)(param_2 + 4);
  *(undefined4 *)(param_1 + 0x30) = *(undefined4 *)(param_2 + 1);
  *(undefined4 *)(param_1 + 0x33) = uVar4;
  if (param_1[8] == '\x03') {
    uVar1 = 1;
  }
  else if (param_1[8] == '\x04') {
    uVar1 = 2;
  }
  else {
    uVar1 = 0;
  }
  param_1[0x29] = uVar1;
  param_1[0x2a] = 1;
  *(undefined2 *)(param_1 + 0x40) = 0x107;
  param_1[0x2f] = 0;
  uVar1 = param_2[8];
  param_1[0x2e] = param_2[0x24];
  param_1[1] = uVar1;
  switch(uVar1) {
  case 0:
    *(undefined2 *)(param_1 + 0x2c) = 3;
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    break;
  case 1:
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    uVar3 = (ushort)(param_1[0x14] != '\0') << 1;
    goto code_r0x6000f860;
  case 2:
    uVar7 = 0xd;
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x14);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x14);
    if (param_1[0xc] == '\0') {
      uVar7 = 5;
    }
    *(undefined2 *)(param_1 + 0x2c) = uVar7;
    goto LAB_6000f8a8;
  case 3:
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    param_1[0x44] = param_1[0x14];
    *(undefined2 *)(param_1 + 0x45) = *(undefined2 *)(param_1 + 0x15);
    uVar3 = (ushort)(byte)param_1[0x17];
    if (param_1[0x17] != 0) {
      uVar3 = 1;
    }
code_r0x6000f860:
    *(ushort *)(param_1 + 0x2c) = uVar3;
    break;
  case 4:
    *(undefined2 *)(param_1 + 0x2c) = 0;
    *(undefined4 *)(param_1 + 0x38) = *(undefined4 *)(param_1 + 0x10);
    *(undefined4 *)(param_1 + 0x3c) = *(undefined4 *)(param_1 + 0x10);
    param_1[0x44] = param_1[0x14];
    *(undefined2 *)(param_1 + 0x45) = *(undefined2 *)(param_1 + 0x15);
    *(undefined4 *)(param_1 + 0x48) = *(undefined4 *)(param_1 + 0x18);
  }
  puVar9 = param_2 + 0x28;
  FUN_6013ac30(param_1,puVar9,0);
  cVar2 = param_1[1];
  if (cVar2 == '\0') {
    if (param_1[0x27] == '\0') {
      puVar9 = param_2 + 0x58;
    }
    FUN_6013ac30(param_1,puVar9,1);
    cVar2 = param_1[1];
  }
  if (cVar2 == '\x04') {
    iVar5 = thunk_FUN_60162e34(**(ushort **)(param_2 + 0x88) + 4);
    *(int *)(param_1 + 0x54) = iVar5;
    if (iVar5 == 0) {
      FUN_6016804c(uRam6000f8c4,0x6000f8c8,0x139);
      *unaff_r7 = puVar9;
      iVar5 = *(int *)(puVar9 + 0x14);
      uVar4 = *(undefined4 *)(param_1 + 0x44);
      param_1[0xd] = (char)param_2;
      *(undefined4 **)(iVar5 + 0x14) = unaff_r7;
      param_1[0x19] = (char)param_1;
      param_1[9] = (char)param_2;
      uVar8 = *(undefined4 *)(puVar9 + 0x14);
      *(undefined1 **)(param_2 + 0x74) = puVar9;
      iVar5 = _DAT_6000f8f4;
      iVar10 = *(int *)(param_2 + 0x14);
      *(undefined4 *)(_DAT_6000f8f4 + 0x154) = 0;
      *(undefined2 *)(iVar5 + 6) = 0x801;
      uVar6 = FUN_60165098(&UNK_60019ee4,0,0,uVar8,iVar5,0x801,uVar4,uVar8,iVar10 << 1,0x6000f8c3);
      uVar8 = _DAT_60019f04;
      uVar4 = _DAT_60019f00;
      iVar5 = _DAT_60019ef0;
      uVar11 = 0x1000;
      uVar12 = 8;
      *(undefined4 *)(_DAT_60019ef0 + 0xc) = uVar6;
      uVar4 = FUN_6001fd8c(&UNK_60019ef4,uVar4,0,uVar8,0x1000,8,10);
      *(undefined4 *)(iVar5 + 0x10) = uVar4;
      return CONCAT44(uVar12,uVar11);
    }
    *(undefined2 *)(iVar5 + 2) = **(undefined2 **)(param_2 + 0x88);
  }
LAB_6000f8a8:
  uVar4 = 0;
  *param_1 = 1;
  param_2 = (undefined1 *)0xff;
  param_1[6] = 0;
  param_1[4] = 0xff;
LAB_6000f8b4:
  return CONCAT44(param_2,uVar4);
}

