
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018a94(void)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  undefined4 *puVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 *puVar7;
  undefined4 *puVar8;
  int *piVar9;
  int iVar10;
  int iVar11;
  int iVar12;
  int iVar13;
  int iVar14;
  
  puVar8 = _DAT_60018ce0;
  puVar7 = _DAT_60018cc8;
  _DAT_60018cc8[0xd] = _DAT_60018c58;
  puVar7[0xe] = 300;
  uVar2 = _DAT_60018c5c;
  puVar8[0x15] = 0;
  puVar8[0x12] = 0;
  puVar8[6] = 0;
  puVar8[4] = 0;
  puVar8[2] = 0;
  *puVar8 = 0;
  puVar7[0xc] = uVar2;
  FUN_6013a776(puVar7 + 0xc);
  puVar3 = _DAT_60018c60;
  _DAT_60018c60[0x18] = 0x3f800000;
  FUN_6013a76e(puVar3 + 0x12);
  uVar2 = _DAT_60018c64;
  puVar7[0x14] = 0x14;
  puVar7[0x11] = 100;
  puVar7[0x10] = uVar2;
  FUN_6013a760(puVar7 + 0x10);
  uVar6 = _DAT_60018c78;
  uVar5 = _DAT_60018c74;
  uVar2 = _DAT_60018c70;
  puVar4 = _DAT_60018c68;
  _DAT_60018c68[0x23] = _DAT_60018c6c;
  puVar4[0x21] = _DAT_60018ea8;
  puVar4[5] = uVar6;
  puVar4[6] = uVar5;
  uVar6 = _DAT_60018c80;
  uVar5 = _DAT_60018c7c;
  puVar4[7] = uVar2;
  puVar4[8] = 0x32;
  *puVar4 = uVar6;
  puVar4[1] = uVar5;
  puVar4[2] = uVar2;
  puVar4[3] = 0x32;
  FUN_6013a752();
  puVar7[0x16] = _DAT_60018c84;
  puVar7[0x1a] = 8;
  puVar7[0x17] = 0x14;
  FUN_6013a744();
  uVar2 = _DAT_60018c88;
  puVar3[4] = 8;
  *puVar3 = uVar2;
  puVar3[1] = 0x14;
  FUN_6013a744(puVar3);
  piVar9 = _DAT_60018dbc;
  iVar11 = _DAT_60018c94;
  _DAT_60018dbc[8] = _DAT_60018c8c;
  piVar9[0xc] = _DAT_60018c90;
  piVar9[0x11] = 0;
  piVar9[0xf] = 100;
  piVar9[9] = iVar11;
  piVar9[10] = 0x78;
  FUN_6013a6e6();
  FUN_6013a6f4(puVar8 + 0x18);
  FUN_6013a6f4(puVar8 + 0x1b);
  iVar14 = _DAT_60018ca4;
  iVar11 = _DAT_60018ca0;
  iVar10 = _DAT_60018c98;
  iVar12 = _DAT_60018c9c;
  for (iVar13 = 0; iVar13 != 0x208; iVar13 = iVar13 + 0x34) {
    *(int *)(iVar11 + iVar13) = iVar10;
    *(int *)(iVar14 + iVar13) = iVar12;
    iVar12 = iVar12 + 0x5a0;
    iVar10 = iVar10 + 0x5a0;
  }
  piVar9[7] = 10;
  piVar9[3] = 10;
  piVar9[4] = iVar11;
  *piVar9 = iVar14;
  puVar3[6] = piVar9;
  puVar3[0xb] = 0;
  puVar3[7] = puVar8 + 0x12;
  puVar3[8] = 2;
  FUN_6013a6de();
  puVar8[8] = _DAT_60018c5c;
  puVar8[9] = 300;
  uVar6 = _DAT_60018cb0;
  puVar8[10] = _DAT_60018c64;
  puVar8[0xb] = 100;
  puVar8[0xc] = _DAT_60018c84;
  puVar8[0xd] = 0x14;
  uVar5 = _DAT_60018ca8;
  puVar8[0xe] = uVar2;
  puVar8[0xf] = 0x14;
  *puVar7 = uVar5;
  puVar7[1] = 0x32;
  puVar4 = _DAT_60018cac;
  puVar7[2] = 0;
  *puVar4 = uVar6;
  puVar4[1] = 0x78;
  iVar11 = _DAT_60018cb4;
  for (iVar14 = 0; iVar14 != 0x40; iVar14 = iVar14 + 0x10) {
    *(int *)((int)puVar4 + iVar14 + 0x34) = iVar11;
    *(undefined4 *)((int)puVar4 + iVar14 + 0x40) = 100;
    iVar11 = iVar11 + 800;
  }
  puVar1 = puVar3 + 0xc;
  *puVar1 = puVar4 + 0xd;
  puVar3[0x11] = 0;
  puVar3[0xd] = puVar8 + 0x12;
  puVar3[0xe] = 4;
  FUN_6013a6d6(puVar1);
  piVar9[0x12] = (int)puVar1;
  iVar11 = _DAT_60018cb8;
  piVar9[0x17] = 100;
  piVar9[0x13] = (int)(puVar8 + 10);
  piVar9[0x14] = iVar11;
  FUN_6013a6c4(piVar9 + 0x12);
  puVar8[0x10] = iVar11;
  puVar8[0x11] = 0;
  puVar7[6] = puVar7 + 3;
  puVar7[7] = puVar3 + 6;
  puVar7[8] = puVar8 + 0xc;
  if (puVar7 + 6 != (undefined4 *)0x0) {
    piVar9 = (int *)puVar7[7];
    if (piVar9 != (int *)0x0) {
      if (piVar9 != (int *)0x0) {
        iVar14 = 0;
        piVar9[3] = 0;
        piVar9[4] = 0;
        for (iVar11 = piVar9[2]; iVar11 != 0; iVar11 = iVar11 + -1) {
          if (*piVar9 != 0) {
            iVar10 = *piVar9 + iVar14;
            *(undefined4 *)(iVar10 + 4) = 0;
            *(undefined4 *)(iVar10 + 8) = 0;
          }
          iVar14 = iVar14 + 0x10;
        }
      }
      return;
    }
    return;
  }
  return;
}

