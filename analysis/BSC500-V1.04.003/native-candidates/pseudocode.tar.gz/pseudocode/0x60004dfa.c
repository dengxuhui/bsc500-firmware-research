
undefined8 FUN_60004dfa(int *param_1,int *param_2,uint param_3,uint param_4)

{
  byte bStack_20;
  byte bStack_1f;
  byte bStack_1e;
  byte bStack_1d;
  byte bStack_1c;
  byte bStack_1b;
  byte bStack_1a;
  byte bStack_19;
  uint uStack_18;
  uint uStack_14;
  
  bStack_1c = (byte)param_2;
  bStack_1b = (byte)((uint)param_2 >> 8);
  bStack_1a = (byte)((uint)param_2 >> 0x10);
  bStack_19 = (byte)((uint)param_2 >> 0x18);
  bStack_20 = (byte)param_1;
  bStack_1f = (byte)((uint)param_1 >> 8);
  bStack_1e = (byte)((uint)param_1 >> 0x10);
  bStack_1d = (byte)((uint)param_1 >> 0x18);
  uStack_18 = param_3;
  uStack_14 = param_4;
  FUN_6000ea30(0x10000000,&bStack_20,0x10);
  *param_1 = ((uint)bStack_1d + (uint)bStack_1e) * 0x10000 +
             ((uint)bStack_20 + (uint)bStack_1f) * 0x1000000 + (uint)bStack_1a +
             ((uint)bStack_1c + (uint)bStack_1b) * 0x100 + (uint)bStack_19;
  *param_2 = ((uStack_18 >> 0x10 & 0xff) + (uStack_18 >> 0x18)) * 0x10000 +
             ((uStack_18 & 0xff) + (uStack_18 >> 8 & 0xff)) * 0x1000000 + (uStack_14 >> 0x10 & 0xff)
             + ((uStack_14 & 0xff) + (uStack_14 >> 8 & 0xff)) * 0x100 + (uStack_14 >> 0x18);
  return CONCAT17(bStack_19,
                  CONCAT16(bStack_1a,
                           CONCAT15(bStack_1b,
                                    CONCAT14(bStack_1c,
                                             CONCAT13(bStack_1d,
                                                      CONCAT12(bStack_1e,
                                                               CONCAT11(bStack_1f,bStack_20)))))));
}

