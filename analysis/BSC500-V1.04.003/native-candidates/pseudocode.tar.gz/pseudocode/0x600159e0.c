
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Instruction at (ram,0x60168084) overlaps instruction at (ram,0x60168082)
    */
/* WARNING: Removing unreachable block (ram,0x6016813c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600159e0(void)

{
  bool bVar1;
  bool bVar2;
  byte bVar3;
  uint uVar4;
  undefined1 uVar5;
  int iVar6;
  int iVar7;
  int extraout_r1;
  int extraout_r2;
  int extraout_r3;
  int unaff_r4;
  int iVar8;
  int unaff_r5;
  int unaff_r6;
  undefined4 uVar9;
  undefined4 *unaff_r7;
  undefined4 unaff_r8;
  char *unaff_r9;
  undefined1 *puVar10;
  undefined1 *puVar11;
  undefined8 in_d24;
  undefined8 uVar12;
  
  FUN_6001fc18();
  uVar12 = FUN_60167f4a(&UNK_60015a08,_DAT_60015a18,0,0x2800);
  iVar8 = (int)uVar12;
  if (iVar8 == 0) {
    return 0;
  }
  puVar10 = &stack0xfffffff8;
  if (iVar8 == 0) {
    FUN_6016804c(uRam60168048,uRam6016803c,0x10f,5);
LAB_60167fec:
    FUN_6016804c(0x60168004,uRam6016803c,0x110);
  }
  else {
    unaff_r4 = iVar8;
    if ((*(byte *)(iVar8 + 0x3c) & 0xf) != 0) goto LAB_60167fec;
    iVar6 = FUN_601631fc(iVar8,(int)((ulonglong)uVar12 >> 0x20),10);
    if (iVar6 == 1) {
      *(undefined1 *)(iVar8 + 0x3c) = 2;
      bVar3 = *(byte *)(iVar8 + 0x3e);
      *(byte *)(iVar8 + 0x3d) = bVar3;
      *(byte *)(iVar8 + 0x3f) = bVar3 >> 3;
      *(char *)(iVar8 + 0x40) = (char)(1 << (bVar3 & 7));
      *(int *)(iVar8 + 0x44) = 1 << (uint)(bVar3 >> 3);
      FUN_60165744(iVar8);
      if (*piRam60168044 != 0) {
        func_0x60163a08();
      }
      return 0;
    }
  }
  uVar5 = FUN_6016804c(uRam60168040,uRam6016803c,0x111);
  *(undefined1 *)(unaff_r5 + 0x10) = uVar5;
  *(undefined1 *)(unaff_r5 + 9) = uVar5;
  *(int *)(unaff_r4 + 0x14) = unaff_r5;
  *(char *)(unaff_r7 + 3) = (char)unaff_r6;
  *(int *)(unaff_r6 + 0x14) = unaff_r4;
  *(char *)(extraout_r2 + extraout_r1) = (char)extraout_r2;
  *(char *)(extraout_r3 + extraout_r1) = (char)unaff_r7;
  *(undefined2 *)(extraout_r1 * 2) = 0x26;
  *(char *)(extraout_r2 + extraout_r1) = (char)extraout_r3;
  *(char *)(extraout_r1 + 0x26) = (char)extraout_r1;
  uVar4 = _DAT_601681a0;
  *(short *)(_DAT_601681a0 + 0x26) = (short)extraout_r1;
  *(char *)(extraout_r2 + extraout_r1) = (char)extraout_r2;
  *(char *)(extraout_r3 + extraout_r1) = (char)unaff_r7;
  *(undefined2 *)(extraout_r1 * 2) = 0x3d;
  uVar9 = uRam6016815c;
  bVar1 = 0xffffffc2 < uVar4 - 0x20;
  bVar2 = CARRY4(uVar4 + 0x1d,(uint)(0x1f < uVar4));
  iVar6 = uVar4 + 0x1d + (uint)(0x1f < uVar4);
  iVar8 = (int)*(short *)(iVar6 + 0x3d);
  *(char *)(extraout_r1 * 2) = (char)extraout_r1;
  iVar7 = 0x3d;
  if (bVar1 || bVar2) {
    *unaff_r7 = uVar9;
    if (bVar1 || bVar2) {
                    /* WARNING: Bad instruction - Truncating control flow here */
      halt_baddata();
    }
    *unaff_r7 = uVar9;
    *unaff_r7 = uVar9;
    puVar10 = &stack0xfffffff0;
    uVar9 = 0;
    FUN_60004a70(0);
    unaff_r8 = FUN_60167d0c();
    unaff_r9 = _DAT_601680c8;
    if (*_DAT_601680c8 == '\x01') {
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    iVar7 = *(int *)(_DAT_601680c8 + 4);
    *_DAT_601680c8 = '\x01';
    iVar8 = extraout_r2;
    iVar6 = extraout_r1;
    puVar11 = &stack0xfffffff0;
    if (iVar7 == 0) goto LAB_6016808e;
    func_0x60166fac(iVar7);
  }
  else {
    VectorShiftLeft(in_d24,3,0x10,1);
  }
  func_0x60166e68(iVar7,0x43);
  puVar11 = puVar10;
LAB_6016808e:
  FUN_6013dd48();
  func_0x60168578(&UNK_601680cc,iVar6,iVar8,uVar9);
  func_0x60168578(&UNK_60168104,unaff_r8);
  FUN_60130f7c();
  if (*(code **)(unaff_r9 + 0xc) != (code *)0x0) {
    (**(code **)(unaff_r9 + 0xc))(uVar9,iVar6,iVar8);
  }
  FUN_60167e94();
  do {
  } while (puVar11[7] == '\0');
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

