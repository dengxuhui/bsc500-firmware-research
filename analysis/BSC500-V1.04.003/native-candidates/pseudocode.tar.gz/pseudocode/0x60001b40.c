
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001b40(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 uStack_1c;
  undefined *puStack_18;
  
  uStack_1c = param_3;
  puStack_18 = (undefined *)param_4;
  FUN_60001b7c();
  puStack_18 = &UNK_60001b68;
  uStack_1c = 0x20;
  FUN_60001c04(&uStack_1c,_DAT_60001b78);
  return;
}

