
void FUN_60019568(undefined4 param_1)

{
  undefined2 uStack_24;
  undefined1 uStack_22;
  undefined1 uStack_21;
  undefined2 uStack_20;
  undefined1 uStack_1d;
  undefined1 uStack_17;
  undefined1 uStack_16;
  undefined1 uStack_15;
  undefined1 uStack_14;
  undefined1 uStack_11;
  
  FUN_60166858(&uStack_21,0x11,0xff);
  uStack_17 = (undefined1)param_1;
  uStack_1d = 0;
  uStack_22 = 0;
  uStack_20 = 5;
  uStack_24 = 0x1903;
  uStack_14 = (undefined1)((uint)param_1 >> 0x18);
  uStack_15 = (undefined1)((uint)param_1 >> 0x10);
  uStack_16 = (undefined1)((uint)param_1 >> 8);
  uStack_11 = FUN_60160db4(&uStack_24,0x13);
  FUN_6015e018(&uStack_24);
  return;
}

