
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d874(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = _DAT_6000d88c;
  if (param_1 != (undefined4 *)0x0) {
    param_1[2] = _DAT_6000d890;
    param_1[3] = uVar1;
    *(undefined2 *)(param_1 + 1) = 0xffff;
    *param_1 = 0xffffffff;
  }
  return;
}

