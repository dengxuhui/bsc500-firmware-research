
undefined8 FUN_6000bf1c(undefined4 param_1,undefined4 param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  uVar2 = 0;
  uStack_1c = 0;
  uStack_24 = 0;
  uStack_20 = 0;
  if (param_3 == 0) {
    param_3 = 1;
  }
  while ((uVar2 < param_3 && (iVar1 = FUN_6013388a(param_1,&uStack_24,0,param_2), iVar1 == 0))) {
    FUN_6000bf56(&uStack_24);
    uVar2 = uVar2 + 1;
  }
  return CONCAT44(uStack_24,param_1);
}

