
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60010b28(int param_1,int param_2,undefined4 param_3)

{
  undefined1 *puVar1;
  int iVar2;
  
  puVar1 = _DAT_60010b5c;
  *(undefined4 *)(_DAT_60010b5c + 4) = param_3;
  iVar2 = param_1;
  if (param_1 < 0) {
    iVar2 = -param_1;
  }
  if (iVar2 < _DAT_60010b60 + 1) {
    iVar2 = param_2;
    if (param_2 < 0) {
      iVar2 = -param_2;
    }
    if ((param_1 != param_2) && (iVar2 <= _DAT_60010b60)) {
      *(int *)(puVar1 + 8) = param_1;
      *(int *)(puVar1 + 0xc) = param_2;
      *puVar1 = 1;
    }
  }
  return;
}

