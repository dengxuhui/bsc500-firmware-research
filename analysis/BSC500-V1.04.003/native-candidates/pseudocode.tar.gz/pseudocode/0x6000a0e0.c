
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a0e0(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = _DAT_6000a0f8;
  if (param_1 != (undefined4 *)0x0) {
    param_1[2] = _DAT_6000a0fc;
    param_1[3] = uVar1;
    *(undefined1 *)(param_1 + 1) = 0xff;
    *param_1 = 0xffffffff;
  }
  return;
}

