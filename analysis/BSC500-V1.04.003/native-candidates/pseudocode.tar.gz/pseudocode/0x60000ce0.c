
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000ce0(void)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  
  uVar3 = _DAT_60000ee0;
  iVar1 = _DAT_60000d10;
  *(undefined1 *)(_DAT_60000d10 + 0x11c) = 1;
  *(undefined1 *)(iVar1 + 0x2a8) = 1;
  *(undefined1 *)(iVar1 + 0x434) = 1;
  iVar2 = _DAT_60000d14;
  iVar4 = _DAT_60000d14 + 0x10;
  *(int *)(_DAT_60000d14 + 0x3c) = _DAT_60000d14;
  *(int *)(iVar2 + 0x50) = iVar4;
  *(int *)(iVar2 + 100) = iVar2 + 0x20;
  FUN_60000ff4(iVar1,iVar2 + 0x30,3,uVar3);
  return 0;
}

