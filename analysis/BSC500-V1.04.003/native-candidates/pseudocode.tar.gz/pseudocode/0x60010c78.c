
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60010c78(void)

{
  undefined4 *puVar1;
  
  puVar1 = _DAT_60010c80;
  *_DAT_60010c80 = 4;
  puVar1[1] = 0;
  puVar1[2] = 0;
  return;
}

