
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_600102b4(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined1 uVar2;
  int *piVar3;
  char cVar4;
  undefined4 uStack_30;
  int *piStack_2c;
  char cStack_21;
  
  piVar1 = _DAT_60010368;
  piVar3 = (int *)*_DAT_60010368;
  if ((code *)piVar3[1] != (code *)0x0) {
    (*(code *)piVar3[1])();
    piVar3 = (int *)*piVar1;
  }
  (**(code **)(*piVar3 + 8))(&uStack_30,piVar3,0);
  if (piStack_2c == (int *)0x0) {
    cVar4 = '\r';
  }
  else {
    (**(code **)(*piStack_2c + 0x10))(piStack_2c,0,2,3,uStack_30);
    (**(code **)(*(int *)*piVar1 + 0xc))((int *)*piVar1,&uStack_30);
    (**(code **)(*piStack_2c + 0x70))(piStack_2c,param_1);
    (**(code **)(*piStack_2c + 0x70))(piStack_2c,param_2);
    (**(code **)(*piStack_2c + 0x70))(piStack_2c,param_3);
    (**(code **)(*piStack_2c + 0x70))(piStack_2c,param_4);
    (**(code **)(*piStack_2c + 100))(piStack_2c,&cStack_21);
    cVar4 = (char)piStack_2c[5];
  }
  (**(code **)(*(int *)*piVar1 + 0x10))((int *)*piVar1,&uStack_30);
  FUN_601675ca(*piVar1,cVar4,3);
  if (*(code **)(*piVar1 + 8) != (code *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  if (cVar4 == '\0') {
    uVar2 = 0;
    if (cStack_21 != '\0') {
      uVar2 = 1;
    }
  }
  else {
    uVar2 = 0;
  }
  return uVar2;
}

