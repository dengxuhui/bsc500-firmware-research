
void FUN_6000fe04(void)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int iVar5;
  undefined1 auStack_34 [32];
  
  for (iVar5 = 0; iVar5 != 8; iVar5 = iVar5 + 1) {
    ZeroBytes(auStack_34,0x20);
    uVar4 = *(undefined4 *)(&UNK_6000fe4c + iVar5 * 4);
    uVar1 = FUN_60168220(uVar4);
    FUN_60163b68(auStack_34,uVar4,uVar1);
    iVar2 = FUN_600193c8();
    if ((iVar2 != 0) && (iVar3 = FUN_60163ab8(), iVar3 != iVar2)) {
      FUN_6001a46c(iVar2);
    }
  }
  return;
}

