
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000ea94(undefined4 *param_1,undefined4 *param_2,undefined4 *param_3)

{
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = *(undefined4 *)(_DAT_6000eab0 + 8);
  }
  if (param_2 != (undefined4 *)0x0) {
    *param_2 = *(undefined4 *)(_DAT_6000eab0 + 0x1c);
  }
  if (param_3 != (undefined4 *)0x0) {
    *param_3 = *(undefined4 *)(_DAT_6000eab0 + 0x20);
  }
  return;
}

