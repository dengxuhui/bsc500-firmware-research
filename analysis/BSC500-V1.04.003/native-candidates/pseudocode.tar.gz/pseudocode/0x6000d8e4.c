
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d8e4(void)

{
  undefined2 uVar1;
  byte bVar2;
  char cVar3;
  ushort uVar4;
  longlong lVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined1 uVar9;
  char cVar10;
  undefined2 *puVar11;
  int iVar12;
  int iVar13;
  undefined4 uVar14;
  undefined4 *in_r3;
  undefined4 uVar15;
  uint uVar16;
  undefined4 uVar17;
  undefined4 uVar18;
  undefined4 uVar19;
  undefined4 *puStack_20;
  
  puStack_20 = in_r3;
  puVar11 = (undefined2 *)FUN_60163b40();
  iVar12 = FUN_60161d80(10,2);
  iVar7 = _DAT_6000db2c;
  iVar6 = _DAT_6000db28;
  *(bool *)(_DAT_6000db2c + 0x8c) = *(char *)(_DAT_6000db28 + 0xa91) == '\x06';
  uVar9 = FUN_601516c0();
  *(undefined1 *)(iVar7 + 2) = uVar9;
  uVar9 = FUN_60156cfc();
  *(undefined1 *)(iVar7 + 3) = uVar9;
  FUN_60011d78(puVar11);
  FUN_60010de4(iVar7,puVar11);
  iVar13 = FUN_601671f0();
  uVar16 = 0;
  puStack_20 = (undefined4 *)0x0;
  func_0x60166e0c(_DAT_6000db30,&puStack_20);
  puVar8 = _DAT_6000db34;
  uVar14 = _DAT_6000db34[1];
  *(undefined4 *)(iVar7 + 4) = *_DAT_6000db34;
  *(undefined4 *)(iVar7 + 8) = uVar14;
  bVar2 = *(byte *)(iVar6 + 0x74);
  *(undefined4 *)(iVar7 + 0xc) = *(undefined4 *)(iVar6 + 0xa74);
  *(undefined2 *)(iVar7 + 0x18) = *(undefined2 *)(iVar6 + 0x70);
  *(undefined2 *)(iVar7 + 0x1a) = *(undefined2 *)(iVar6 + 0xac);
  *(undefined1 *)(iVar7 + 0x8f) = *(undefined1 *)(iVar6 + 0x73);
  lVar5 = (ulonglong)*(uint *)(iVar6 + 0xaa8) * 100;
  *(int *)(iVar7 + 0x10) = (int)lVar5;
  *(undefined4 *)(iVar7 + 0xa8) = *puStack_20;
  *(byte *)(iVar7 + 0x8e) = bVar2 & 1;
  *(int *)(iVar7 + 0x14) = *(int *)(iVar6 + 0xaac) * 100 + (int)((ulonglong)lVar5 >> 0x20);
  *(undefined2 *)(iVar7 + 0x1c) = *puVar11;
  *(byte *)(iVar7 + 0x93) = (byte)(((uint)*(byte *)(iVar6 + 0xba4) << 0x1d) >> 0x1f);
  if (0x76b < (int)puVar8[7]) {
    uVar16 = puVar8[7] + 0x94 & 0xff;
  }
  cVar10 = (char)uVar16 - *(byte *)(iVar6 + 0x72);
  if (uVar16 < *(byte *)(iVar6 + 0x72)) {
    cVar10 = '\x18';
  }
  *(char *)(iVar7 + 0x90) = cVar10;
  if ((iVar12 != 0) && (puVar11[0x217] != 0)) {
    *(undefined2 *)(iVar7 + 0x1c) = puVar11[0x217];
  }
  uVar1 = puVar11[8];
  cVar10 = *(char *)(iVar6 + 0xda);
  *(undefined1 *)(iVar7 + 0x20) = *(undefined1 *)(iVar6 + 0xdc);
  uVar4 = *(ushort *)(iVar6 + 0xd8);
  *(undefined2 *)(iVar7 + 0x22) = uVar1;
  *(char *)(iVar7 + 0x21) = cVar10;
  *(ushort *)(iVar7 + 0x1e) = uVar4 & 0x7fff;
  iVar12 = iVar6 + iVar13 * 0x14;
  uVar14 = *(undefined4 *)(iVar12 + 0x45d4);
  *(undefined4 *)(iVar7 + 0x28) = *(undefined4 *)(iVar12 + 0x45c8);
  *(undefined4 *)(iVar7 + 0x24) = uVar14;
  *(undefined1 *)(iVar7 + 0x30) = *(undefined1 *)(iVar12 + 0x45d0);
  bVar2 = *(byte *)(iVar12 + 0x45d8);
  *(byte *)(iVar7 + 0x92) = bVar2 >> 7;
  *(undefined4 *)(iVar7 + 0x2c) = *(undefined4 *)(iVar12 + 0x45cc);
  *(byte *)(iVar7 + 0x91) = (byte)(((uint)bVar2 << 0x19) >> 0x1f);
  iVar12 = iVar6 + iVar13 * 0x38;
  uVar14 = *(undefined4 *)(iVar12 + 0x4690);
  uVar19 = *(undefined4 *)(iVar12 + 0x4694);
  uVar18 = *(undefined4 *)(iVar12 + 0x4698);
  uVar15 = *(undefined4 *)(iVar12 + 0x46a0);
  uVar17 = *(undefined4 *)(iVar12 + 0x46a4);
  *(undefined4 *)(iVar7 + 0x34) = *(undefined4 *)(iVar12 + 0x469c);
  *(undefined4 *)(iVar7 + 0x38) = uVar15;
  *(undefined4 *)(iVar7 + 0x3c) = uVar17;
  *(undefined4 *)(iVar7 + 0x40) = uVar14;
  *(undefined4 *)(iVar7 + 0x44) = uVar18;
  *(undefined4 *)(iVar7 + 0x48) = uVar19;
  *(undefined4 *)(iVar7 + 0x5a) = *(undefined4 *)(iVar12 + 0x46c0);
  uVar4 = *(ushort *)(iVar12 + 0x46c4);
  uVar14 = *(undefined4 *)(iVar12 + 0x46b4);
  uVar15 = *(undefined4 *)(iVar12 + 0x46b8);
  *(ushort *)(iVar7 + 0x5e) =
       (*(ushort *)(iVar7 + 0x5e) & 0xfc00) + (uVar4 & 1) + (uVar4 & 2) + (uVar4 & 0x40) +
       (uVar4 & 4) + (uVar4 & 8) + (uVar4 & 0x10) | uVar4 & 0x20 | uVar4 & 0x200 | uVar4 & 0x80 |
       uVar4 & 0x100;
  uVar1 = *(undefined2 *)(iVar12 + 0x46a8);
  *(undefined4 *)(iVar7 + 0x52) = uVar14;
  *(undefined2 *)(iVar7 + 0x4c) = uVar1;
  uVar1 = *(undefined2 *)(iVar12 + 0x46aa);
  *(short *)(iVar7 + 0x56) = (short)uVar15;
  *(undefined2 *)(iVar7 + 0x4e) = uVar1;
  *(short *)(iVar7 + 0x50) = (short)*(undefined4 *)(iVar12 + 0x46ac);
  bVar2 = *(byte *)(iVar6 + 0x114);
  *(undefined2 *)(iVar7 + 0x58) = *(undefined2 *)(iVar12 + 0x46bc);
  cVar3 = *(char *)(iVar6 + (uint)bVar2 + 0x101);
  if (cVar10 != cVar3) {
    *(char *)(iVar6 + 0xda) = cVar3;
  }
  *(byte *)(iVar7 + 0x71) = bVar2;
  *(int *)(iVar7 + 100) = iVar6 + 0xf2;
  *(int *)(iVar7 + 0x68) = iVar6 + 0x102;
  *(int *)(iVar7 + 0x6c) = iVar6 + 0x10a;
  uVar9 = *(undefined1 *)(iVar6 + 0x115);
  *(undefined1 *)(iVar7 + 0x70) = *(undefined1 *)(iVar6 + 0x113);
  *(undefined1 *)(iVar7 + 0x72) = uVar9;
  FUN_600153ac(iVar6);
  uVar14 = *(undefined4 *)(iVar6 + 0xa90);
  uVar15 = *(undefined4 *)(iVar6 + 0xa94);
  uVar17 = *(undefined4 *)(iVar6 + 0xa98);
  uVar18 = *(undefined4 *)(iVar6 + 0xa9c);
  uVar19 = *(undefined4 *)(iVar6 + 0xaa0);
  *(undefined4 *)(iVar7 + 0x74) = *(undefined4 *)(iVar6 + 0xa8c);
  *(undefined4 *)(iVar7 + 0x78) = uVar14;
  *(undefined4 *)(iVar7 + 0x7c) = uVar15;
  *(undefined4 *)(iVar7 + 0x80) = uVar17;
  *(undefined4 *)(iVar7 + 0x84) = uVar18;
  *(undefined4 *)(iVar7 + 0x88) = uVar19;
  *(undefined1 *)(iVar7 + 0x8d) = *(undefined1 *)((short)iVar13 * 0x2c + iVar6 + 0xbaf);
  return;
}

