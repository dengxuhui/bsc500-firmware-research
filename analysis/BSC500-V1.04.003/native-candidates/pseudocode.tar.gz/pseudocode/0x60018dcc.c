
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018dcc(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int *piVar5;
  int iVar6;
  int iVar7;
  undefined4 *puVar8;
  
  puVar4 = _DAT_60018ee4;
  uVar1 = _DAT_60018e9c;
  *_DAT_60018ee4 = 0;
  puVar4[1] = 0;
  FUN_6013a69a(uVar1);
  uVar1 = _DAT_60018ea4;
  puVar4[0xd] = _DAT_60018ea0;
  puVar4[0xe] = 300;
  puVar4[0xc] = uVar1;
  FUN_6013a692(puVar4 + 0xc);
  uVar2 = _DAT_60018eac;
  puVar4[0x13] = _DAT_60018ea8;
  puVar4[0x11] = 100;
  puVar4[0x10] = uVar2;
  FUN_6013a67e(puVar4 + 0x10);
  uVar2 = _DAT_60018eb0;
  puVar4[0x18] = _DAT_60018eb0;
  puVar4[0x1c] = 0x14;
  puVar4[0x19] = 100;
  FUN_6013a662(puVar4 + 0x18);
  iVar3 = _DAT_60018eb8;
  iVar6 = _DAT_60018eb4;
  puVar4[2] = uVar1;
  puVar4[3] = 300;
  puVar4[4] = uVar2;
  puVar4[5] = 100;
  for (iVar7 = 0; piVar5 = _DAT_600191e8, iVar7 != 0x80; iVar7 = iVar7 + 0x10) {
    *(int *)(iVar3 + iVar7) = iVar6;
    iVar6 = iVar6 + 0x4b0;
    *(undefined4 *)(iVar3 + iVar7 + 0xc) = 0x32;
  }
  _DAT_600191e8[5] = 0;
  *piVar5 = iVar3;
  piVar5[1] = (int)(puVar4 + 1);
  piVar5[2] = 8;
  FUN_6013a652(piVar5);
  iVar3 = _DAT_60018ec0;
  iVar6 = _DAT_60018ebc;
  puVar8 = puVar4 + 4;
  piVar5[10] = _DAT_60018ebc;
  piVar5[0xb] = 300;
  piVar5[0xc] = 100;
  piVar5[6] = (int)piVar5;
  piVar5[7] = (int)puVar8;
  piVar5[8] = iVar3;
  FUN_6013a64a(piVar5 + 6);
  puVar4[0x14] = piVar5;
  puVar4[0x15] = puVar8;
  puVar4[6] = iVar3;
  puVar4[7] = iVar6;
  puVar4[8] = 0;
  FUN_6013a642(puVar4 + 0x14);
  puVar4[9] = piVar5;
  puVar4[10] = puVar8;
  return;
}

