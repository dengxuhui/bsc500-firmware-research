
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60019274(void)

{
  int *piVar1;
  
  piVar1 = _DAT_60019288;
  if (*_DAT_60019288 != 0) {
    FUN_601667bc();
    *piVar1 = 0;
  }
  return;
}

