
/* WARNING: Possible PIC construction at 0x6000d7ba: Changing call to branch */
/* WARNING: Possible PIC construction at 0x6000d7c2: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6000d7be) */
/* WARNING: Removing unreachable block (ram,0x6000d7c6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000d764(undefined4 param_1)

{
  int iVar1;
  int *piVar2;
  uint *puVar3;
  undefined *puVar4;
  int extraout_r1;
  undefined *extraout_r2;
  undefined *extraout_r2_00;
  uint uVar5;
  int extraout_r3;
  int extraout_r3_00;
  uint uVar6;
  int iVar7;
  undefined8 uVar8;
  int *piStack_80;
  int iStack_7c;
  int iStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  int iStack_6c;
  undefined *puStack_68;
  int iStack_64;
  int iStack_60;
  undefined4 auStack_5c [16];
  
  ZeroBytes(auStack_5c,0x40);
  uVar8 = FUN_600154ec(auStack_5c,0x10,param_1);
  iStack_6c = (int)((ulonglong)uVar8 >> 0x20);
  iStack_78 = (int)uVar8;
  puStack_68 = extraout_r2;
  iStack_64 = extraout_r3;
  iVar7 = _DAT_6000d7d4;
  for (iStack_7c = 0; iVar1 = _DAT_60161478, iStack_78 != iStack_7c; iStack_7c = iStack_7c + 1) {
    func_0x601681f4(iVar7,&UNK_6000d7d8,auStack_5c[iStack_7c]);
    *(undefined1 *)(iVar7 + 8) = 0x20;
    iVar7 = iVar7 + 9;
    iStack_6c = extraout_r1;
    puStack_68 = extraout_r2_00;
    iStack_64 = extraout_r3_00;
  }
  if (iStack_78 == 0) {
    uStack_70 = 0x6000d7c7;
    puVar4 = &UNK_6000d82c;
  }
  else {
    iStack_64 = iStack_78 * 9;
    puStack_68 = &UNK_6000d824;
    iStack_60 = _DAT_6000d7d4;
    iStack_6c = _DAT_6000d7e0 + 0x11;
    uStack_70 = 0x6000d7bf;
    puVar4 = &UNK_6000d7e4;
  }
  uStack_74 = 0x20;
  if (puVar4 != (undefined *)0x0) {
    piStack_80 = &iStack_6c;
    FUN_60001d60(_DAT_60161478,puVar4,&piStack_80);
    piVar2 = _DAT_6016147c;
    if (*_DAT_6016147c != _DAT_60161480) {
      *_DAT_6016147c = _DAT_60161480;
      piVar2[1] = 0;
    }
    puVar3 = _DAT_60161484;
    if ((*_DAT_60161484 < 0x1ff8) && (uVar5 = *(uint *)(iVar1 + 8), uVar5 != 0)) {
      uVar6 = 0x1ff8;
      if (uVar5 < 0x1ff8) {
        uVar6 = uVar5;
      }
      piVar2[1] = uVar6;
      *puVar3 = uVar6;
    }
  }
  return;
}

