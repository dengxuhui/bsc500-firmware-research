
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60003730(void)

{
  int *piVar1;
  uint uVar2;
  int iVar3;
  undefined4 unaff_r4;
  int iVar4;
  
  iVar3 = _DAT_60003750;
  FUN_60161cdc(*(undefined1 *)(_DAT_60003750 + 0xa68));
  piVar1 = _DAT_60161d30;
  uVar2 = (uint)(*(char *)(iVar3 + 0xa69) == '\x01');
  if (*_DAT_60161d30 == 0) {
    func_0x60167f3c(4,_DAT_60161d38,1,_DAT_60161d48,unaff_r4);
    return -1;
  }
  iVar3 = FUN_6016089c();
  if (iVar3 != 0) {
    uVar2 = 0;
  }
  iVar4 = piVar1[7];
  piVar1[7] = uVar2;
  iVar3 = FUN_60158f2c();
  if (iVar3 != 0) {
    piVar1[7] = iVar4;
    return iVar3;
  }
  *(bool *)(_DAT_60161d34 + 0xa69) = uVar2 != 0;
  return 0;
}

