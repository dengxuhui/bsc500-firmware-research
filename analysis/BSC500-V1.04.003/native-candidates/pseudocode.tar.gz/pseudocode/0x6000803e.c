
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000803e(uint param_1,undefined4 param_2,uint param_3,uint param_4)

{
  ushort uVar1;
  int iVar2;
  uint uVar3;
  int iVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  int unaff_r4;
  int unaff_r5;
  uint *unaff_r6;
  uint unaff_r7;
  char in_CY;
  
  iVar2 = _DAT_60008140;
  if ((in_CY == '\0') || (*(ushort *)(unaff_r4 + 0x4a) <= param_3)) {
    *unaff_r6 = param_1 & param_4;
    FUN_60019b94();
  }
  else {
    param_1 = param_1 & param_4 + 0x1000000;
    uVar5 = param_1 | 0x100;
    *unaff_r6 = uVar5;
    uVar7 = *(uint *)(unaff_r4 + 8) / 1000;
    iVar4 = *(int *)(iVar2 + 0x28);
    if ((iVar4 == 0) || (0x3c < uVar7 - iVar4)) {
      *(uint *)(iVar2 + 0x28) = uVar7;
      *unaff_r6 = param_1 | 0x1000100;
      FUN_60019b9c(2);
    }
    else {
      *unaff_r6 = param_4 + 0x100 & uVar5;
    }
  }
  iVar2 = _DAT_60008140;
  if (-1 < (int)((uint)*(ushort *)(unaff_r4 + 0x5e) << 0x16)) {
    return;
  }
  uVar5 = (uint)*(ushort *)(unaff_r5 + 0xc);
  if (uVar5 == unaff_r7) {
    *(undefined4 *)(_DAT_60008140 + 0x40) = 0;
    *(undefined4 *)(iVar2 + 0x44) = 0;
    return;
  }
  if (*(ushort *)(unaff_r4 + 0x5a) < uVar5) {
    uVar3 = *unaff_r6 & _DAT_6000817c;
    uVar5 = uVar3 + 0x2000;
    *unaff_r6 = uVar5;
    uVar6 = *(uint *)(unaff_r4 + 8) / 1000;
    if ((*(int *)(_DAT_60008140 + 0x40) == 0) ||
       (uVar7 = _DAT_60008180, 0x3c < uVar6 - *(int *)(_DAT_60008140 + 0x40))) {
      *(uint *)(_DAT_60008140 + 0x40) = uVar6;
      uVar7 = uVar3 | 0x20002000;
      goto LAB_6000813a;
    }
  }
  else {
    uVar1 = *(ushort *)(unaff_r4 + 0x5c);
    uVar7 = *unaff_r6;
    *unaff_r6 = uVar7 & 0xffffdfff;
    if (uVar1 <= uVar5) {
      uVar7 = uVar7 & 0x9fff9fff;
      goto LAB_6000813a;
    }
    uVar7 = _DAT_6000817c + 0x20000000 & uVar7;
    uVar5 = uVar7 + 0x4000;
    *unaff_r6 = uVar5;
    uVar3 = *(uint *)(unaff_r4 + 8) / 1000;
    if ((*(int *)(_DAT_60008140 + 0x44) == 0) || (0x3c < uVar3 - *(int *)(_DAT_60008140 + 0x44))) {
      *(uint *)(_DAT_60008140 + 0x44) = uVar3;
      uVar7 = uVar7 | 0x40004000;
      goto LAB_6000813a;
    }
    uVar7 = _DAT_60008180 + 0x2000;
  }
  uVar7 = uVar7 & uVar5;
LAB_6000813a:
  *unaff_r6 = uVar7;
  return;
}

