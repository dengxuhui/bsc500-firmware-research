
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60007a98(char *param_1,int param_2)

{
  byte bVar1;
  ushort uVar2;
  ushort uVar3;
  uint *puVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  uint *puVar10;
  uint uVar11;
  uint uVar12;
  
  uVar5 = 0;
  puVar10 = (uint *)(param_2 + 0x330);
  *(undefined4 *)(param_2 + 0x330) = 0;
  puVar4 = _DAT_60008140;
  if (*param_1 != '\0') {
    uVar5 = *(uint *)(param_2 + 0x1c8) / 1000;
    if ((*(ushort *)(param_1 + 0x5e) & 1) == 0) {
      uVar7 = 0;
    }
    else {
      uVar7 = 0;
      if (*(uint *)(param_1 + 0x34) != 0) {
        uVar7 = (uint)(*(uint *)(param_1 + 0x34) <= uVar5);
        *puVar10 = uVar7;
        uVar8 = *(uint *)(param_1 + 0x34);
        uVar11 = *puVar4;
        iVar9 = uVar11 - (uVar11 / uVar8) * uVar8;
        if (iVar9 != 0) {
          uVar11 = uVar11 - iVar9;
          *puVar4 = uVar11;
        }
        if (uVar11 + uVar8 <= uVar5) {
          uVar7 = uVar7 + 0x10000;
          *puVar4 = (((uVar5 - uVar11) / uVar8) * uVar8 - (uVar5 - uVar11)) + uVar5;
        }
      }
    }
    *puVar10 = uVar7;
    puVar4 = _DAT_60008140;
    if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x18) < 0) {
      if ((*(short *)(param_1 + 0x4c) == 0) && (*(ushort *)(param_1 + 0x4e) != 0)) {
        uVar8 = uVar7 | 0x800;
        if (uVar5 < *(ushort *)(param_1 + 0x4e)) {
          uVar8 = uVar7 & _DAT_60007e90;
        }
        uVar7 = uVar8;
        *puVar10 = uVar7;
        uVar11 = puVar4[0xb];
        uVar8 = (uint)*(ushort *)(param_1 + 0x4e);
        iVar9 = uVar11 - (uVar11 / uVar8) * uVar8;
        if (iVar9 != 0) {
          uVar11 = uVar11 - iVar9;
          puVar4[0xb] = uVar11;
        }
        if (uVar5 < uVar11 + uVar8) {
          *puVar10 = uVar7;
        }
        else {
          uVar7 = uVar7 + 0x8000000;
          *puVar10 = uVar7;
          puVar4[0xb] = (((uVar5 - uVar11) / uVar8) * uVar8 - (uVar5 - uVar11)) + uVar5;
        }
      }
    }
    else {
      *puVar10 = uVar7;
    }
    puVar4 = _DAT_60008140;
    if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x17) < 0) {
      if ((*(short *)(param_1 + 0x52) == 1) && (*(ushort *)(param_1 + 0x54) != 0)) {
        uVar8 = uVar7 | 0x1000;
        if (uVar5 < *(ushort *)(param_1 + 0x54)) {
          uVar8 = uVar7 & _DAT_60007e84;
        }
        uVar7 = uVar8;
        *puVar10 = uVar7;
        uVar11 = puVar4[0xe];
        uVar8 = (uint)*(ushort *)(param_1 + 0x54);
        iVar9 = uVar11 - (uVar11 / uVar8) * uVar8;
        if (iVar9 != 0) {
          uVar11 = uVar11 - iVar9;
          puVar4[0xe] = uVar11;
        }
        if (uVar5 < uVar11 + uVar8) {
          *puVar10 = uVar7;
        }
        else {
          uVar7 = uVar7 + 0x10000000;
          *puVar10 = uVar7;
          puVar4[0xe] = uVar5 + (((uVar5 - uVar11) / uVar8) * uVar8 - (uVar5 - uVar11));
        }
      }
    }
    else {
      *puVar10 = uVar7;
    }
    puVar4 = _DAT_60008140;
    uVar8 = *(uint *)(param_2 + 0x1b4) / 100;
    if (((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x1e) < 0) && (*(uint *)(param_1 + 0x38) != 0))
    {
      uVar5 = uVar7 | 2;
      if (uVar8 < *(uint *)(param_1 + 0x38)) {
        uVar5 = uVar7;
      }
      *puVar10 = uVar5;
      uVar11 = puVar4[1];
      uVar7 = *(uint *)(param_1 + 0x38);
      iVar9 = uVar11 - (uVar11 / uVar7) * uVar7;
      if (iVar9 != 0) {
        uVar11 = uVar11 - iVar9;
        puVar4[1] = uVar11;
      }
      if (uVar8 < uVar11 + uVar7) {
        uVar5 = uVar5 & _DAT_60007e88;
      }
      else {
        uVar5 = uVar5 | 0x20000;
        puVar4[1] = (((uVar8 - uVar11) / uVar7) * uVar7 - (uVar8 - uVar11)) + uVar8;
      }
    }
    else {
      uVar5 = _DAT_60007e88 & uVar7;
    }
    *puVar10 = uVar5;
    puVar4 = _DAT_60008140;
    if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x18) < 0) {
      if ((*(short *)(param_1 + 0x4c) == 1) && (*(ushort *)(param_1 + 0x50) != 0)) {
        uVar7 = uVar5 | 0x800;
        if (uVar8 < *(ushort *)(param_1 + 0x50)) {
          uVar7 = uVar5 & _DAT_60007e8c;
        }
        *puVar10 = uVar7;
        uVar11 = puVar4[0xc];
        uVar12 = (uint)*(ushort *)(param_1 + 0x50);
        iVar9 = uVar11 - (uVar11 / uVar12) * uVar12;
        if (iVar9 != 0) {
          uVar11 = uVar11 - iVar9;
          puVar4[0xc] = uVar11;
        }
        uVar5 = uVar7;
        if (uVar8 < uVar11 + uVar12) goto LAB_60007bd2;
        uVar5 = uVar7 | 0x8000000;
        *puVar10 = uVar5;
        puVar4[0xc] = (uVar12 * ((uVar8 - uVar11) / uVar12) - (uVar8 - uVar11)) + uVar8;
      }
    }
    else {
LAB_60007bd2:
      uVar5 = uVar5 & 0x17ffffff;
      *puVar10 = uVar5;
    }
    puVar4 = _DAT_60008140;
    if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x17) < 0) {
      if ((*(short *)(param_1 + 0x52) == 2) && (*(ushort *)(param_1 + 0x56) != 0)) {
        uVar7 = uVar5 | 0x1000;
        if (uVar8 < *(ushort *)(param_1 + 0x56)) {
          uVar7 = uVar5 & _DAT_60007e94;
        }
        *puVar10 = uVar7;
        uVar11 = puVar4[0xf];
        uVar12 = (uint)*(ushort *)(param_1 + 0x56);
        iVar9 = uVar11 - (uVar11 / uVar12) * uVar12;
        if (iVar9 != 0) {
          uVar11 = uVar11 - iVar9;
          puVar4[0xf] = uVar11;
        }
        uVar5 = uVar7;
        if (uVar8 < uVar11 + uVar12) goto LAB_60007cb0;
        uVar5 = uVar7 | 0x10000000;
        *puVar10 = uVar5;
        puVar4[0xf] = uVar8 + (uVar12 * ((uVar8 - uVar11) / uVar12) - (uVar8 - uVar11));
      }
    }
    else {
LAB_60007cb0:
      uVar5 = uVar5 & 0xfffffff;
      *puVar10 = uVar5;
    }
    puVar4 = _DAT_60008140;
    uVar7 = (uint)*(ushort *)(param_2 + 0x22a);
    if (((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x1d) < 0) && (*(uint *)(param_1 + 0x3c) != 0))
    {
      if (*(uint *)(param_1 + 0x3c) < uVar7) {
        uVar5 = uVar5 | 4;
      }
      *puVar10 = uVar5;
      uVar8 = puVar4[2];
      uVar11 = *(uint *)(param_1 + 0x3c);
      iVar9 = uVar8 - (uVar8 / uVar11) * uVar11;
      if (iVar9 != 0) {
        uVar8 = uVar8 - iVar9;
        puVar4[2] = uVar8;
      }
      if (uVar7 < uVar8 + uVar11) {
        uVar5 = _DAT_60007e98 & uVar5;
        *puVar10 = uVar5;
      }
      else {
        uVar5 = uVar5 | 0x40000;
        *puVar10 = uVar5;
        puVar4[2] = (uVar11 * ((uVar7 - uVar8) / uVar11) - (uVar7 - uVar8)) + uVar7;
      }
    }
    puVar4 = _DAT_60008140;
    if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x17) < 0) {
      if ((*(short *)(param_1 + 0x52) == 0) && (*(ushort *)(param_1 + 0x58) != 0)) {
        uVar8 = _DAT_60008144 & uVar5;
        if (*(ushort *)(param_1 + 0x58) < uVar7) {
          uVar8 = uVar5 | 0x1000;
        }
        *puVar10 = uVar8;
        uVar11 = puVar4[0xd];
        uVar12 = (uint)*(ushort *)(param_1 + 0x58);
        iVar9 = uVar11 - (uVar11 / uVar12) * uVar12;
        if (iVar9 != 0) {
          uVar11 = uVar11 - iVar9;
          puVar4[0xd] = uVar11;
        }
        uVar5 = uVar8;
        if (uVar7 < uVar11 + uVar12) goto LAB_60007d78;
        uVar5 = uVar8 | 0x10000000;
        *puVar10 = uVar5;
        puVar4[0xd] = uVar7 + (uVar12 * ((uVar7 - uVar11) / uVar12) - (uVar7 - uVar11));
      }
    }
    else {
LAB_60007d78:
      uVar5 = uVar5 & 0xfffffff;
      *puVar10 = uVar5;
    }
  }
  puVar4 = _DAT_60008140;
  if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x19) < 0) {
    uVar7 = *(uint *)(param_2 + 4);
    if (uVar7 == 0xffffffff) {
      _DAT_60008140[3] = 0;
      puVar4[4] = 0;
    }
    else {
      if (*(ushort *)(param_1 + 0x44) < uVar7) {
        uVar5 = uVar5 & _DAT_60007e9c;
        uVar7 = uVar5 + 0x200;
        *puVar10 = uVar7;
        if ((_DAT_60008140[3] == 0) ||
           (uVar8 = _DAT_60007ea0, 0x3c < *(uint *)(param_1 + 8) / 1000 - _DAT_60008140[3])) {
          _DAT_60008140[3] = *(uint *)(param_1 + 8) / 1000;
          uVar5 = uVar5 | 0x2000200;
        }
        else {
LAB_60007e10:
          uVar5 = uVar8 & uVar7;
        }
      }
      else {
        uVar2 = *(ushort *)(param_1 + 0x46);
        *puVar10 = uVar5 & _DAT_60007ea4;
        if ((uVar7 < 0x342) || (uVar2 <= uVar7)) {
          uVar5 = uVar5 & _DAT_60008148;
        }
        else {
          uVar5 = uVar5 & _DAT_60007ea8 + 0x2000000U;
          uVar7 = uVar5 + 0x400;
          *puVar10 = uVar7;
          if ((_DAT_60008140[4] != 0) && (*(uint *)(param_1 + 8) / 1000 - _DAT_60008140[4] < 0x3d))
          {
            uVar8 = _DAT_6000814c + 0x200;
            goto LAB_60007e10;
          }
          _DAT_60008140[4] = *(uint *)(param_1 + 8) / 1000;
          uVar5 = uVar5 | 0x4000400;
        }
      }
      *puVar10 = uVar5;
    }
  }
  puVar4 = _DAT_60008140;
  if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x1c) < 0) {
    bVar1 = *(byte *)(param_2 + 0xe);
    if (bVar1 == 0xff) {
      _DAT_60008140[5] = 0;
      puVar4[6] = 0;
    }
    else {
      if ((byte)param_1[0x40] < bVar1) {
        uVar5 = uVar5 & _DAT_6000815c;
        uVar7 = uVar5 + 8;
        *puVar10 = uVar7;
        if ((_DAT_60008140[5] == 0) ||
           (uVar8 = _DAT_60008160, 0x3c < *(uint *)(param_1 + 8) / 1000 - _DAT_60008140[5])) {
          _DAT_60008140[5] = *(uint *)(param_1 + 8) / 1000;
          uVar5 = uVar5 | 0x80008;
        }
        else {
LAB_60007f0c:
          uVar5 = uVar8 & uVar7;
        }
      }
      else if ((bVar1 < 0x1f) || ((byte)param_1[0x41] <= bVar1)) {
        uVar5 = uVar5 & _DAT_60008150;
      }
      else {
        uVar5 = uVar5 & _DAT_60008154 + 0x80000U;
        uVar7 = uVar5 + 0x10;
        *puVar10 = uVar7;
        if ((_DAT_60008140[6] != 0) && (*(uint *)(param_1 + 8) / 1000 - _DAT_60008140[6] < 0x3d)) {
          uVar8 = _DAT_60008158 + 8;
          goto LAB_60007f0c;
        }
        _DAT_60008140[6] = *(uint *)(param_1 + 8) / 1000;
        uVar5 = uVar5 | 0x100010;
      }
      *puVar10 = uVar5;
    }
  }
  puVar4 = _DAT_60008140;
  if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x1b) < 0) {
    bVar1 = *(byte *)(param_2 + 0xf);
    if (bVar1 == 0xff) {
      _DAT_60008140[7] = 0;
      puVar4[8] = 0;
    }
    else {
      if ((byte)param_1[0x42] < bVar1) {
        uVar5 = uVar5 & _DAT_60008170;
        uVar7 = uVar5 + 0x20;
        *puVar10 = uVar7;
        if ((_DAT_60008140[7] == 0) ||
           (uVar8 = _DAT_60008174, 0x3c < *(uint *)(param_1 + 8) / 1000 - _DAT_60008140[7])) {
          _DAT_60008140[7] = *(uint *)(param_1 + 8) / 1000;
          uVar5 = uVar5 | 0x200020;
        }
        else {
LAB_60007fce:
          uVar5 = uVar8 & uVar7;
        }
      }
      else if ((bVar1 < 0x15) || ((byte)param_1[0x43] <= bVar1)) {
        uVar5 = uVar5 & _DAT_60008164;
      }
      else {
        uVar5 = uVar5 & _DAT_60008168 + 0x200000U;
        uVar7 = uVar5 + 0x40;
        *puVar10 = uVar7;
        if ((_DAT_60008140[8] != 0) && (*(uint *)(param_1 + 8) / 1000 - _DAT_60008140[8] < 0x3d)) {
          uVar8 = _DAT_6000816c + 0x20;
          goto LAB_60007fce;
        }
        _DAT_60008140[8] = *(uint *)(param_1 + 8) / 1000;
        uVar5 = uVar5 | 0x400040;
      }
      *puVar10 = uVar5;
    }
  }
  uVar7 = _DAT_60008178;
  puVar4 = _DAT_60008140;
  if ((int)((uint)*(ushort *)(param_1 + 0x5e) << 0x1a) < 0) {
    uVar2 = *(ushort *)(param_2 + 10);
    if (uVar2 == 0xffff) {
      _DAT_60008140[9] = 0;
      puVar4[10] = 0;
    }
    else if (*(ushort *)(param_1 + 0x48) < uVar2) {
      uVar5 = uVar5 & _DAT_60008178 + 0x800000;
      uVar8 = uVar5 | 0x80;
      *puVar10 = uVar8;
      if ((puVar4[9] == 0) || (0x3c < *(uint *)(param_1 + 8) / 1000 - puVar4[9])) {
        puVar4[9] = *(uint *)(param_1 + 8) / 1000;
        *puVar10 = uVar5 | 0x800080;
        uVar6 = 1;
LAB_6000809e:
        FUN_60019b9c(uVar6);
      }
      else {
        iVar9 = 0x80;
LAB_60008074:
        *puVar10 = uVar7 + iVar9 & uVar8;
      }
    }
    else {
      if ((1 < uVar2) && (uVar2 < *(ushort *)(param_1 + 0x4a))) {
        uVar5 = uVar5 & _DAT_60008178 + 0x1000000;
        uVar8 = uVar5 | 0x100;
        *puVar10 = uVar8;
        if ((puVar4[10] == 0) || (0x3c < *(uint *)(param_1 + 8) / 1000 - puVar4[10])) {
          puVar4[10] = *(uint *)(param_1 + 8) / 1000;
          *puVar10 = uVar5 | 0x1000100;
          uVar6 = 2;
          goto LAB_6000809e;
        }
        iVar9 = 0x100;
        goto LAB_60008074;
      }
      *puVar10 = uVar5 & _DAT_60008178;
      FUN_60019b94();
    }
  }
  puVar4 = _DAT_60008140;
  if (-1 < (int)((uint)*(ushort *)(param_1 + 0x5e) << 0x16)) {
    return;
  }
  uVar2 = *(ushort *)(param_2 + 0xc);
  if (uVar2 == 0xffff) {
    _DAT_60008140[0x10] = 0;
    puVar4[0x11] = 0;
    return;
  }
  if (*(ushort *)(param_1 + 0x5a) < uVar2) {
    uVar8 = *puVar10 & _DAT_6000817c;
    uVar7 = uVar8 + 0x2000;
    *puVar10 = uVar7;
    if ((_DAT_60008140[0x10] == 0) ||
       (uVar5 = _DAT_60008180, 0x3c < *(uint *)(param_1 + 8) / 1000 - _DAT_60008140[0x10])) {
      _DAT_60008140[0x10] = *(uint *)(param_1 + 8) / 1000;
      uVar5 = uVar8 | 0x20002000;
      goto LAB_6000813a;
    }
  }
  else {
    uVar3 = *(ushort *)(param_1 + 0x5c);
    uVar5 = *puVar10;
    *puVar10 = uVar5 & 0xffffdfff;
    if (uVar3 <= uVar2) {
      uVar5 = uVar5 & 0x9fff9fff;
      goto LAB_6000813a;
    }
    uVar5 = _DAT_6000817c + 0x20000000 & uVar5;
    uVar7 = uVar5 + 0x4000;
    *puVar10 = uVar7;
    if ((_DAT_60008140[0x11] == 0) || (0x3c < *(uint *)(param_1 + 8) / 1000 - _DAT_60008140[0x11]))
    {
      _DAT_60008140[0x11] = *(uint *)(param_1 + 8) / 1000;
      uVar5 = uVar5 | 0x40004000;
      goto LAB_6000813a;
    }
    uVar5 = _DAT_60008180 + 0x2000;
  }
  uVar5 = uVar5 & uVar7;
LAB_6000813a:
  *puVar10 = uVar5;
  return;
}

