
/* WARNING: Removing unreachable block (ram,0x60132aa8) */
/* WARNING: Removing unreachable block (ram,0x601329ba) */
/* WARNING: Removing unreachable block (ram,0x60132940) */
/* WARNING: Removing unreachable block (ram,0x6013279e) */
/* WARNING: Removing unreachable block (ram,0x60132748) */
/* WARNING: Removing unreachable block (ram,0x6013275a) */
/* WARNING: Removing unreachable block (ram,0x6013275c) */
/* WARNING: Removing unreachable block (ram,0x60132a92) */
/* WARNING: Removing unreachable block (ram,0x60132ae6) */
/* WARNING: Removing unreachable block (ram,0x601327d0) */
/* WARNING: Removing unreachable block (ram,0x60132b16) */
/* WARNING: Removing unreachable block (ram,0x60132b2c) */
/* WARNING: Removing unreachable block (ram,0x60132b2e) */
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x60132780 */
/* WARNING: Removing unreachable block (ram,0x601327e4) */
/* WARNING: Removing unreachable block (ram,0x601327b4) */
/* WARNING: Removing unreachable block (ram,0x60132a7c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: register */

undefined4 FUN_60018dc0(undefined8 *param_1)

{
  int *piVar1;
  int iVar2;
  float fVar3;
  int *piVar4;
  undefined8 *puVar5;
  int iVar6;
  undefined4 uVar7;
  uint uVar8;
  undefined8 *unaff_r4;
  bool bVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  undefined4 uVar13;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr11;
  float fVar14;
  undefined4 uVar15;
  undefined8 in_d1;
  undefined4 in_s5;
  undefined8 uVar16;
  float fVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  undefined8 uVar20;
  uint uStack_f4;
  undefined4 uStack_f0;
  undefined4 uStack_ec;
  undefined4 uStack_e8;
  undefined4 uStack_e4;
  undefined4 uStack_e0;
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  float fStack_d0;
  undefined1 auStack_c8 [16];
  float fStack_b8;
  undefined1 auStack_b0 [24];
  undefined8 uStack_98;
  undefined8 uStack_90;
  float fStack_88;
  undefined8 uStack_80;
  undefined8 uStack_78;
  undefined8 uStack_70;
  undefined8 uStack_68;
  undefined4 uStack_60;
  undefined4 uStack_5c;
  undefined4 uStack_58;
  undefined4 uStack_54;
  
  iVar6 = _DAT_60018ee4;
  uVar7 = (undefined4)((ulonglong)in_d1 >> 0x20);
  piVar1 = (int *)(_DAT_60018ee4 + 0x24);
  if (piVar1 != (int *)0x0) {
    unaff_r4 = param_1;
  }
  if (piVar1 == (int *)0x0 || param_1 == (undefined8 *)0x0) {
    return 0xffffffff;
  }
  iVar2 = FUN_60137930(0xffffffff);
  if ((iVar2 == 0) || (*(int *)(*(int *)(iVar6 + 0x28) + 4) == 0)) {
code_r0x601329e6:
    uVar7 = 0xffffffff;
  }
  else {
    uVar12 = 0;
    uStack_58 = 0;
    uStack_54 = 0;
    uStack_60 = 0;
    uStack_5c = 0;
    FUN_6012fba8(&uStack_58,&uStack_60);
    uStack_78 = FUN_601682c8(uStack_58,uStack_54);
    uStack_80 = FUN_60165558();
    uStack_68 = FUN_601682c8(uStack_60,uStack_5c);
    uVar19 = FUN_60165558();
    fVar14 = _UNK_60132934;
    fVar3 = (float)uVar19;
    bVar9 = false;
    uStack_f4 = 0;
    uStack_70 = uVar19;
    fVar17 = _UNK_60132930;
    while( true ) {
      piVar4 = *(int **)(iVar6 + 0x28);
      uVar8 = piVar4[1];
      if (uVar8 <= uVar12) break;
      iVar2 = FUN_6012fb3c(&uStack_80,*piVar4 + uVar12 * 0x30);
      if (iVar2 != 0) {
        iVar2 = **(int **)(iVar6 + 0x28) + uVar12 * 0x30;
        uVar11 = *(uint *)(iVar2 + 0x2c);
        for (uVar8 = *(uint *)(iVar2 + 0x28); uVar8 < uVar11; uVar8 = uVar8 + 1) {
          iVar2 = FUN_6013028a(*piVar1,uVar8,auStack_b0);
          if (iVar2 != 0) goto code_r0x601329e6;
          iVar2 = uVar8 - 1;
          if (uVar8 == 0) {
            iVar2 = 1;
          }
          iVar2 = FUN_6013028a(*piVar1,iVar2,auStack_c8);
          if (iVar2 != 0) goto code_r0x601329e6;
          FUN_6012fee0();
          if (fVar3 < fVar14) {
            if ((!bVar9) || (fVar3 < fVar17)) {
              FUN_60156244(&uStack_98,auStack_b0);
              bVar9 = true;
              uStack_f4 = uVar8;
              fVar17 = fVar3;
            }
            else {
              bVar9 = true;
            }
          }
        }
      }
      uVar12 = uVar12 + 1;
    }
    if (!bVar9) {
      iVar2 = 0;
      uVar12 = 0;
      uVar13 = (undefined4)((ulonglong)_UNK_60132b48 >> 0x20);
      uVar15 = (undefined4)_UNK_60132b48;
      while( true ) {
        uVar7 = (undefined4)((ulonglong)in_d1 >> 0x20);
        if (uVar8 <= uVar12) break;
        puVar5 = (undefined8 *)(*piVar4 + iVar2);
        uVar19 = *puVar5;
        in_d1 = puVar5[1];
        uVar16 = puVar5[2];
        uVar18 = puVar5[3];
        uVar20 = FUN_601682c8((float)in_d1,(int)((ulonglong)in_d1 >> 0x20),(float)uVar19,
                              (int)((ulonglong)uVar19 >> 0x20));
        FUN_601678fc((int)uVar20,(int)((ulonglong)uVar20 >> 0x20),uVar15,uVar13);
        uVar16 = FUN_601682c8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar16,
                              (int)((ulonglong)uVar16 >> 0x20));
        FUN_601678fc((int)uVar16,(int)((ulonglong)uVar16 >> 0x20),uVar15,uVar13);
        FUN_60161ad0();
        iVar2 = iVar2 + 0x30;
        coprocessor_function2(10,3,0,in_cr1,in_cr0,in_cr11);
        coprocessor_function2(10,0,0,in_cr1,in_cr0,in_cr1);
        if ((float)uVar19 < fVar17) {
          uStack_f4 = uVar12;
        }
        if (uVar12 == 0) {
          uStack_f4 = uVar12;
        }
        piVar4 = *(int **)(iVar6 + 0x28);
        uVar12 = uVar12 + 1;
        uVar8 = piVar4[1];
        fVar17 = (float)in_d1;
      }
      iVar2 = 0;
      iVar6 = *piVar4 + uStack_f4 * 0x30;
      uVar8 = *(uint *)(iVar6 + 0x28);
      uVar12 = *(uint *)(iVar6 + 0x2c);
      while( true ) {
        uVar11 = uVar8 + iVar2;
        if (uVar12 <= uVar11) break;
        iVar6 = FUN_6013028a(*piVar1,uVar11,auStack_b0);
        if (iVar6 != 0) goto code_r0x601329e6;
        iVar6 = uVar11 - 1;
        if (uVar11 == 0) {
          iVar6 = 1;
        }
        iVar6 = FUN_6013028a(*piVar1,iVar6,auStack_c8);
        if (iVar6 != 0) goto code_r0x601329e6;
        FUN_6012fee0();
        uVar10 = uVar8;
        if ((iVar2 == 0) || (uVar10 = uVar11, (float)uVar19 < fVar17)) {
          FUN_60156244(&uStack_98,auStack_b0);
          uStack_f4 = uVar10;
          fVar17 = (float)uVar19;
        }
        iVar2 = iVar2 + 1;
      }
    }
    uVar13 = (undefined4)((ulonglong)uVar19 >> 0x20);
    fVar14 = (float)uStack_98;
    FUN_6015e318(fVar14,uVar13,(int)uStack_90);
    FUN_6012fc48();
    if (_UNK_60132b44 <= fVar14) {
      if (uStack_f4 == 0) {
        *(float *)(unaff_r4 + 2) = fStack_88;
      }
      else {
        iVar6 = FUN_6013028a(*piVar1,uStack_f4 - 1,auStack_c8);
        if (iVar6 != 0) goto code_r0x601329e6;
        uStack_e0 = 0;
        uStack_dc = 0;
        uStack_e8 = 0;
        uStack_e4 = 0;
        FUN_6012fc58(&uStack_e0,&uStack_e8);
        fVar17 = fStack_b8;
        FUN_60161ad0(uStack_e0,uVar13,uStack_e8,uVar7,(undefined4)uStack_98,in_s5,
                     (undefined4)uStack_90);
        if (fVar14 <= ABS(fStack_88 - fVar17)) {
          *(float *)(unaff_r4 + 2) = fVar14;
        }
        else {
          *(float *)(unaff_r4 + 2) = fStack_b8;
        }
        uStack_98 = CONCAT44(uStack_dc,uStack_e0);
        uStack_90 = CONCAT44(uStack_e4,uStack_e8);
      }
      *unaff_r4 = uStack_98;
      unaff_r4[1] = uStack_90;
      if (uStack_f4 != 0) {
        uStack_f4 = uStack_f4 - 1;
      }
    }
    else {
      if (uStack_f4 == *(int *)(*piVar1 + 0x14) - 1U) {
        *(float *)(unaff_r4 + 2) = fStack_88;
      }
      else {
        iVar6 = FUN_6013028a(*piVar1,uStack_f4 + 1,&uStack_e0);
        if (iVar6 != 0) goto code_r0x601329e6;
        uStack_e8 = 0;
        uStack_e4 = 0;
        uStack_f0 = 0;
        uStack_ec = 0;
        FUN_6012fc58(&uStack_e8,&uStack_f0);
        fVar3 = fStack_88;
        fVar17 = fStack_d0;
        FUN_60161ad0(uStack_e8,uVar13,uStack_f0,uVar7,uStack_e0,in_s5,uStack_d8);
        if (fVar14 <= ABS(fVar17 - fVar3)) {
          *(float *)(unaff_r4 + 2) = fStack_d0 - fVar14;
        }
        else {
          *(float *)(unaff_r4 + 2) = fStack_88;
        }
        uStack_98 = CONCAT44(uStack_e4,uStack_e8);
        uStack_90 = CONCAT44(uStack_ec,uStack_f0);
      }
      *unaff_r4 = uStack_98;
      unaff_r4[1] = uStack_90;
    }
    *(uint *)((int)unaff_r4 + 0x14) = uStack_f4;
    uVar7 = 0;
  }
  return uVar7;
}

