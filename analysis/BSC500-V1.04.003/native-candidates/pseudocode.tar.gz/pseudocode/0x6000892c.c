
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000892c(void)

{
  int *piVar1;
  short sVar2;
  byte *pbVar3;
  int *piVar4;
  undefined4 *puVar5;
  uint uVar6;
  uint uVar7;
  int iVar8;
  int iVar9;
  undefined4 extraout_r2;
  int extraout_r3;
  int unaff_r5;
  int unaff_r6;
  undefined4 uVar10;
  undefined1 auStack_d8 [176];
  uint uStack_28;
  uint uStack_24;
  int iStack_20;
  int iStack_1c;
  
  FUN_6016572c(_DAT_60008960,1,_DAT_60008964);
  FUN_6016507e(_DAT_60008968,1000,0);
  FUN_6016572c(_DAT_6000896c,0,_DAT_60008970);
  uVar10 = _DAT_60008974;
  FUN_6015f550(_DAT_60008974);
  puVar5 = (undefined4 *)FUN_60162e34(0xc);
  piVar4 = piRam6015f590;
  if (puVar5 != (undefined4 *)0x0) {
    *puVar5 = uVar10;
    iVar9 = *piVar4;
    piVar1 = puVar5 + 1;
    *piVar1 = iVar9;
    *(int **)(iVar9 + 4) = piVar1;
    *piVar4 = (int)piVar1;
    puVar5[2] = piVar4;
    return;
  }
  FUN_6016804c(0x6015f594,0x6015f5a0,0x3fd);
  *(short *)(unaff_r6 + 0x24) = (short)uVar10;
  *(char *)(unaff_r5 + 0x20) = (char)unaff_r6;
  iStack_1c = *(int *)(unaff_r6 + 0x74);
  *(int *)(unaff_r6 + 0x34) = unaff_r5;
  sVar2 = *(short *)(unaff_r5 * 2);
  uVar6 = (uint)sVar2;
  *(undefined4 *)(unaff_r6 + 0x54) = extraout_r2;
  uVar10 = *(undefined4 *)(iStack_1c + 0x14);
  *(char *)(unaff_r6 + 0x11) = (char)extraout_r3;
  *(char *)(iStack_1c + 9) = (char)unaff_r5;
  *(undefined4 *)(extraout_r3 + 0x54) = uVar10;
  *(int *)(unaff_r6 + 0x54) = unaff_r6;
  *(char *)(unaff_r5 + 0x11) = (char)unaff_r6;
  *(undefined1 *)(unaff_r5 + 0xd) = 0x20;
  *(int *)(unaff_r6 + 0x54) = iStack_1c;
  *(int *)(unaff_r5 + 0x54) = unaff_r6;
  uVar10 = _DAT_6015f6d0;
  pbVar3 = _DAT_6015f6cc;
  iVar9 = _DAT_6015f6c8;
  if (*(char *)(_DAT_6015f6c8 + 3) == '\x01') {
    *(undefined2 *)(_DAT_6015f6c8 + 3) = 0;
  }
  if (uVar6 == 4) {
    *(undefined1 *)(iVar9 + 2) = 1;
  }
  uStack_28 = (uint)*pbVar3;
  uStack_24 = uVar6;
  iStack_20 = extraout_r3;
  func_0x60167f3c(6,uVar10,1,&UNK_6015f6d4);
  uVar7 = (uint)*pbVar3;
  if ((uVar7 == 0x10 && uVar6 == 4) || (uVar6 == 0x10 && uVar7 == 4)) {
    uVar7 = uVar7 | uVar6;
    *pbVar3 = (byte)uVar7;
LAB_6015f614:
    if ((uVar7 == 0x20) || ((uVar7 & 0x14) != 0)) {
      iVar8 = FUN_60057c24();
      if (uVar7 != 0x20) goto LAB_6015f640;
      if (iVar8 == 0) {
        uVar10 = 1;
        goto LAB_6015f650;
      }
      goto LAB_6015f654;
    }
    if (uVar7 == 2) {
      FUN_60157590(3);
      FUN_6015a0a0(0x1b);
    }
    else if (uVar7 == 1) {
      FUN_6012ee00();
      FUN_60155f80(3);
    }
  }
  else {
    if ((uVar6 == 0x20) || (uVar7 != 4)) {
      *pbVar3 = (byte)sVar2;
      uVar7 = uVar6;
      if (uVar6 == 3) {
        FUN_60155f80(1);
        iVar9 = FUN_6014f8d4(8);
        if (iVar9 == 0) {
          FUN_60157590(2);
        }
        else {
          FUN_60155f80(2);
        }
        pbVar3[4] = 0xb8;
        pbVar3[5] = 0xb;
        pbVar3[6] = 0;
        pbVar3[7] = 0;
        goto LAB_6015f668;
      }
      goto LAB_6015f614;
    }
    iVar8 = FUN_60057c24();
LAB_6015f640:
    if (iVar8 == 0) {
      FUN_60155f80(1);
    }
    iVar8 = FUN_60057c2c();
    if (iVar8 == 0) {
      uVar10 = 2;
LAB_6015f650:
      FUN_60155f80(uVar10);
    }
LAB_6015f654:
    pbVar3[4] = 0xd0;
    pbVar3[5] = 7;
    pbVar3[6] = 0;
    pbVar3[7] = 0;
    FUN_6012ee00();
  }
  if (uVar6 == 0x10) {
    *(undefined4 *)(iVar9 + 0x14) = **(undefined4 **)(iVar9 + 0x18);
  }
LAB_6015f668:
  uStack_28 = (uint)*pbVar3;
  func_0x60167f3c(6,_DAT_6015f6d0,1,&UNK_6015f6f0);
  if ((*pbVar3 == 4) && (iVar9 = FUN_60150308(), iVar9 != 0)) {
    FUN_60132374(1,auStack_d8,uStack_24,iStack_20);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(2,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(5,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(6,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(3,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(8,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(9,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(10,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(0xc,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(0xd,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    FUN_60132374(0xe,auStack_d8);
    for (iVar9 = 4; iVar9 != 0xa0; iVar9 = iVar9 + 0x34) {
      FUN_6012ba74(auStack_d8 + iVar9);
    }
    return;
  }
  return;
}

