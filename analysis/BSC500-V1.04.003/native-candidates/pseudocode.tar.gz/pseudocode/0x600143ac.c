
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600143ac(void)

{
  undefined4 uVar1;
  
  if (*_DAT_600143c0 == '\x02') {
    *_DAT_600143c0 = '\x01';
    uVar1 = 0;
  }
  else {
    uVar1 = 0xffffffff;
  }
  return uVar1;
}

