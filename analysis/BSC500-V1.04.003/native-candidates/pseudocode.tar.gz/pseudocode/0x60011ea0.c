
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60011ea0(int param_1,int *param_2)

{
  undefined4 *puVar1;
  int *piVar2;
  
  piVar2 = *(int **)(_DAT_60011f20 + param_1 * 4 + 4);
  if ((piVar2 != (int *)0x0) && (*piVar2 != 0)) {
    FUN_60166b98();
    puVar1 = (undefined4 *)*piVar2;
    *param_2 = (int)puVar1;
    if ((int *)*puVar1 != (int *)0x0) {
      piVar2 = (int *)*puVar1;
    }
    piVar2[1] = puVar1[1];
    *(undefined4 *)((undefined4 *)*param_2)[1] = *(undefined4 *)*param_2;
    func_0x60166b64();
    return 1;
  }
  return 0;
}

