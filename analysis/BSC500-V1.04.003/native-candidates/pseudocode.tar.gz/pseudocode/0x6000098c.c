
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000098c(void)

{
  undefined1 *puVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  iVar2 = _DAT_60000a00;
  puVar1 = _DAT_600009fc;
  *(undefined2 *)(_DAT_600009fc + 2) = 0;
  for (iVar3 = 0; iVar3 != 0x1c0; iVar3 = iVar3 + 8) {
    iVar4 = iVar2 + iVar3;
    *(int *)(iVar2 + iVar3) = iVar4;
    *(int *)(iVar4 + 4) = iVar4;
  }
  *(undefined4 *)(puVar1 + 8) = 0;
  *(undefined4 *)(puVar1 + 0xc) = 0;
  *puVar1 = 0x37;
  func_0x60134ac8(puVar1 + 0x18,0,0x20);
  *(undefined1 **)(puVar1 + 0x10) = puVar1 + 0x10;
  *(undefined1 **)(puVar1 + 0x14) = puVar1 + 0x10;
  return;
}

