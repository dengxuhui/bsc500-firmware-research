
/* WARNING: Control flow encountered bad instruction data */

void FUN_60010c28(void)

{
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

