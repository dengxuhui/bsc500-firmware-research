
/* WARNING: Heritage AFTER dead removal. Example location: s1 : 0x6000e7dc */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: register */

void FUN_6000e544(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  undefined8 *puVar2;
  int iVar3;
  undefined1 uVar4;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  float fVar11;
  undefined8 uVar12;
  undefined8 uVar13;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined4 uStack_cc;
  undefined4 uStack_c8;
  undefined4 uStack_c4;
  undefined4 uStack_c0;
  undefined4 uStack_bc;
  undefined4 uStack_b8;
  undefined4 uStack_b4;
  float afStack_b0 [2];
  undefined4 uStack_a8;
  undefined1 auStack_a0 [64];
  undefined8 uStack_60;
  undefined8 uStack_58;
  float fStack_50;
  undefined4 uStack_4c;
  
  iVar3 = _DAT_6000ea2c;
  iVar1 = _DAT_6000e9e0;
  if (*(char *)(_DAT_6000ea2c + 0x40) != '\x03') {
    return;
  }
  iVar5 = func_0x60166dd0(_DAT_6000e9e0 + 0x50);
  if ((iVar5 == 1) || (iVar5 = func_0x60166dd0(iVar1 + 0x58), iVar5 == 1)) {
    puVar2 = _DAT_6000e9e4;
    *(undefined4 *)(iVar3 + 100) = 0;
    *(undefined1 *)((int)puVar2 + 0x74) = 0;
    *(undefined1 *)((int)puVar2 + 0x51) = 0;
    uVar6 = _DAT_6000e96c;
    *(undefined1 *)((int)puVar2 + 0x21) = 5;
    *(undefined4 *)(puVar2 + 0xe) = uVar6;
    *(undefined4 *)((int)puVar2 + 0x54) = 0xffffffff;
    *(undefined4 *)(puVar2 + 0xb) = 0xffffffff;
    *(undefined4 *)((int)puVar2 + 0x5c) = 0xffffffff;
    return;
  }
  ZeroBytes(&uStack_60,0x18);
  puVar2 = _DAT_6000e9e4;
  if (*(int *)(iVar3 + 100) == 0) {
    uVar8 = *(undefined4 *)(iVar1 + 0x58);
    uVar9 = *(undefined4 *)(iVar1 + 0x5c);
    *(undefined1 *)((int)_DAT_6000e9e4 + 0x74) = 0;
    *(undefined1 *)((int)puVar2 + 0x51) = 0;
    *(undefined1 *)((int)puVar2 + 0x21) = 4;
    *(undefined4 *)(puVar2 + 0xe) = _DAT_6000e9e8;
    *(undefined4 *)((int)puVar2 + 0x54) = 0xffffffff;
    *(undefined4 *)(puVar2 + 0xb) = 0xffffffff;
    *(undefined4 *)((int)puVar2 + 0x5c) = 0xffffffff;
    uVar6 = *(undefined4 *)(iVar1 + 0x54);
    *(undefined4 *)(iVar3 + 0x54) = *(undefined4 *)(iVar1 + 0x50);
    *(undefined4 *)(iVar3 + 0x58) = uVar6;
    *(undefined4 *)(iVar3 + 0x5c) = uVar8;
    *(undefined4 *)(iVar3 + 0x60) = uVar9;
    *(undefined4 *)(iVar3 + 100) = 1;
    uVar12 = FUN_6016759c();
    uVar13 = FUN_6016759c(uVar6);
    uVar6 = FUN_601675d8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,
                         (int)((ulonglong)uVar13 >> 0x20));
    uVar12 = FUN_6016759c(uVar8);
    uVar13 = FUN_6016759c(uVar9);
    uVar8 = FUN_601675d8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,
                         (int)((ulonglong)uVar13 >> 0x20));
    iVar5 = FUN_60018dc0(uVar6,param_2,uVar8,&uStack_60);
    if (iVar5 == 0) {
      fVar11 = (float)FUN_60161ad0(uVar6,param_2,uVar8,param_4,(int)uStack_60,param_6,(int)uStack_58
                                  );
      *(float *)((int)puVar2 + 0xa4) = fStack_50;
      *puVar2 = uStack_60;
      puVar2[1] = uStack_58;
      *(float *)(puVar2 + 0x15) = fVar11 + (*(float *)(iVar3 + 0x50) - fStack_50);
      FUN_600191d8(iVar1 + 0x30,uStack_4c);
      FUN_60018db0(fStack_50);
    }
    goto LAB_6000e9b0;
  }
  *(int *)(iVar3 + 100) = *(int *)(iVar3 + 100) + 1;
  uVar6 = *(undefined4 *)(iVar3 + 0x58);
  uVar8 = *(undefined4 *)(iVar3 + 0x5c);
  uVar9 = *(undefined4 *)(iVar3 + 0x60);
  uVar12 = FUN_6016759c(*(undefined4 *)(iVar3 + 0x54));
  uVar13 = FUN_6016759c(uVar6);
  uVar6 = FUN_601675d8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,
                       (int)((ulonglong)uVar13 >> 0x20));
  uVar12 = FUN_6016759c(uVar8);
  uVar13 = FUN_6016759c(uVar9);
  uVar8 = FUN_601675d8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,
                       (int)((ulonglong)uVar13 >> 0x20));
  uVar10 = *(undefined4 *)(iVar1 + 0x5c);
  uVar9 = *(undefined4 *)(iVar1 + 0x54);
  uVar7 = *(undefined4 *)(iVar1 + 0x58);
  uVar12 = FUN_6016759c(*(undefined4 *)(iVar1 + 0x50));
  uVar13 = FUN_6016759c(uVar9);
  uVar9 = FUN_601675d8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,
                       (int)((ulonglong)uVar13 >> 0x20));
  uVar12 = FUN_6016759c(uVar7);
  uVar13 = FUN_6016759c(uVar10);
  uVar7 = FUN_601675d8((int)uVar12,(int)((ulonglong)uVar12 >> 0x20),(int)uVar13,
                       (int)((ulonglong)uVar13 >> 0x20));
  fVar11 = (float)FUN_60161ad0(uVar6,param_2,uVar8,param_4,uVar9,param_6,uVar7);
  if (fVar11 < 4.0) goto LAB_6000e9b0;
  uVar6 = FUN_6015e318(uVar6,param_2,uVar8,param_4,uVar9,param_6,uVar7);
  ZeroBytes(afStack_b0,0x50);
  ZeroBytes(&uStack_d0,0x20);
  uStack_d4 = 0;
  iVar5 = FUN_60018ec4(uVar9,param_2,uVar7,param_4,uVar6,&uStack_60);
  puVar2 = _DAT_6000e9e4;
  if (iVar5 == 2) {
    *(undefined1 *)((int)_DAT_6000e9e4 + 0x21) = 3;
    uVar6 = _DAT_6000e9e8;
    *(undefined1 *)((int)puVar2 + 0x74) = 0;
    *(undefined1 *)((int)puVar2 + 0x51) = 0;
    *(undefined4 *)(puVar2 + 0xe) = uVar6;
    *(undefined4 *)((int)puVar2 + 0x54) = 0xffffffff;
    *(undefined4 *)(puVar2 + 0xb) = 0xffffffff;
    *(undefined4 *)((int)puVar2 + 0x5c) = 0xffffffff;
    iVar5 = FUN_60018dc0(uVar9,param_2,uVar7,&uStack_60);
    if (iVar5 == 0) {
      fVar11 = (float)FUN_60161ad0(uVar9,param_2,uVar7,param_4,(int)uStack_60,param_6,(int)uStack_58
                                  );
      *(float *)((int)puVar2 + 0xa4) = fStack_50;
      *puVar2 = uStack_60;
      puVar2[1] = uStack_58;
      *(float *)(puVar2 + 0x15) = fVar11 + (*(float *)(iVar3 + 0x50) - fStack_50);
      goto LAB_6000e992;
    }
  }
  else {
    if (iVar5 == 1) {
      *(undefined1 *)((int)_DAT_6000e9e4 + 0x21) = 1;
      *(undefined1 *)((int)puVar2 + 0x74) = 0;
      *(undefined1 *)((int)puVar2 + 0x51) = 0;
      *(undefined4 *)(puVar2 + 0xe) = _DAT_6000e9e8;
      *(float *)((int)puVar2 + 0xa4) = fStack_50;
      *(undefined4 *)((int)puVar2 + 0x54) = 0xffffffff;
      *(undefined4 *)(puVar2 + 0xb) = 0xffffffff;
      *(undefined4 *)((int)puVar2 + 0x5c) = 0xffffffff;
      *puVar2 = uStack_60;
      puVar2[1] = uStack_58;
      *(float *)(puVar2 + 0x15) = *(float *)(iVar3 + 0x50) - fStack_50;
    }
    else {
      if (iVar5 != 0) goto LAB_6000e9a4;
      fVar11 = *(float *)(iVar3 + 0x50);
      if (fVar11 + -20.0 <= fStack_50) {
        *(undefined4 *)(_DAT_6000e9e4 + 0x15) = 0;
        *(float *)((int)puVar2 + 0xa4) = fStack_50;
        *(undefined1 *)((int)puVar2 + 0x21) = 2;
      }
      else {
        *(undefined1 *)((int)_DAT_6000e9e4 + 0x21) = 0;
        *(float *)((int)puVar2 + 0xa4) = fStack_50;
        *(float *)(puVar2 + 0x15) = fVar11 - fStack_50;
        iVar5 = FUN_60019264(afStack_b0,&uStack_d4);
        if (iVar5 == 0) {
          *(undefined1 *)((int)puVar2 + 0x51) = 1;
          uVar4 = FUN_60018cf8(uStack_a8);
          fVar11 = fStack_50;
          *(undefined1 *)((int)puVar2 + 0x24) = uVar4;
          *(undefined4 *)((int)puVar2 + 0x2c) = uStack_d4;
          *(float *)(puVar2 + 5) = afStack_b0[0] - fStack_50;
          CopyBytes(puVar2 + 6,auStack_a0,0x20);
          *(undefined1 *)(puVar2 + 10) = 0;
        }
        else {
          *(undefined1 *)((int)puVar2 + 0x51) = 0;
          fVar11 = fStack_50;
        }
        iVar5 = FUN_60018cbc(fVar11,&uStack_d0);
        if (iVar5 == 0) {
          *(undefined1 *)((int)puVar2 + 0x74) = 1;
          *(undefined4 *)((int)puVar2 + 0x54) = uStack_d0;
          *(undefined4 *)(puVar2 + 0xb) = uStack_cc;
          *(undefined4 *)((int)puVar2 + 0x5c) = uStack_c8;
          *(undefined4 *)(puVar2 + 0xc) = uStack_c4;
          *(undefined4 *)((int)puVar2 + 100) = uStack_c0;
          *(undefined4 *)(puVar2 + 0xd) = uStack_bc;
          *(undefined4 *)((int)puVar2 + 0x6c) = uStack_b8;
          *(undefined4 *)(puVar2 + 0xe) = uStack_b4;
        }
        else {
          *(undefined1 *)((int)puVar2 + 0x74) = 0;
          *(undefined4 *)((int)puVar2 + 0x54) = uStack_d0;
          *(undefined4 *)(puVar2 + 0xb) = uStack_cc;
          *(undefined4 *)((int)puVar2 + 0x5c) = uStack_c8;
          *(undefined4 *)(puVar2 + 0xe) = uStack_b4;
        }
      }
      puVar2 = _DAT_6000e9e4;
      *_DAT_6000e9e4 = uStack_60;
      puVar2[1] = uStack_58;
    }
LAB_6000e992:
    FUN_600191d8(iVar1 + 0x30,uStack_4c);
    FUN_60018db0(fStack_50);
  }
LAB_6000e9a4:
  uVar6 = *(undefined4 *)(iVar1 + 0x54);
  uVar8 = *(undefined4 *)(iVar1 + 0x58);
  uVar9 = *(undefined4 *)(iVar1 + 0x5c);
  *(undefined4 *)(iVar3 + 0x54) = *(undefined4 *)(iVar1 + 0x50);
  *(undefined4 *)(iVar3 + 0x58) = uVar6;
  *(undefined4 *)(iVar3 + 0x5c) = uVar8;
  *(undefined4 *)(iVar3 + 0x60) = uVar9;
LAB_6000e9b0:
  puVar2 = _DAT_6000e9e4;
  if (*(char *)((int)_DAT_6000e9e4 + 0x21) == '\x02') {
    FUN_6014a9b0();
    if (*(char *)(puVar2 + 4) == '\x03') {
      *(undefined1 *)(iVar1 + 2) = 0;
    }
    if (*(code **)(iVar3 + 0x4c) != (code *)0x0) {
      (**(code **)(iVar3 + 0x4c))(*(undefined1 *)(iVar3 + 0x42));
    }
  }
  return;
}

