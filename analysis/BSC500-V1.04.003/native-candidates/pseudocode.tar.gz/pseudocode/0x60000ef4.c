
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000ef4(uint param_1)

{
  if (param_1 - 3 < 5) {
    *_DAT_60000f14 = _DAT_60000f18 | *_DAT_60000f14 & 0xf8ff | (param_1 & 7) << 8;
    return;
  }
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

