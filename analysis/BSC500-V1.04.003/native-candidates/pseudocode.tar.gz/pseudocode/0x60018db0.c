
/* WARNING: Removing unreachable block (ram,0x60112898) */
/* WARNING: Removing unreachable block (ram,0x601128fe) */
/* WARNING: Removing unreachable block (ram,0x60112838) */
/* WARNING: Removing unreachable block (ram,0x60112924) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60018db0(float param_1,undefined4 param_2)

{
  int iVar1;
  int *piVar2;
  uint *puVar3;
  uint uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  int iVar10;
  uint uVar11;
  uint uVar12;
  bool bVar13;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr9;
  float fVar14;
  float extraout_s0;
  float extraout_s0_00;
  float extraout_s0_01;
  undefined4 extraout_s1;
  undefined4 extraout_s1_00;
  undefined4 extraout_s1_01;
  undefined4 extraout_s1_02;
  float extraout_s2;
  float extraout_s2_00;
  float extraout_s2_01;
  float extraout_s2_02;
  float unaff_s18;
  undefined8 uStack_40;
  
  iVar1 = _DAT_60018dbc;
  piVar2 = (int *)(_DAT_60018dbc + 0x48);
  if (piVar2 == (int *)0x0) {
    return 0xffffffff;
  }
  iVar10 = 0;
  iVar6 = **(int **)(_DAT_60018dbc + 0x4c);
  iVar7 = (*(int **)(_DAT_60018dbc + 0x4c))[1];
  puVar3 = (uint *)(iVar6 + 8);
  param_1 = *(float *)(iVar6 + iVar7 * 0x10 + -0xc) - param_1;
  coprocessor_function2(10,0,0,in_cr9,in_cr1,in_cr0);
  while( true ) {
    if (iVar7 == iVar10) {
      return 1;
    }
    if (((float)puVar3[-2] <= unaff_s18) && (fVar14 = (float)puVar3[-1], unaff_s18 <= fVar14))
    break;
    puVar3 = puVar3 + 4;
    iVar10 = iVar10 + 1;
  }
  uVar12 = *puVar3;
  if ((*(int *)(_DAT_60018dbc + 100) == iVar10) &&
     (fVar14 = *(float *)(_DAT_60018dbc + 0x68), fVar14 <= unaff_s18)) {
    uVar12 = *(uint *)(_DAT_60018dbc + 0x6c);
  }
  uVar11 = puVar3[1];
  uStack_40 = 0;
  for (; uVar12 < uVar11; uVar12 = uVar12 + 1) {
    iVar6 = FUN_600f8a44(fVar14,param_2,param_1,*piVar2,uVar12,&uStack_40);
    if (iVar6 != 0) {
      return 0xffffffff;
    }
    fVar14 = (float)uStack_40;
    param_1 = extraout_s2;
    param_2 = extraout_s1;
    if (unaff_s18 <= (float)uStack_40) goto LAB_601127ae;
  }
  uVar12 = 0;
LAB_601127ae:
  uVar4 = *(uint *)(iVar1 + 0x5c);
  uVar11 = 0;
  if (uVar4 >> 1 <= uVar12) {
    uVar11 = uVar12 - (uVar4 >> 1);
  }
  uVar5 = *(uint *)(*piVar2 + 0x14);
  uVar8 = (uVar4 & 1) + uVar12 + (uVar4 >> 1);
  if (uVar5 < uVar8) {
    uVar8 = uVar5;
  }
  uVar9 = uVar8;
  if (uVar8 - uVar11 < uVar4) {
    uVar4 = uVar4 - (uVar8 - uVar11);
    bVar13 = uVar11 < uVar4;
    uVar11 = uVar11 - uVar4;
    if (bVar13) {
      uVar11 = 0;
    }
    uVar9 = uVar8 + uVar4;
    if (uVar5 < uVar8 + uVar4) {
      uVar9 = uVar5;
    }
  }
  uVar4 = *(uint *)(iVar1 + 0x54);
  if ((uVar4 != uVar11) || (*(uint *)(iVar1 + 0x58) != uVar9)) {
    if ((uVar4 < uVar9) && (uVar11 < *(uint *)(iVar1 + 0x58))) {
      if (uVar11 < uVar4) {
        iVar6 = uVar9 * 8;
        uVar4 = uVar9;
        while( true ) {
          uVar4 = uVar4 - 1;
          iVar6 = iVar6 + -8;
          if (uVar4 <= uVar11) break;
          if ((*(uint *)(iVar1 + 0x54) <= uVar4) && (uVar4 < *(uint *)(iVar1 + 0x58))) {
            FUN_60136e74(uVar11 * -8 + *(int *)(iVar1 + 0x50) + iVar6,
                         *(int *)(iVar1 + 0x50) + *(uint *)(iVar1 + 0x54) * -8 + iVar6);
            fVar14 = extraout_s0;
            param_1 = extraout_s2_00;
            param_2 = extraout_s1_00;
          }
        }
      }
      else {
        iVar6 = 0;
        for (uVar4 = uVar11; uVar4 < uVar9; uVar4 = uVar4 + 1) {
          if ((*(uint *)(iVar1 + 0x54) <= uVar4) && (uVar4 < *(uint *)(iVar1 + 0x58))) {
            FUN_60136e74(*(int *)(iVar1 + 0x50) + iVar6,
                         uVar11 * 8 + *(int *)(iVar1 + 0x50) + iVar6 + *(uint *)(iVar1 + 0x54) * -8)
            ;
            fVar14 = extraout_s0_00;
            param_1 = extraout_s2_01;
            param_2 = extraout_s1_01;
          }
          iVar6 = iVar6 + 8;
        }
      }
    }
    for (iVar6 = 0; uVar4 = uVar11 + iVar6, uVar4 < uVar9; iVar6 = iVar6 + 1) {
      if (((uVar4 < *(uint *)(iVar1 + 0x54)) || (*(uint *)(iVar1 + 0x58) <= uVar4)) &&
         (iVar7 = FUN_600f8a44(fVar14,param_2,param_1,*piVar2,uVar4,
                               *(int *)(iVar1 + 0x50) + iVar6 * 8), fVar14 = extraout_s0_01,
         param_1 = extraout_s2_02, param_2 = extraout_s1_02, iVar7 != 0)) {
        return 0xffffffff;
      }
    }
    *(uint *)(iVar1 + 0x54) = uVar11;
    *(uint *)(iVar1 + 0x58) = uVar9;
    *(uint *)(iVar1 + 0x60) = uVar9 - uVar11;
    *(int *)(iVar1 + 100) = iVar10;
    *(float *)(iVar1 + 0x68) = (float)uStack_40;
    *(uint *)(iVar1 + 0x6c) = uVar12;
  }
  return 0;
}

