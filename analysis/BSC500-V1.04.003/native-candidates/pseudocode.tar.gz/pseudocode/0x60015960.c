
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60015960(void)

{
  char *pcVar1;
  int iVar2;
  
  pcVar1 = _DAT_600159dc;
  if ((_DAT_600159dc[3] == '\0') && (iVar2 = FUN_601176c4(0x7e), iVar2 != 0)) {
    iVar2 = FUN_6001c904(pcVar1[3] ^ 1);
    if (iVar2 == 0) goto LAB_600159b0;
    pcVar1[3] = '\x01';
  }
  else {
    if ((pcVar1[2] != '\x01') || ((iVar2 = FUN_601176c4(0x7e), iVar2 == 0 || (*pcVar1 != '\0')))) {
      return 0;
    }
    iVar2 = FUN_6001c904(pcVar1[3] ^ 1);
    if (iVar2 == 0) goto LAB_600159b0;
  }
  if (*pcVar1 != '\x01') {
    return 0;
  }
LAB_600159b0:
  pcVar1[3] = '\0';
  *pcVar1 = '\0';
  return 1;
}

