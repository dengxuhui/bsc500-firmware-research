
undefined * FUN_6000a0d0(void)

{
  return &UNK_6000a0d4;
}

