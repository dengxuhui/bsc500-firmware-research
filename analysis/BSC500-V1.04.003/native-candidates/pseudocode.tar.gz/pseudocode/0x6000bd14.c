
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Possible PIC construction at 0x6000bd38: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6000bd3c) */
/* WARNING: Removing unreachable block (ram,0x6000bd42) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000bd14(void)

{
  byte bVar1;
  byte bVar2;
  ushort uVar3;
  ushort uVar4;
  short sVar5;
  int iVar6;
  uint *puVar7;
  int extraout_r2;
  int unaff_r4;
  int unaff_r7;
  undefined8 uVar8;
  
  iVar6 = FUN_601179cc();
  if (iVar6 != 0) {
    FUN_60017160(iVar6,uRam6000bd80);
    FUN_60017164(iVar6,uRam6000bd84);
    FUN_60017168(iVar6,uRam6000bd88);
    *(undefined4 *)(iVar6 + 0xc) = uRam6000bd8c;
    return;
  }
  FUN_6016804c(_DAT_6000bda0,_DAT_6000bda4,0x118);
  uVar8 = FUN_6016804c(_DAT_6000bda0,_DAT_6000bda4,0x124);
  puVar7 = (uint *)uVar8;
  uVar3 = *(ushort *)((int)puVar7 + unaff_r7);
  *puVar7 = (uint)((ulonglong)uVar8 >> 0x20);
  bVar1 = *(byte *)((int)puVar7 * 2);
  *puVar7 = (uint)bVar1;
  bVar2 = *(byte *)(unaff_r4 + (int)puVar7);
  *puVar7 = (uint)bVar1;
  uVar4 = *(ushort *)((int)puVar7 + unaff_r7);
  *puVar7 = (uint)uVar4;
  sVar5 = *(short *)(unaff_r4 + (uint)uVar3);
  *puVar7 = (uint)uVar4;
  *puVar7 = (int)*(short *)((int)puVar7 + (uint)bVar2);
  *puVar7 = (int)*(short *)((uint)bVar2 + unaff_r7);
  *puVar7 = (int)*(short *)(extraout_r2 + sVar5);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

