
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_60003d26(undefined4 param_1)

{
  byte bVar1;
  short sVar2;
  undefined1 uVar3;
  code *pcVar4;
  char cVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  int iVar9;
  uint *puVar10;
  undefined4 *puVar11;
  undefined4 extraout_r2;
  uint uVar12;
  undefined4 uVar13;
  int unaff_r4;
  uint uVar14;
  int unaff_r5;
  uint *puVar15;
  int iVar16;
  undefined4 *puVar17;
  uint uVar18;
  int *piVar19;
  int unaff_r8;
  undefined4 *puVar20;
  undefined4 in_cr4;
  int *in_stack_00000008;
  int in_stack_0000000c;
  undefined4 in_stack_00000010;
  undefined4 *in_stack_00000014;
  undefined4 in_stack_000000a4;
  
  *puRam60003f2c = param_1;
  uVar6 = FUN_6000bc5c();
  pcVar4 = pcRam60003f34;
  *puRam60003f30 = uVar6;
  uVar6 = (*pcVar4)(0);
  puVar11 = puRam60003f38;
  *puRam60003f38 = uVar6;
  uVar6 = (*pcVar4)(1);
  puVar11[1] = uVar6;
  uVar6 = (*pcVar4)(2);
  puVar11[2] = uVar6;
  FUN_60006c90();
  uVar6 = FUN_6000fcb8();
  *(undefined4 *)(unaff_r5 + -0xc) = uVar6;
  uVar6 = FUN_60147954();
  *puRam60003f3c = uVar6;
  FUN_60006eb8(unaff_r4 + 0xc,5);
  FUN_60006e90(uRam60003f40,0x60000);
  uVar6 = FUN_60167488(0x60003f44,uRam60003f4c,0,0x10);
  *(undefined4 *)(unaff_r5 + -4) = uVar6;
  func_0x60167bd4();
  FUN_60008bf8();
  uVar6 = FUN_6011c240(0x60003f50,uRam60003f60,4);
  *(undefined4 *)(unaff_r5 + -0x1c) = uVar6;
  uVar6 = FUN_600102ac(0x20);
  *(undefined4 *)(unaff_r5 + -0x18) = uVar6;
  FUN_60115764(*(undefined4 *)(unaff_r5 + -0x24),uVar6);
  pcVar4 = pcRam60003f6c;
  uVar6 = uRam60003f68;
  iVar9 = iRam60003f64;
  (*pcRam60003f6c)(*(undefined4 *)(unaff_r5 + -0x24),iRam60003f64,uRam60003f68,0);
  uVar13 = uRam60003f70;
  iVar16 = iVar9 + 5;
  (*pcVar4)(*(undefined4 *)(unaff_r5 + -0x24),iVar16,uRam60003f70,0);
  (*pcVar4)(*(undefined4 *)(unaff_r5 + -0x24),iVar9 + 6,uRam60003f74,0);
  FUN_60162398(unaff_r5 + 0x10);
  thunk_FUN_60016c68();
  piVar19 = piRam60003f78;
  while( true ) {
    while (iVar7 = FUN_60162268(*(undefined4 *)(unaff_r8 + 0xc)), iVar7 == 0) {
      iVar7 = FUN_60154888();
      if (*(char *)(iVar7 + 0x18b) != '\0') {
        FUN_6000bf1c(*(undefined4 *)(unaff_r8 + 0x10),0,6);
      }
      (**(code **)(*(int *)*piVar19 + 8))();
    }
    FUN_6014aa3c(*(undefined4 *)(unaff_r8 + 4),iVar16,uVar13);
    FUN_6014aa3c(*(undefined4 *)(unaff_r8 + 4),iVar9,uVar6);
    FUN_6000befc(*(undefined4 *)(unaff_r8 + 0x10));
    iVar7 = func_0x60166f2c(0x60003f7c);
    if (iVar7 == 0) break;
    FUN_601673ec(*(undefined4 *)(unaff_r8 + 0x24));
    thunk_FUN_60016c78();
    iVar8 = FUN_6015e9c8();
    if (iVar8 != 0) {
      (**(code **)(**(int **)(*piVar19 + 4) + 0x18))(*(int **)(*piVar19 + 4),0);
    }
    FUN_60008d42();
    FUN_6000bcd0();
    FUN_60154888();
    FUN_60006e58();
    *(undefined1 *)(*piVar19 + 0x55) = 2;
    FUN_60114dd4(*(undefined4 *)(unaff_r8 + 0xc));
    FUN_60154888();
    FUN_60006e38();
    FUN_60165124(iVar7,0x15,0);
    iVar7 = FUN_6015e9c8();
    if (iVar7 != 0) {
      (**(code **)(**(int **)(*piVar19 + 4) + 0x18))(*(int **)(*piVar19 + 4),1);
    }
    FUN_60008d40();
    FUN_6000449c();
    FUN_6000d73c();
    FUN_60010b64();
    func_0x60167bd4(*(undefined4 *)(unaff_r8 + 0x24));
    FUN_6015f3c8(1);
    FUN_60006d08();
    FUN_6014aa24(*(undefined4 *)(unaff_r8 + 4),iVar9,uVar6,0);
    FUN_6014aa24(*(undefined4 *)(unaff_r8 + 4),iVar16,uVar13,0);
    thunk_FUN_60016c68();
  }
  FUN_6016804c(0x60003f80,0x60003f8c,0x48);
  iVar9 = iRam00000054;
  uRam00000000 = 0;
  iVar16 = *piRam00000058;
  piRam00000058[3] = in_stack_0000000c;
  bVar1 = *(byte *)(in_stack_0000000c + 5);
  *(int *)(iVar16 + 0x34) = in_stack_0000000c;
  uRam00000000 = CONCAT13(3,(int3)uRam00000000);
  uRam00000004 = 0;
  uVar6 = *(undefined4 *)(in_stack_0000000c + 0x54);
  *(undefined4 *)(bVar1 + 0x74) = *(undefined4 *)(in_stack_0000000c + 0x58);
  piVar19 = *(int **)(bVar1 + 0x54);
  *(int **)(*(int *)(in_stack_0000000c + 0x14) + 0x44) = piVar19;
  *(undefined4 *)uVar6 = uVar6;
  *(undefined4 *)uVar6 = uVar6;
  in_stack_000000a4 = 0x600041ec;
  puVar15 = (uint *)piVar19[0x15];
  *(undefined4 *)uVar6 = uVar6;
  uVar13 = *(undefined4 *)(iVar9 + 0x58);
  *(undefined4 *)uVar6 = uVar6;
  puVar15[0xd] = 0x600041ec;
  puVar15[0xd] = 0xc00083d8;
  uVar14 = (uint)(short)puVar15[-0xfffdf0a];
  *(uint *)(uVar14 + 0x54) = uVar14;
  puVar17 = *(undefined4 **)(in_stack_0000000c + 0x14);
  *(undefined4 *)(uVar14 + 0x54) = uVar13;
  uVar3 = SUB41(piVar19,0);
  *(undefined1 *)(uVar14 + 0x15) = uVar3;
  sVar2 = *(short *)((int)puVar15 * 2);
  puVar17[5] = uVar14;
  iVar16 = puVar17[0xd];
  *(undefined1 *)(iVar16 + 0xd) = uVar3;
  puVar15[0x15] = uVar14;
  *(char *)(uVar14 + 1) = (char)puVar15;
  *(undefined1 *)(iVar16 + 1) = uVar3;
  uVar6 = puVar17[0x1d];
  *(int *)(uVar14 + 0x54) = iVar16;
  *(char *)((int)puVar17 + 0xd) = (char)iVar16;
  iVar9 = *(int *)(_DAT_60003fb8 + 8);
  in_stack_0000000c = 0x60003f07;
  puVar11 = puVar17;
  in_stack_00000008 = piVar19;
  if (iVar9 == 0) {
    FUN_6016804c(_DAT_60165554,uRam6016553c,0x329);
LAB_6016550e:
    FUN_6016804c(uRam60165538,uRam6016553c,0x32a);
    uVar6 = _DAT_60165550;
    puVar10 = puVar15;
  }
  else {
    iVar7 = FUN_601631fc(iVar9,(int)sVar2,uVar6);
    if (iVar7 != 3) goto LAB_6016550e;
    puVar10 = (uint *)FUN_60167d0c();
    iVar7 = FUN_60163ab8();
    uVar6 = _DAT_60165550;
    if (iVar7 != 0) {
      puVar11 = (undefined4 *)FUN_60167d0c();
      iVar7 = FUN_6015b3f4();
      uVar6 = uRam60165540;
      if (iVar7 == 0) {
        func_0x60167d14(puVar11);
        puVar11 = (undefined4 *)FUN_60167d0c();
        iVar7 = FUN_60163aac();
        uVar6 = uRam60165548;
        if (iVar7 == 0) {
          func_0x60167d14(puVar11);
          func_0x60167d14(puVar10);
          iVar16 = FUN_60163ab8();
          uVar6 = FUN_60167d0c();
          if ((code *)*puRam6016554c != (code *)0x0) {
            (*(code *)*puRam6016554c)(iVar9);
          }
          if (iVar16 == *(int *)(iVar9 + 0x28)) {
            cVar5 = *(char *)(iVar9 + 0x27) + -1;
            *(char *)(iVar9 + 0x27) = cVar5;
            if (cVar5 == '\0') {
              if (*(char *)(iVar9 + 0x26) != *(char *)(iVar16 + 0x3d)) {
                FUN_6013fdb8(iVar16,2,(char *)(iVar9 + 0x26));
              }
              piVar19 = *(int **)(iVar9 + 0x1c);
              if (piVar19 == (int *)(iVar9 + 0x1c)) {
                puVar11 = (undefined4 *)0x0;
                *(undefined1 *)(iVar9 + 0x26) = 0xff;
                *(undefined4 *)(iVar9 + 0x28) = 0;
                *(short *)(iVar9 + 0x24) = *(short *)(iVar9 + 0x24) + 1;
                goto LAB_60165486;
              }
              uVar3 = *(undefined1 *)((int)piVar19 + 0x21);
              *(int **)(iVar9 + 0x28) = piVar19 + -7;
              *(undefined1 *)(iVar9 + 0x26) = uVar3;
              *(char *)(iVar9 + 0x27) = *(char *)(iVar9 + 0x27) + '\x01';
              FUN_6013a15a();
              func_0x60167d14(uVar6);
              func_0x60163a08();
            }
            else {
              func_0x60167d14(uVar6);
            }
            puVar11 = (undefined4 *)0x0;
          }
          else {
            puVar11 = (undefined4 *)0xffffffff;
            *(undefined4 *)(iVar16 + 0x38) = 0xffffffff;
LAB_60165486:
            func_0x60167d14(uVar6);
          }
          return puVar11;
        }
      }
    }
  }
  uVar13 = uRam6016553c;
  func_0x60168578(uVar6,uRam6016553c);
  FUN_6016804c(uRam60165544,uVar13,0x32f);
  iVar9 = *piVar19;
  *(undefined4 **)piVar19[2] = puVar11;
  uVar12 = *puVar10;
  puVar11 = (undefined4 *)puVar10[2];
  uVar18 = puVar10[3];
  *(uint *)puVar10[4] = uVar18;
  uVar6 = *puVar11;
  uVar13 = puVar11[1];
  puVar20 = puVar11 + 3;
  *(uint *)puVar11[2] = uVar18;
  uVar12 = (uint)(puVar10 + 5) | uVar12;
  *(undefined4 *)(iVar9 + 4) = uVar13;
  *puVar17 = puVar15;
  coprocessor_storelong(6,in_cr4,uVar12 - 0x14);
  iVar9 = FUN_60163ab8(iVar9,uVar6,iVar16,uVar14);
  uVar6 = _DAT_60165550;
  if (iVar9 == 0) {
LAB_6016537e:
    uVar13 = uRam601653e8;
    func_0x60168578(uVar6,uRam601653e8);
    FUN_6016804c(uRam601653ec,uVar13,0x29f);
LAB_60165392:
    FUN_6016804c(_DAT_60165554,uRam601653e8,0x2a2);
  }
  else {
    puVar15 = (uint *)FUN_60167d0c();
    iVar9 = FUN_6015b3f4();
    uVar6 = uRam601653f0;
    if (iVar9 != 0) goto LAB_6016537e;
    func_0x60167d14(puVar15);
    puVar15 = (uint *)FUN_60167d0c();
    iVar9 = FUN_60163aac();
    uVar6 = uRam601653f4;
    if (iVar9 != 0) goto LAB_6016537e;
    func_0x60167d14(puVar15);
    func_0x60167d14(uVar12 - 0x14);
    if (puVar20 == (undefined4 *)0x0) goto LAB_60165392;
    iVar9 = FUN_601631fc(puVar20);
    if (iVar9 == 3) {
      iVar9 = FUN_60163ab8();
      if (iVar9 != 0) {
        uVar6 = FUN_60167d0c();
        if ((code *)*puRam601653fc != (code *)0x0) {
          (*(code *)*puRam601653fc)(puVar20);
        }
        *(undefined4 *)(iVar9 + 0x38) = 0;
        if (puVar11[0xd] == iVar9) {
LAB_6016532c:
          *(char *)((int)puVar11 + 0x33) = *(char *)((int)puVar11 + 0x33) + '\x01';
        }
        else {
          do {
            if (*(short *)(puVar11 + 0xc) != 0) {
              puVar11[0xd] = iVar9;
              *(short *)(puVar11 + 0xc) = *(short *)(puVar11 + 0xc) + -1;
              *(undefined1 *)((int)puVar11 + 0x32) = *(undefined1 *)(iVar9 + 0x3d);
              goto LAB_6016532c;
            }
            if (in_stack_00000008 == (int *)0x0) {
              *(undefined4 *)(iVar9 + 0x38) = 0xfffffffe;
              func_0x60167d14(uVar6);
              return (undefined4 *)0xfffffffe;
            }
            if (*(byte *)(iVar9 + 0x3d) < *(byte *)(puVar11[0xd] + 0x3d)) {
              FUN_6013fdb8(puVar11[0xd],2,(byte *)(iVar9 + 0x3d));
            }
            FUN_6013a10c(puVar11 + 10,iVar9,*(undefined1 *)((int)puVar11 + 0x1d));
            if (0 < (int)in_stack_00000008) {
              FUN_6016295c(iVar9 + 0x58,0,&stack0x00000008);
              func_0x60167bd4(iVar9 + 0x58);
            }
            func_0x60167d14(uVar6);
            func_0x60163a08();
            puVar17 = *(undefined4 **)(iVar9 + 0x38);
          } while (puVar17 == (undefined4 *)0xfffffff7);
          if (puVar17 != (undefined4 *)0x0) {
            return puVar17;
          }
          uVar6 = FUN_60167d0c();
        }
        func_0x60167d14(uVar6);
        if ((code *)*_DAT_60165400 != (code *)0x0) {
          (*(code *)*_DAT_60165400)(puVar20);
        }
        return (undefined4 *)0x0;
      }
      goto LAB_60165100;
    }
  }
  FUN_6016804c(uRam601653f8,uRam601653e8,0x2a3);
LAB_60165100:
  iVar9 = FUN_6016804c(&UNK_60165404,uRam601653e8,0x2a7);
  *(char *)(iVar9 + 0x15) = (char)puVar15;
  *(uint **)(uVar12 + 0x20) = puVar15;
  iVar9 = iRam00000094;
  uVar18 = puVar15[5];
  puVar11 = *(undefined4 **)(uVar12 + 0x50);
  uVar14 = puVar15[1];
  *(undefined4 *)(uVar18 + 0x54) = extraout_r2;
  *(undefined1 *)(uVar18 + 0x14) = 0x74;
  *(uint *)(iVar9 + 0x54) = uVar14;
  uVar12 = *(uint *)(iVar9 + 0x14);
  *(uint *)(*(int *)(iVar9 + 0x14) + 0x14) = uVar14;
  uVar13 = uRam00000030;
  uVar14 = uRam0000002c;
  iVar9 = iRam00000028;
  uVar6 = uRam00000024;
  *puVar11 = uRam00000030;
  uVar14 = uVar14 | uVar12;
  *(undefined4 *)((uVar18 | 100) + 4) = uVar6;
  **(undefined4 **)(iVar9 + 8) = uVar13;
  *in_stack_00000014 = in_stack_00000010;
  uVar6 = *in_stack_00000014;
  uVar13 = in_stack_00000014[1];
  *(undefined4 *)in_stack_00000014[2] = in_stack_00000010;
  puVar11 = (undefined4 *)FUN_60122a50(uVar6,uVar13,in_stack_00000008,in_stack_0000000c);
  if (puVar11 != (undefined4 *)0x0) {
    if (uVar14 == 3) {
      puVar11[2] = uVar6;
      return puVar11;
    }
    if (uVar14 == 2) {
      puVar11[1] = uVar6;
      return puVar11;
    }
    if (uVar14 == 1) {
      *puVar11 = uVar6;
      return puVar11;
    }
  }
  return puVar11;
}

