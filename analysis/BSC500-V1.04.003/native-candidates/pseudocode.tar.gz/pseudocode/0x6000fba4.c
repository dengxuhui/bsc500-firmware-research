
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000fba4(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_60019e10();
  func_0x60161424(&UNK_6000fbc8,uVar1,*(undefined4 *)(_DAT_6000fbc4 + 0xc),
                  *(undefined4 *)(_DAT_6000fbc4 + 0x10),*(undefined4 *)(_DAT_6000fbc4 + 4),
                  *(undefined4 *)(_DAT_6000fbc4 + 8));
  return;
}

