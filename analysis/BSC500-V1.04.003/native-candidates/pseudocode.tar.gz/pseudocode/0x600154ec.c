
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600154ec(undefined4 *param_1,uint param_2,int *param_3)

{
  bool bVar1;
  char *pcVar2;
  int iVar3;
  int *piVar4;
  uint *puVar5;
  uint uVar6;
  uint uVar7;
  uint uVar8;
  uint uVar9;
  bool bVar10;
  bool bVar11;
  uint uStack_30;
  int iStack_2c;
  int *piStack_28;
  
  iVar3 = _DAT_60015608;
  uVar6 = _DAT_60015604;
  pcVar2 = _DAT_600155f8;
  piStack_28 = (int *)0x0;
  if (*_DAT_600155f8 != '\0') {
    piStack_28 = _DAT_600155fc;
  }
  iStack_2c = 0;
  if (_DAT_600155f8[4] != '\0') {
    iStack_2c = _DAT_60015600 - (int)_DAT_600155fc;
  }
  uStack_30 = param_2;
  if (_DAT_600155f8[0xe] == '\x01') {
    bVar1 = false;
    if (_DAT_600155f8[0xf] == '\0') {
      *param_1 = 0;
      uVar9 = 1;
      uVar7 = 0;
      if (pcVar2[8] != '\0') {
        uVar7 = uVar6;
      }
      if (pcVar2[0xc] != '\0') {
        uVar7 = uVar7 + (iVar3 - uVar6);
      }
      if ((1 < param_2) && (uVar7 == 0xfffffffc)) {
        bVar1 = true;
        uVar9 = 2;
        param_1[1] = 0xfffffffc;
      }
    }
    else {
      uVar9 = 0;
    }
    if (pcVar2[0x10] != '\0') {
      FUN_6015a194(&piStack_28,&iStack_2c);
    }
  }
  else {
    puVar5 = (uint *)getProcessStackPointer();
    if (&uStack_30 == puVar5) {
      FUN_6015a194(&piStack_28,&iStack_2c);
    }
    uVar9 = 0;
    bVar1 = false;
  }
  piVar4 = param_3;
  if (((pcVar2[0xf] == '\x01') && (piVar4 = piStack_28, piStack_28 <= param_3)) &&
     (piVar4 = param_3, (int *)(iStack_2c + (int)piStack_28) < param_3)) {
    piVar4 = (int *)(iStack_2c + (int)piStack_28);
  }
  uVar6 = 0;
  if (pcVar2[8] != '\0') {
    uVar6 = _DAT_60015604;
  }
  uVar7 = uVar6;
  if (pcVar2[0xc] != '\0') {
    uVar7 = uVar6 + (_DAT_60015608 - _DAT_60015604);
  }
  for (; piVar4 < (int *)((int)piStack_28 + iStack_2c); piVar4 = piVar4 + 1) {
    uVar8 = *piVar4 - 4;
    if ((((uVar8 & 1) != 0) && (uVar6 <= uVar8)) && (uVar9 < param_2)) {
      bVar11 = 0xe < uVar9;
      bVar10 = uVar9 == 0xf;
      if (uVar9 < 0x10) {
        bVar11 = uVar7 <= uVar8;
        bVar10 = uVar8 == uVar7;
      }
      if (!bVar11 || bVar10) {
        if ((uVar9 == 2 && bVar1) && (uVar8 == param_1[1])) {
          uVar9 = 2;
        }
        else {
          param_1[uVar9] = uVar8;
          uVar9 = uVar9 + 1;
        }
      }
    }
  }
  return;
}

