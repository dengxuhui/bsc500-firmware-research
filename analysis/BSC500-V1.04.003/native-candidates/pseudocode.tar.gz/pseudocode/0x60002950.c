
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60002950(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined *puStack_34;
  undefined1 auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  ZeroBytes(auStack_30,0x20);
  iVar1 = _DAT_60002994;
  uStack_1c = 0x2c;
  puStack_34 = &UNK_6000298c;
  uStack_20 = 0x2000;
  FUN_60137768(_DAT_60002994 + 0x38);
  uVar2 = FUN_601566b4(_DAT_60002998,0,&puStack_34);
  *(undefined4 *)(iVar1 + 4) = uVar2;
  FUN_60156808();
  return 0;
}

