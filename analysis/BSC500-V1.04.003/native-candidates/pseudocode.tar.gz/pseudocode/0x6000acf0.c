
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_6000acf0(int param_1,int param_2)

{
  short sVar1;
  undefined1 uVar2;
  undefined4 uVar3;
  int iVar4;
  int *piVar5;
  int iVar6;
  int extraout_r3;
  int extraout_r3_00;
  int unaff_r4;
  int unaff_r5;
  int unaff_r6;
  int iVar7;
  int *unaff_r7;
  undefined1 in_stack_00000010;
  undefined1 auStack_54 [48];
  
  if (param_1 != 0) {
    piVar5 = (int *)(param_1 + 0x18);
    iVar6 = *piVar5;
    if (*piVar5 != 0) {
      do {
        iVar7 = iVar6;
        iVar6 = *(int *)(iVar7 + 8);
      } while (iVar6 != 0);
      piVar5 = (int *)(iVar7 + 8);
    }
    *piVar5 = param_2;
    return piVar5;
  }
  piVar5 = (int *)FUN_6016804c(uRam6000ad04,0x6000ad08,0x7f);
  *unaff_r7 = unaff_r6;
  uVar2 = (undefined1)unaff_r5;
  *(undefined1 *)(unaff_r4 + 9) = uVar2;
  *(int **)(unaff_r6 + 0x34) = piVar5;
  *(int **)(extraout_r3 + 0x14) = unaff_r7;
  *(int *)(unaff_r4 + 0x44) = unaff_r4;
  *(char *)(extraout_r3 + 0xd) = (char)unaff_r7;
  *(undefined1 *)(unaff_r4 + 9) = uVar2;
  iVar6 = *(int *)(unaff_r6 + 0x14);
  *(int *)(unaff_r4 + 0x54) = extraout_r3;
  *(char *)(extraout_r3 + 0x11) = (char)unaff_r7;
  sVar1 = *(short *)(unaff_r5 * 2);
  *(int *)(iVar6 + 0x54) = extraout_r3;
  *(undefined1 *)(iVar6 + 0x19) = in_stack_00000010;
  *(undefined1 *)(unaff_r4 + 9) = uVar2;
  if (piVar5 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x6000ad30. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    piVar5 = (int *)(**(code **)(*piVar5 + 8))();
    return piVar5;
  }
  uVar3 = FUN_6016804c(uRam6000ad3c,0x6000ad40,0x9b);
  *(int *)(int)sVar1 = iVar6;
  *(undefined1 *)(unaff_r4 + 9) = uVar2;
  *(undefined4 *)(iVar6 + 0x34) = uVar3;
  *(char *)(extraout_r3_00 + 0xd) = (char)sVar1;
  *(undefined1 *)(unaff_r4 + 9) = uVar2;
  *(int *)(iVar6 + 0x54) = iVar6;
  *(char *)(iVar6 + 0x15) = (char)*(undefined2 *)(iVar6 + unaff_r5);
  iVar7 = 0xd;
  iVar6 = _DAT_6000adbc;
  do {
    iVar4 = _DAT_6000adc0;
    if (iVar7 == 0) {
      iVar6 = 0;
      do {
        if (iVar6 == 0x1a4) {
          return (int *)0x1;
        }
        iVar7 = FUN_6015c8a2(auStack_54,iVar4 + iVar6);
        if (iVar7 == 0) {
          FUN_6015bd24(auStack_54);
        }
        else if ((iVar7 == 0xd) || (iVar7 = FUN_6015ad48(iVar4 + iVar6), iVar7 != 0)) {
          return (int *)0x0;
        }
        iVar6 = iVar6 + 0x23;
      } while( true );
    }
    iVar4 = FUN_6015c8a2(auStack_54,iVar6);
    if (iVar4 == 0) {
      FUN_6015bd24(auStack_54);
    }
    else {
      if (iVar4 == 0xd) {
        return (int *)0x0;
      }
      iVar4 = FUN_6015ad48(iVar6);
      if (iVar4 != 0) {
        return (int *)0x0;
      }
    }
    iVar6 = iVar6 + 0x23;
    iVar7 = iVar7 + -1;
  } while( true );
}

