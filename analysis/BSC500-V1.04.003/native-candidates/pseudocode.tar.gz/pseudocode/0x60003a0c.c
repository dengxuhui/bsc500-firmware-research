
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60003a0c(void)

{
  *_DAT_60003a14 = 1;
  return;
}

