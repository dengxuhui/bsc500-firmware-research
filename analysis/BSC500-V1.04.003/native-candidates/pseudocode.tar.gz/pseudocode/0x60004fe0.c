
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60004fe0(void)

{
  int *piVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int aiStack_20 [5];
  
  iVar4 = _DAT_60004ffc + 8;
  ZeroBytes(iVar4,0x11);
  piVar1 = _DAT_6000a45c;
  if ((iVar4 == 0) || (_DAT_6000a45c[1] == 0)) {
    func_0x60168578(&UNK_6000a4b0);
    return 0;
  }
  iVar2 = *_DAT_6000a45c;
  if (iVar2 == 0) {
    aiStack_20[3] = 0;
    aiStack_20[1] = 0;
    aiStack_20[2] = 0;
    aiStack_20[0] = _DAT_6000a460;
    iVar2 = FUN_60168494(aiStack_20);
    *piVar1 = iVar2;
  }
  FUN_6016825e(iVar2,0xffffffff);
  iVar2 = FUN_60166758(piVar1 + 1,_DAT_6000a464,1);
  uVar3 = _DAT_6000a468;
  if (iVar2 == 0) {
    iVar4 = FUN_60161ef4(piVar1[1],iVar4,0x14,aiStack_20);
    if ((iVar4 != 0) || (aiStack_20[0] != 0x14)) {
      func_0x60168578(_DAT_6000a4ac,0x14);
      FUN_601667bc(piVar1[1]);
      goto LAB_6000a432;
    }
    iVar4 = FUN_601667bc(piVar1[1]);
    uVar3 = _DAT_6000a46c;
    if (iVar4 == 0) {
      func_0x60168578(&UNK_6000a470,piVar1[2],piVar1[3],piVar1[4],piVar1[5]);
      if (*piVar1 != 0) {
        func_0x601682ae();
      }
      return 1;
    }
  }
  func_0x60168578(uVar3,_DAT_6000a464);
LAB_6000a432:
  if (*piVar1 != 0) {
    func_0x601682ae();
  }
  return 0;
}

