
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_6000f914(int param_1,int param_2,int *param_3)

{
  undefined1 uVar1;
  int *piVar2;
  int iVar3;
  
  if (param_1 == 0) {
    return 1;
  }
  piVar2 = (int *)FUN_601633cc(0x14);
  if (piVar2 != (int *)0x0) {
    FUN_6001a23c();
    iVar3 = FUN_601633cc();
    piVar2[3] = iVar3;
    if (iVar3 != 0) {
      if (param_2 < 7) {
        param_2 = 6;
      }
      iVar3 = FUN_6001a2bc(piVar2,param_1,param_2,0x98,iVar3);
      if (iVar3 == 0) {
        FUN_6001a3bc(*piVar2,_DAT_6000f98c);
        piVar2[1] = 0;
        piVar2[2] = 0;
        uVar1 = FUN_6001a2b4(*piVar2);
        *(undefined1 *)((int)piVar2 + 0x11) = uVar1;
        *param_3 = (int)piVar2;
        return 0;
      }
      if (*piVar2 != 0) {
        FUN_6001a240();
      }
      FUN_601634dc(piVar2);
      goto LAB_6000f96c;
    }
    FUN_601634dc(piVar2);
  }
  iVar3 = 7;
LAB_6000f96c:
  *param_3 = 0;
  return iVar3;
}

