
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60019458(void)

{
  int iVar1;
  undefined1 auStack_a0 [12];
  uint uStack_94;
  undefined1 auStack_90 [63];
  undefined1 uStack_51;
  undefined1 auStack_50 [64];
  
  iVar1 = _DAT_60019554;
  func_0x601608ac(_DAT_60019554,0x3bc);
  func_0x60129756(iVar1 + 4,0x3b8);
  uStack_94 = 0;
  func_0x601681f4(auStack_50,_DAT_60019558,_DAT_6001955c,_DAT_60019560);
  iVar1 = FUN_601609d0(auStack_a0,auStack_50,2);
  if (iVar1 == 0) {
    FUN_60160948(auStack_a0,0,0);
    FUN_6015c2f4(auStack_a0,auStack_90,0x40,&uStack_94);
    FUN_60160a64(auStack_a0);
    if (6 < uStack_94) {
      uStack_51 = 0;
      iVar1 = FUN_6016228c(auStack_90,0x3d);
      if ((iVar1 != 0) && (iVar1 = FUN_6016811c(iVar1 + 1), iVar1 == 0x6e)) {
        func_0x601681f4(auStack_50,_DAT_60019558,_DAT_6001955c,_DAT_60019560);
        iVar1 = FUN_601609d0(auStack_a0,auStack_50,2);
        if (iVar1 != 0) {
          return;
        }
        FUN_60160948(auStack_a0,0,0);
        FUN_6015c2f4(auStack_a0,_DAT_60019554,0x3bc,&uStack_94);
        goto LAB_6001954a;
      }
    }
  }
  for (iVar1 = 4; iVar1 != 0; iVar1 = iVar1 + -1) {
    FUN_6013f78c();
  }
  iVar1 = FUN_601609d0(auStack_a0,auStack_50,1);
  if (iVar1 != 0) {
    return;
  }
  func_0x601681f4(auStack_90,_DAT_60019564,0x6e);
  FUN_60160948(auStack_a0,0,0);
  iVar1 = FUN_60168220(auStack_90);
  FUN_60160774(auStack_a0,auStack_90,iVar1 + 1,&uStack_94);
LAB_6001954a:
  FUN_60160a64(auStack_a0);
  return;
}

