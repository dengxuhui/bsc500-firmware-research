
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60011474(int param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  char *pcVar1;
  int iVar2;
  uint uVar3;
  char *pcVar4;
  uint uVar5;
  undefined4 uStack_14;
  
  pcVar1 = _DAT_600116f0;
  iVar2 = _DAT_60011510;
  uStack_14 = param_4 & 0xffff;
  if (param_1 == 0) {
    uVar5 = (uint)*(ushort *)(_DAT_600116f0 + 0x1a);
    if (uVar5 == 0) {
      if (_DAT_600116f0[0xb] == '\0') {
        if (*_DAT_600116f0 == '\0') {
          uVar5 = 0x14;
          pcVar1[0x1a] = '\x14';
          pcVar1[0x1b] = '\0';
        }
        else {
          uVar5 = 0;
          pcVar4 = _DAT_600116f0 + 0x1e;
          *_DAT_600116f0 = '\0';
          CopyBytes(iVar2,pcVar4,0x14,param_4,param_3);
        }
        *(short *)(pcVar1 + 0xe) = *(short *)(pcVar1 + 0xe) + 0x14;
        pcVar1[0xb] = '\x01';
      }
      else {
        uVar5 = 0;
      }
    }
    if (uVar5 < *(ushort *)(pcVar1 + 0xe)) {
      uVar3 = *(ushort *)(pcVar1 + 0xe) - uVar5;
      if ((int)(uint)*_DAT_600116f8 < (int)uVar3) {
        uVar3 = (uint)*_DAT_600116f8;
      }
      uStack_14 = CONCAT22((short)uVar3,(undefined2)uStack_14);
      iVar2 = FUN_6012ea18(_DAT_60011510 + uVar5,(int)&uStack_14 + 2,0x9e);
      if (iVar2 == 0) {
        uVar5 = (uint)*(ushort *)(pcVar1 + 0x1a) + (uStack_14 >> 0x10);
        *(short *)(pcVar1 + 0x1a) = (short)uVar5;
      }
      else {
        uVar5 = (uint)*(ushort *)(pcVar1 + 0x1a);
      }
    }
    uVar3 = (uint)*(ushort *)(pcVar1 + 0xe);
    if ((uVar5 & 0xffff) < uVar3) {
      return;
    }
    pcVar1[0xb] = '\0';
    pcVar1[0x1a] = '\0';
    pcVar1[0x1b] = '\0';
    pcVar1[5] = '\0';
  }
  else {
    _DAT_600116f0[0xb] = '\0';
    pcVar1[0x1a] = '\0';
    pcVar1[0x1b] = '\0';
    pcVar1[5] = '\0';
    uVar3 = (uint)*(ushort *)(pcVar1 + 0xe);
  }
  ZeroBytes(_DAT_60011510,uVar3);
  pcVar1 = _DAT_600116f0;
  pcVar1[0xe] = '\0';
  pcVar1[0xf] = '\0';
  return;
}

