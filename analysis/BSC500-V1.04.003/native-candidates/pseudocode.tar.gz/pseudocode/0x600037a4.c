
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_600037a4(void)

{
  int *piVar1;
  int iVar2;
  undefined *puStack_2c;
  undefined1 auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  ZeroBytes(auStack_28,0x20);
  uStack_14 = 0xe;
  puStack_2c = &UNK_600037e0;
  uStack_18 = 0x1000;
  iVar2 = FUN_601566b4(_DAT_600037ec,0,&puStack_2c);
  piVar1 = _DAT_600037f0;
  *_DAT_600037f0 = iVar2;
  FUN_60156808();
  return *piVar1 != 0;
}

