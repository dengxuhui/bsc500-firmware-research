
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000fbe8(void)

{
  uint uVar1;
  uint uVar2;
  undefined4 uVar3;
  int in_r3;
  int iVar4;
  uint uVar5;
  int iStack_18;
  
  iVar4 = _DAT_6000fc48 + 8;
  iStack_18 = in_r3;
  uVar1 = FUN_601637b4(iVar4);
  uVar2 = FUN_60011418(&iStack_18);
  uVar5 = 0;
  while ((uVar2 != 0 && (uVar1 != 0))) {
    uVar3 = FUN_601637a0(iVar4);
    if (uVar2 <= uVar1) {
      CopyBytes(iStack_18 + uVar5,uVar3,uVar2);
      uVar5 = uVar2;
      goto LAB_6000fc3e;
    }
    CopyBytes(iStack_18 + uVar5,uVar3,uVar1);
    FUN_6016375e(iVar4,uVar1);
    uVar2 = uVar2 - uVar1;
    uVar5 = uVar5 + uVar1;
    uVar1 = FUN_601637b4(iVar4);
  }
  if (uVar5 == 0) {
    return;
  }
LAB_6000fc3e:
  FUN_60011430(uVar5);
  return;
}

