
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001b7c(void)

{
  int iVar1;
  undefined *puStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined4 uStack_c;
  
  uStack_c = 0;
  uStack_14 = 0;
  uStack_10 = 0;
  puStack_18 = &UNK_60001bbc;
  iVar1 = FUN_60168494(&puStack_18);
  *(int *)(_DAT_60001bc8 + 4) = iVar1;
  if (iVar1 != 0) {
    return;
  }
  func_0x60167f3c(0,_DAT_60001c00,1,_DAT_60001d20,&UNK_60001bdc,&UNK_60001bcc,0x33);
  FUN_6013dd48();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

