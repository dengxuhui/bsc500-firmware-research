
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60018084(float param_1,undefined4 param_2,undefined8 *param_3,undefined8 *param_4)

{
  undefined4 *puVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  uint uVar7;
  undefined4 uVar8;
  uint uVar9;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr8;
  undefined8 in_d2;
  undefined8 in_d3;
  undefined8 in_d4;
  undefined8 in_d5;
  undefined8 in_d6;
  undefined8 in_d7;
  float unaff_s16;
  undefined8 uVar10;
  undefined8 uVar11;
  undefined8 uStack_60;
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined8 uStack_38;
  
  iVar4 = _DAT_60018094;
  puVar1 = (undefined4 *)(_DAT_60018094 + 0x24);
  if ((((0.0 <= param_1) && (puVar1 != (undefined4 *)0x0)) && (param_3 != (undefined8 *)0x0)) &&
     ((param_4 != (undefined8 *)0x0 &&
      (param_1 <= *(float *)(*(int *)(_DAT_60018094 + 0x2c) + 0x20))))) {
    iVar6 = 0;
    uVar7 = 0;
    coprocessor_function2(10,0,0,in_cr8,in_cr1,in_cr0);
    uStack_60 = in_d2;
    uStack_58 = in_d3;
    uStack_50 = in_d4;
    uStack_48 = in_d5;
    uStack_40 = in_d6;
    uStack_38 = in_d7;
    for (; piVar2 = *(int **)(iVar4 + 0x28), uVar7 < (uint)piVar2[1]; uVar7 = uVar7 + 1) {
      iVar3 = FUN_6010e156(*piVar2 + iVar6 + 0x20);
      if (iVar3 == 1) {
        iVar6 = **(int **)(iVar4 + 0x28) + iVar6;
        uVar9 = *(uint *)(iVar6 + 0x28);
        uVar7 = *(uint *)(iVar6 + 0x2c);
        while( true ) {
          if (uVar7 <= uVar9) {
            return 0xffffffff;
          }
          iVar4 = FUN_6013028a(*puVar1,uVar9,&uStack_48);
          if (iVar4 != 0) break;
          if (unaff_s16 <= (float)uStack_38) {
            if (uVar9 == 0) {
              *param_3 = uStack_48;
            }
            else {
              iVar4 = FUN_6013028a(*puVar1,uVar9 - 1,&uStack_60);
              if (iVar4 != 0) {
                return 0xffffffff;
              }
              uVar10 = FUN_60166bb4((unaff_s16 - (float)uStack_50) /
                                    ((float)uStack_38 - (float)uStack_50));
              uVar5 = (undefined4)((ulonglong)uVar10 >> 0x20);
              uVar8 = (undefined4)((ulonglong)uStack_60 >> 0x20);
              uVar11 = FUN_60165558((int)uStack_48,(int)((ulonglong)uStack_48 >> 0x20),
                                    (int)uStack_60,uVar8);
              uVar11 = FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),(int)uVar10,uVar5);
              uVar11 = FUN_601682c8((int)uStack_60,uVar8,(int)uVar11,
                                    (int)((ulonglong)uVar11 >> 0x20));
              uVar8 = (undefined4)((ulonglong)uStack_58 >> 0x20);
              *param_3 = uVar11;
              uVar11 = FUN_60165558((int)uStack_40,(int)((ulonglong)uStack_40 >> 0x20),
                                    (int)uStack_58,uVar8);
              uVar11 = FUN_601678fc((int)uVar11,(int)((ulonglong)uVar11 >> 0x20),(int)uVar10,uVar5);
              uStack_40 = FUN_601682c8((int)uStack_58,uVar8,(int)uVar11,
                                       (int)((ulonglong)uVar11 >> 0x20));
            }
            *param_4 = uStack_40;
            return 0;
          }
          uVar9 = uVar9 + 1;
        }
        return 0xffffffff;
      }
      iVar6 = iVar6 + 0x30;
    }
  }
  return 0xffffffff;
}

