
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60019658(undefined4 param_1,undefined4 param_2,undefined4 param_3,int param_4)

{
  int iVar1;
  undefined4 uVar2;
  uint uStack_18;
  int iStack_14;
  
  uVar2 = 0;
  uStack_18 = 0;
  iStack_14 = param_4;
  iVar1 = FUN_6015e8c2(&iStack_14,&uStack_18);
  if (iVar1 == 0) {
    iVar1 = FUN_6001bd84(param_1,iStack_14 + 1,&uStack_18);
    if (iVar1 != 0) {
      func_0x6016713c(iVar1,0x659,_DAT_60019698);
    }
    uStack_18 = uStack_18 + 1;
    uVar2 = FUN_6015e94c(iStack_14,uStack_18 & 0xffff,_DAT_6001969c);
  }
  return uVar2;
}

