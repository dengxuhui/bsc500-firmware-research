
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000c0f8(void)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)FUN_60164b70();
  func_0x60161424(&UNK_6000c11c,*puVar1,puVar1[2],*(undefined4 *)(*_DAT_6000c118 + 0xb4),
                  *(undefined4 *)(*_DAT_6000c118 + 0xbc));
  return;
}

