
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000a720(uint param_1)

{
  undefined4 uVar1;
  
  uVar1 = 5;
  if ((param_1 < 0xf) && ((1 << (param_1 & 0xff) & 0x6333U) != 0)) {
    *(char *)(_DAT_6000a760 + 0x2c) = (char)param_1;
    uVar1 = 0;
  }
  return uVar1;
}

