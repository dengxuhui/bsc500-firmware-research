
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_6000bda8(uint *param_1)

{
  bool bVar1;
  uint *puVar2;
  uint *puVar3;
  uint *puVar4;
  byte *pbVar5;
  uint uVar6;
  byte bVar7;
  byte bVar8;
  undefined2 uVar9;
  uint uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  bool bVar15;
  
  puVar3 = _DAT_6000bdb4;
  uVar6 = 0x20;
  uVar10 = (uint)_DAT_6000bdb4 & 3;
  uVar11 = uVar10;
  if (uVar10 != 0) {
    bVar7 = (byte)*param_1;
    puVar4 = (uint *)((int)param_1 + 1);
    if (uVar10 < 3) {
      puVar4 = (uint *)((int)param_1 + 2);
      uVar11 = (uint)*(byte *)((int)param_1 + 1);
    }
    puVar2 = (uint *)((int)_DAT_6000bdb4 + 1);
    *(byte *)_DAT_6000bdb4 = bVar7;
    param_1 = puVar4;
    if (uVar10 < 2) {
      param_1 = (uint *)((int)puVar4 + 1);
      bVar7 = (byte)*puVar4;
    }
    uVar6 = uVar10 + 0x1c;
    puVar4 = puVar2;
    if (uVar10 < 3) {
      puVar4 = (uint *)((int)puVar3 + 2);
      *(byte *)puVar2 = (byte)uVar11;
    }
    puVar3 = puVar4;
    if (uVar10 < 2) {
      puVar3 = (uint *)((int)puVar4 + 1);
      *(byte *)puVar4 = bVar7;
    }
  }
  uVar10 = (uint)param_1 & 3;
  if (uVar10 != 0) {
    while( true ) {
      bVar7 = (byte)uVar11;
      if (uVar6 < 8) break;
      puVar4 = param_1 + 1;
      uVar10 = *param_1;
      param_1 = param_1 + 2;
      uVar11 = *puVar4;
      *puVar3 = uVar10;
      puVar3[1] = uVar11;
      puVar3 = puVar3 + 2;
      uVar6 = uVar6 - 8;
    }
    puVar4 = puVar3;
    puVar2 = param_1;
    if (-1 < (int)(uVar6 - 4)) {
      puVar2 = param_1 + 1;
      uVar10 = *param_1;
      puVar4 = puVar3 + 1;
      *puVar3 = uVar10;
    }
    bVar8 = (byte)uVar10;
    bVar1 = (uVar6 - 4 & 2) != 0;
    uVar6 = uVar6 << 0x1f;
    bVar15 = (int)uVar6 < 0;
    if (bVar1) {
      pbVar5 = (byte *)((int)puVar2 + 1);
      bVar8 = (byte)*puVar2;
      puVar2 = (uint *)((int)puVar2 + 2);
      bVar7 = *pbVar5;
    }
    puVar3 = puVar2;
    if (bVar15) {
      puVar3 = (uint *)((int)puVar2 + 1);
      uVar6 = (uint)(byte)*puVar2;
    }
    if (bVar1) {
      pbVar5 = (byte *)((int)puVar4 + 1);
      *(byte *)puVar4 = bVar8;
      puVar4 = (uint *)((int)puVar4 + 2);
      *pbVar5 = bVar7;
    }
    puVar2 = puVar4;
    if (bVar15) {
      puVar2 = (uint *)((int)puVar4 + 1);
      *(byte *)puVar4 = (byte)uVar6;
    }
    return CONCAT44(puVar3,puVar2);
  }
  uVar11 = 0;
  while (uVar10 = uVar6 - 0x20, 0x1f < uVar6) {
    uVar11 = param_1[1];
    uVar6 = param_1[2];
    uVar12 = param_1[3];
    *puVar3 = *param_1;
    puVar3[1] = uVar11;
    puVar3[2] = uVar6;
    puVar3[3] = uVar12;
    uVar11 = param_1[4];
    uVar6 = param_1[5];
    uVar12 = param_1[6];
    uVar13 = param_1[7];
    param_1 = param_1 + 8;
    puVar3[4] = uVar11;
    puVar3[5] = uVar6;
    puVar3[6] = uVar12;
    puVar3[7] = uVar13;
    puVar3 = puVar3 + 8;
    uVar6 = uVar10;
  }
  if ((uVar10 & 0x10) != 0) {
    uVar11 = *param_1;
    uVar12 = param_1[1];
    uVar13 = param_1[2];
    uVar14 = param_1[3];
    param_1 = param_1 + 4;
    *puVar3 = uVar11;
    puVar3[1] = uVar12;
    puVar3[2] = uVar13;
    puVar3[3] = uVar14;
    puVar3 = puVar3 + 4;
  }
  if ((int)(uVar6 << 0x1c) < 0) {
    uVar11 = *param_1;
    uVar12 = param_1[1];
    param_1 = param_1 + 2;
    *puVar3 = uVar11;
    puVar3[1] = uVar12;
    puVar3 = puVar3 + 2;
  }
  puVar2 = puVar3;
  puVar4 = param_1;
  if ((uVar10 & 4) != 0) {
    puVar4 = param_1 + 1;
    uVar11 = *param_1;
    puVar2 = puVar3 + 1;
    *puVar3 = uVar11;
  }
  uVar9 = (undefined2)uVar11;
  if ((uVar10 & 3) != 0) {
    bVar1 = (uVar10 & 2) != 0;
    uVar6 = uVar6 << 0x1f;
    bVar15 = (int)uVar6 < 0;
    puVar3 = puVar4;
    if (bVar1) {
      puVar3 = (uint *)((int)puVar4 + 2);
      uVar9 = (undefined2)*puVar4;
    }
    puVar4 = puVar3;
    if (bVar15) {
      puVar4 = (uint *)((int)puVar3 + 1);
      uVar6 = (uint)(byte)*puVar3;
    }
    puVar3 = puVar2;
    if (bVar1) {
      puVar3 = (uint *)((int)puVar2 + 2);
      *(undefined2 *)puVar2 = uVar9;
    }
    puVar2 = puVar3;
    if (bVar15) {
      puVar2 = (uint *)((int)puVar3 + 1);
      *(byte *)puVar3 = (byte)uVar6;
    }
    return CONCAT44(puVar4,puVar2);
  }
  return CONCAT44(puVar4,puVar2);
}

