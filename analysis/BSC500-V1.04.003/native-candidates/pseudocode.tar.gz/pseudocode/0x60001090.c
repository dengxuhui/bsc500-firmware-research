
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001090(void)

{
  byte bVar1;
  undefined1 *puVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  int ***pppiVar6;
  undefined4 extraout_r1;
  uint uVar7;
  int ****ppppiVar8;
  int ****ppppiVar9;
  ulonglong uVar10;
  int ***pppiStack_2c;
  int ***pppiStack_28;
  
  pppiStack_2c = (int ***)&pppiStack_2c;
  pppiStack_28 = (int ***)&pppiStack_2c;
  uVar10 = FUN_60167d0c();
  uVar3 = _DAT_60001154;
  puVar2 = _DAT_60001150;
  while ((ppppiVar9 = *(int *****)(puVar2 + 0x18), uVar7 = (uint)(uVar10 >> 0x20),
         ppppiVar9 != (int ****)(puVar2 + 0x18) &&
         (iVar4 = func_0x6016717c(), uVar7 = uVar3, (uint)(iVar4 - (int)ppppiVar9[6]) <= uVar3))) {
    ppppiVar8 = ppppiVar9 + -7;
    if (*(code **)(puVar2 + 4) != (code *)0x0) {
      (**(code **)(puVar2 + 4))(ppppiVar8);
    }
    FUN_6016374c(ppppiVar8);
    if (-1 < (int)((uint)*(byte *)((int)ppppiVar9 + -0xb) << 0x1e)) {
      *(byte *)((int)ppppiVar9 + -0xb) = *(byte *)((int)ppppiVar9 + -0xb) & 0xfe;
    }
    pppiStack_2c[1] = (int **)ppppiVar9;
    *ppppiVar9 = pppiStack_2c;
    ppppiVar9[1] = (int ***)&pppiStack_2c;
    *puVar2 = 1;
    pppiStack_2c = (int ***)ppppiVar9;
    func_0x60167d14((int)uVar10);
    (*(code *)ppppiVar9[2])(ppppiVar9[3]);
    if (*(code **)(puVar2 + 8) != (code *)0x0) {
      (**(code **)(puVar2 + 8))(ppppiVar8);
    }
    uVar10 = FUN_60167d0c();
    uVar5 = (undefined4)uVar10;
    *puVar2 = 0;
    if ((int ****)pppiStack_2c != &pppiStack_2c) {
      pppiVar6 = *ppppiVar9;
      pppiVar6[1] = (int **)ppppiVar9[1];
      *ppppiVar9[1] = (int **)pppiVar6;
      *ppppiVar9 = (int ***)ppppiVar9;
      ppppiVar9[1] = (int ***)ppppiVar9;
      bVar1 = *(byte *)((int)ppppiVar9 + -0xb);
      uVar10 = (ulonglong)CONCAT14(bVar1,uVar5) & 0x3ffffffff;
      if ((bVar1 & 3) == 3) {
        *(byte *)((int)ppppiVar9 + -0xb) = bVar1 & 0xfe;
        func_0x60167bd4(ppppiVar8);
        uVar10 = CONCAT44(extraout_r1,uVar5);
      }
    }
  }
  func_0x60167d14((int)uVar10,uVar7);
  return;
}

