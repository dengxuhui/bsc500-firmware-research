
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60013470(void)

{
  undefined4 uVar1;
  
  if (*_DAT_60013820 == '\x02') {
    *_DAT_60013820 = '\x01';
    uVar1 = 0;
  }
  else {
    uVar1 = 0xffffffff;
  }
  return uVar1;
}

