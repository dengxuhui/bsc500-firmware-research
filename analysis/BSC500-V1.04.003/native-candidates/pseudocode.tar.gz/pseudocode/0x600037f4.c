
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600037f4(void)

{
  *_DAT_600037fc = 1;
  return;
}

