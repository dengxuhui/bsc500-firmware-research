
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60011768(undefined2 *param_1)

{
  char cVar1;
  char cVar2;
  int iVar3;
  uint uVar4;
  undefined *puVar5;
  undefined4 uVar6;
  uint uVar7;
  bool bVar8;
  undefined1 auStack_238 [12];
  uint uStack_22c;
  undefined1 auStack_224 [4];
  undefined1 auStack_220 [80];
  char acStack_1d0 [36];
  undefined4 uStack_1ac;
  undefined4 uStack_1a8;
  int iStack_148;
  undefined4 uStack_144;
  undefined4 uStack_140;
  char acStack_dc [56];
  undefined2 uStack_a4;
  undefined1 uStack_a2;
  undefined4 uStack_a0;
  undefined4 uStack_9c;
  undefined1 uStack_30;
  undefined2 uStack_2c;
  undefined1 uStack_2a;
  undefined1 uStack_29;
  undefined1 uStack_28;
  undefined4 uStack_24;
  undefined2 *puStack_20;
  undefined4 uStack_1c;
  
  puStack_20 = (undefined2 *)0x0;
  uStack_1c = 0;
  ZeroBytes(&uStack_a4,0x84);
  *(undefined4 *)(_DAT_600118f0 + 4) = 0;
  ZeroBytes(&iStack_148,0xa4);
  iVar3 = FUN_60119330(*(undefined4 *)(param_1 + 2),*param_1,&iStack_148);
  if (iVar3 == 0) {
    puVar5 = &UNK_600118f4;
    goto LAB_600117b2;
  }
  ZeroBytes(auStack_224,0xdc);
  iVar3 = FUN_6002aed0(auStack_224);
  if (iVar3 == 0) {
    func_0x60168578(_DAT_60011918,auStack_220,uStack_1ac,uStack_1a8);
    func_0x60168578(&UNK_6001191c,acStack_1d0);
    uVar4 = FUN_60168220(acStack_dc);
    if (uVar4 == 0) {
      puVar5 = &UNK_60011938;
    }
    else {
      func_0x60168578(_DAT_60011968,acStack_dc);
      iVar3 = FUN_60163bc6(acStack_dc,acStack_1d0,0x21);
      func_0x60168578(_DAT_6001196c,iVar3);
      if (iVar3 != 0) {
        func_0x60168578(_DAT_6001198c);
        uVar6 = _DAT_60011994;
        uVar7 = 0;
        while( true ) {
          bVar8 = 0x1e < uVar7;
          if (uVar7 < 0x20) {
            bVar8 = uVar4 <= uVar7;
          }
          if (bVar8) break;
          cVar1 = acStack_1d0[uVar7];
          cVar2 = acStack_dc[uVar7];
          if (cVar2 != cVar1) {
            func_0x60168578(uVar6,uVar7,cVar2,cVar2,cVar1,cVar1);
          }
          uVar7 = uVar7 + 1;
        }
        func_0x60168578(_DAT_60011990);
        goto LAB_600117ac;
      }
      puVar5 = &UNK_60011970;
    }
    func_0x60168578(puVar5);
  }
  else {
LAB_600117ac:
    uStack_1a8 = 0;
  }
  uStack_a4 = 0x215;
  uStack_28 = 1;
  uStack_30 = 1;
  uStack_2a = 1;
  uStack_a0 = uStack_144;
  uStack_9c = uStack_140;
  uStack_a2 = (undefined1)iStack_148;
  uStack_2c = 0x101;
  uStack_29 = iStack_148 == 5;
  uVar6 = _DAT_6001199c;
  if (iStack_148 == 5) {
    uVar6 = _DAT_60011998;
  }
  uStack_24 = uStack_1a8;
  func_0x60168578(uVar6);
  iVar3 = FUN_6013a780(&uStack_1c,&puStack_20,0x6e);
  if (iVar3 != 0) {
    func_0x60168578(_DAT_600119a0);
    return 1;
  }
  FUN_601648d4(auStack_238,uStack_1c,0x640);
  iVar3 = FUN_60164868(auStack_238,_DAT_600119a4,&uStack_a4);
  puVar5 = _DAT_600119a8;
  if (iVar3 != 0) {
    *puStack_20 = (short)uStack_22c;
    FUN_6012c348();
    uVar6 = FUN_6015f2e8(uStack_1c,*puStack_20);
    FUN_6013a800(0x15,0,2,0,uStack_22c & 0xffff,uVar6);
    return 1;
  }
LAB_600117b2:
  func_0x60168578(puVar5);
  FUN_60129ec8(0x15,0,2,0);
  return 1;
}

