
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000e54(void)

{
  longlong lVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uVar6;
  uint uVar7;
  
  uVar6 = 1;
  uVar2 = FUN_60134adc(1,1);
  if (uVar2 <= _DAT_60000ed0) {
    uVar6 = 0;
    uVar4 = uVar2 / _DAT_60000ed8;
    uVar3 = uVar2 / _DAT_60000ed4;
    uVar7 = (_DAT_60000edc + uVar2 * 10) / _DAT_60000ee0;
    lVar1 = (ulonglong)uVar7 * (ulonglong)_DAT_60000ee4;
    uVar2 = FUN_60162a88((int)lVar1,(int)((ulonglong)lVar1 >> 0x20),uVar2,0);
    uVar5 = (uint)(uVar2 < 9000);
    if (11000 < uVar2) {
      uVar5 = 0xffffffff;
    }
    *_DAT_60000eec =
         _DAT_60000ee8 & (uVar5 + uVar7) * 0x400 | uVar4 * 0x80 + 0x80 & 0x380 | uVar3 + 1;
  }
  return uVar6;
}

