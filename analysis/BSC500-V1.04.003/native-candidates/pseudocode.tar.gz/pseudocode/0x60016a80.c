
/* WARNING: Removing unreachable block (ram,0x6001e0ba) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016a80(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_6002a8b8(5);
  (**(code **)(_DAT_6001e0d4 + 0x38))();
  return uVar1;
}

