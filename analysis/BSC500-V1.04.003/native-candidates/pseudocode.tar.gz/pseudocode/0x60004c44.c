
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60004c44(void)

{
  int iVar1;
  int iVar2;
  
  iVar1 = _DAT_60004c58;
  FUN_600e9ee8(_DAT_60004c58);
  iVar2 = 0;
  if (*(char *)(iVar1 + 8) != '\0') {
    iVar2 = iVar1;
  }
  return iVar2;
}

