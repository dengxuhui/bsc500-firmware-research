
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60010628(void)

{
  int iVar1;
  int *piVar2;
  undefined4 *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  int iVar8;
  undefined *puVar9;
  int iVar10;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  undefined *puVar11;
  int iVar12;
  
  iVar8 = FUN_6015982e();
  FUN_60159828(iVar8,4,0,0);
  puVar9 = (undefined *)FUN_6015bd44();
  iVar4 = _UNK_600e7ff4;
  if ((puVar9 == (undefined *)0x0) && (iVar8 != 0)) {
    func_0x6011ed5c(iVar8);
  }
  else if (iVar8 == 0) {
    iVar8 = FUN_6015982e();
    FUN_60159828(iVar8,iVar4,0,0);
  }
  iVar10 = *(int *)(_DAT_60159870 + 8);
  puVar11 = puVar9;
  if (iVar10 == 0) {
    if (iVar8 != 0) {
      func_0x60139eac(iVar8);
      puVar11 = puVar9;
    }
  }
  else {
    iVar12 = iVar4;
    iVar7 = iVar8;
    iVar1 = FUN_60133088();
    uVar6 = _DAT_600570a8;
    uVar5 = _DAT_60057044;
    if (iVar1 != 0) {
      piVar2 = (int *)(iVar10 + 4);
      do {
        piVar2 = (int *)*piVar2;
        if (piVar2 == (int *)0x0) {
LAB_6005702c:
          FUN_601330ec();
          if (iVar8 != 0) {
LAB_60057036:
            func_0x60139eac(iVar8);
          }
          return CONCAT44(puVar11,1);
        }
        if (((undefined *)piVar2[1] == puVar9) && (*piVar2 == iVar4)) {
          puVar3 = (undefined4 *)FUN_60139e84(puVar9);
          if (puVar3 != (undefined4 *)0x0) {
            puVar11 = (undefined *)piVar2[3];
            iVar4 = FUN_60058f40(puVar3[1],piVar2[2],puVar3[3],iVar8,puVar11,iVar12,iVar7,unaff_r4,
                                 unaff_r5,unaff_r6);
            if (iVar4 == 0) {
              if (puVar3[1] != 0) {
                uVar5 = FUN_60052acc();
                uVar6 = FUN_6005b1e8(puVar3[1]);
                iVar7 = FUN_6012376e(puVar3[1]);
                func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057048,uVar5,uVar6,iVar7);
              }
              puVar11 = (undefined *)*puVar3;
              uVar5 = FUN_6013a3fc(puVar11);
              func_0x60167f3c(3,_DAT_60057044,1,&UNK_60057074,puVar11,uVar5,iVar7);
            }
            else if (((puVar3[1] == 0) && (iVar8 != 0)) && (puVar3[3] != 0)) {
              func_0x60139eac(iVar8);
              FUN_601330ec();
              goto LAB_60057036;
            }
            goto LAB_6005702c;
          }
          puVar11 = &UNK_60057094;
          func_0x60167f3c(3,uVar5,1,uVar6);
        }
        piVar2 = piVar2 + 4;
      } while( true );
    }
  }
  return ZEXT48(puVar11) << 0x20;
}

