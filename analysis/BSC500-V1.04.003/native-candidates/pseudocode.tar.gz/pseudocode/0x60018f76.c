
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60018f76(void)

{
  float fVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  char cVar5;
  int unaff_r10;
  code *unaff_r11;
  uint in_fpscr;
  undefined8 uVar6;
  undefined8 uVar7;
  undefined8 in_stack_00000030;
  undefined8 in_stack_00000038;
  float in_stack_00000040;
  undefined4 in_stack_00000048;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000064;
  
  iVar2 = FUN_60022154();
  if (iVar2 == 0) {
    iVar2 = FUN_60021bf8();
    if (iVar2 == 0) {
      in_stack_00000064 = 0;
      iVar2 = FUN_60166758(&stack0x00000064);
      if (iVar2 == 0) {
        in_stack_0000005c = 1;
        in_stack_00000054 = 1;
        in_stack_00000058 = 0x7fffffff;
        in_stack_0000004c = 0x7fffffff;
        in_stack_00000050 = 0x7fffffff;
        in_stack_00000048 = 0xffffffff;
        iVar2 = _DAT_600191c8 + 8;
        FUN_60132d1c();
        ZeroBytes(&stack0x00000030,0x18);
        ZeroBytes(&stack0x00000010,0x20);
        fVar1 = _UNK_600191d4;
        do {
          do {
            do {
              iVar3 = FUN_6015d9d4(in_stack_00000064);
              if (iVar3 != 0) {
                FUN_601667bc(in_stack_00000064);
                iVar2 = FUN_60132d28(iVar2,&stack0x00000010);
                if (iVar2 != 0) goto LAB_600190ca;
                iVar2 = FUN_60021df4(&stack0x00000010);
                if (iVar2 != 0) goto code_r0x600190ce;
                iVar2 = FUN_60021fec(&stack0x00000010);
                if (iVar2 != 0) {
                  FUN_60021ee4();
                  goto code_r0x600190d2;
                }
                iVar2 = FUN_6002183c(&stack0x00000010);
                if (iVar2 != 0) {
                  FUN_60021ee4();
                  FUN_60022138();
                  goto LAB_600190d6;
                }
                cVar5 = '\0';
                *(undefined4 *)(unaff_r10 + 100) = 0;
                *(undefined2 *)(unaff_r10 + 0x40) = 0x103;
                iVar2 = FUN_6015e0d0();
                if (iVar2 != 0) {
                  *(undefined4 *)(unaff_r10 + 0x50) = *(undefined4 *)(iVar2 + 0x20);
                }
                iVar2 = _UNK_600191cc;
                *(undefined1 *)(_UNK_600191cc + 0x21) = 4;
                uVar4 = _UNK_600191d0;
                *(undefined1 *)(iVar2 + 0x74) = 0;
                *(undefined1 *)(iVar2 + 0x51) = 0;
                *(undefined4 *)(iVar2 + 0x70) = uVar4;
                uVar4 = *(undefined4 *)(unaff_r10 + 0x50);
                *(undefined4 *)(iVar2 + 0xa4) = 0;
                *(undefined4 *)(iVar2 + 0xa8) = uVar4;
                if (*(byte *)(unaff_r10 + 0x42) < 3) {
                  cVar5 = *(byte *)(unaff_r10 + 0x42) + 1;
                }
                *(char *)(iVar2 + 0x20) = cVar5;
                iVar3 = FUN_601623fc();
                if (iVar3 != 0) {
                  *(undefined4 *)(iVar2 + 0x54) = 0xffffffff;
                  *(undefined4 *)(iVar2 + 0x58) = 0xffffffff;
                  *(undefined4 *)(iVar2 + 0x5c) = 0xffffffff;
                  uVar4 = *(undefined4 *)(iVar3 + 4);
                  *(undefined4 *)(iVar2 + 0x68) = *(undefined4 *)(iVar3 + 8);
                  *(undefined4 *)(iVar2 + 0x6c) = uVar4;
                }
                if (*(code **)(unaff_r10 + 0x44) != (code *)0x0) {
                  (**(code **)(unaff_r10 + 0x44))(*(undefined1 *)(unaff_r10 + 0x42));
                }
                uVar4 = 0;
                goto LAB_600190e2;
              }
              iVar3 = (*unaff_r11)(in_stack_00000064,&stack0x00000058,&stack0x00000050,
                                   &stack0x00000048);
            } while (((iVar3 == -1) || (iVar3 = func_0x60166dd0(&stack0x00000058), iVar3 == 1)) ||
                    (iVar3 = func_0x60166dd0(&stack0x00000050), uVar4 = in_stack_00000054,
                    iVar3 == 1));
            in_stack_00000040 =
                 (float)VectorSignedToFloat(in_stack_0000004c,(byte)(in_fpscr >> 0x16) & 3);
            in_stack_00000040 = in_stack_00000040 / fVar1;
            uVar6 = FUN_6016759c(in_stack_00000050);
            uVar7 = FUN_6016759c(uVar4);
            in_stack_00000030 =
                 FUN_601675d8((int)uVar6,(int)((ulonglong)uVar6 >> 0x20),(int)uVar7,
                              (int)((ulonglong)uVar7 >> 0x20));
            uVar4 = in_stack_0000005c;
            uVar6 = FUN_6016759c(in_stack_00000058);
            uVar7 = FUN_6016759c(uVar4);
            in_stack_00000038 =
                 FUN_601675d8((int)uVar6,(int)((ulonglong)uVar6 >> 0x20),(int)uVar7,
                              (int)((ulonglong)uVar7 >> 0x20));
            iVar3 = FUN_60132c70(iVar2,&stack0x00000030,&stack0x00000010);
          } while (iVar3 != 0);
          iVar3 = FUN_60030b8c(&stack0x00000010);
          if (iVar3 != 0) {
            FUN_6011c6ec();
LAB_60019116:
            FUN_6011c710();
            goto LAB_6001911a;
          }
          iVar3 = FUN_60030c34(&stack0x00000010);
          if (iVar3 != 0) {
            FUN_6011c750();
            goto LAB_60019116;
          }
          iVar3 = FUN_60030a78(&stack0x00000010);
        } while (iVar3 == 0);
        FUN_6011c750();
        FUN_6011c6ec();
LAB_6001911a:
        FUN_601667bc(in_stack_00000064);
      }
      else {
LAB_600190ca:
        FUN_6011c750();
code_r0x600190ce:
        FUN_6011c6ec();
code_r0x600190d2:
        FUN_6011c710();
      }
    }
    else {
      FUN_6011c750();
      FUN_6011c6ec();
    }
  }
  else {
    FUN_6011c750();
  }
LAB_600190d6:
  *(undefined2 *)(unaff_r10 + 0x40) = 0x201;
  uVar4 = 0xffffffff;
LAB_600190e2:
  *(undefined1 *)(unaff_r10 + 0x68) = 0;
  return uVar4;
}

