
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_60003754(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined *puStack_2c;
  undefined1 auStack_28 [16];
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  ZeroBytes(auStack_28,0x20);
  uStack_14 = 0x18;
  puStack_2c = &UNK_60003790;
  uStack_18 = 0x1000;
  uVar2 = FUN_601566b4(_DAT_6000379c,0,&puStack_2c);
  iVar1 = _DAT_600037a0;
  *(undefined4 *)(_DAT_600037a0 + 0x10) = uVar2;
  FUN_60156808();
  return *(int *)(iVar1 + 0x10) != 0;
}

