
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60016a88(void)

{
  undefined4 uStack_20;
  undefined *puStack_1c;
  undefined4 uStack_18;
  
  uStack_18 = _DAT_60016ac0;
  puStack_1c = &UNK_60016ac4;
  uStack_20 = _DAT_60016bc0;
  FUN_6001e130(&uStack_20);
  return;
}

