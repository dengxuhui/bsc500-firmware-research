
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6000fffc(int param_1,uint param_2,int param_3,int param_4,int param_5,undefined4 param_6)

{
  uint *puVar1;
  code *pcVar2;
  uint uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int extraout_r1;
  undefined4 *puVar7;
  int iVar8;
  undefined4 uVar9;
  int extraout_r2;
  int iVar10;
  undefined2 unaff_r5;
  undefined4 unaff_r6;
  int *piVar11;
  int iVar12;
  int in_stack_ffffffc0;
  
  puVar1 = puRam600101b0;
  if (param_1 == 0) {
    FUN_6016804c(0x60010214,uRam600101ac,0xfe);
LAB_60010184:
    FUN_6016804c(uRam600101a8,uRam600101ac,0xff);
  }
  else {
    if (7 < param_2) goto LAB_60010184;
    if (param_3 != 0) {
      if (param_5 != 0) {
        *puRam600101b0 = 0;
        uVar3 = FUN_601626c0(uRam600101b4);
        puVar1[1] = uVar3;
        FUN_60016db4(puVar1 + 7,puVar1 + 6,puVar1 + 5,puVar1 + 4,puVar1 + 3,puVar1 + 2);
        FUN_60162c3a(param_1 + *puVar1,0x80 - *puVar1,0x600101b8,puVar1[7],puVar1[6],puVar1[5],
                     puVar1[4],puVar1[3],puVar1[2]);
        iVar4 = FUN_601626c0(*puVar1 + param_1);
        pcVar2 = pcRam600101dc;
        uVar5 = uRam600101d8;
        uVar3 = iVar4 + *puVar1;
        *puVar1 = uVar3;
        iVar4 = (*pcVar2)(uVar3,param_1 + uVar3,uVar5);
        uVar9 = *(undefined4 *)(param_2 * 4 + 0x600101e0);
        uVar3 = iVar4 + *puVar1;
        *puVar1 = uVar3;
        iVar4 = (*pcVar2)(uVar3,param_1 + uVar3,uVar9);
        uVar3 = iVar4 + *puVar1;
        *puVar1 = uVar3;
        iVar4 = (*pcVar2)(uVar3,param_1 + uVar3,param_3);
        uVar3 = iVar4 + *puVar1;
        *puVar1 = uVar3;
        iVar4 = (*pcVar2)(uVar3,param_1 + uVar3,uVar5);
        *puVar1 = iVar4 + *puVar1;
        iVar4 = FUN_60163aac();
        if (iVar4 == 0) {
          iVar4 = FUN_60163ab8();
          if (iVar4 == 0) {
            uVar5 = 0x60010204;
          }
          else {
            uVar5 = FUN_60163ab8();
          }
          iVar4 = FUN_601308ac(uVar5,0x10);
          func_0x6015f784(*puVar1 + param_1,uVar5,iVar4);
        }
        else {
          iVar4 = FUN_600f40dc(*puVar1,param_1 + *puVar1,0x60010200);
        }
        uVar5 = uRam60010208;
        uVar3 = *puVar1 + iVar4;
        *puVar1 = uVar3;
        iVar4 = FUN_600f40dc(uVar3,param_1 + uVar3,uVar5);
        uVar3 = *puVar1 + iVar4;
        *puVar1 = uVar3;
        uVar6 = FUN_60164d18(param_1 + uVar3,0x80 - uVar3,param_5,param_6);
        uVar3 = *puVar1 + uVar6;
        if (0x80 < uVar3) {
          uVar3 = 0x80;
        }
        if (0x7fffffff < uVar6) {
          uVar3 = 0x80;
        }
        *puVar1 = uVar3;
        if (0x80 < uVar3 + puVar1[1]) {
          uVar3 = 0x80 - puVar1[1];
          *puVar1 = uVar3;
        }
        if (param_4 != 0) {
          iVar4 = FUN_600f40dc(uVar3,param_1 + uVar3,uRam600101b4);
          uVar3 = iVar4 + *puVar1;
          *puVar1 = uVar3;
        }
        return uVar3;
      }
      goto LAB_6001019a;
    }
  }
  FUN_6016804c(uRam60010210,uRam600101ac,0x100);
LAB_6001019a:
  FUN_6016804c(uRam6001020c,uRam600101ac,0x101);
  uVar3 = *(uint *)(extraout_r1 + 4);
  **(undefined4 **)(extraout_r1 + 0xc) = unaff_r6;
  puVar7 = *(undefined4 **)(extraout_r1 + 0x14);
  iVar4 = *(int *)(extraout_r1 + 0x18);
  piVar11 = *(int **)(extraout_r1 + 0x1c);
  *piVar11 = iVar4;
  *(undefined2 *)((int)puVar7 + 0x1a) = unaff_r5;
  *piVar11 = iVar4;
  *(int *)(iVar4 + 0x40) = extraout_r2 + 0x25;
  *(int *)(iVar4 + 0x40) = extraout_r2 + 0x55;
  *(int *)(iVar4 + 0x40) = extraout_r2 + 0x21;
  *piVar11 = in_stack_ffffffc0;
  uVar3 = 0x3a >> (uVar3 & 0xff);
  *puVar7 = piVar11;
  piVar11 = (int *)puVar7[3];
  *piVar11 = in_stack_ffffffc0;
  *piVar11 = (int)piVar11;
  piVar11 = (int *)puVar7[4];
  iVar10 = puVar7[5];
  *(int *)puVar7[7] = in_stack_ffffffc0;
  iVar4 = *piVar11;
  iVar8 = piVar11[1];
  *(int *)piVar11[3] = in_stack_ffffffc0;
  iVar12 = iVar8 + 8;
  **(int **)(iVar8 + 4) = in_stack_ffffffc0;
  *(short *)(iVar12 + uVar3) = (short)iVar12;
  piVar11 = *(int **)(iVar4 * 2 + 4);
  **(int **)(iVar4 * 2 + 8) = in_stack_ffffffc0;
  iVar4 = *piVar11;
  iVar8 = piVar11[1];
  *(int *)(iVar4 + 4) = iVar8;
  *(int *)(iVar4 + 4) = iVar8;
  *(char *)(*(int *)(uVar3 + 0xe7) + 0x15) = (char)(iVar10 << 1);
  iVar4 = _DAT_60010240;
  for (iVar8 = 0; iVar8 != 0x30; iVar8 = iVar8 + 0xc) {
    iVar10 = iVar4 + iVar8;
    FUN_6001b060(*(undefined4 *)(iVar10 + 8));
    FUN_6001ae90(*(undefined4 *)(iVar10 + 4),*(undefined4 *)(iVar4 + iVar8));
  }
  return 1;
}

