
/* WARNING: Possible PIC construction at 0x60015426: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6001542a) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600153e0(undefined4 param_1)

{
  int iVar1;
  int *piVar2;
  int iVar3;
  
  iVar3 = _UNK_60015468;
  iVar1 = _UNK_60015464;
  switch(param_1) {
  case 1:
    piVar2 = *(int **)(*(int *)(_UNK_60015464 + 8) + 0xd8);
    if (piVar2 == (int *)0x0) {
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x6001b938. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar2 + 0xe0))();
    return;
  case 2:
    func_0x600ee0f0(*(undefined4 *)(_UNK_60015464 + 8),_UNK_60015468 + 1);
    iVar1 = *(int *)(iVar1 + 8);
    goto code_r0x600ee0f0;
  case 3:
    iVar3 = _UNK_60015468 + 0xc;
    break;
  case 4:
    iVar3 = _UNK_60015468 + 0x19;
    iVar1 = *(int *)(_UNK_60015464 + 8);
    goto code_r0x600ee0f0;
  case 5:
    iVar3 = _UNK_60015468 + 0xe;
    break;
  case 6:
    iVar3 = _UNK_60015468 + 0x15;
    break;
  case 7:
    piVar2 = *(int **)(*(int *)(_UNK_60015464 + 8) + 0xd8);
    if ((piVar2 != (int *)0x0) && (piVar2[0x11] == 3)) {
                    /* WARNING: Could not recover jumptable at 0x6001b94e. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (**(code **)(*piVar2 + 0xe0))();
      return;
    }
    return;
  case 8:
    piVar2 = *(int **)(*(int *)(_UNK_60015464 + 0x10) + 0x524);
    if (piVar2 == (int *)0x0) {
      return;
    }
                    /* WARNING: Could not recover jumptable at 0x6001b818. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar2 + 0xe0))();
    return;
  default:
    return;
  }
  iVar1 = *(int *)(_UNK_60015464 + 8);
code_r0x600ee0f0:
  piVar2 = *(int **)(iVar1 + 0xd8);
  if ((piVar2 != (int *)0x0) && (piVar2[0x12] == iVar3)) {
                    /* WARNING: Could not recover jumptable at 0x600ee102. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    (**(code **)(*piVar2 + 0xe0))();
    return;
  }
  return;
}

