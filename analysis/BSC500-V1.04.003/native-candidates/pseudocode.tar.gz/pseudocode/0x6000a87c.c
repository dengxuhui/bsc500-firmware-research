
/* WARNING: Removing unreachable block (ram,0x6000a914) */
/* WARNING: Removing unreachable block (ram,0x6000a920) */
/* WARNING: Removing unreachable block (ram,0x6000a932) */
/* WARNING: Removing unreachable block (ram,0x6000a992) */
/* WARNING: Removing unreachable block (ram,0x6000aa18) */
/* WARNING: Removing unreachable block (ram,0x6000aa1e) */
/* WARNING: Removing unreachable block (ram,0x6000aa76) */
/* WARNING: Removing unreachable block (ram,0x6000aa98) */
/* WARNING: Removing unreachable block (ram,0x6000aa7e) */
/* WARNING: Removing unreachable block (ram,0x6000aa3c) */
/* WARNING: Removing unreachable block (ram,0x6000aa88) */
/* WARNING: Removing unreachable block (ram,0x6000aa46) */
/* WARNING: Removing unreachable block (ram,0x6000aa8e) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6000a87c(void)

{
  undefined2 uVar1;
  short sVar2;
  byte bVar3;
  undefined4 *puVar4;
  byte bVar5;
  int iVar6;
  int iVar7;
  int iVar8;
  uint uVar9;
  byte *pbVar10;
  undefined1 extraout_r1;
  undefined1 extraout_r1_00;
  code *extraout_r2;
  int extraout_r2_00;
  int *piVar11;
  int unaff_r4;
  int unaff_r6;
  int iVar12;
  undefined4 unaff_r7;
  uint uStack_7c;
  undefined4 uStack_78;
  uint uStack_74;
  byte *pbStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  undefined4 *puStack_60;
  uint uStack_5c;
  undefined4 uStack_58;
  uint uStack_54;
  undefined1 auStack_4c [4];
  uint uStack_48;
  undefined4 *puStack_44;
  int *piStack_40;
  int iStack_34;
  undefined4 uStack_30;
  int iStack_2c;
  
  puVar4 = puRam6000a8d8;
  iVar6 = FUN_600f92bc(*puRam6000a8d8,*(short *)(puRam6000a8d8 + 1) << 0xf | 0x7fff);
  if (iVar6 == 0xff) {
    bVar5 = 0;
  }
  else {
    FUN_60164a88();
    iVar7 = FUN_6015d5fc(*puVar4,iVar6);
    iVar8 = FUN_60162e34(0x20);
    *(int *)(iVar7 + 0xc) = iVar8;
    if (iVar8 == 0) {
      FUN_6016804c(0x6000a8dc,0x6000a8ec,0x4d1);
      iVar8 = *(int *)(iVar6 + 0x44);
      *(char *)(iVar7 + 0x11) = (char)unaff_r6;
      iVar12 = unaff_r6 + -0x2d;
      *(char *)(unaff_r6 + -0x20) = (char)iVar7;
      *(char *)(iVar6 + 9) = (char)iVar7;
      *(undefined4 *)(iVar8 + 0x44) = unaff_r7;
      *(undefined1 *)(iVar6 + 0x11) = extraout_r1;
      *(int *)(iVar6 + 0x14) = iVar6;
      *(int *)(unaff_r6 + -0x19) = iVar6;
      piVar11 = (int *)(int)*(short *)(iVar6 + iVar7);
      *(char *)(iVar7 + 1) = (char)unaff_r7;
      uStack_30 = *(undefined4 *)(iVar6 + 100);
      iStack_34 = iVar6;
      iStack_2c = iVar12;
      FUN_60168220(iVar6 << 1);
      FUN_60164ac8();
      uStack_54 = uStack_54 & 0xffffff00;
      uStack_58 = 0xffffffff;
      uVar9 = 0x88000;
      uStack_48 = 0x88000;
      piStack_40 = piVar11;
      if (unaff_r4 != 0) {
        puStack_44 = (undefined4 *)FUN_60162e34(8);
        if (puStack_44 == (undefined4 *)0x0) {
          FUN_6016804c(0x6000aad4,uRam6000aad0,0x559);
          iVar7 = FUN_6016804c(0x6000aae8,0x6000aaf8,0x2c1);
          *piVar11 = iVar12;
          *piVar11 = iVar12;
          *(undefined4 *)(iVar7 + 4) = 0x6000ae84;
          *piVar11 = iVar12;
          *(undefined1 *)(iVar6 + 9) = extraout_r1_00;
          uVar1 = *(undefined2 *)(iVar6 + 0x6000aae0);
          iRam6000aaf0 = iVar12;
          *(int *)(unaff_r6 + 0x47) = extraout_r2_00;
          iRam6000ab20 = iVar12;
          *(undefined1 *)(iVar6 + 0x11) = extraout_r1_00;
          iRam6000aae3 = iVar6 * 2;
          *(char *)(extraout_r2_00 + iRam6000aae3) = (char)extraout_r2_00;
          iVar7 = _DAT_6000ac68;
          iVar6 = iRam6000ac44;
          *(undefined1 *)(iRam6000ac44 + 8) = 0x4c;
          *(undefined1 *)(iVar6 + 5) = 0xbf;
          *(int *)(iVar6 + 0x14) = iVar6;
          *(int *)(iVar7 + 0x14) = iVar6;
          uStack_74 = (uint)*(short *)(iVar6 + 0x6000aabf);
          bVar5 = (byte)*(short *)(iVar6 + 0x6000aabf);
          *(byte *)(iVar7 + 0x15) = bVar5;
          *(char *)(iVar6 + 0xd) = (char)extraout_r2_00;
          *(byte *)(iVar6 + 9) = bVar5;
          sVar2 = *(short *)(iVar6 + 0x6000aabf);
          pbStack_70 = (byte *)(iVar7 * 2);
          *(byte **)(pbStack_70 + 0x14) = pbStack_70;
          *(byte **)(iVar7 + 0x14) = pbStack_70;
          pbStack_70[0xc] = 0x4c;
          bVar3 = (byte)sVar2;
          pbStack_70[9] = bVar3;
          iVar6 = *(int *)(iVar7 + 0x14);
          *(uint *)(pbStack_70 + 0x54) = uStack_74;
          pbStack_70[0xc] = 0x4c;
          *(int *)(iVar6 + 0x24) = (int)sVar2;
          *(uint *)(iVar6 + 0x34) = uStack_74;
          uStack_78 = *(undefined4 *)(iVar6 + 0x14);
          *(undefined4 *)(pbStack_70 + 0x54) = uStack_78;
          pbStack_70[0xc] = bVar3;
          pbStack_70[0xc] = 0x4c;
          pbStack_70[9] = bVar3;
          iVar6 = *(int *)(iVar6 + 0x14);
          *(uint *)(pbStack_70 + 0x54) = uStack_74;
          uStack_7c = (uint)*pbStack_70;
          *(byte **)(pbStack_70 + 0x14) = pbStack_70;
          *(byte **)(iVar6 + 0x14) = pbStack_70;
          *(byte *)(iVar6 + 0x15) = bVar5;
          pbStack_70[0xd] = (byte)uStack_78;
          pbStack_70[9] = bVar5;
          *(uint *)(uStack_7c + 0x24) = uStack_7c;
          *(byte **)(pbStack_70 + 0x54) = pbStack_70;
          *(char *)(uStack_7c + 1) = (char)uVar1;
          uStack_6c = 0x6000aac5;
          if ((*(char *)*_DAT_6000abbc == '\0') || (iVar6 = FUN_60019c8c(), iVar6 == 0)) {
            *_DAT_6000abc0 = 0x1d;
            bVar5 = 0;
            pbVar10 = _DAT_6000abc4;
          }
          else {
            uStack_74 = uStack_74 & 0xffff0000;
            uStack_7c = 0;
            uStack_78 = 0;
            iVar6 = FUN_60019c04(&uStack_7c);
            if (iVar6 == 0) {
              *_DAT_6000abc0 = 0x1d;
              *_DAT_6000abc4 = 0;
              return 0x76;
            }
            bVar5 = *_DAT_6000abc4;
            if ((bVar5 < 5) && (*_DAT_6000abc4 = bVar5 + 1, bVar5 != 4)) {
              return 0x76;
            }
            if (0x1c < *_DAT_6000abc0) {
              *_DAT_6000abc0 = 0;
              FUN_60163e70(_DAT_6000abc8,&uStack_7c,0);
              return 0x76;
            }
            bVar5 = *_DAT_6000abc0 + 1;
            pbVar10 = _DAT_6000abc0;
          }
          *pbVar10 = bVar5;
          return 0x76;
        }
        *puStack_44 = uStack_58;
        puStack_44[1] = uStack_54;
        iVar6 = FUN_601622a0(unaff_r4,auStack_4c,0x10);
        if (iVar6 == 0) {
          return 0;
        }
        uStack_64 = uStack_48 & 0xffff;
        uStack_5c = uStack_48 >> 0x10;
        uStack_68 = 0;
        puStack_60 = puStack_44;
        func_0x60167f3c(7,uRam6000aac4,1,uRam6000aac8);
        uVar9 = FUN_6016804c(uRam6000aacc,uRam6000aad0,0x55f);
      }
      if (extraout_r2 != (code *)0x0) {
        puStack_44 = &uStack_58;
        uVar9 = (*extraout_r2)(&uStack_48);
      }
      return uVar9;
    }
    FUN_60167214(iVar8,0x20);
    *(undefined1 *)(*(int *)(iVar7 + 0xc) + 8) = 1;
    FUN_60164ac8();
    bVar5 = (char)iVar6 + 10;
  }
  return (uint)bVar5;
}

