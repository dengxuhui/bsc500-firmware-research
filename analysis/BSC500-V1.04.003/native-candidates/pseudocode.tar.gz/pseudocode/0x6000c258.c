
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000c258(int param_1,int param_2)

{
  char cVar1;
  bool bVar2;
  undefined1 uVar3;
  byte bVar4;
  int iVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined1 *puVar8;
  int extraout_r1;
  int extraout_r2;
  int extraout_r3;
  int unaff_r4;
  uint unaff_r5;
  uint uVar9;
  undefined4 unaff_r6;
  undefined4 uVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  undefined4 uVar13;
  undefined4 in_cr14;
  undefined4 uVar14;
  undefined8 uVar15;
  undefined4 uStack_80;
  int iStack_7c;
  undefined4 uStack_70;
  undefined4 uStack_6c;
  undefined4 uStack_68;
  undefined4 uStack_64;
  undefined4 auStack_60 [2];
  undefined8 uStack_58;
  undefined8 uStack_50;
  undefined8 uStack_48;
  undefined8 uStack_40;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  if ((param_1 != 0) && (param_2 != 0)) {
    ZeroBytes(&uStack_58,0x20);
    uStack_70 = *(undefined4 *)(param_1 + 0xbc);
    uStack_6c = *(undefined4 *)(param_1 + 0xc0);
    uStack_64 = *(undefined4 *)(param_1 + 0xb8);
    uStack_68 = *(undefined4 *)(param_1 + 0xb4);
    uStack_38 = uStack_70;
    uStack_34 = uStack_6c;
    uStack_30 = uStack_68;
    uStack_2c = uStack_64;
    iVar5 = FUN_6011d9b4();
    if (iVar5 == 1) {
      auStack_60[0] = *(undefined4 *)(param_1 + 0x9c);
    }
    else {
      auStack_60[0] = FUN_6015616c();
    }
    iVar5 = FUN_60167080();
    if ((*(char *)(iVar5 + 0x16) == '\0') &&
       ((iVar7 = func_0x60166dd0((undefined4 *)(param_1 + 0xbc)), iVar7 == 1 ||
        (iVar7 = func_0x60166dd0((undefined4 *)(param_1 + 0xb4)), iVar7 == 1)))) {
      ZeroBytes(&uStack_58,0x20);
    }
    else {
      puVar6 = (undefined4 *)FUN_600168ac();
      uVar10 = puVar6[1];
      uVar13 = puVar6[2];
      uVar12 = puVar6[3];
      uVar15 = FUN_6016759c(*puVar6);
      uVar11 = (undefined4)((ulonglong)uRam6000c4b0 >> 0x20);
      uVar14 = (undefined4)uRam6000c4b0;
      uStack_58 = FUN_601675d8((int)uVar15,(int)((ulonglong)uVar15 >> 0x20),uVar14,uVar11);
      uVar15 = FUN_6016759c(uVar10);
      uStack_50 = FUN_601675d8((int)uVar15,(int)((ulonglong)uVar15 >> 0x20),uVar14,uVar11);
      uVar15 = FUN_6016759c(uVar13);
      uStack_48 = FUN_601675d8((int)uVar15,(int)((ulonglong)uVar15 >> 0x20),uVar14,uVar11);
      uVar15 = FUN_6016759c(uVar12);
      uStack_40 = FUN_601675d8((int)uVar15,(int)((ulonglong)uVar15 >> 0x20),uVar14,uVar11);
    }
    if (*(char *)(iVar5 + 0x16) != '\0') {
      puVar6 = (undefined4 *)FUN_6015e450();
      uStack_38 = puVar6[2];
      uStack_34 = puVar6[3];
      uStack_30 = *puVar6;
      uStack_2c = puVar6[1];
      uStack_70 = puVar6[2];
      uStack_6c = puVar6[3];
      uStack_68 = *puVar6;
      uStack_64 = puVar6[1];
      FUN_601323d4(auStack_60,0);
    }
    FUN_60017c04(&uStack_58);
    FUN_60018ce4(&uStack_58);
    FUN_6001a694(&uStack_70);
    puVar6 = (undefined4 *)FUN_60163b60();
    uVar3 = FUN_60167258();
    *(undefined1 *)(puVar6 + 0xe) = uVar3;
    *(undefined1 *)(puVar6 + 5) = *(undefined1 *)(param_1 + 0xcc);
    puVar6[4] = (int)*(short *)(param_2 + 0x32e);
    uVar11 = *(undefined4 *)(param_1 + 0xb8);
    uVar12 = *(undefined4 *)(param_1 + 0xbc);
    uVar10 = *(undefined4 *)(param_1 + 8);
    *puVar6 = *(undefined4 *)(param_1 + 0xb4);
    puVar6[1] = uVar11;
    puVar6[2] = uVar12;
    iVar5 = iRam6000c4b8;
    puVar6[3] = *(undefined4 *)(param_1 + 0xc0);
    uVar11 = *(undefined4 *)(iVar5 + 0xb3c);
    puVar6[6] = *(undefined4 *)(iVar5 + 0xb38);
    puVar6[7] = uVar11;
    puVar6[10] = uVar10;
    *(byte *)(puVar6 + 0xb) = ~*(byte *)(iVar5 + 0xb40) & 1;
    *(byte *)((int)puVar6 + 0x31) = *(byte *)(iVar5 + 0xb40) >> 7;
    *(byte *)((int)puVar6 + 0x32) = (byte)(((uint)*(byte *)(iVar5 + 0xb40) << 0x1d) >> 0x1f);
    *(byte *)((int)puVar6 + 0x2d) = *(byte *)(iVar5 + 0xa88) & 1;
    *(byte *)((int)puVar6 + 0x2e) = (byte)(((uint)*(byte *)(iVar5 + 0xa88) << 0x1e) >> 0x1f);
    puVar6[8] = (*(int *)(iVar5 + 0xb40) << 0x15) >> 0x1f;
    bVar4 = FUN_600168b8();
    *(byte *)((int)puVar6 + 0x35) = bVar4 ^ 1;
    *(byte *)((int)puVar6 + 0x2f) = (byte)((uint)(*(int *)(iVar5 + 0xb40) << 0x13) >> 0x1f);
    *(byte *)((int)puVar6 + 0x36) = (byte)((uint)(*(int *)(iVar5 + 0xb40) << 0x14) >> 0x1f);
    uVar3 = FUN_60167458(0xc);
    *(undefined1 *)((int)puVar6 + 0x37) = uVar3;
    uVar10 = uRam6000c4bc;
    *(byte *)(puVar6 + 0xc) = (byte)(((uint)*(byte *)(iVar5 + 0xb40) << 0x1e) >> 0x1f);
    iVar5 = FUN_60168220(uVar10);
    CopyBytes((int)puVar6 + 0x9d,uVar10,iVar5 + 1);
    uVar10 = uRam6000c4c0;
    iVar5 = FUN_60168220(uRam6000c4c0);
    CopyBytes((int)puVar6 + 0x39,uVar10,iVar5 + 1);
    puVar8 = (undefined1 *)FUN_60163b48();
    iVar5 = FUN_60160de0(0xe);
    puVar8[0xd] = iVar5 == 0;
    uVar3 = FUN_6015e15c();
    puVar8[1] = uVar3;
    uVar10 = FUN_60149038();
    *puVar8 = (char)uVar10;
    return uVar10;
  }
  if ((*puRam6000c4c4 & 1) != 0) {
    software_bkpt(0);
  }
  bVar2 = (bool)isCurrentModePrivileged();
  if (bVar2) {
    isIRQinterruptsEnabled();
  }
  disableIRQinterrupts();
  FUN_6016804c(uRam6000c4c8,0x6000c4cc,0x10d);
  iStack_7c = extraout_r3 + unaff_r4 + (uint)((extraout_r2 >> 10 & 1U) != 0);
  if (extraout_r2 >> 0xb != 0) {
    *(undefined4 *)(extraout_r2 * 2) = unaff_r6;
    *(uint *)(unaff_r4 + 0x92) = unaff_r5;
    *(uint *)(unaff_r4 + 0x8e) = unaff_r5;
    iVar5 = _DAT_6000c560;
    ZeroBytes(_DAT_6000c560 + 0x68);
    FUN_60166858(iVar5 + 0x9e,0x85,0xff);
    *(char *)(iVar5 + 0x9a) = (char)unaff_r5;
    *(uint *)(iVar5 + 0x96) = unaff_r5;
    *(uint *)(iVar5 + 0x92) = unaff_r5;
    *(uint *)(iVar5 + 0x8e) = unaff_r5;
    return 0;
  }
  cVar1 = *(char *)(extraout_r1 + unaff_r5);
  coprocessor_loadlong(0,in_cr14,0);
  uVar9 = unaff_r5 | (int)*(char *)(extraout_r2 + unaff_r4);
  iRam00000004 = iStack_7c;
  *(int *)(uVar9 + 0x14) = (int)cVar1;
  iVar5 = *(int *)(cVar1 + 0x14);
  *(char *)(uVar9 + 1) = (char)iVar5;
  *(char *)(iVar5 + 0x11) = (char)uVar9;
  if (*_DAT_6000c4e8 == 0) {
    uStack_80 = 0;
    iVar5 = FUN_60166758(&iStack_7c,_DAT_60017ed4,1);
    if (iVar5 == 0) {
      uVar10 = FUN_60161ef4(iStack_7c,_DAT_60017ed8,0xf4,&uStack_80);
      FUN_601667bc(iStack_7c);
    }
    else {
      uVar10 = 0xffffffff;
    }
    return uVar10;
  }
  return 0;
}

