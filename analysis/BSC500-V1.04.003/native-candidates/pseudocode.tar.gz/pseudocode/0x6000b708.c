
/* WARNING: Removing unreachable block (ram,0x6001b6ee) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6000b708(void)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  uint uVar7;
  
  ZeroBytes(_DAT_6000b734,0x1280);
  func_0x6007db44(_DAT_6000b738,_DAT_6000b73c,0x2d80);
  func_0x6007db44(_DAT_6000b740,_DAT_6000b744,0xc0);
  iVar2 = _DAT_6001b744;
  piVar1 = _DAT_60010618;
  if (*_DAT_60010618 == _DAT_6001061c) {
    uVar4 = _DAT_60010618[1];
    uVar7 = 0;
    *(undefined4 *)(_DAT_6001b744 + 0x80) = 0;
    uVar3 = _DAT_6001b748;
    for (uVar5 = 0; uVar4 >> 3 != uVar5; uVar5 = uVar5 + 1) {
      uVar6 = 1 << (uVar5 & 0xff);
      uVar7 = uVar7 | uVar6;
      *(uint *)(iVar2 + uVar5 * 4) = piVar1[uVar5 * 2 + 2] & uVar3;
      *(uint *)(iVar2 + 0x84) = uVar6;
      *(int *)(iVar2 + 0x88) = piVar1[uVar5 * 2 + 3];
    }
    *(undefined4 *)(iVar2 + 0x84) = 0;
    *(uint *)(iVar2 + 0x80) = uVar7;
    return uVar7;
  }
  return 0;
}

