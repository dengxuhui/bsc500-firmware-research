
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a4e4(int param_1)

{
  char *pcVar1;
  code *pcVar2;
  code *pcVar3;
  undefined1 uVar4;
  int iVar5;
  undefined1 *puVar6;
  int iVar7;
  undefined4 extraout_r2;
  undefined4 extraout_r3;
  undefined1 auStack_d8 [8];
  undefined4 uStack_d0;
  undefined2 uStack_bc;
  undefined1 auStack_b8 [32];
  undefined1 auStack_98 [20];
  undefined1 *puStack_84;
  undefined1 auStack_68 [8];
  undefined2 *puStack_60;
  undefined1 *puStack_50;
  undefined2 *puStack_40;
  undefined1 auStack_36 [8];
  undefined2 uStack_2e;
  undefined1 uStack_2c;
  undefined1 uStack_2b;
  undefined2 uStack_2a;
  undefined4 uStack_28;
  undefined4 uStack_24;
  
  iVar5 = FUN_60149334();
  if ((iVar5 == 0) || (*_DAT_6000a510 == 0)) {
    *_DAT_6000a510 = param_1;
  }
  else if (599 < (uint)(param_1 - *_DAT_6000a510)) {
    FUN_6014a9f8(0);
    *_DAT_6001170c = 0;
    func_0x60168578(&UNK_60056110);
    pcVar1 = _DAT_6005613c;
    uStack_2a = 0x481;
    uStack_28 = 0;
    uStack_24 = 0;
    iVar5 = *(int *)(_DAT_6005613c + 0x10);
    iVar7 = *(int *)(_DAT_6005613c + 0x14);
    if (iVar5 == 0 && iVar7 == 0) {
      func_0x60168578(&UNK_60056140);
      iVar5 = *(int *)(pcVar1 + 0x10);
      iVar7 = *(int *)(pcVar1 + 0x14);
    }
    FUN_60162a88(iVar5,iVar7,_DAT_60056180,0);
    *(undefined4 *)(pcVar1 + 0x10) = extraout_r2;
    *(undefined4 *)(pcVar1 + 0x14) = extraout_r3;
    FUN_6005239a(extraout_r2,extraout_r3,&uStack_28);
    pcVar2 = _DAT_60056184;
    (*_DAT_60056184)(auStack_36,&uStack_28,8);
    uStack_2b = 0;
    uStack_2e = 0x43ff;
    uStack_2c = 0;
    if (*pcVar1 != '\0') {
      uStack_2c = 0xc0;
    }
    ZeroBytes(auStack_68,0x30);
    ZeroBytes(auStack_98,0x30);
    pcVar3 = _DAT_60056188;
    puStack_40 = (undefined2 *)(*_DAT_60056188)(0x10);
    *(undefined1 *)(puStack_40 + 1) = 0xc;
    *puStack_40 = 0x73;
    (*pcVar2)((int)puStack_40 + 3,auStack_36,0xc);
    puStack_50 = (undefined1 *)(*pcVar3)(0x12);
    *puStack_50 = 1;
    puStack_50[2] = 10;
    puStack_50[1] = 2;
    puStack_50[3] = 0x18;
    puStack_60 = &uStack_2a;
    ZeroBytes(auStack_b8,0x1f);
    FUN_60162c3a(auStack_b8,0xc,_DAT_6005618c);
    iVar5 = FUN_601626c0(auStack_b8);
    puVar6 = (undefined1 *)(*pcVar3)(iVar5 + 1);
    puStack_84 = puVar6;
    uVar4 = FUN_601626c0(auStack_b8);
    *puVar6 = uVar4;
    (*pcVar2)(puStack_84 + 1,auStack_b8,*puStack_84);
    ZeroBytes(auStack_d8,0x20);
    uStack_d0 = 0x30;
    uStack_bc = 0x7f;
    func_0x60168578(_DAT_60056190);
    iVar5 = _DAT_60056194;
    iVar7 = FUN_6005cab4(*(undefined4 *)(_DAT_60056194 + 4),auStack_68,auStack_98);
    if (iVar7 != 0) {
      func_0x60168578(_DAT_60056198,iVar7);
    }
    func_0x60168578(_DAT_6005619c);
    iVar7 = FUN_6014d820(*(undefined4 *)(iVar5 + 4));
    if (iVar7 != 0) {
      func_0x60168578(_DAT_600561a0,iVar7);
    }
    func_0x60168578(_DAT_600561a4);
    iVar7 = FUN_6005ca18(*(undefined4 *)(iVar5 + 4),auStack_d8);
    if (iVar7 != 0) {
      func_0x60168578(_DAT_600561a8,iVar7);
    }
    func_0x60168578(_DAT_600561ac);
    iVar5 = FUN_60163d34(*(undefined4 *)(iVar5 + 4));
    if (iVar5 != 0) {
      func_0x60168578(_DAT_600561b0,iVar5);
    }
    pcVar2 = _DAT_600561b4;
    (*_DAT_600561b4)(puStack_40);
    (*pcVar2)(puStack_50);
    (*pcVar2)(puStack_84);
    func_0x60168578(_DAT_600561b8,uStack_2c);
    return;
  }
  return;
}

