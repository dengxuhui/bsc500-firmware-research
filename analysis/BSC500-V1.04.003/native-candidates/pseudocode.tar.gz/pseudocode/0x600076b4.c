
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600076b4(undefined4 *param_1,char *param_2,undefined4 *param_3)

{
  undefined2 uVar1;
  undefined1 uVar2;
  int iVar3;
  undefined4 uVar4;
  uint uVar5;
  undefined4 *puVar6;
  int iVar7;
  undefined4 *puVar8;
  undefined4 uVar9;
  uint *extraout_r2;
  uint extraout_r3;
  uint unaff_r4;
  uint uVar10;
  char *unaff_r5;
  int unaff_r6;
  uint uVar11;
  undefined4 unaff_r7;
  char cVar12;
  bool bVar13;
  bool bVar14;
  undefined4 in_cr14;
  undefined8 uVar15;
  
  if (((param_1 != (undefined4 *)0x0) && (unaff_r5 = param_2, param_2 != (char *)0x0)) &&
     (param_3 != (undefined4 *)0x0)) {
    *param_1 = *param_3;
    iVar3 = FUN_6011d9b4();
    if (iVar3 == 1) {
      uVar4 = *(undefined4 *)(param_2 + 0x9c);
    }
    else {
      uVar4 = FUN_6015616c();
    }
    param_1[1] = uVar4;
    param_1[2] = 0;
    *(undefined1 *)((int)param_1 + 0x15) = 1;
    *(bool *)((int)param_1 + 0x12) = *param_2 != '\0';
    iVar3 = iRam6000772c;
    *(byte *)(param_1 + 5) = *(byte *)(iRam6000772c + 0xa88) & 1;
    *(byte *)((int)param_1 + 0x13) = (byte)(((uint)*(byte *)(iVar3 + 0xa88) << 0x1e) >> 0x1f);
    uVar2 = FUN_60167258();
    *(undefined1 *)((int)param_1 + 0x16) = uVar2;
    uVar2 = FUN_60167458(0xc);
    *(undefined1 *)((int)param_1 + 0x17) = uVar2;
    return;
  }
  cVar12 = (*puRam60007730 & 1) == 0;
  if (!(bool)cVar12) {
    software_bkpt(0);
  }
  bVar13 = (bool)isCurrentModePrivileged();
  if (bVar13) {
    isIRQinterruptsEnabled();
  }
  disableIRQinterrupts();
  uVar15 = FUN_6016804c(uRam60007734,0x60007738,0x17f);
  uVar5 = (uint)uVar15;
  if (uVar5 != 0) {
    uVar1 = (undefined2)extraout_r3;
    if ((cVar12 == '\0') && (unaff_r4 != 0)) {
      bVar14 = unaff_r4 <= uVar5;
      bVar13 = uVar5 == unaff_r4;
      if (bVar14 && !bVar13) {
        bVar14 = 4 < uVar5 - unaff_r4;
        bVar13 = uVar5 - unaff_r4 == 5;
      }
      if ((!bVar14 || bVar13) && ((unaff_r4 <= uVar5 || (unaff_r4 - uVar5 < 6)))) {
        bVar13 = true;
        iVar3 = 0;
        *(undefined2 *)(extraout_r2 + 2) = uVar1;
        extraout_r2[1] = *(uint *)((int)extraout_r2 + 6);
        uVar10 = 0;
        do {
          uVar11 = extraout_r3;
          if (iVar3 != 2) {
            if (iVar3 == 3) {
              if (bVar13) {
                for (iVar3 = 0; uVar10 = extraout_r3, iVar3 != 3; iVar3 = iVar3 + 1) {
                  *(undefined2 *)((int)extraout_r2 + iVar3 * 2 + 4) = uVar1;
                }
              }
              else {
                uVar10 = uVar10 / 3 & 0xffff;
              }
              *extraout_r2 = uVar5;
              *(undefined2 *)((ulonglong)uVar15 >> 0x20) = (short)uVar10;
              return;
            }
            uVar11 = (uint)*(ushort *)((int)extraout_r2 + iVar3 * 2 + 4);
            if (uVar11 != 0) {
              bVar13 = false;
            }
          }
          uVar10 = uVar10 + uVar11;
          iVar3 = iVar3 + 1;
        } while( true );
      }
    }
    *extraout_r2 = uVar5;
    for (iVar3 = 0; iVar3 != 3; iVar3 = iVar3 + 1) {
      *(undefined2 *)((int)extraout_r2 + iVar3 * 2 + 4) = uVar1;
    }
    return;
  }
  coprocessor_loadlong(0,in_cr14,4);
  uVar4 = *(undefined4 *)(unaff_r4 + 0x44);
  iVar3 = *(int *)(unaff_r6 + 0x14);
  uRam00000008 = extraout_r3;
  *(char *)(unaff_r6 + 0x15) = (char)iVar3;
  *(int *)(iVar3 + 0x54) = iVar3;
  *(undefined4 *)(extraout_r3 + 0x74) = unaff_r7;
  *(uint **)(unaff_r6 + 0x14) = extraout_r2;
  puVar6 = *(undefined4 **)(unaff_r6 + 4);
  *(char *)(((uint)unaff_r5 | (uint)extraout_r2) + 1) = (char)unaff_r6;
  *(char *)(unaff_r6 + 0x11) = (char)((uint)unaff_r5 | (uint)extraout_r2);
  if ((puVar6 != (undefined4 *)0x0) &&
     (iVar7 = FUN_6011d9b4(puVar6,uVar4), iVar3 = _DAT_6000776c, iVar7 == 0)) {
    puVar8 = (undefined4 *)(_DAT_6000776c + 0x98);
    uVar4 = FUN_600316b8();
    *(undefined4 *)(iVar3 + 0xa0) = uVar4;
    uVar4 = *puVar6;
    uVar9 = puVar6[1];
    *puVar8 = puVar6[2];
    *(undefined4 *)(iVar3 + 0x9c) = uVar4;
    *(undefined4 *)(iVar3 + 0xa4) = uVar9;
    return;
  }
  return;
}

