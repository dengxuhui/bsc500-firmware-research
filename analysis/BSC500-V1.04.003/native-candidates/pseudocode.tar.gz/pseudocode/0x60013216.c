
void FUN_60013216(undefined1 *param_1,undefined1 param_2,uint param_3)

{
  int *piVar1;
  uint uVar2;
  int unaff_r5;
  
  *param_1 = param_2;
  *(uint *)(unaff_r5 + 0x104) = param_3;
  *(undefined1 **)(unaff_r5 + 0x104) = param_1;
  piVar1 = (int *)(unaff_r5 + 0x1fc);
  for (; param_3 = param_3 & 0xff, param_3 < 0x14; param_3 = param_3 + 1) {
    *piVar1 = *(int *)(&stack0x00000118 + param_3 * 8) +
              *(int *)(&stack0x0000011c + param_3 * 8) * 0x10000;
    piVar1 = piVar1 + 1;
  }
  *(int *)(unaff_r5 + 0x104) = *(int *)(unaff_r5 + 0x104) + 0x97000;
  piVar1 = (int *)(unaff_r5 + 0x254);
  for (uVar2 = 0; uVar2 = uVar2 & 0xff, uVar2 < 0xe; uVar2 = uVar2 + 1) {
    *piVar1 = *(int *)(&stack0x00000000 + uVar2 * 8) +
              *(int *)(&stack0x00000004 + uVar2 * 8) * 0x10000;
    piVar1 = piVar1 + 1;
  }
  return;
}

