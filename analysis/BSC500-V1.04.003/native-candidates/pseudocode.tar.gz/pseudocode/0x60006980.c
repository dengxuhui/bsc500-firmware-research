
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006980(int *param_1)

{
  char *pcVar1;
  int iVar2;
  
  pcVar1 = _DAT_600069b4;
  if (*_DAT_600069b4 == '\x01') {
    FUN_600102b4(param_1,param_1 + 1,param_1 + 2,_DAT_600069b4 + 4);
    iVar2 = *param_1;
    *(int *)(pcVar1 + 0xc) = iVar2;
    if (*param_1 == 0) {
      iVar2 = 1;
    }
    *(int *)(pcVar1 + 0xc) = iVar2;
    iVar2 = param_1[2];
    *(int *)(pcVar1 + 0x10) = param_1[1];
    *(int *)(pcVar1 + 0x14) = iVar2;
  }
  return;
}

