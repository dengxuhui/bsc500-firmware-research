
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000299c(void)

{
  int iVar1;
  int iStack_78;
  undefined1 auStack_74 [100];
  
  iVar1 = _DAT_600029dc;
  *(undefined4 *)(_DAT_600029dc + 0x14) = 0;
  ZeroBytes(auStack_74,100);
  func_0x601681f4(auStack_74,_DAT_600029e0,_DAT_600029e4,_DAT_600029e8);
  iStack_78 = 0;
  FUN_6016243c(auStack_74,_DAT_600029ec,&iStack_78);
  if (iStack_78 != 0) {
    *(int *)(iVar1 + 0x14) = iStack_78;
    func_0x60168578(&UNK_600029f0,&UNK_60002a0c);
  }
  return;
}

