
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600182cc(void)

{
  int *piVar1;
  
  piVar1 = _DAT_600182e0;
  if (*_DAT_600182e0 != 0) {
    FUN_601667bc();
    *piVar1 = 0;
  }
  return;
}

