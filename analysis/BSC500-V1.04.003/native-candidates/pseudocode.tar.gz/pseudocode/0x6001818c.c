
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001818c(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  
  puVar4 = _DAT_600182e0;
  uVar2 = _DAT_600181f4;
  *_DAT_600182e0 = 0;
  puVar4[1] = 0;
  FUN_6013a686(uVar2);
  uVar2 = _DAT_600181f8;
  puVar4[6] = _DAT_600181f8;
  puVar4[10] = 10;
  puVar4[7] = 100;
  FUN_6013a670(puVar4 + 6);
  iVar3 = _DAT_60018200;
  iVar5 = _DAT_600181fc;
  puVar4[2] = uVar2;
  puVar4[3] = 100;
  for (iVar6 = 0; iVar6 != 0x40; iVar6 = iVar6 + 0x10) {
    *(int *)(iVar3 + iVar6) = iVar5;
    iVar5 = iVar5 + 4000;
    *(undefined4 *)(iVar3 + iVar6 + 0xc) = 0x32;
  }
  puVar4[0x11] = 0;
  puVar4[0xd] = puVar4;
  puVar4[0xe] = 4;
  piVar1 = puVar4 + 0xc;
  *piVar1 = iVar3;
  FUN_6013a65a(piVar1);
  puVar4[4] = piVar1;
  puVar4[5] = puVar4 + 2;
  return;
}

