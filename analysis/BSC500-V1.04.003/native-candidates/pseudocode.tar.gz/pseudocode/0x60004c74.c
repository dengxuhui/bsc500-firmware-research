
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60004c74(int *param_1,int param_2)

{
  short sVar1;
  code *pcVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  int iVar6;
  undefined4 extraout_r1;
  undefined4 *extraout_r2;
  int extraout_r3;
  undefined4 unaff_r4;
  uint uVar7;
  undefined4 *unaff_r5;
  int unaff_r6;
  int *unaff_r7;
  undefined4 in_stack_00000030;
  undefined4 uStack_50;
  undefined1 auStack_4c [32];
  undefined4 uStack_2c;
  undefined4 uStack_28;
  int iStack_24;
  
  pcVar2 = pcRam60004cdc;
  if (param_1 == (int *)0x0) {
    FUN_6016804c(0x60004d08,uRam60004d04,0x25);
  }
  else if (param_2 != 0) {
    piVar3 = (int *)(*pcRam60004cdc)(4);
    *piVar3 = iRam60004ce0 + 8;
    uVar4 = (*pcVar2)(4);
    FUN_600f5a7c();
    piVar5 = (int *)(*pcVar2)(0x20);
    ZeroBytes(piVar5 + 1,0x18);
    *(undefined1 *)(piVar5 + 7) = 1;
    *piVar5 = iRam60004ce4 + 8;
    (**(code **)(*param_1 + 0x14))(param_1,uVar4);
    piVar5[3] = param_2;
    piVar5[4] = (int)piVar3;
    piVar5[5] = (int)param_1;
    return piVar5;
  }
  FUN_6016804c(0x60004ce8,uRam60004d04,0x26);
  *extraout_r2 = unaff_r4;
  *unaff_r5 = extraout_r1;
  uVar7 = (uint)*(byte *)(extraout_r3 + 1);
  *unaff_r5 = extraout_r1;
  unaff_r5[0x15] = unaff_r5;
  *(char *)(unaff_r6 + 0xd) = (char)extraout_r3;
  *(undefined4 *)(uVar7 + 0x74) = extraout_r1;
  sVar1 = *(short *)(uVar7 + (int)unaff_r5);
  *(char *)(uVar7 + 0x15) = (char)extraout_r2;
  *(int *)(uVar7 + 100) = unaff_r6;
  *(char *)(uVar7 + 9) = (char)sVar1;
  *(int **)(extraout_r3 + 100) = unaff_r7;
  *(undefined4 *)(uVar7 + 0x34) = extraout_r1;
  uStack_28 = *(undefined4 *)(unaff_r6 + 0x74);
  *unaff_r7 = unaff_r6;
  *(char *)(unaff_r6 + 9) = (char)uStack_28;
  *(char *)(unaff_r6 + 1) = (char)extraout_r3;
  *(char *)(sVar1 + 9) = (char)unaff_r7;
  iStack_24 = sVar1 + -0x21;
  uStack_2c = 0;
  ZeroBytes(auStack_4c,0x20,in_stack_00000030);
  uStack_50 = 0;
  iVar6 = FUN_60166758(&uStack_2c,0x94,1);
  if (iVar6 == 0) {
    FUN_601667bc(uStack_2c);
    iVar6 = FUN_60166758(&uStack_2c,_DAT_60004dc8,1);
    if (iVar6 == 0) {
      ZeroBytes(auStack_4c,0x20);
      FUN_60161ef4(uStack_2c,auStack_4c,0x1f,&uStack_50);
      iVar6 = FUN_60166834(auStack_4c,_DAT_60004dcc);
      FUN_601667bc(uStack_2c);
      if (iVar6 != 0) {
        return (int *)0x1;
      }
      FUN_60163bbe(0x94);
      uStack_2c = 0;
      iVar6 = FUN_60166758(&uStack_2c,_DAT_60004dd0,1);
      if (iVar6 == 0) {
        ZeroBytes(auStack_4c,0x20);
        FUN_60161ef4(uStack_2c,auStack_4c,0x1f,&uStack_50);
        iVar6 = FUN_60166834(auStack_4c,_DAT_60004dcc);
        FUN_601667bc(uStack_2c);
        if (iVar6 != 0) {
          return (int *)0x1;
        }
      }
    }
    FUN_60163bbe(0x94);
    return (int *)0x0;
  }
  return (int *)0x0;
}

