
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_60016998(void)

{
  return *_DAT_600169a0;
}

