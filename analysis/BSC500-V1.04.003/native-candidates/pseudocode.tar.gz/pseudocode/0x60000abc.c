
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000abc(undefined1 *param_1,uint *param_2)

{
  uint *puVar1;
  uint *puVar2;
  uint uVar3;
  undefined4 uVar4;
  
  puVar2 = _DAT_60000b2c;
  puVar1 = _DAT_60000b28;
  uVar4 = 1;
  if ((param_1 != (undefined1 *)0x0) && (param_2 != (uint *)0x0)) {
    if ((int)(*_DAT_60000b28 << 0x1e) < 0) {
      if ((*_DAT_60000b28 & 1) == 0) {
        *param_1 = 2;
        *puVar2 = *puVar2 & 0xfffffbff;
      }
      else {
        *param_1 = 1;
      }
      *puVar1 = *puVar1 & 0xfffffffd;
      uVar3 = puVar1[2];
      *param_2 = uVar3;
      if ((uVar3 & 1) != 0) {
        *puVar2 = *puVar2 & 0xfffffffd;
        uVar3 = *param_2;
      }
      puVar1[3] = uVar3;
    }
    else {
      *param_1 = 0;
      *param_2 = 0;
      if (-1 < (int)(*puVar1 << 0x1d)) {
        return 0;
      }
      *param_2 = puVar1[2];
      *param_1 = 3;
      *puVar1 = *puVar1 & 0xfffffffb;
    }
    uVar4 = 0;
  }
  return uVar4;
}

