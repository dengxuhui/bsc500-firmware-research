
void FUN_60006eb8(int param_1,int param_2)

{
  if (param_2 != 0) {
    *(short *)(param_1 + 4) = (short)param_2;
  }
  return;
}

