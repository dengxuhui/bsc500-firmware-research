
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60011f34(uint param_1,undefined4 *param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  uVar2 = (uint)*(byte *)(_DAT_60011f90 + 1);
  if (3 < uVar2) {
    uVar2 = 4;
  }
  do {
    if (uVar2 <= uVar3) {
      return 3;
    }
    iVar1 = uVar3 * 8;
    uVar3 = uVar3 + 1;
  } while (*(byte *)(_DAT_60011f90 + iVar1 + 0x24) != param_1);
  *param_2 = *(undefined4 *)(_DAT_60011f90 + uVar3 * 8 + 0x20);
  return 0;
}

