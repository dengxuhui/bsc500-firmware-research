
/* WARNING: Removing unreachable block (ram,0x6013cd1c) */
/* WARNING: Removing unreachable block (ram,0x6013cce6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_6001036c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  undefined1 uVar2;
  int *piVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  int iVar7;
  uint extraout_r2;
  int *unaff_r5;
  int iVar8;
  undefined8 *puVar9;
  int unaff_r6;
  uint uVar10;
  undefined8 uVar11;
  
  iVar7 = _DAT_60010378;
  piVar3 = (int *)(_DAT_60010378 + 0x38);
  if (piVar3 == (int *)0x0) {
    FUN_6016804c(uRam6013cdac,uRam6013cd7c,0x24,param_4,param_3);
  }
  else {
    unaff_r6 = FUN_60163ab8();
    uVar4 = FUN_60167d0c();
    if (*piVar3 == 1) {
      uVar10 = 0;
LAB_6013cd0c:
      *piVar3 = 0;
      func_0x60167d14(uVar4);
      return uVar10;
    }
    piVar1 = (int *)(iVar7 + 0x3c);
    unaff_r5 = piVar3;
    if ((int *)*piVar1 == piVar1) {
      *(undefined4 *)(unaff_r6 + 0x38) = 0;
      FUN_601670bc(unaff_r6);
      piVar5 = *(int **)(iVar7 + 0x40);
      *(int **)(unaff_r6 + 0x20) = piVar5;
      *piVar5 = unaff_r6 + 0x1c;
      *(int *)(iVar7 + 0x40) = unaff_r6 + 0x1c;
      *(int **)(unaff_r6 + 0x1c) = piVar1;
      uVar6 = FUN_60167d0c();
      iVar7 = FUN_60163aac();
      if (iVar7 == 0) {
        func_0x60167d14(uVar6);
        func_0x60167d14(uVar4);
        func_0x60163a08();
        uVar10 = *(uint *)(unaff_r6 + 0x38);
        uVar4 = FUN_60167d0c();
        goto LAB_6013cd0c;
      }
      goto LAB_6013cd36;
    }
  }
  FUN_6016804c(0x6013cd4c,uRam6013cd7c,0x2d);
LAB_6013cd36:
  uVar4 = uRam6013cd7c;
  func_0x60168578(0x6013cd80,uRam6013cd7c);
  uVar11 = FUN_6016804c(0x6013cda8,uVar4,0x40);
  iRam0000006f = (int)uVar11;
  *(char *)(unaff_r6 + 0x11) = (char)extraout_r2;
  uVar2 = (undefined1)((ulonglong)uVar11 >> 0x20);
  *(undefined1 *)((int)unaff_r5 + 0xd) = uVar2;
  iVar7 = (int)*(short *)(unaff_r6 + (int)unaff_r5);
  *(undefined1 *)((int)unaff_r5 + 0xd) = uVar2;
  iVar8 = *(int *)(iVar7 + 0x54);
  *(char *)(unaff_r6 + 0x11) = (char)uVar11;
  uVar4 = *(undefined4 *)(iVar7 + 0x74);
  *(char *)(iVar8 + 1) = (char)iVar8;
  *(int *)(iVar8 + 0x54) = iVar7;
  iVar7 = *(int *)(unaff_r6 + 0x14);
  piVar3 = *(int **)(iVar8 + 100);
  iRam0000005b = unaff_r6 + -0x2d;
  uVar2 = (undefined1)uVar4;
  *(undefined1 *)(unaff_r6 + -0x18) = uVar2;
  *(undefined1 *)(unaff_r6 + -0x2c) = uVar2;
  puVar9 = *(undefined8 **)(iVar7 + 100);
  *(int *)(iVar7 + 0x54) = iVar7;
  *(undefined1 *)(unaff_r6 + -0x1c) = uVar2;
  *puVar9 = uVar11;
  *(undefined4 *)(puVar9 + 1) = uVar4;
  *(int *)((int)puVar9 + 0xc) = iRam0000005b;
  *piVar3 = iRam0000005b;
  *(char *)(iRam0000006f + 0x15) = (char)iRam0000005b;
  *(int *)((int)puVar9 + 0x44) = iRam0000005b;
  piVar3 = *(int **)((int)puVar9 + 0x74);
  *(char *)(*(int *)(unaff_r6 + -0x19) + 0xc) = (char)uVar11;
  iRam00000063 = iRam0000009f;
  uRam0000006c = SUB41(piVar3,0);
  *(undefined4 *)(iRam0000009f + 0x20) = *(undefined4 *)(iRam0000009f + 0x60);
  *(undefined1 *)(unaff_r6 + -0x20) = 0x5b;
  *(undefined4 *)(iRam00000063 + 0x44) = 0x5b;
  *(short *)((int)((ulonglong)uVar11 >> 0x20) + 0x5b) = (short)((ulonglong)uVar11 >> 0x20);
  uRam0000005f = extraout_r2 >> 9;
  uRam00000067 = 0x5b;
  *piVar3 = iRam0000005b;
  iVar7 = FUN_60168418();
  return (uint)(iVar7 == 0);
}

