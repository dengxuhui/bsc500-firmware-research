
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60005480(void)

{
  int iVar1;
  
  iVar1 = FUN_6000a514(1);
  if (iVar1 != 0) {
    return 0;
  }
  func_0x60168578(&UNK_600054a8,*_DAT_600054a4);
  FUN_6005136c();
  FUN_60009c30();
  return 1;
}

