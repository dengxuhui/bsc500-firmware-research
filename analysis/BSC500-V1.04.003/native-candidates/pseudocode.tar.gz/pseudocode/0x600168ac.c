
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_600168ac(void)

{
  return _DAT_600168b4 + 0xc;
}

