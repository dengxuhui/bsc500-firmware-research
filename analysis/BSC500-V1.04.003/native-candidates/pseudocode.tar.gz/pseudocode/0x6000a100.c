
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a100(char *param_1,int param_2)

{
  char cVar1;
  float fVar2;
  byte *pbVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  bool bVar7;
  uint in_fpscr;
  float fVar8;
  float fVar9;
  int iVar10;
  undefined4 uVar11;
  
  FUN_60013f5c();
  FUN_60013840(param_1,param_2);
  FUN_60014a40(param_1,param_2);
  FUN_6001b1f0(param_1);
  iVar4 = FUN_60164dd4();
  if (iVar4 == 0) {
    iVar4 = FUN_60164dbc();
  }
  else {
    iVar4 = FUN_60164dd4();
  }
  fVar2 = _UNK_6000a390;
  if (((iVar4 == 0) || (*(char *)(iVar4 + 0x21) != '\x03' && *(char *)(iVar4 + 0x21) != '\0')) ||
     (*(ushort *)(param_2 + 0x22c) == 0)) {
    FUN_6015c4f0(param_2 + 0x334,0x14,0xff);
  }
  else {
    fVar8 = (float)VectorUnsignedToFloat
                             ((uint)*(ushort *)(param_2 + 0x22c),(byte)(in_fpscr >> 0x16) & 3);
    fVar8 = fVar8 / _UNK_6000a390;
    fVar9 = *(float *)(iVar4 + 0xa8) / fVar8;
    uVar11 = VectorFloatToUnsigned(fVar9 * _UNK_6000a390,3);
    *(undefined4 *)(param_2 + 0x334) = uVar11;
    iVar10 = VectorFloatToUnsigned(fVar9,3);
    iVar5 = *(int *)(param_1 + 4);
    *(int *)(param_2 + 0x338) = iVar10 + iVar5;
    bVar7 = *(char *)(iVar4 + 0xa1) != '\x01';
    if (bVar7) {
      iVar4 = -1;
      *(undefined4 *)(param_2 + 0x33c) = 0xffffffff;
      *(undefined4 *)(param_2 + 0x340) = 0xffffffff;
    }
    if (!bVar7) {
      fVar9 = *(float *)(iVar4 + 0x7c);
      uVar11 = VectorFloatToUnsigned(fVar9 * _UNK_6000a394,3);
      *(undefined4 *)(param_2 + 0x33c) = uVar11;
      fVar9 = fVar9 / fVar8;
      uVar11 = VectorFloatToUnsigned(fVar9 * fVar2,3);
      *(undefined4 *)(param_2 + 0x340) = uVar11;
      iVar4 = VectorFloatToUnsigned(fVar9,3);
      iVar4 = iVar4 + iVar5;
    }
    *(int *)(param_2 + 0x344) = iVar4;
  }
  iVar4 = FUN_60164dd4();
  if (((iVar4 == 0) || (*(char *)(iVar4 + 0x74) == '\0')) || (*param_1 == '\0')) {
    *(undefined2 *)(param_2 + 0x37e) = 0;
  }
  else {
    if (*(uint *)(iVar4 + 0x54) != (uint)*(ushort *)(param_2 + 0x380)) {
      *(short *)(param_2 + 0x380) = (short)*(uint *)(iVar4 + 0x54);
      *(undefined2 *)(param_2 + 0x37e) = 0;
    }
    iVar5 = FUN_601632f4();
    cVar1 = *(char *)(param_2 + 0x37e);
    if (cVar1 == '\x03') {
LAB_6000a20e:
      if ((*(float *)(iVar4 + 0xa4) < *(float *)(iVar5 + 8)) ||
         (20.0 < *(float *)(iVar4 + 0xa4) - *(float *)(iVar5 + 8))) {
        if (cVar1 != '\x02') goto LAB_6000a250;
      }
      else {
        FUN_601320f4(param_2);
        FUN_60013394(param_1);
        *(undefined1 *)(param_2 + 0x37e) = 2;
      }
    }
    else if (cVar1 != '\x02') {
      if (cVar1 != '\0') goto LAB_6000a250;
      goto LAB_6000a20e;
    }
    if ((*(float *)(iVar4 + 0xa4) <= *(float *)(iVar5 + 0xc)) &&
       (*(float *)(iVar5 + 0xc) - *(float *)(iVar4 + 0xa4) <= 20.0)) {
      *(undefined2 *)(param_2 + 0x37e) = 0x303;
      *(undefined2 *)(param_2 + 0x382) = *(undefined2 *)(param_2 + 0x380);
      FUN_60013470();
      if (*(char *)(param_2 + 0x37e) != '\x02') goto LAB_6000a250;
    }
    FUN_60013488(param_1,param_2);
  }
LAB_6000a250:
  iVar4 = FUN_6011679c(0,param_1[0xda],param_1[0xd8],*(undefined2 *)(param_1 + 0xd6));
  pbVar3 = _DAT_6000a398;
  if ((iVar4 == 0) &&
     (((*(short *)(param_1 + 0xd0) == -1 || (param_1[0x8c] != '\x01')) && (param_1[0xcc] != '\0'))))
  {
    if (*(int *)(param_1 + 0xc4) - 0x341U < 0xfaa8) {
      if (*_DAT_6000a398 < 3) {
        *_DAT_6000a398 = *_DAT_6000a398 + 1;
      }
      else {
        *(undefined1 *)(param_2 + 0x32a) = 1;
      }
      pbVar3[1] = 0;
    }
    else {
      if (_DAT_6000a398[1] < 2) {
        _DAT_6000a398[1] = _DAT_6000a398[1] + 1;
      }
      else {
        *(undefined1 *)(param_2 + 0x32a) = 0;
      }
      *pbVar3 = 0;
    }
  }
  else {
    *(undefined1 *)(param_2 + 0x32a) = *(undefined1 *)(param_2 + 0x329);
  }
  iVar4 = FUN_60163834();
  iVar5 = *(int *)(iVar4 + 0x68);
  if (*(char *)(iVar4 + 0x6d) == '\0') {
    if (iVar5 != 0) {
      if (*(char *)(iVar4 + 0x6c) == '\0') {
        iVar10 = *(int *)(param_2 + 0x388);
        if (iVar10 != 0) goto LAB_6000a308;
      }
      else {
        *(undefined1 *)(iVar4 + 0x6c) = 0;
      }
      iVar6 = *(int *)(param_1 + 4);
      goto LAB_6000a310;
    }
    iVar10 = *(int *)(param_2 + 0x388);
LAB_6000a308:
    iVar6 = *(int *)(param_1 + 4);
    iVar5 = iVar6 - iVar10;
  }
  else {
    if ((iVar5 == 0) && (*(char *)(iVar4 + 0x70) != '\0')) {
      *(undefined1 *)(iVar4 + 0x70) = 0;
      iVar5 = *(int *)(param_1 + 4);
      *(int *)(param_2 + 900) = iVar5;
      iVar6 = iVar5;
      goto LAB_6000a316;
    }
    iVar6 = *(int *)(param_1 + 4);
    if (*(char *)(iVar4 + 0x6c) == '\0') {
      iVar5 = *(int *)(param_2 + 900);
      goto LAB_6000a316;
    }
    *(undefined1 *)(iVar4 + 0x6c) = 0;
LAB_6000a310:
    iVar5 = iVar6 - iVar5;
  }
  *(int *)(param_2 + 900) = iVar5;
LAB_6000a316:
  uVar11 = *(undefined4 *)(iVar4 + 100);
  *(int *)(param_2 + 0x388) = iVar6 - iVar5;
  *(undefined4 *)(param_2 + 0x38c) = uVar11;
  return;
}

