
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60004968(undefined4 param_1,undefined4 param_2,int param_3,int param_4)

{
  char *pcVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int iStack_18;
  int iStack_14;
  
  pcVar1 = _DAT_600049f4;
  iStack_18 = param_3;
  iStack_14 = param_4;
  if (_DAT_600049f4[0xd] == '\0') {
    func_0x60161424(_DAT_600049f8,_DAT_600049fc,&UNK_60004a00);
    func_0x60161424(_DAT_60004a14);
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  func_0x60161424(_DAT_60004a18);
  func_0x60161424(_DAT_60004a14);
  FUN_6000a660();
  piVar2 = (int *)getMainStackPointer();
  if (&iStack_18 == piVar2) {
    func_0x60161424(&UNK_60004a30);
    func_0x60161424(_DAT_60004a14);
    iVar4 = 0;
    if (*pcVar1 != '\0') {
      iVar4 = _DAT_60004a68;
    }
    iVar5 = 0;
    if (pcVar1[4] != '\0') {
      iVar5 = _DAT_60004a6c - _DAT_60004a68;
    }
  }
  else {
    piVar2 = (int *)getProcessStackPointer();
    if (&iStack_18 != piVar2) goto LAB_600049ec;
    uVar3 = FUN_60163ab8();
    func_0x60161424(&UNK_60004a1c,uVar3);
    func_0x60161424(_DAT_60004a14);
    FUN_6015a194(&iStack_14,&iStack_18);
    iVar4 = iStack_14;
    iVar5 = iStack_18;
  }
  FUN_6000abcc(iVar4,iVar5,param_1);
LAB_600049ec:
  FUN_6000d764(param_1);
  return;
}

