
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60007054(void)

{
  byte bVar1;
  undefined4 uVar2;
  byte bVar3;
  uint uVar4;
  
  uVar4 = *_DAT_60007094 + _DAT_60007098;
  bVar1 = FUN_60010d38();
  bVar3 = *(byte *)(_DAT_60007420 + 0xb5b);
  if ((bVar1 < uVar4) && (uVar4 - bVar1 <= _DAT_6000709c)) {
    bVar3 = bVar3 | 1;
    uVar2 = 0;
  }
  else {
    if ((bVar3 & 1) == 0) {
      return 0;
    }
    bVar3 = bVar3 & 0xfe;
    uVar2 = 1;
  }
  *(byte *)(_DAT_60007420 + 0xb5b) = bVar3;
  return uVar2;
}

