
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600074e4(void)

{
  *_DAT_600074ec = 0;
  return;
}

