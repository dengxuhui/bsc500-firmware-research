
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_60003b40(void)

{
  int iVar1;
  undefined4 uVar2;
  undefined *puStack_34;
  undefined1 auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  ZeroBytes(auStack_30,0x20);
  uStack_1c = 0x10;
  puStack_34 = &UNK_60003b8c;
  uStack_20 = 0x1000;
  FUN_60003bdc();
  uVar2 = FUN_6011e4a8(0x14,4,0);
  iVar1 = _DAT_60003c00;
  *(undefined4 *)(_DAT_60003c00 + 8) = uVar2;
  uVar2 = FUN_601566b4(_DAT_60003ba4,0,&puStack_34);
  *(undefined4 *)(iVar1 + 4) = uVar2;
  FUN_60156808();
  return *(int *)(iVar1 + 4) != 0;
}

