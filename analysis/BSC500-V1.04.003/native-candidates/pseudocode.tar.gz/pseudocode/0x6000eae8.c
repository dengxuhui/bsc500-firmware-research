
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000eae8(char *param_1,int param_2)

{
  byte *pbVar1;
  char *pcVar2;
  ushort uVar3;
  uint *puVar4;
  undefined4 *puVar5;
  undefined1 uVar6;
  char cVar7;
  undefined2 uVar8;
  int iVar9;
  undefined4 uVar10;
  uint uVar11;
  int iVar12;
  bool bVar13;
  int iVar14;
  int *piVar15;
  int iVar16;
  uint uVar17;
  undefined4 uVar18;
  undefined4 *puVar19;
  undefined4 *puVar20;
  undefined2 uVar21;
  undefined4 uVar22;
  undefined4 uVar23;
  uint uVar24;
  byte bVar25;
  undefined4 uVar26;
  int unaff_r9;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  iVar14 = _DAT_6000f648;
  if (param_1 != (char *)0x0) {
    unaff_r9 = param_2;
  }
  if (param_1 == (char *)0x0 || param_2 == 0) {
    return 0xffffffff;
  }
  *(byte *)(_DAT_6000f648 + 0x6e6b) = *(byte *)(_DAT_6000f64c + 0x74) & 1;
  iVar9 = FUN_6012d794();
  puVar5 = _DAT_6000f650;
  if (((((iVar9 != 0) || (*param_1 == '\0')) || (*(char *)((int)_DAT_6000f650 + 10) == '\x01')) ||
      ((*(char *)(iVar14 + 0x6e68) == '\0' || (*(char *)(iVar14 + 1) == '\0')))) ||
     ((iVar9 = func_0x60166dd0(param_1 + 0xb4), iVar9 == 1 ||
      (iVar9 = func_0x60166dd0(param_1 + 0xbc), iVar9 == 1)))) {
    FUN_6013115c();
    *(undefined4 *)(iVar14 + 0x6e3c) = 0;
    *(undefined1 *)(iVar14 + 0x9d7c) = 0;
    if (*(char *)(puVar5 + 1) != '\x01') {
      return 0;
    }
    *(undefined2 *)(puVar5 + 3) = 0;
    *(undefined1 *)(puVar5 + 4) = 0;
    if (*(char *)((int)puVar5 + 5) == '\x01') {
      FUN_60164914(_DAT_6000eee8,2);
      *(undefined1 *)((int)puVar5 + 5) = 0;
    }
    if (7 < *(byte *)(puVar5 + 9)) {
      *(undefined1 *)(puVar5 + 9) = 7;
      *(undefined1 *)(puVar5 + 1) = 0;
      return 0;
    }
                    /* WARNING: Could not recover jumptable at 0x6000eba0. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar10 = (*(code *)(&UNK_6000eba4 + (uint)(byte)(&UNK_6000eba4)[*(byte *)(puVar5 + 9)] * 2))();
    return uVar10;
  }
  uVar11 = (uint)*(byte *)(iVar14 + 0x9d7c);
  *(undefined1 *)(puVar5 + 1) = 1;
  if (uVar11 == 0) {
    uVar11 = 1;
    *(undefined1 *)(iVar14 + 0x9d7c) = 1;
  }
  if (0 < *(short *)(puVar5 + 3)) {
    *(short *)(puVar5 + 3) = *(short *)(puVar5 + 3) + -1;
  }
  uVar10 = _DAT_6000eee8;
  uStack_38 = *(undefined4 *)(param_1 + 0xb4);
  uStack_34 = *(undefined4 *)(param_1 + 0xb8);
  uStack_30 = *(undefined4 *)(param_1 + 0xbc);
  uStack_2c = *(undefined4 *)(param_1 + 0xc0);
  if (uVar11 - 3 < 2) {
    if (*(char *)((int)puVar5 + 9) == '\0') {
      FUN_600143c8(param_1,unaff_r9);
      if ((*(code **)(iVar14 + 0x9d74) == (code *)0x0) ||
         (iVar9 = (**(code **)(iVar14 + 0x9d74))(iVar14 + 0x6e74,param_1,unaff_r9), iVar9 != 0)) {
LAB_6000ec46:
        *(undefined1 *)(iVar14 + 0x9d7c) = 1;
        *(undefined1 *)(puVar5 + 4) = 0;
        *(undefined1 *)((int)puVar5 + 0x26) = 5;
        goto LAB_6000ec5c;
      }
      func_0x6007db44(iVar14 + 0x9dac,iVar14 + 0x9bac,0x90);
      cVar7 = *(char *)(iVar14 + 0x9ba8);
      if (*(char *)(iVar14 + 0x9d7c) != '\x03' || cVar7 != '\x04') {
        if (cVar7 == '\x03' && *(char *)(iVar14 + 0x9d7c) == '\x04') {
          *(undefined1 *)(iVar14 + 0x9d7c) = 3;
          uVar6 = 4;
          goto LAB_6000f1be;
        }
        if (cVar7 != '\x06') {
          if (cVar7 == '\x05') goto LAB_6000ec46;
          if (*(char *)((int)puVar5 + 0x26) == '\x06') goto LAB_6000f3f0;
          if (*(char *)((int)puVar5 + 0x26) == '\x05') goto LAB_6000ec5c;
          goto LAB_6000ecc0;
        }
        func_0x6007db44(iVar14 + 0x9e3c,iVar14 + 0x9c44,0xa4);
        piVar15 = _DAT_6000f5b0;
        iVar9 = *(int *)(iVar14 + 0x6e3c);
        if ((iVar9 != 0) &&
           (iVar12 = FUN_6013bb40(*(undefined4 *)(_DAT_6000f5ac + 100),_DAT_6000f5b0), iVar12 == 1))
        {
          iVar12 = *(int *)(unaff_r9 + 0x9c);
          *piVar15 = *(int *)(unaff_r9 + 0x98);
          piVar15[1] = iVar12;
          FUN_60118c40(unaff_r9 + 0xa0,unaff_r9 + 0xa8,piVar15 + 2,piVar15 + 3);
          FUN_60118c40(unaff_r9 + 0xb0,unaff_r9 + 0xb8,piVar15 + 4,piVar15 + 5);
          iVar12 = *(int *)(unaff_r9 + 0xc0);
          iVar16 = *(int *)(unaff_r9 + 0xc4);
          uVar22 = *(undefined4 *)(unaff_r9 + 0xce);
          uVar8 = *(undefined2 *)(unaff_r9 + 0x240);
          *(undefined4 *)((int)piVar15 + 0x2a) = *(undefined4 *)(unaff_r9 + 0xca);
          uVar18 = *(undefined4 *)(unaff_r9 + 0xd2);
          *(undefined2 *)(piVar15 + 10) = uVar8;
          *(undefined4 *)((int)piVar15 + 0x2e) = uVar22;
          *(undefined4 *)((int)piVar15 + 0x32) = uVar18;
          *(undefined2 *)((int)piVar15 + 0x36) = *(undefined2 *)(unaff_r9 + 0xd6);
          uVar21 = 0xffff;
          piVar15[6] = (*piVar15 - piVar15[1]) * 1000;
          piVar15[7] = iVar16;
          piVar15[8] = iVar12;
          piVar15[9] = iVar16;
          iVar12 = *(int *)(unaff_r9 + 0xdc);
          piVar15[0xe] = *(int *)(unaff_r9 + 0xd8);
          uVar8 = 0xffff;
          if (iVar12 != 0x7fffffff) {
            uVar21 = (undefined2)((iVar12 + 50000) / 0x14);
          }
          iVar12 = *(int *)(unaff_r9 + 0xe0);
          *(undefined2 *)(piVar15 + 0xf) = uVar21;
          uVar21 = 0xffff;
          if (iVar12 != 0x7fffffff) {
            uVar21 = (undefined2)((iVar12 + 50000) / 0x14);
          }
          *(undefined2 *)((int)piVar15 + 0x3e) = uVar21;
          uVar22 = *(undefined4 *)(unaff_r9 + 0xea);
          uVar23 = *(undefined4 *)(unaff_r9 + 0xee);
          uVar26 = *(undefined4 *)(unaff_r9 + 0xf2);
          *(undefined2 *)(piVar15 + 0x10) = *(undefined2 *)(unaff_r9 + 0xe4);
          uVar18 = *(undefined4 *)(unaff_r9 + 0xe6);
          *(undefined4 *)((int)piVar15 + 0x46) = uVar22;
          *(undefined4 *)((int)piVar15 + 0x4a) = uVar23;
          *(undefined4 *)((int)piVar15 + 0x4e) = uVar26;
          *(undefined4 *)((int)piVar15 + 0x42) = uVar18;
          if (*(int *)(unaff_r9 + 0xf8) != 0x7fffffff) {
            uVar8 = (undefined2)((*(int *)(unaff_r9 + 0xf8) + 50000) / 0x14);
          }
          *(undefined2 *)((int)piVar15 + 0x52) = uVar8;
          *(undefined2 *)((int)piVar15 + 0x5a) = 0x702;
          *(undefined4 *)((int)piVar15 + 0x56) = *(undefined4 *)(unaff_r9 + 0xfc);
          *(undefined1 *)(piVar15 + 0x17) = *(undefined1 *)(unaff_r9 + 0x100);
          *(undefined4 *)((int)piVar15 + 0x5d) = *(undefined4 *)(unaff_r9 + 0x101);
          *(undefined2 *)((int)piVar15 + 0x61) = *(undefined2 *)(unaff_r9 + 0x105);
          CopyBytes((int)piVar15 + 99,iVar9,0x3d);
        }
        FUN_600106c2(*(undefined4 *)(param_1 + 4),_DAT_6000f5b0);
        func_0x60167010(0x12);
        iVar9 = _DAT_6000f5b4;
        *(short *)(unaff_r9 + 0x240) = *(short *)(unaff_r9 + 0x240) + 1;
        iVar12 = *(int *)(iVar14 + 0x6e74);
        CopyBytes(iVar9 + 0x965,iVar12,0x3d);
        *(undefined1 *)(iVar9 + 0x964) = 1;
        cVar7 = *(char *)(iVar14 + 0x6e6b);
        puVar19 = (undefined4 *)(iVar14 + 0x9ec8);
        uVar18 = *(undefined4 *)(iVar12 + 0x40);
        *(undefined4 *)(iVar9 + 0x9ac) = *(undefined4 *)(iVar14 + 0x9ed0);
        uVar22 = *(undefined4 *)(iVar14 + 0x9eb0);
        *(undefined4 *)(iVar9 + 0x9a4) = uVar18;
        uVar3 = *(ushort *)(iVar14 + 0x9ba4);
        uVar11 = (uint)uVar3;
        *(undefined4 *)(iVar9 + 0x9a8) = uVar22;
        *(ushort *)(iVar9 + 0x960) = uVar3;
        if (cVar7 == '\0') {
          puVar19 = (undefined4 *)(iVar14 + 0x9ecc);
        }
        puVar20 = (undefined4 *)(iVar9 + 8);
        *(undefined4 *)(iVar9 + 0x9b0) = *puVar19;
        puVar19 = (undefined4 *)(iVar14 + 0x73cc);
        for (; uVar11 != 0; uVar11 = uVar11 - 1) {
          uVar22 = *puVar19;
          uVar23 = puVar19[2];
          uVar26 = puVar19[4];
          uVar18 = puVar19[0x10];
          puVar19 = puVar19 + 0x11;
          puVar20[-2] = uVar22;
          puVar20[-1] = uVar23;
          *puVar20 = uVar18;
          puVar20[1] = uVar26;
          puVar20 = puVar20 + 4;
        }
        FUN_60148a34(0,1,1);
        *(undefined1 *)(puVar5 + 4) = 0;
        *(undefined1 *)(iVar14 + 0x9d7c) = 1;
        *(undefined1 *)((int)puVar5 + 0x26) = 6;
LAB_6000f3f0:
        uVar11 = 5;
        bVar25 = *(byte *)(iVar14 + 0x6e6b);
        uStack_40 = 0;
        uStack_44 = (float)((uint)bVar25 << 0x10);
        if (bVar25 == 0) {
          uVar11 = 6;
        }
        iVar12 = *(int *)(iVar14 + 0x6e74);
        iVar9 = 0;
        do {
          if ((uint)*(byte *)(iVar12 + 0x80) * 0x20 + 0x20 == iVar9 + 0x20) {
            bVar13 = false;
            goto LAB_6000f43c;
          }
          iVar16 = iVar9 + iVar12;
          iVar9 = iVar9 + 0x20;
        } while (*(byte *)(iVar16 + 0xa0) != uVar11);
        bVar13 = true;
        uStack_44 = (float)(uint)CONCAT12(bVar25,0x100);
LAB_6000f43c:
        iVar9 = 0;
        do {
          if ((uint)*(byte *)(iVar12 + 0x80) * 0x20 + 0x20 == iVar9 + 0x20) {
            uStack_44 = (float)CONCAT13(1,(undefined3)uStack_44);
            if (bVar13) {
              if (*(int *)(iVar14 + uVar11 * 4 + 0x9eb4) < 0) goto LAB_6000f49a;
            }
            else {
              uStack_40 = 1;
LAB_6000f49a:
              uStack_40 = (uint)CONCAT12(1,(undefined2)uStack_40);
            }
            uStack_40._0_2_ = CONCAT11(1,(undefined1)uStack_40);
            goto LAB_6000f4d8;
          }
          iVar16 = iVar9 + iVar12;
          iVar9 = iVar9 + 0x20;
        } while (*(char *)(iVar16 + 0xa0) != '\a');
        uStack_44 = (float)CONCAT31(uStack_44._1_3_,1);
        if (*(int *)(iVar14 + 0x9ed0) < 0) {
          uStack_40 = 0x100;
          if (bVar13) {
            if (*(int *)(iVar14 + uVar11 * 4 + 0x9eb4) < 0) {
              uStack_40 = 0x10100;
            }
          }
          else {
            uStack_40 = 0x10101;
          }
LAB_6000f4d8:
          uStack_3c = *(undefined4 *)(iVar14 + 0x9eb0);
          FUN_60019744(iVar12,&uStack_44,iVar14 + 0x9ce8,iVar14 + 0x9cf4);
          if (uStack_40._2_1_ == '\x01') {
            iVar9 = *(byte *)(*(int *)(iVar14 + 0x6e74) + 0x80) + 1;
            puVar19 = (undefined4 *)(*(int *)(iVar14 + 0x6e74) + 0x7c);
            do {
              iVar9 = iVar9 + -1;
              if (iVar9 == 0) goto LAB_6000f524;
              puVar20 = puVar19 + 8;
              pbVar1 = (byte *)(puVar19 + 9);
              puVar19 = puVar20;
            } while (*pbVar1 != uVar11);
            *puVar20 = uStack_3c;
          }
        }
        else {
          uStack_3c = *(undefined4 *)(iVar14 + 0x9eb0);
        }
LAB_6000f524:
        if (uStack_40._1_1_ == '\x01') {
          iVar9 = *(byte *)(*(int *)(iVar14 + 0x6e74) + 0x80) + 1;
          puVar19 = (undefined4 *)(*(int *)(iVar14 + 0x6e74) + 0x7c);
          do {
            iVar9 = iVar9 + -1;
            if (iVar9 == 0) goto LAB_6000f554;
            puVar20 = puVar19 + 8;
            pcVar2 = (char *)(puVar19 + 9);
            puVar19 = puVar20;
          } while (*pcVar2 != '\a');
          *puVar20 = uStack_3c;
        }
LAB_6000f554:
        if (*(char *)(iVar14 + 0x9cec) == '\x01') {
          FUN_601667bc(*(undefined4 *)(iVar14 + 0x9ce8));
          *(undefined1 *)(iVar14 + 0x9cec) = 0;
        }
        if (*(char *)(iVar14 + 0x9d68) == '\x01') {
          FUN_601667bc(*(undefined4 *)(iVar14 + 0x9cf4));
          *(undefined1 *)(iVar14 + 0x9d68) = 0;
          FUN_60163bbe(iVar14 + 0x9cf8);
        }
        if (*(char *)((int)puVar5 + 5) != '\x01') goto LAB_6000ecc0;
        uVar6 = 2;
        goto LAB_6000ecbc;
      }
      *(undefined1 *)(iVar14 + 0x9d7c) = 4;
      uVar6 = 3;
LAB_6000f1be:
      *(undefined1 *)((int)puVar5 + 0x26) = uVar6;
    }
    else {
      *(undefined1 *)(iVar14 + 0x9d7c) = 1;
      *(undefined1 *)(puVar5 + 4) = 0;
      *(undefined1 *)((int)puVar5 + 0x26) = 5;
      *(undefined1 *)((int)puVar5 + 9) = 0;
LAB_6000ec5c:
      if (*(char *)(iVar14 + 0x9cec) == '\x01') {
        FUN_601667bc(*(undefined4 *)(iVar14 + 0x9ce8));
        *(undefined1 *)(iVar14 + 0x9cec) = 0;
      }
      if (*(char *)(iVar14 + 0x9d68) == '\x01') {
        FUN_601667bc(*(undefined4 *)(iVar14 + 0x9cf4));
        *(undefined1 *)(iVar14 + 0x9d68) = 0;
        FUN_60163bbe(iVar14 + 0x9cf8);
      }
      if (*(char *)((int)puVar5 + 5) == '\x01') {
        *(undefined1 *)((int)puVar5 + 0x25) = 2;
        FUN_60164914(uVar10,2);
        uVar6 = 3;
LAB_6000ecbc:
        *(undefined1 *)((int)puVar5 + 0x25) = uVar6;
      }
    }
LAB_6000ecc0:
    uVar11 = (uint)*(byte *)(iVar14 + 0x9d7c);
  }
  if (uVar11 == 1) {
    if (*(code **)(iVar14 + 0x6e60) != (code *)0x0) {
      (**(code **)(iVar14 + 0x6e60))(iVar14,&uStack_38,iVar14 + 0x9d7c);
    }
    uVar11 = (uint)*(byte *)(iVar14 + 0x9d80);
    if (uVar11 == 0) {
      *(undefined4 *)(iVar14 + 0x6e3c) = 0;
      if (*(short *)(puVar5 + 3) < 1) {
        *(undefined1 *)(puVar5 + 4) = 0;
      }
      if (*(char *)((int)puVar5 + 5) == '\x01') {
        *(undefined1 *)((int)puVar5 + 0x25) = 2;
      }
    }
    else {
      if ((*(char *)(iVar14 + 0x6e70) == '\x01') && (*(short *)(puVar5 + 3) < 1)) {
        if (*(byte *)(puVar5 + 4) < uVar11) {
LAB_6000ed12:
          if (*(char *)(puVar5 + 2) == '\0') {
            puVar19 = puVar5 + 5;
            *(byte *)(puVar5 + 4) = *(byte *)(iVar14 + 0x9d80);
            *(undefined2 *)(puVar5 + 3) = 0x78;
            *(undefined1 *)((int)puVar5 + 0x25) = 0;
            piVar15 = (int *)(iVar14 + 0x9d84);
            for (uVar17 = uVar11; uVar17 != 0; uVar17 = uVar17 - 1) {
              *puVar19 = *(undefined4 *)(*piVar15 + 0x40);
              puVar19 = puVar19 + 1;
              piVar15 = piVar15 + 2;
            }
          }
        }
        else {
          for (uVar17 = 0; uVar17 != uVar11; uVar17 = uVar17 + 1) {
            uVar24 = (uint)*(byte *)(puVar5 + 4);
            piVar15 = puVar5 + 5;
            do {
              if (uVar24 == 0) goto LAB_6000ed12;
              iVar9 = *piVar15;
              piVar15 = piVar15 + 1;
              uVar24 = uVar24 - 1;
            } while (*(int *)(*(int *)(iVar14 + uVar17 * 8 + 0x9d84) + 0x40) != iVar9);
          }
        }
      }
      if (*(uint *)(iVar14 + 0x9d88) < 0x4e21) {
        for (bVar25 = 0; uVar17 = (uint)bVar25, uVar17 < uVar11; bVar25 = bVar25 + 1) {
          iVar9 = iVar14 + uVar17 * 8;
          uVar11 = *(uint *)(iVar9 + 0x9d88);
          if (20000 < uVar11) break;
          iVar9 = *(int *)(iVar9 + 0x9d84);
          if ((*(int *)(iVar9 + 0x44) == *(int *)(iVar9 + 0x54)) &&
             (*(int *)(iVar9 + 0x4c) == *(int *)(iVar9 + 0x5c))) goto LAB_6000edf8;
          uStack_44 = 0.0;
          FUN_60118418(&uStack_44,(int *)(iVar9 + 0x44),iVar9 + 0x4c,(int *)(iVar9 + 0x54),
                       iVar9 + 0x5c);
          if ((*(ushort *)(param_1 + 200) < 0x169) &&
             (0xb4 < (int)(((uint)*(ushort *)(param_1 + 200) - (int)uStack_44) + 0x168) % 0x168 -
                     0x5aU)) {
            bVar13 = true;
            goto LAB_6000edea;
          }
          uVar11 = (uint)*(byte *)(iVar14 + 0x9d80);
        }
        bVar13 = false;
        bVar25 = 0;
LAB_6000edea:
        uVar10 = _DAT_6000eee8;
        if (bVar13) {
          uVar17 = (uint)bVar25;
          uVar11 = *(uint *)(iVar14 + uVar17 * 8 + 0x9d88);
LAB_6000edf8:
          uVar10 = _DAT_6000eee8;
          *(undefined1 *)(iVar14 + 0x9d7c) = 2;
          uVar18 = *(undefined4 *)(iVar14 + uVar17 * 8 + 0x9d84);
          *(undefined4 *)(iVar14 + 0x6e3c) = uVar18;
          puVar4 = _DAT_6000f5b8;
          *(undefined4 *)(iVar14 + 0x9da4) = uVar18;
          *(uint *)(iVar14 + 0x9da8) = uVar11;
          *puVar4 = uVar11;
          *(bool *)((int)puVar5 + 0x26) = uVar11 < 0x1389;
          goto LAB_6000ee72;
        }
      }
      *(undefined4 *)(iVar14 + 0x6e3c) = 0;
    }
  }
LAB_6000ee72:
  if (*(char *)(iVar14 + 0x9d7c) == '\x02') {
    if (*(code **)(iVar14 + 0x6e60) != (code *)0x0) {
      (**(code **)(iVar14 + 0x6e60))(iVar14,&uStack_38,iVar14 + 0x9d7c);
    }
    if (*(code **)(iVar14 + 0x6e64) != (code *)0x0) {
      (**(code **)(iVar14 + 0x6e64))(iVar14,&uStack_38,iVar14 + 0x9d7c);
    }
    puVar4 = _DAT_6000f5b8;
    uVar11 = *(uint *)(iVar14 + 0x9da8);
    if ((*_DAT_6000f5b8 < uVar11) && (*_DAT_6000f5b8 < 0xbb9)) {
      uVar17 = *(uint *)(iVar14 + 0x6e3c);
      if ((*(int *)(uVar17 + 0x44) == *(int *)(uVar17 + 0x54)) &&
         (*(int *)(uVar17 + 0x4c) == *(int *)(uVar17 + 0x5c))) {
        *_DAT_6000f5b8 = uVar11;
LAB_6000ef46:
        uStack_44 = (float)(iVar14 + 0x6e68);
        uStack_3c = *puVar5;
        uStack_40 = uVar17;
        FUN_600143ac();
        FUN_60014278(unaff_r9);
        FUN_600142a8(param_1);
        if ((*(code **)(iVar14 + 0x9d70) != (code *)0x0) &&
           (iVar9 = (**(code **)(iVar14 + 0x9d70))(iVar14 + 0x6e74,&uStack_44,param_1,unaff_r9),
           iVar9 == 0)) {
          *(undefined2 *)((int)puVar5 + 0x25) = 0x201;
          func_0x6007db44(iVar14 + 0x9dac,iVar14 + 0x9bac,0x90);
          *(undefined1 *)(iVar14 + 0x9d7c) = 3;
        }
        goto LAB_6000effa;
      }
      uStack_44 = 0.0;
      FUN_60118418(&uStack_44,uVar17 + 0x44,uVar17 + 0x4c,uVar17 + 0x54,uVar17 + 0x5c);
      uVar3 = *(ushort *)(param_1 + 200);
      if (0x168 < uVar3) {
        uVar11 = *(uint *)(iVar14 + 0x9da8);
        goto LAB_6000efb0;
      }
      uVar11 = *(uint *)(iVar14 + 0x9da8);
      *puVar4 = uVar11;
      if (0xb4 < (int)(((uint)uVar3 - (int)uStack_44) + 0x168) % 0x168 - 0x5aU) {
        uVar17 = *(uint *)(iVar14 + 0x6e3c);
        goto LAB_6000ef46;
      }
    }
    else {
LAB_6000efb0:
      *puVar4 = uVar11;
    }
    if (uVar11 < 0x1389) {
      if ((*(char *)(puVar5 + 9) == '\x01') && (*(char *)((int)puVar5 + 6) != '\x01'))
      goto LAB_6000effa;
      uVar6 = 1;
    }
    else if (uVar11 < 0x4e21) {
      if ((*(char *)(puVar5 + 9) == '\0') && (*(char *)((int)puVar5 + 6) != '\x01'))
      goto LAB_6000effa;
      uVar6 = 0;
    }
    else {
      *(undefined1 *)(iVar14 + 0x9d7c) = 1;
      uVar6 = 7;
    }
    *(undefined1 *)((int)puVar5 + 0x26) = uVar6;
  }
LAB_6000effa:
  bVar25 = *(byte *)((int)puVar5 + 0x25);
  if (bVar25 < 2) {
    uVar6 = 1;
LAB_6000f010:
    *(undefined1 *)((int)puVar5 + 5) = uVar6;
LAB_6000f014:
    FUN_60164914(uVar10);
    *(undefined1 *)((int)puVar5 + 0x25) = 3;
  }
  else if (bVar25 != 3) {
    if (bVar25 == 2) {
      uVar6 = 0;
      goto LAB_6000f010;
    }
    goto LAB_6000f014;
  }
  uVar10 = _DAT_6000f5bc;
  cVar7 = *(char *)((int)puVar5 + 0x26);
  if (cVar7 == '\x01') {
    FUN_6016708c();
    iVar9 = FUN_6015c500();
    uVar10 = _DAT_6000f5bc;
    if (iVar9 == 0xd) {
      cVar7 = *(char *)((int)puVar5 + 0x26);
      goto LAB_6000f06c;
    }
    *(undefined1 *)(puVar5 + 9) = 1;
    *(undefined1 *)((int)puVar5 + 6) = 1;
    iVar14 = iVar14 + 0x9da4;
    iVar9 = _DAT_6000f3cc;
LAB_6000f0ec:
    FUN_60163e70(iVar9,iVar14,uVar10);
    goto LAB_6000f0f0;
  }
  if (cVar7 == '\0') {
    cVar7 = *(char *)((int)puVar5 + 7);
    *(undefined1 *)(puVar5 + 9) = 0;
    *(undefined1 *)((int)puVar5 + 6) = 1;
    FUN_60163e70(_DAT_6000f3cc,iVar14 + 0x9da4,uVar10);
    if (cVar7 == '\0') {
      FUN_60161f30(0x1a);
      *(undefined1 *)((int)puVar5 + 7) = 1;
    }
    goto LAB_6000f0f0;
  }
LAB_6000f06c:
  switch(cVar7) {
  case '\x02':
    *(undefined1 *)(puVar5 + 9) = 2;
    FUN_60164fb0(_DAT_6000f3cc + 2,0,0);
    goto LAB_6000f0f0;
  case '\x03':
    *(undefined1 *)(puVar5 + 9) = 3;
    iVar14 = _DAT_6000f3cc + 3;
    break;
  case '\x04':
    *(undefined1 *)(puVar5 + 9) = 4;
    iVar14 = _DAT_6000f3cc + 4;
    break;
  case '\x05':
    *(undefined1 *)(puVar5 + 9) = 5;
    iVar14 = _DAT_6000f3cc + 5;
    break;
  case '\x06':
    uVar10 = 0;
    *(undefined1 *)(puVar5 + 2) = 1;
    *(undefined1 *)(puVar5 + 9) = 6;
    iVar14 = iVar14 + 0x9e3c;
    iVar9 = _DAT_6000f3cc + 6;
    goto LAB_6000f0ec;
  case '\a':
    *(undefined1 *)((int)puVar5 + 7) = 0;
    if (*(char *)(puVar5 + 9) == '\x01') {
      FUN_60010624();
    }
    else {
      if (*(char *)(puVar5 + 9) != '\0') goto LAB_6000f0f0;
      thunk_FUN_600e7fd0();
    }
    *(undefined1 *)(puVar5 + 9) = 7;
  default:
    goto LAB_6000f0f0;
  }
  FUN_601499c0(iVar14);
LAB_6000f0f0:
  *(undefined1 *)((int)puVar5 + 0x26) = 8;
  return 0;
}

