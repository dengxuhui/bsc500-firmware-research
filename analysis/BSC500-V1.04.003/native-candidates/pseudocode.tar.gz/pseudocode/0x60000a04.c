
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60000a04(void)

{
  int iVar1;
  int iVar2;
  
  iVar1 = _DAT_60000a48;
  iVar2 = _DAT_60000a48 + 0x10;
  *(int *)(_DAT_60000a48 + 0x10) = iVar2;
  *(int *)(iVar1 + 0x14) = iVar2;
  return;
}

