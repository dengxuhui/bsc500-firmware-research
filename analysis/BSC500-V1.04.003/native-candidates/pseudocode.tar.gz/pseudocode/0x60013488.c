
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60013488(char *param_1,int param_2)

{
  uint uVar1;
  char cVar2;
  char *pcVar3;
  float *pfVar4;
  undefined2 uVar5;
  undefined4 uVar6;
  int iVar7;
  float fVar8;
  int iVar9;
  char *pcVar10;
  undefined4 uVar11;
  undefined4 uVar12;
  uint in_fpscr;
  uint uVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  float fVar17;
  undefined8 uVar18;
  undefined8 uVar19;
  
  pcVar3 = _DAT_60013820;
  if (*_DAT_60013820 == '\x02') {
    uVar6 = 0xffffffff;
    if ((param_1 != (char *)0x0) && (param_2 != 0)) {
      pcVar10 = param_1 + 0xbc;
      iVar7 = func_0x60166dd0(pcVar10);
      if (iVar7 != 1) {
        iVar7 = func_0x60166dd0(param_1 + 0xb4);
        if (iVar7 != 1) {
          uVar6 = *(undefined4 *)(param_1 + 0xc0);
          *(undefined4 *)(param_2 + 0x354) = *(undefined4 *)pcVar10;
          *(undefined4 *)(param_2 + 0x358) = uVar6;
          uVar6 = *(undefined4 *)(param_1 + 0xb8);
          *(undefined4 *)(param_2 + 0x34c) = *(undefined4 *)(param_1 + 0xb4);
          *(undefined4 *)(param_2 + 0x350) = uVar6;
        }
      }
      *(undefined4 *)(param_2 + 0x348) = *(undefined4 *)(param_1 + 4);
      FUN_60136728(pcVar3 + 8);
      iVar7 = func_0x60166dd0(param_1 + 0xb4);
      if ((iVar7 != 1) && (iVar7 = func_0x60166dd0(pcVar10), iVar7 != 1)) {
        uVar12 = *(undefined4 *)(param_1 + 0xb4);
        uVar6 = *(undefined4 *)(param_1 + 0xb8);
        uVar11 = *(undefined4 *)(param_1 + 0xc0);
        uVar18 = FUN_6016759c(*(undefined4 *)(param_1 + 0xbc));
        uVar19 = FUN_6016759c(uVar11);
        uVar18 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                              (int)((ulonglong)uVar19 >> 0x20));
        *(undefined8 *)(pcVar3 + 8) = uVar18;
        uVar18 = FUN_6016759c(uVar12);
        uVar19 = FUN_6016759c(uVar6);
        uVar18 = FUN_601675d8((int)uVar18,(int)((ulonglong)uVar18 >> 0x20),(int)uVar19,
                              (int)((ulonglong)uVar19 >> 0x20));
        *(undefined8 *)(pcVar3 + 0x10) = uVar18;
      }
      iVar7 = _DAT_60013824;
      pcVar3[0x18] = *param_1;
      *(undefined4 *)(pcVar3 + 0x1c) = *(undefined4 *)(param_1 + 4);
      *(undefined2 *)(pcVar3 + 0x20) = *(undefined2 *)(param_1 + 0xd0);
      *(undefined2 *)(pcVar3 + 0x22) = *(undefined2 *)(param_1 + 0x1c);
      FUN_60110c8c(iVar7,pcVar3 + 8);
      pfVar4 = _DAT_60013828;
      FUN_60110c78(iVar7,_DAT_60013828);
      fVar15 = _UNK_60013830;
      fVar17 = _UNK_6001382c;
      fVar8 = pfVar4[2];
      fVar16 = pfVar4[1];
      fVar14 = *pfVar4 * _UNK_6001382c;
      *(int *)(param_2 + 0x360) = (int)fVar8 * 1000;
      uVar6 = VectorFloatToUnsigned(fVar14,3);
      *(undefined4 *)(param_2 + 0x35c) = uVar6;
      *(short *)(param_2 + 0x366) = (short)(int)(fVar16 * fVar15);
      if (*param_1 == '\x01') {
        cVar2 = param_1[0xd9];
        pcVar3[0x2d] = param_1[0x91];
        pcVar3[0x2c] = cVar2;
        *(uint *)(pcVar3 + 0x28) = (uint)((int)fVar8 * 1000) / 1000;
        FUN_60110ee0(iVar7 + 0x48,pcVar3 + 0x28);
        FUN_60110eae(iVar7 + 0x48,pfVar4 + 3);
        *(undefined2 *)(param_2 + 0x37a) = *(undefined2 *)(pfVar4 + 0xc);
        *(undefined4 *)(pcVar3 + 0x30) = *(undefined4 *)(param_2 + 0x2c8);
        FUN_601111ce(iVar7 + 0x88,pcVar3 + 0x30);
        FUN_601111c4(iVar7 + 0x88,pfVar4 + 0xd);
        fVar8 = pfVar4[0xd];
        uVar6 = *(undefined4 *)(param_2 + 0x2b4);
        uVar11 = *(undefined4 *)(param_2 + 700);
        uVar12 = *(undefined4 *)(param_2 + 0x2c0);
        *(undefined4 *)(pcVar3 + 0x38) = *(undefined4 *)(param_2 + 0x2b8);
        *(undefined4 *)(pcVar3 + 0x3c) = uVar11;
        *(undefined4 *)(pcVar3 + 0x40) = uVar12;
        *(short *)(param_2 + 0x364) = (short)(int)(fVar8 / fVar15);
        *(undefined4 *)(pcVar3 + 0x34) = uVar6;
        FUN_601112bc(iVar7 + 0x8c,pcVar3 + 0x34);
        FUN_60111298(iVar7 + 0x8c,pfVar4 + 0xe);
        fVar8 = _UNK_60013834;
        fVar16 = pfVar4[0x10];
        fVar14 = pfVar4[0xe] * _UNK_60013834;
        pcVar3[0x48] = param_1[0xd8];
        *(short *)(param_2 + 0x376) = (short)(int)fVar14;
        *(short *)(param_2 + 0x374) = (short)(int)(fVar16 * fVar8);
        *(uint *)(pcVar3 + 0x44) = *(uint *)(param_2 + 0x360) / 1000;
        FUN_60111506(iVar7 + 0xac,pcVar3 + 0x44);
        FUN_601114ca(iVar7 + 0xac,pfVar4 + 0x16);
        *(undefined2 *)(param_2 + 0x378) = *(undefined2 *)((int)pfVar4 + 0x7d);
        *(uint *)(pcVar3 + 0x4c) = *(uint *)(param_2 + 0x360) / 1000;
        *(undefined2 *)(pcVar3 + 0x50) = *(undefined2 *)(param_1 + 0xd4);
        *(undefined2 *)(pcVar3 + 0x52) = *(undefined2 *)(param_2 + 0x294);
        pcVar3[0x54] = param_1[0x92];
        FUN_60111924(iVar7 + 0xe8);
        FUN_601118e4(iVar7 + 0xe8,pfVar4 + 0x20);
        fVar8 = pfVar4[0x29];
        *(float *)(param_2 + 0x36a) = pfVar4[0x2c];
        uVar1 = in_fpscr & 0xfffffff | (uint)(fVar8 < 0.0) << 0x1f;
        uVar13 = uVar1 | (uint)NAN(fVar8) << 0x1c;
        uVar5 = (undefined2)(int)fVar8;
        if ((byte)(uVar1 >> 0x1f) != ((byte)(uVar13 >> 0x1c) & 1)) {
          uVar5 = 0xffff;
        }
        *(undefined2 *)(param_2 + 0x36e) = uVar5;
        fVar8 = _UNK_60013838;
        if (*(int *)(param_2 + 4) != -1) {
          fVar8 = (float)VectorUnsignedToFloat(*(int *)(param_2 + 4),(byte)(uVar13 >> 0x16) & 3);
          fVar8 = fVar8 / fVar15;
        }
        *(float *)(pcVar3 + 0x58) = fVar8;
        FUN_60111c16(iVar7 + 0x150,pcVar3 + 0x58);
        FUN_60111c0c(iVar7 + 0x150,pfVar4 + 0x2d);
        fVar8 = (float)VectorSignedToFloat(*(undefined4 *)(param_1 + 0xa4),
                                           (byte)(uVar13 >> 0x16) & 3);
        *(float *)(pcVar3 + 0x5c) = fVar8 / 10.0;
        *(short *)(param_2 + 0x368) = (short)(int)(pfVar4[0x2d] * fVar15);
        FUN_60111c4c(iVar7 + 0x154,pcVar3 + 0x5c);
        FUN_60111c3a(iVar7 + 0x154,pfVar4 + 0x2e);
        fVar15 = pfVar4[0x2f];
        iVar9 = *(int *)(param_1 + 0x9c);
        fVar8 = pfVar4[0x30];
        *(undefined4 *)(pcVar3 + 0x60) = *(undefined4 *)(param_1 + 4);
        *(char *)(param_2 + 0x37c) = (char)(int)fVar15;
        *(char *)(param_2 + 0x37d) = (char)(int)fVar8;
        fVar15 = (float)VectorUnsignedToFloat
                                  (*(undefined4 *)(param_2 + 0x35c),(byte)(uVar13 >> 0x16) & 3);
        *(float *)(pcVar3 + 100) = fVar15 / fVar17;
        fVar15 = _UNK_6001383c;
        if (iVar9 != 0x7fffffff) {
          fVar15 = (float)VectorSignedToFloat(iVar9,(byte)(uVar13 >> 0x16) & 3);
          fVar15 = fVar15 / fVar17;
        }
        *(float *)(pcVar3 + 0x68) = fVar15;
        FUN_601125a4(iVar7 + 0x16c,pcVar3 + 0x60);
        FUN_60112594(iVar7 + 0x16c,pfVar4 + 0x31);
        fVar17 = pfVar4[0x32];
        *(short *)(param_2 + 0x370) = (short)(int)pfVar4[0x31];
        *(short *)(param_2 + 0x372) = (short)(int)-fVar17;
      }
      uVar6 = 0;
    }
  }
  else {
    uVar6 = 0xffffffff;
  }
  return uVar6;
}

