
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006e90(int param_1,int param_2)

{
  undefined4 uVar1;
  
  uVar1 = FUN_60016ddc(param_1,param_2 + param_1,1,0,0,_DAT_60006eac);
  *_DAT_60006eb0 = uVar1;
  return;
}

