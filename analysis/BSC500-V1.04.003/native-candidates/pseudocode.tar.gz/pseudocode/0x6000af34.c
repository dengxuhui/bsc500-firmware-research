
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_6000af34(void)

{
  return *_DAT_6000af44 == '\x01';
}

