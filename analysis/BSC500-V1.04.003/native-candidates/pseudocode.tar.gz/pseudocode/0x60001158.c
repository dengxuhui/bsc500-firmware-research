
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60001158(void)

{
  char *pcVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  code *pcVar7;
  uint uVar8;
  
  iVar2 = _DAT_600012e8;
  pcVar1 = _DAT_600012e4;
  if (*_DAT_600012e4 == '\0') {
    return;
  }
  if ((*(byte *)(_DAT_600012e8 + 0x69) & 1) != 0) {
    uVar3 = FUN_60167d0c();
    (**(code **)(*(int *)(iVar2 + 0x78) + 4))(iVar2,*(undefined1 *)(iVar2 + 0x5f));
    FUN_601630cc(*(undefined1 *)(iVar2 + 0x5f));
    *(byte *)(iVar2 + 0x69) = *(byte *)(iVar2 + 0x69) & 0xfe;
    func_0x60167d14(uVar3);
  }
  uVar3 = FUN_60167d0c();
  if (*(char *)(iVar2 + 0x58) == '\0' && *(char *)(iVar2 + 0x59) == '\0') {
    iVar4 = FUN_600f3120();
    if (iVar4 == -1) {
      iVar4 = -1;
    }
    else {
      iVar5 = func_0x6016717c();
      iVar4 = iVar4 - iVar5;
    }
    uVar6 = FUN_600018e4(iVar2,iVar4);
    *(char *)(iVar2 + 0x5e) = (char)uVar6;
    if (1 < uVar6) {
      if (*(code **)(pcVar1 + 4) != (code *)0x0) {
        (**(code **)(pcVar1 + 4))(0,uVar6,*(undefined4 *)(pcVar1 + 8));
      }
      for (uVar8 = 0; uVar8 < *(byte *)(iVar2 + 0x60); uVar8 = uVar8 + 1) {
        pcVar7 = (code *)**(undefined4 **)(*(int *)(iVar2 + 100) + uVar8 * 8 + 4);
        if ((pcVar7 != (code *)0x0) &&
           (iVar4 = (*pcVar7)(*(undefined4 *)(*(int *)(iVar2 + 100) + uVar8 * 8),uVar6), iVar4 != 0)
           ) {
          FUN_600f11f0(uVar6);
          if (*(code **)(pcVar1 + 4) != (code *)0x0) {
            (**(code **)(pcVar1 + 4))(1,uVar6,*(undefined4 *)(pcVar1 + 8));
          }
          goto LAB_600011d6;
        }
      }
      if ((*(byte *)(iVar2 + 0x68) >> (uVar6 & 0xff) & 1) != 0) {
        iVar4 = FUN_600f3120();
        if (iVar4 == -1) {
          pcVar7 = *(code **)(*(int *)(iVar2 + 0x78) + 8);
          if (pcVar7 != (code *)0x0) {
            uVar8 = 0xffffffff;
            iVar4 = _DAT_600012e8;
            goto LAB_60001282;
          }
        }
        else {
          iVar5 = func_0x6016717c();
          uVar8 = iVar4 - iVar5;
          if (uVar8 < 2) {
            uVar6 = 1;
          }
          else {
            pcVar7 = *(code **)(*(int *)(iVar2 + 0x78) + 8);
            iVar4 = iVar2;
LAB_60001282:
            (*pcVar7)(iVar4,uVar8);
          }
        }
      }
      (*(code *)**(undefined4 **)(iVar2 + 0x78))(iVar2,uVar6);
      if ((*(byte *)(iVar2 + 0x68) >> (uVar6 & 0xff) & 1) != 0) {
        iVar4 = (**(code **)(*(int *)(iVar2 + 0x78) + 0x18))(iVar2);
        (**(code **)(*(int *)(iVar2 + 0x78) + 0xc))(iVar2);
        if (iVar4 != 0) {
          iVar5 = func_0x6016717c();
          FUN_60001b28(iVar5 + iVar4);
          FUN_6016367c();
        }
      }
      FUN_600f11f0(uVar6);
      if (*(code **)(pcVar1 + 4) != (code *)0x0) {
        (**(code **)(pcVar1 + 4))(1,uVar6,*(undefined4 *)(pcVar1 + 8));
      }
      func_0x60167d14(uVar3);
      if (1 < uVar6) {
        return;
      }
      goto LAB_600011dc;
    }
  }
LAB_600011d6:
  func_0x60167d14(uVar3);
LAB_600011dc:
  uVar3 = FUN_60167d0c();
  pcVar7 = *(code **)(*(int *)(iVar2 + 0x78) + 0x10);
  if (pcVar7 != (code *)0x0) {
    (*pcVar7)(_DAT_600012e8);
  }
  func_0x60167d14(uVar3);
  WaitForEvent();
  return;
}

