
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60006bf8(void)

{
  FUN_60156878(_DAT_60006c04);
  return 1;
}

