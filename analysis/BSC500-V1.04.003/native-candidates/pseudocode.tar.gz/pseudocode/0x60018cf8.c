
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60018cf8(float param_1)

{
  char cVar1;
  
  if (0.0 <= param_1) {
    if (_UNK_60018d98 <= param_1) {
      cVar1 = '\x04';
      goto LAB_60018d94;
    }
    if (_UNK_60018d9c <= param_1) {
      cVar1 = '\x03';
      goto LAB_60018d94;
    }
    if (_UNK_60018da0 <= param_1) {
      cVar1 = '\x02';
      goto LAB_60018d94;
    }
    if (30.0 <= param_1) {
      cVar1 = '\x01';
      goto LAB_60018d94;
    }
  }
  else {
    if (param_1 <= _UNK_60018da4) {
      cVar1 = -4;
      goto LAB_60018d94;
    }
    if (param_1 <= _UNK_60018da8) {
      cVar1 = -3;
      goto LAB_60018d94;
    }
    if (param_1 <= _UNK_60018dac) {
      cVar1 = -2;
      goto LAB_60018d94;
    }
    if (param_1 <= -30.0) {
      cVar1 = -1;
      goto LAB_60018d94;
    }
  }
  cVar1 = '\0';
LAB_60018d94:
  return (int)cVar1;
}

