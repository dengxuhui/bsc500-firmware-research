
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600180ac(void)

{
  int *piVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 *puVar4;
  int iVar5;
  int iVar6;
  
  puVar4 = _DAT_6001817c;
  uVar2 = _DAT_6001811c;
  _DAT_6001817c[0xc] = 10;
  puVar4[9] = 0x14;
  *puVar4 = 0;
  puVar4[1] = 0;
  puVar4[8] = uVar2;
  FUN_6013a634(puVar4 + 8);
  iVar3 = _DAT_60018124;
  iVar5 = _DAT_60018120;
  puVar4[2] = uVar2;
  puVar4[3] = 0x14;
  for (iVar6 = 0; iVar6 != 0x20; iVar6 = iVar6 + 0x10) {
    *(int *)(iVar3 + iVar6) = iVar5;
    iVar5 = iVar5 + 0x460;
    *(undefined4 *)(iVar3 + iVar6 + 0xc) = 0x14;
  }
  puVar4[0x13] = 0;
  puVar4[0xf] = puVar4;
  puVar4[0x10] = 2;
  piVar1 = puVar4 + 0xe;
  *piVar1 = iVar3;
  FUN_6013a62c(piVar1);
  puVar4[0x14] = piVar1;
  uVar2 = _DAT_60018128;
  puVar4[0x19] = 0x14;
  puVar4[0x15] = puVar4 + 2;
  puVar4[0x16] = uVar2;
  puVar4[4] = piVar1;
  puVar4[5] = puVar4 + 2;
  FUN_6013a620(puVar4 + 0x14);
  puVar4[6] = uVar2;
  puVar4[7] = 0;
  return;
}

