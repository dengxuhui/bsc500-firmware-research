
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60006c90(void)

{
  int iVar1;
  undefined1 auStack_38 [48];
  
  iVar1 = FUN_60162384(auStack_38,_DAT_60006ce0);
  if (iVar1 == 0) {
    FUN_6016238c(auStack_38);
  }
  else {
    FUN_60137572(_DAT_60006ce0);
  }
  FUN_60017770(0);
  iVar1 = FUN_60162384(auStack_38,_DAT_60006ce4);
  if (iVar1 == 0) {
    FUN_6016238c(auStack_38);
  }
  else {
    FUN_60137572(_DAT_60006ce4);
  }
  FUN_60019458();
  FUN_60018550();
  FUN_60163734(_DAT_60006ce8);
  return 0;
}

