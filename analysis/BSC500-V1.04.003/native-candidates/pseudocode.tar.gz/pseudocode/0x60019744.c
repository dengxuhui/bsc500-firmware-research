
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60019744(int param_1,int param_2,undefined4 *param_3,undefined4 *param_4)

{
  bool bVar1;
  undefined1 uVar2;
  char cVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  bool bVar10;
  bool bVar11;
  undefined4 *puStack_84;
  uint uStack_78;
  uint uStack_74;
  uint uStack_6c;
  undefined4 uStack_68;
  undefined4 auStack_64 [4];
  undefined4 uStack_54;
  undefined4 uStack_50;
  uint uStack_4c;
  undefined4 uStack_38;
  byte bStack_25;
  
  uVar4 = 0xffffffff;
  if ((((param_1 != 0) && (param_2 != 0)) && (param_3 != (undefined4 *)0x0)) &&
     (param_4 != (undefined4 *)0x0)) {
    if ((((*(char *)(param_3 + 1) == '\0') || (*(char *)(param_4 + 0x1d) == '\0')) ||
        ((param_3[2] != *(int *)(param_1 + 0x74) ||
         ((param_3[2] != param_4[0x1e] || (iVar5 = FUN_60163c98(*param_3,0x18), iVar5 != 0)))))) ||
       (iVar5 = FUN_60163c98(*param_4,0), iVar5 != 0)) {
LAB_6001978e:
      uVar4 = 0xffffffff;
    }
    else {
      bStack_25 = 0xff;
      ZeroBytes(auStack_64,0x3c);
      uStack_6c = 0;
      uStack_68 = 0;
      if ((*(char *)(param_2 + 6) == '\x01') || (*(char *)(param_2 + 5) == '\x01')) {
        iVar5 = 0x18;
        cVar3 = '\0';
        bVar1 = false;
        bVar10 = false;
        uStack_74 = 0;
        uStack_78 = 0;
LAB_600197d4:
        do {
          bVar11 = false;
          while( true ) {
            if (bVar11) {
              if (cVar3 == '\0') goto LAB_60019b1a;
              iVar5 = FUN_60163c98(*param_3,0x18);
              if (iVar5 != 0) goto LAB_6001978e;
              bVar10 = true;
              iVar5 = 0x18;
              goto LAB_60019a60;
            }
            iVar6 = FUN_60161ef4(*param_3,&bStack_25,1,&uStack_6c);
            if (iVar6 != 0) {
              return 0xffffffff;
            }
            if (uStack_6c != 1) {
              return 0xffffffff;
            }
            if (0xf < bStack_25) goto LAB_6001978e;
            uVar9 = (uint)*(byte *)(_DAT_60019b20 + (uint)bStack_25);
            iVar6 = FUN_60161ef4(*param_3,auStack_64,uVar9,&uStack_6c);
            if (iVar6 != 0) {
              return 0xffffffff;
            }
            if (uStack_6c != uVar9) {
              return 0xffffffff;
            }
            iVar6 = iVar5 + 1;
            iVar5 = iVar6 + uVar9;
            if (bStack_25 == 0xe) break;
            bVar11 = false;
            if (bStack_25 == 0xf) {
              iVar7 = FUN_60161ef4(*param_4,&uStack_68,4,&uStack_6c);
              if (iVar7 != 0) {
                return 0xffffffff;
              }
              if (uStack_6c != 4) {
                return 0xffffffff;
              }
              if (*(char *)(param_2 + 6) == '\x01') {
                iVar7 = 0x24;
                if (*(char *)(param_2 + 2) == '\0') {
                  iVar7 = 0x28;
                }
                *(undefined4 *)((int)auStack_64 + iVar7) = uStack_68;
              }
              if (*(char *)(param_2 + 5) == '\x01') {
                uStack_38 = uStack_68;
              }
              iVar6 = FUN_60163c98(*param_3,iVar6);
              if (iVar6 != 0) goto LAB_6001978e;
              iVar6 = FUN_60164ed8(*param_3,auStack_64,uVar9,&uStack_6c);
              if (iVar6 != 0) {
                return 0xffffffff;
              }
              if (uStack_6c != uVar9) {
                return 0xffffffff;
              }
              iVar6 = FUN_60163c98(*param_3,iVar5);
              if (iVar6 != 0) goto LAB_6001978e;
              uStack_78 = uStack_78 + 1;
              bVar11 = *(uint *)(param_1 + 0x74) <= uStack_78;
            }
          }
          uStack_74 = uStack_74 + 1;
          uVar8 = uStack_74 & 0xff;
          if (*(byte *)(param_1 + 0x80) < uVar8) {
            if ((bVar10) || (*(char *)(param_2 + 4) != '\x01')) {
              if ((bVar1) || (*(char *)(param_2 + 3) != '\x01')) goto LAB_600197d4;
              iVar7 = param_1 + uVar8 * 0x20;
              puStack_84 = (undefined4 *)(iVar7 + 100);
              ZeroBytes(puStack_84,0x15);
              *(undefined2 *)(iVar7 + 100) = 0x5250;
              *(undefined1 *)(iVar7 + 0x80) = 7;
              *(undefined4 *)(iVar7 + 0x7c) = *(undefined4 *)(param_2 + 8);
              bVar1 = true;
            }
            else {
              iVar7 = param_1 + uVar8 * 0x20;
              *(undefined4 *)(iVar7 + 0x7c) = *(undefined4 *)(param_2 + 8);
              puStack_84 = (undefined4 *)(iVar7 + 100);
              ZeroBytes(puStack_84,0x15);
              bVar10 = *(char *)(param_2 + 2) == '\0';
              uVar2 = 5;
              *(undefined2 *)(iVar7 + 0x65) = 0x4d4f;
              if (bVar10) {
                uVar2 = 6;
              }
              *(undefined1 *)(iVar7 + 0x80) = uVar2;
              uVar2 = 0x4b;
              if (bVar10) {
                uVar2 = 0x51;
              }
              *(undefined1 *)(iVar7 + 100) = uVar2;
              bVar10 = true;
            }
            auStack_64[0] = *puStack_84;
            auStack_64[1] = puStack_84[1];
            auStack_64[2] = puStack_84[2];
            auStack_64[3] = puStack_84[3];
            uStack_54 = puStack_84[4];
            uStack_50 = puStack_84[6];
            uStack_4c = (uint)*(byte *)(puStack_84 + 7);
            iVar6 = FUN_60163c98(*param_3,iVar6);
            if (iVar6 != 0) goto LAB_6001978e;
            iVar6 = FUN_60164ed8(*param_3,auStack_64,uVar9,&uStack_6c);
            if (iVar6 != 0) {
              return 0xffffffff;
            }
            if (uStack_6c != uVar9) {
              return 0xffffffff;
            }
            iVar6 = FUN_60163c98(*param_3,iVar5);
            cVar3 = cVar3 + '\x01';
          }
          else {
            if (*(char *)(param_2 + 6) == '\x01') {
              uVar8 = 5;
              if (*(char *)(param_2 + 2) == '\0') {
                uVar8 = 6;
              }
              bVar11 = uStack_4c == uVar8;
            }
            else {
              bVar11 = false;
            }
            if ((!bVar11) && (uStack_4c != 7 || *(char *)(param_2 + 5) != '\x01'))
            goto LAB_600197d4;
            uStack_50 = *(undefined4 *)(param_2 + 8);
            iVar6 = FUN_60163c98(*param_3,iVar6);
            if (iVar6 != 0) goto LAB_6001978e;
            iVar6 = FUN_60164ed8(*param_3,auStack_64,uVar9,&uStack_6c);
            if (iVar6 != 0) {
              return 0xffffffff;
            }
            if (uStack_6c != uVar9) {
              return 0xffffffff;
            }
            iVar6 = FUN_60163c98(*param_3,iVar5);
          }
          uVar4 = 0xffffffff;
        } while (iVar6 == 0);
      }
      else {
LAB_60019b1a:
        uVar4 = 0;
      }
    }
  }
  return uVar4;
LAB_60019a60:
  if (!bVar10) {
    *(char *)(param_1 + 0x80) = *(char *)(param_1 + 0x80) + cVar3;
    goto LAB_60019b1a;
  }
  iVar6 = FUN_60161ef4(*param_3,&bStack_25,1,&uStack_6c);
  if (iVar6 != 0) {
    return 0xffffffff;
  }
  if (uStack_6c != 1) {
    return 0xffffffff;
  }
  if (0xf < bStack_25) goto LAB_6001978e;
  uVar9 = (uint)*(byte *)(_DAT_60019b20 + (uint)bStack_25);
  iVar6 = FUN_60161ef4(*param_3,auStack_64,uVar9,&uStack_6c);
  if (iVar6 != 0) {
    return 0xffffffff;
  }
  if (uStack_6c != uVar9) {
    return 0xffffffff;
  }
  iVar6 = iVar5 + 1;
  bVar10 = true;
  iVar5 = iVar6 + uVar9;
  if (bStack_25 == 0xd) {
    iVar6 = FUN_60163c98(*param_3,iVar6);
    if (iVar6 != 0) goto LAB_6001978e;
    auStack_64[0] = CONCAT31(auStack_64[0]._1_3_,*(char *)(param_1 + 0x80) + cVar3);
    iVar6 = FUN_60164ed8(*param_3,auStack_64,uVar9,&uStack_6c);
    if (iVar6 != 0) {
      return 0xffffffff;
    }
    if (uStack_6c != uVar9) {
      return 0xffffffff;
    }
    iVar6 = FUN_60163c98(*param_3,iVar5);
    bVar10 = false;
    if (iVar6 != 0) {
      return 0xffffffff;
    }
  }
  goto LAB_60019a60;
}

