
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_600193c8(int param_1)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int extraout_r3;
  int unaff_r5;
  undefined1 unaff_r7;
  int *piVar5;
  undefined1 auStack_b8 [12];
  uint uStack_ac;
  undefined1 auStack_a8 [63];
  undefined1 uStack_69;
  undefined1 auStack_68 [64];
  int iStack_28;
  int iStack_24;
  
  piVar1 = piRam6001942c;
  if (*piRam6001942c != 0) {
    FUN_60166b98();
  }
  iVar2 = FUN_60164eb0(1);
  if (iVar2 != 0) {
    piVar5 = (int *)(iVar2 + 4);
    do {
      piVar5 = (int *)*piVar5;
      if (piVar5 == (int *)(iVar2 + 4)) {
        if (*piVar1 != 0) {
          func_0x60166b64();
        }
        return 0;
      }
      iVar3 = FUN_601343dc(piVar5 + -5,param_1,0x10);
    } while (iVar3 != 0);
    if (*piVar1 != 0) {
      func_0x60166b64();
    }
    return (int)(piVar5 + -5);
  }
  FUN_6016804c(0x60019430,0x60019448,0x30c);
  iVar3 = *(int *)(param_1 + 0x74);
  uVar4 = *(undefined4 *)(iVar3 + 0x54);
  *(char *)(param_1 + 0x11) = (char)*(undefined4 *)(unaff_r5 + 100);
  iVar2 = *(int *)(unaff_r5 + 0x74);
  iStack_24 = unaff_r5 + -0x21;
  *(undefined2 *)(param_1 + 0x6e) = 0x6e;
  *(char *)(iVar2 + iStack_24) = (char)iVar3;
  iVar2 = iRam60019578;
  *(char *)(iVar3 + 0x11) = (char)uVar4;
  *(undefined1 *)(extraout_r3 + 0x11) = unaff_r7;
  *(undefined1 *)(unaff_r5 + -0x18) = 0x6e;
  *(int *)(iVar2 + 0x14) = iStack_24;
  iStack_28 = (int)*(short *)(iVar2 + iStack_24);
  *(undefined4 *)(unaff_r5 + 0x23) = *(undefined4 *)(iStack_28 + 0x14);
  iVar2 = _DAT_60019554;
  func_0x601608ac(_DAT_60019554,0x3bc);
  func_0x60129756(iVar2 + 4,0x3b8);
  uStack_ac = 0;
  func_0x601681f4(auStack_68,_DAT_60019558,_DAT_6001955c,_DAT_60019560);
  iVar2 = FUN_601609d0(auStack_b8,auStack_68,2);
  if (iVar2 == 0) {
    FUN_60160948(auStack_b8,0,0);
    FUN_6015c2f4(auStack_b8,auStack_a8,0x40,&uStack_ac);
    FUN_60160a64(auStack_b8);
    if (6 < uStack_ac) {
      uStack_69 = 0;
      iVar2 = FUN_6016228c(auStack_a8,0x3d);
      if ((iVar2 != 0) && (iVar2 = FUN_6016811c(iVar2 + 1), iVar2 == 0x6e)) {
        func_0x601681f4(auStack_68,_DAT_60019558,_DAT_6001955c,_DAT_60019560);
        iVar2 = FUN_601609d0(auStack_b8,auStack_68,2);
        if (iVar2 != 0) {
          return iVar2;
        }
        FUN_60160948(auStack_b8,0,0);
        FUN_6015c2f4(auStack_b8,_DAT_60019554,0x3bc,&uStack_ac);
        goto LAB_6001954a;
      }
    }
  }
  for (iVar2 = 4; iVar2 != 0; iVar2 = iVar2 + -1) {
    FUN_6013f78c();
  }
  iVar2 = FUN_601609d0(auStack_b8,auStack_68,1);
  if (iVar2 != 0) {
    return iVar2;
  }
  func_0x601681f4(auStack_a8,_DAT_60019564,0x6e);
  FUN_60160948(auStack_b8,0,0);
  iVar2 = FUN_60168220(auStack_a8);
  FUN_60160774(auStack_b8,auStack_a8,iVar2 + 1,&uStack_ac);
LAB_6001954a:
  iVar2 = FUN_60160a64(auStack_b8);
  return iVar2;
}

