
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6001896c(void)

{
  char *pcVar1;
  char *pcVar2;
  bool bVar3;
  int iVar4;
  undefined4 *puVar5;
  char *pcVar6;
  int iVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  byte bVar10;
  uint uVar11;
  int iVar12;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  
  pcVar6 = _DAT_60018a90;
  if (*_DAT_60018a90 != '\0') {
    iVar7 = FUN_6012d7c0();
    puVar5 = _DAT_60018a6c;
    iVar4 = _DAT_60018a68;
    iVar12 = 0;
    if ((iVar7 != 0) && (**(char **)(_DAT_60018a68 + 4) != '\0')) {
      iVar12 = *(int *)(*(char **)(_DAT_60018a68 + 4) + 4) - iVar7;
    }
    if (pcVar6[0x18] != '\x02') {
      iVar7 = FUN_6001d7e0(_DAT_60018a8c,_DAT_60018a6c,0x1e,_DAT_60018a6c + 4);
      if (iVar7 < 0) {
        *pcVar6 = '\x03';
        return;
      }
      if (pcVar6[0x18] == '\0') {
        *(undefined4 *)(pcVar6 + 0x14) = *puVar5;
      }
      pcVar6[0x18] = '\x02';
    }
    puVar5 = _DAT_60018a6c;
    iVar7 = *(int *)(pcVar6 + 0x14);
    bVar10 = 0;
    do {
      uVar11 = (uint)bVar10;
      if ((uint)_DAT_60018a6c[4] <= uVar11) {
        bVar3 = false;
        goto LAB_60018a2e;
      }
      bVar10 = bVar10 + 1;
    } while (iVar12 != _DAT_60018a6c[uVar11 * 5] - iVar7);
    uVar9 = _DAT_60018a6c[uVar11 * 5 + 1];
    uVar8 = _DAT_60018a6c[uVar11 * 5 + 3];
    pcVar1 = pcVar6 + 8;
    *(undefined4 *)pcVar1 = _DAT_60018a6c[uVar11 * 5 + 2];
    *(undefined4 *)(pcVar6 + 0x10) = uVar8;
    uStack_24 = _DAT_60018a70;
    pcVar2 = pcVar6 + 0xc;
    *(undefined4 *)pcVar2 = uVar9;
    uStack_30 = 0;
    uStack_2c = uStack_24;
    uStack_28 = 0;
    FUN_6013823c(pcVar2,pcVar1,&uStack_30,&uStack_28);
    *(undefined4 *)pcVar2 = uStack_30;
    *(undefined4 *)pcVar1 = uStack_28;
    iVar7 = *(int *)(pcVar6 + 0x14);
    bVar3 = pcVar6[0x18] == '\x01';
LAB_60018a2e:
    if (iVar12 == puVar5[0x91] - iVar7 && !bVar3) {
      pcVar6[0x18] = '\x01';
    }
    *(int *)(pcVar6 + 0x1c) =
         (*(int *)(*(int *)(iVar4 + 8) + 0x1b4) - *(int *)(pcVar6 + 0x10)) / 100;
  }
  return;
}

