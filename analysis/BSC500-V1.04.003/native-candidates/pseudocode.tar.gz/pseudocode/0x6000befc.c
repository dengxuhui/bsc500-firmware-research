
undefined8 FUN_6000befc(undefined4 param_1)

{
  int iVar1;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  
  uStack_14 = 0;
  uStack_1c = 0;
  uStack_18 = 0;
  do {
    iVar1 = FUN_6013388a(param_1,&uStack_1c,0,0);
  } while (iVar1 == 0);
  return CONCAT44(uStack_1c,param_1);
}

