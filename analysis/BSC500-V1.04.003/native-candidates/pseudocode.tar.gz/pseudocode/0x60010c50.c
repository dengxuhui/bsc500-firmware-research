
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60010c50(void)

{
  FUN_6001b918();
  FUN_60155a8c(_DAT_60010c5c);
  return _UNK_60010c60;
}

