
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006e14(void)

{
  int *piVar1;
  
  piVar1 = (int *)FUN_60010bac();
  piVar1[0x1a] = 0;
  piVar1[0x1b] = 0;
  *piVar1 = _DAT_60006e28 + 8;
  return;
}

