
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001021c(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = _DAT_60010240;
  for (iVar2 = 0; iVar2 != 0x30; iVar2 = iVar2 + 0xc) {
    iVar3 = iVar1 + iVar2;
    FUN_6001b060(*(undefined4 *)(iVar3 + 8));
    FUN_6001ae90(*(undefined4 *)(iVar3 + 4),*(undefined4 *)(iVar1 + iVar2));
  }
  return 1;
}

