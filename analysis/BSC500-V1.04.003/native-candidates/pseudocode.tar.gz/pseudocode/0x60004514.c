
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60004514(void)

{
  short sVar1;
  bool bVar2;
  undefined2 *puVar3;
  code *pcVar4;
  code *pcVar5;
  undefined1 uVar6;
  undefined2 uVar7;
  int iVar8;
  undefined2 *puVar9;
  undefined1 *puVar10;
  undefined4 uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  byte *extraout_r2;
  undefined4 uVar15;
  undefined4 extraout_r2_00;
  undefined4 extraout_r3;
  uint unaff_r4;
  uint uVar16;
  int iVar17;
  byte *pbVar18;
  int unaff_r7;
  int unaff_r9;
  undefined8 uVar19;
  undefined1 uStack_e9;
  int iStack_e8;
  undefined1 auStack_e4 [8];
  undefined4 uStack_dc;
  undefined4 uStack_d8;
  undefined4 uStack_d4;
  undefined4 uStack_d0;
  undefined2 uStack_cc;
  undefined1 auStack_c8 [6];
  undefined2 uStack_c2;
  undefined1 auStack_c0 [32];
  uint uStack_a0;
  undefined4 uStack_9c;
  uint uStack_98;
  undefined4 uStack_94;
  undefined4 uStack_90;
  undefined2 uStack_7c;
  undefined2 *puStack_70;
  undefined1 *puStack_60;
  undefined2 *puStack_50;
  undefined1 *puStack_34;
  undefined4 uStack_14;
  
  iVar8 = FUN_6000a87c();
  *puRam60004540 = (char)iVar8;
  if (iVar8 != 0) {
    FUN_6000a8f8(iVar8,0x60004544,uRam60004548,0);
    return 0;
  }
  FUN_6016804c(0x6000454c,0x6000457c,0x19a);
  bVar2 = ((uint)extraout_r2 & 0x80000000) != 0;
  uRam00000004 = 4;
  uVar16 = unaff_r4 + 4 + (uint)bVar2;
  sVar1 = *(short *)(*extraout_r2 + 4);
  pbVar18 = extraout_r2 +
            unaff_r9 +
            (uint)(CARRY4(uVar16,(uint)extraout_r2) ||
                  CARRY4((uint)(extraout_r2 + uVar16),
                         (uint)(0xfffffffb < unaff_r4 || CARRY4(unaff_r4 + 4,(uint)bVar2)))) +
            iRam60004680;
  iVar8 = *(int *)(sVar1 + 100);
  *(byte **)((int)extraout_r2 * 2 * unaff_r7 + 0x10) = pbVar18;
  *(char *)(iVar8 + 0xd) = (char)iVar8;
  iVar8 = *(int *)(sVar1 + 0x44);
  uVar15 = *(undefined4 *)(iVar8 + 0x44);
  iVar17 = (int)*(short *)(iVar8 * 3);
  uVar11 = *(undefined4 *)(iVar8 + 0x54);
  *(int *)(pbVar18 + 0x54) = (int)*(short *)(pbVar18 + iVar17);
  pbVar18[0x19] = (byte)uVar15;
  *(undefined4 *)(iVar17 + 0x34) = uVar11;
  *(char *)(*(short *)(iVar8 + iVar17) + 0x11) =
       (char)*(undefined4 *)(*(short *)(iVar8 + iVar17) + 100);
  uVar11 = FUN_6012a4e4(&UNK_60004878,8,0);
  puVar3 = _DAT_6000487c;
  *(undefined4 *)(_DAT_6000487c + 0x32) = uVar11;
  FUN_6000f8e0();
  uVar12 = _DAT_60004884 + 8;
  uVar13 = _DAT_60004884 + 0x18;
  uVar14 = _DAT_60004884 + 0x28;
  uVar16 = _DAT_60004884 + 0x38;
  do {
    do {
      FUN_6015f0f0(*(undefined4 *)(puVar3 + 0x32),&iStack_e8,0xffffffff);
    } while (iStack_e8 != 0);
    *(undefined1 *)puVar3 = 1;
    uStack_94 = CONCAT31(uStack_94._1_3_,0x40);
    uStack_98 = 6;
    uStack_e9 = 0x10;
    uStack_9c = _DAT_60004880;
    uStack_a0 = uVar12;
    iVar8 = FUN_600f3608(&uStack_a0);
    *(int *)(puVar3 + 0x10) = iVar8;
    if (iVar8 != 0) {
      FUN_600f3600(iVar8,_DAT_60004888,_DAT_6000488c);
    }
    uStack_94 = CONCAT31(uStack_94._1_3_,0x40);
    uStack_98 = 6;
    uStack_9c = _DAT_60004890;
    uStack_a0 = uVar13;
    iVar8 = FUN_600f3608(&uStack_a0);
    *(int *)(puVar3 + 0x16) = iVar8;
    if (iVar8 != 0) {
      FUN_600f3600(iVar8,_DAT_60004894,_DAT_60004898);
    }
    uStack_94 = CONCAT31(uStack_94._1_3_,0x40);
    uStack_98 = 6;
    uStack_9c = _DAT_6000489c;
    uStack_a0 = uVar14;
    iVar8 = FUN_600f3608(&uStack_a0);
    *(int *)(puVar3 + 0x1c) = iVar8;
    if (iVar8 != 0) {
      FUN_600f3600(iVar8,_DAT_600048a0,_DAT_600048a4);
    }
    uStack_94 = CONCAT31(uStack_94._1_3_,0x40);
    uStack_98 = 6;
    uStack_9c = _DAT_600048a8;
    uStack_a0 = uVar16;
    iVar8 = FUN_600f3608(&uStack_a0);
    *(int *)(puVar3 + 0x22) = iVar8;
    if (iVar8 != 0) {
      FUN_600f3600(iVar8,_DAT_600048ac,_DAT_600048b0);
    }
    uStack_98 = 6;
    uStack_94 = CONCAT31(uStack_94._1_3_,0x41);
    uStack_9c = _DAT_600048b4;
    uStack_a0 = _DAT_60004884 + 0x48;
    iVar8 = FUN_600f3608(&uStack_a0);
    *(int *)(puVar3 + 0x28) = iVar8;
    if (iVar8 != 0) {
      FUN_600f3600(iVar8,_DAT_600048b8,_DAT_600048bc);
    }
    uVar11 = FUN_60163ab8();
    FUN_6013fdb8(uVar11,2,&uStack_e9);
    FUN_60165070(200);
    puVar9 = puVar3;
    for (iVar8 = 0; puVar9 = puVar9 + 6, iVar8 != 2; iVar8 = iVar8 + 1) {
      *puVar9 = 0xf3;
      FUN_600090a8(*(undefined1 *)((int)puVar3 + iVar8 + 1),0x18,0xc,400);
    }
    FUN_6000a740(1);
    FUN_6000a6e8(1);
    FUN_6000a720(9);
    FUN_6000a750(5);
    pcVar4 = _DAT_600048f0;
    (*_DAT_600048f0)(&UNK_600048c0);
    ZeroBytes(&uStack_a0,0x90);
    ZeroBytes(auStack_c0,0x1f);
    uStack_c2 = 0x481;
    uStack_cc = 0;
    uStack_d0 = 0;
    uStack_d8 = 0;
    uStack_d4 = 0;
    FUN_6015978c(auStack_c8);
    FUN_60162c3a(auStack_c0,0xc,_DAT_600048f4);
    FUN_60132294(&uStack_d0,6);
    (*pcVar4)(&UNK_600048f8);
    (*pcVar4)(&UNK_6000490c,uStack_cc._1_1_,(undefined1)uStack_cc,uStack_d0._3_1_,
              uStack_d0 >> 0x10 & 0xff,uStack_d0 >> 8 & 0xff,uStack_d0 & 0xff);
    iVar8 = FUN_60168220(auStack_c0);
    pcVar4 = _DAT_6000492c;
    puVar9 = (undefined2 *)(*_DAT_6000492c)(iVar8 + 2);
    uVar7 = FUN_60168220(auStack_c0);
    *puVar9 = uVar7;
    CopyBytes(puVar9 + 1,auStack_c0,uVar7);
    FUN_600093dc(puVar9);
    (*_DAT_60004930)(puVar9);
    uStack_7c = 0x7f;
    uStack_94 = 0;
    uStack_90 = 0x30;
    uStack_98 = uStack_98 & 0xffffff00;
    uStack_a0 = uStack_a0 & 0xffffff00;
    iVar8 = FUN_601626c0(auStack_c0);
    puVar10 = (undefined1 *)(*pcVar4)(iVar8 + 1);
    puStack_34 = puVar10;
    uVar6 = FUN_601626c0(auStack_c0);
    *puVar10 = uVar6;
    pcVar5 = _DAT_60004934;
    (*_DAT_60004934)(puStack_34 + 1,auStack_c0,*puStack_34);
    uVar19 = FUN_6013a600();
    FUN_60162a88((int)uVar19,(int)((ulonglong)uVar19 >> 0x20),_DAT_60004938,0);
    iVar8 = _DAT_6000493c;
    *(undefined4 *)(_DAT_6000493c + 0x10) = extraout_r2_00;
    *(undefined4 *)(iVar8 + 0x14) = extraout_r3;
    FUN_6005239a(extraout_r2_00,extraout_r3,&uStack_d8);
    FUN_60052334(&uStack_d8,8);
    (*pcVar5)(auStack_e4,&uStack_d8,8);
    uStack_dc = 0x43ff;
    puStack_50 = (undefined2 *)(*pcVar4)(0x10);
    *(undefined1 *)(puStack_50 + 1) = 0xc;
    *puStack_50 = 0x73;
    (*pcVar5)((int)puStack_50 + 3,auStack_e4,0xc);
    puStack_60 = (undefined1 *)(*pcVar4)(0x12);
    *puStack_60 = 1;
    puStack_60[2] = 10;
    puStack_60[1] = 2;
    puStack_60[3] = 0x18;
    puStack_70 = &uStack_c2;
    uStack_14 = _DAT_60004940;
    FUN_6000f764(*(undefined4 *)(_DAT_60004884 + 4),&uStack_a0);
    pcVar4 = _DAT_60004930;
    (*_DAT_60004930)(puStack_34);
    (*pcVar4)(puStack_50);
    (*pcVar4)(puStack_60);
    if (*(char *)((int)puVar3 + 5) == '\0') {
      FUN_60159708();
    }
    func_0x60168578(&UNK_60004944);
    FUN_60007770();
  } while( true );
}

