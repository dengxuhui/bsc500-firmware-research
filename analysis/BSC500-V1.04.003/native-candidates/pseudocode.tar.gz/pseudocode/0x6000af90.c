
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_6000af90(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  
  FUN_6016708c();
  uVar2 = FUN_6015c500();
  iVar1 = _DAT_6000afd4;
  if (uVar2 == 0xb) {
    return true;
  }
  iVar4 = *(int *)(_DAT_6000afd4 + 0xb40);
  iVar3 = FUN_60016840();
  if ((iVar3 == 0) && ((int)((uint)*(byte *)(iVar1 + 0xb40) << 0x1b) < 0)) {
    if (iVar4 << 0x1a < 0) {
      return uVar2 < 5;
    }
    return uVar2 != 5;
  }
  return false;
}

