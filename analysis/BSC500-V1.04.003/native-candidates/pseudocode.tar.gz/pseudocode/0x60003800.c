
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 * FUN_60003800(uint *param_1,uint param_2,undefined4 param_3,undefined4 param_4)

{
  byte bVar1;
  undefined1 *puVar2;
  ushort uVar3;
  uint uVar4;
  uint *puVar5;
  undefined4 *puVar6;
  undefined4 uVar7;
  uint extraout_r1;
  uint uVar8;
  undefined4 uVar9;
  uint extraout_r2;
  uint uVar10;
  uint extraout_r3;
  uint *unaff_r4;
  uint *unaff_r5;
  uint *puVar11;
  uint unaff_r6;
  uint *unaff_r7;
  ushort uVar12;
  bool bVar13;
  
  puVar5 = unaff_r5;
  if (param_1 == (uint *)0x0) {
    FUN_6016804c(uRam60003a08,uRam600039e8,0x244,param_4,param_4);
LAB_600039a8:
    FUN_6016804c(uRam600039e4,uRam600039e8,0x263);
    puVar5 = unaff_r5;
LAB_600039b4:
    FUN_6016804c(0x600039f4,uRam600039e8,0x2a5);
    param_1 = unaff_r4;
LAB_600039c0:
    FUN_6016804c(uRam600039f0,uRam600039e8,0x2b4);
    puVar11 = puVar5;
  }
  else {
    uVar4 = param_2 & 0x200;
    if (((((uVar4 != 0) && (-1 < (int)((uint)*(ushort *)((int)param_1 + 0x1e) << 0x16))) ||
         ((unaff_r7 = (uint *)(param_2 & 0x800), unaff_r7 != (uint *)0x0 &&
          (-1 < (int)((uint)*(ushort *)((int)param_1 + 0x1e) << 0x14))))) ||
        ((uVar8 = param_2 & 0x100, uVar8 != 0 &&
         (-1 < (int)((uint)*(ushort *)((int)param_1 + 0x1e) << 0x17))))) ||
       ((unaff_r6 = param_2 & 0x400, unaff_r6 != 0 &&
        (-1 < (int)((uint)*(ushort *)((int)param_1 + 0x1e) << 0x15))))) {
      return (undefined1 *)0xfffffff8;
    }
    uVar10 = param_2 << 0x19;
    bVar13 = -1 < (int)uVar10;
    if (bVar13) {
      uVar10 = (uint)(ushort)param_1[8];
    }
    if (bVar13 && -1 < (int)(uVar10 << 0x19)) {
      uVar12 = 0;
    }
    else {
      uVar12 = 0x40;
    }
    uVar3 = (ushort)param_2 & 0xff;
    *(ushort *)(param_1 + 8) = uVar3;
    unaff_r4 = param_1;
    if (param_1[0x19] != 0) {
      if (uVar8 == 0) {
        if (uVar4 == 0) goto LAB_6000391a;
        uVar3 = uVar3 + 0x200;
      }
      else {
        uVar3 = uVar3 + 0x100;
      }
LAB_60003918:
      *(ushort *)(param_1 + 8) = uVar3;
LAB_6000391a:
      if (param_1[0x1a] != 0) {
        if (unaff_r6 == 0) {
          if (unaff_r7 == (uint *)0x0) goto LAB_6000398e;
          uVar3 = (ushort)param_1[8] | 0x800;
        }
        else {
          uVar3 = (ushort)param_1[8] | 0x400;
        }
        *(ushort *)(param_1 + 8) = uVar3;
        goto LAB_6000398e;
      }
      if (unaff_r6 == 0) {
        if (unaff_r7 == (uint *)0x0) {
          param_1[0x1a] = 0;
          goto LAB_6000398e;
        }
        puVar6 = (undefined4 *)FUN_60162e34(0x28);
        if (puVar6 == (undefined4 *)0x0) goto LAB_600039c0;
        *puVar6 = 0;
        FUN_60155e1c(puVar6 + 1,8,4,0);
        uVar7 = 3;
        uVar9 = 0x800;
        param_1[0x1a] = (uint)puVar6;
        uVar3 = (ushort)param_1[8] | 0x800;
      }
      else {
        uVar4 = FUN_60162e34(0xc);
        if (uVar4 == 0) goto LAB_600039b4;
        FUN_60137768();
        uVar7 = 0x10;
        uVar9 = 0x400;
        param_1[0x1a] = uVar4;
        uVar3 = (ushort)param_1[8] | 0x400;
      }
      *(ushort *)(param_1 + 8) = uVar3;
      (**(code **)(param_1[0x16] + 4))(param_1,uVar7,uVar9);
LAB_6000398e:
      *(ushort *)(param_1 + 8) = (ushort)param_1[8] | uVar12;
      return (undefined1 *)0x0;
    }
    if (uVar8 != 0) {
      puVar5 = (uint *)FUN_60162e34((param_1[0x18] >> 10 & 0xffff) + 0xc);
      if (puVar5 == (uint *)0x0) goto LAB_600039a8;
      *puVar5 = (uint)(puVar5 + 3);
      func_0x60134ac8(puVar5 + 3,0,(param_1[0x18] & 0x3ffffff) >> 10);
      puVar5[1] = 0;
      puVar5[2] = 0;
      param_1[0x19] = (uint)puVar5;
      *(ushort *)(param_1 + 8) = (ushort)param_1[8] | 0x100;
      (**(code **)(param_1[0x16] + 4))(param_1,0x10,0x100);
      goto LAB_6000391a;
    }
    if (uVar4 == 0) {
      param_1[0x19] = 0;
      goto LAB_6000391a;
    }
    uVar4 = (param_1[0x18] & 0x3ffffff) >> 10;
    puVar11 = unaff_r5;
    if (uVar4 == 0) {
      puVar6 = (undefined4 *)FUN_60162e34(4);
      if (puVar6 == (undefined4 *)0x0) goto LAB_600039d8;
      param_1[0x19] = (uint)puVar6;
      *puVar6 = 0;
LAB_60003912:
      uVar3 = (ushort)param_1[8] | 0x200;
      goto LAB_60003918;
    }
    puVar5 = (uint *)FUN_60162e34(uVar4 + 0xc);
    if (puVar5 != (uint *)0x0) {
      *puVar5 = (uint)(puVar5 + 3);
      func_0x60134ac8(puVar5 + 3,0,(param_1[0x18] & 0x3ffffff) >> 10);
      puVar5[1] = 0;
      puVar5[2] = 0;
      param_1[0x19] = (uint)puVar5;
      (**(code **)(param_1[0x16] + 4))(param_1,3,0x200);
      goto LAB_60003912;
    }
  }
  FUN_6016804c(uRam600039e4,uRam600039e8,0x282);
LAB_600039d8:
  FUN_6016804c(uRam600039ec,uRam600039e8,0x277);
  *param_1 = extraout_r2;
  param_1[1] = (uint)param_1;
  param_1[2] = unaff_r6;
  *unaff_r7 = unaff_r6;
  *param_1 = extraout_r3;
  param_1[1] = (uint)param_1;
  param_1[2] = (uint)unaff_r7;
  *unaff_r7 = unaff_r6;
  *param_1 = (uint)param_1;
  param_1[1] = (uint)puVar11;
  *unaff_r7 = unaff_r6;
  *param_1 = extraout_r1;
  param_1[1] = unaff_r6;
  *unaff_r7 = unaff_r6;
  bVar1 = *(byte *)(unaff_r6 + 1);
  *(uint **)(extraout_r3 + 100) = unaff_r7;
  puVar11[0x19] = extraout_r1;
  *(undefined2 *)(bVar1 + 0x6f) = 0x6f;
  *(char *)((int)puVar11 + (extraout_r1 - 0x21)) = (char)unaff_r6;
  *unaff_r5 = unaff_r6;
  puVar2 = _DAT_60003a14;
  *_DAT_60003a14 = 1;
  return puVar2;
}

