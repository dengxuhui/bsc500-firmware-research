
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018ed0(void)

{
  int iVar1;
  
  iVar1 = _DAT_60018ee4;
  if (*(int *)(_DAT_60018ee4 + 4) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 4) = 0;
  }
  return;
}

