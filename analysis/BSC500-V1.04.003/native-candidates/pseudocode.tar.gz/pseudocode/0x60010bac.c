
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60010bac(int *param_1)

{
  *param_1 = _DAT_60010bd0 + 8;
  param_1[1] = 0;
  FUN_600e7fa8(param_1 + 2);
  FUN_600e7fa8(param_1 + 0xe);
  return param_1;
}

