
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000b6dc(void)

{
  int iVar1;
  
  iVar1 = _DAT_6000b700;
  func_0x6007db44(_DAT_6000b6fc,_DAT_6000b700,0x4000);
  func_0x6007db44(_DAT_6000b704,iVar1 + 0x4000,0x8860);
  return;
}

