
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600034e4(void)

{
  int iVar1;
  
  iVar1 = FUN_60004e7c();
  *(bool *)(_DAT_60003560 + 3) = iVar1 != 0;
  return;
}

