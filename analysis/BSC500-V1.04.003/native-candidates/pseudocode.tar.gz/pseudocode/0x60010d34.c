
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60010d34(void)

{
  FUN_60154c98();
  return *_DAT_60010d40;
}

