
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60010538(void)

{
  int iVar1;
  undefined4 uStack_44;
  undefined4 uStack_40;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  undefined4 uStack_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 uStack_10;
  undefined2 uStack_c;
  
  uStack_14 = _DAT_600105a0;
  uStack_18 = _DAT_600105a4;
  uStack_1c = _DAT_600105a8;
  uStack_20 = _DAT_600105ac;
  uStack_c = 0x501;
  uStack_10 = _DAT_600105b0;
  uStack_24 = _DAT_600105b4;
  uStack_28 = _DAT_600105b8;
  uStack_2c = _DAT_600105bc;
  uStack_30 = _DAT_600105c0;
  uStack_34 = _DAT_600105c4;
  uStack_38 = _DAT_600105c8;
  uStack_3c = _DAT_600105cc;
  FUN_6001b58c(&uStack_20,&uStack_3c);
  FUN_6014abf6();
  uStack_44 = 0;
  uStack_40 = 0;
  iVar1 = FUN_60160fd0(3,&uStack_40,&uStack_44);
  if (iVar1 == 0) {
    FUN_60148a34(&UNK_600105d0,3,1);
  }
  return;
}

