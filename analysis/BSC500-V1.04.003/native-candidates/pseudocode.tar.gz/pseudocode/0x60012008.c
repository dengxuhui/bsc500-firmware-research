
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60012008(void)

{
  uint *puVar1;
  bool bVar2;
  ulonglong uVar3;
  float fVar4;
  int iVar5;
  code *pcVar6;
  uint uVar7;
  uint uVar8;
  int iVar9;
  byte bVar10;
  uint uVar11;
  uint uVar12;
  uint extraout_r3;
  uint uVar13;
  int iVar14;
  uint *puVar15;
  byte bVar16;
  uint unaff_r7;
  uint unaff_r8;
  uint uVar17;
  uint uVar18;
  uint uVar19;
  uint unaff_r11;
  uint extraout_r12;
  uint uVar20;
  bool bVar21;
  uint in_fpscr;
  undefined4 uVar22;
  float fVar23;
  float fVar24;
  undefined8 uVar25;
  undefined8 uVar26;
  uint uStack_798;
  uint uStack_794;
  uint auStack_790 [408];
  byte abStack_130 [256];
  
  FUN_6013496a();
  iVar9 = _DAT_600123b4;
  puVar15 = _DAT_600123b0;
  _DAT_600123b0[0x3d] = _DAT_600123b0[0x3d] & 0xfffffffe;
  puVar15[0x3d] = puVar15[0x3d] & 0xfffffffd;
  puVar15[2] = puVar15[2] | 0xc00;
  puVar15[2] = puVar15[2] | 0x300;
  puVar15[1] = puVar15[1] & 0xffffff0f;
  puVar15[1] = puVar15[1] | 0x70;
  *puVar15 = *puVar15 | 0x8000000;
  puVar15[1] = puVar15[1] | 0x1000;
  puVar15[1] = puVar15[1] | 0x800000;
  puVar15[6] = puVar15[6] | 0x4000;
  *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) & 0xf03fffff;
  *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) | 0x1c00000;
  *puVar15 = *puVar15 | 1;
  *puVar15 = *puVar15 & 0xffc07fff;
  *puVar15 = *puVar15 | 0x200000;
  FUN_60134a32(4);
  uVar7 = 1;
  uVar11 = 0x40;
  auStack_790[0x118] = extraout_r3;
  while ((iVar9 = _DAT_600123b4, uVar7 != 7 &&
         (auStack_790[0x118] = puVar15[1] << 0x1e, (int)auStack_790[0x118] < 0))) {
    if ((puVar15[1] & 1) == 0) {
      uVar11 = uVar11 - (0x40U >> (uVar7 & 0xff));
    }
    else if ((puVar15[1] & 1) != 0) {
      uVar11 = uVar11 + (0x40U >> (uVar7 & 0xff));
    }
    uVar7 = uVar7 + 1;
    *puVar15 = *puVar15 & 0xffc07fff;
    auStack_790[0x118] = *puVar15 | (uVar11 & 0xff) << 0xf;
    *puVar15 = auStack_790[0x118];
  }
  uVar19 = 0xffffffff;
  uVar11 = 0x80;
  puVar15[1] = puVar15[1] & 0xffffefff;
  puVar15[3] = puVar15[3] | 0x800;
  puVar15[1] = puVar15[1] | 0x800000;
  puVar15[4] = puVar15[4] & 0xffff;
  puVar15[4] = puVar15[4] | 0x1e000000;
  *(uint *)(iVar9 + 0x9c) = *(uint *)(iVar9 + 0x9c) & 0xfffff801;
  *(uint *)(iVar9 + 0x9c) = *(uint *)(iVar9 + 0x9c) | 0x10;
  *(uint *)(iVar9 + 0x9c) = *(uint *)(iVar9 + 0x9c) & 0xfffffffe;
  *puVar15 = *puVar15 & 0xffff807f;
  *puVar15 = *puVar15 | 0x4000;
  *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) & 0xf03fffff;
  *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) | 0x1c00000;
  *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) & 0xffdfffff;
  *puVar15 = *puVar15 | 1;
  puVar15[3] = puVar15[3] | 0x40;
  puVar15[3] = puVar15[3] & 0xffffffbf;
  puVar15[3] = puVar15[3] & 0xfffffffd;
  puVar15[3] = puVar15[3] | 2;
  puVar15[2] = puVar15[2] | 0x11000;
  puVar15[5] = puVar15[5] | 0x80000;
  *puVar15 = *puVar15 & 0xffc07fff;
  *puVar15 = *puVar15 | 0x200000;
  uStack_794 = 0xffffffff;
  uVar7 = extraout_r12;
  for (uVar12 = 1; uVar12 != 9; uVar12 = uVar12 + 1) {
    uVar17 = 0x40;
    *puVar15 = *puVar15 & 0xffc07fff;
    *puVar15 = *puVar15 | 0x200000;
    puVar15[1] = puVar15[1] | 0x1000;
    uVar13 = 1;
    while ((uVar13 != 7 &&
           (puVar1 = puVar15 + 1, puVar15 = _DAT_600123b0, (int)(*puVar1 << 0x1e) < 0))) {
      if ((_DAT_600123b0[1] & 1) == 0) {
        uVar17 = uVar17 - (0x40U >> (uVar13 & 0xff));
      }
      else if ((_DAT_600123b0[1] & 1) != 0) {
        uVar17 = uVar17 + (0x40U >> (uVar13 & 0xff));
      }
      uVar13 = uVar13 + 1;
      *_DAT_600123b0 = *_DAT_600123b0 & 0xffc07fff;
      puVar15 = _DAT_600123b0;
      *_DAT_600123b0 = *_DAT_600123b0 | (uVar17 & 0xff) << 0xf;
    }
    puVar15[1] = puVar15[1] & 0xffffefff;
    puVar15[3] = puVar15[3] | 4;
    do {
    } while ((puVar15[3] & 1) == 0);
    uVar13 = puVar15[4] & 0xffff;
    if (uVar13 < 0x8449) {
      uStack_794 = 0x8448 - uVar13;
      uVar8 = -(0x80U >> (uVar12 & 0xff));
      unaff_r11 = uVar11;
      uStack_798 = uVar17;
    }
    else {
      uVar19 = uVar13 - 0x8448;
      uVar8 = 0x80 >> (uVar12 & 0xff);
      auStack_790[0x118] = uVar13;
      unaff_r7 = uVar11;
      unaff_r8 = uVar17;
      uVar13 = uVar7;
    }
    uVar11 = uVar8 + uVar11;
    puVar15[3] = puVar15[3] & 0xfffffffb;
    *puVar15 = *puVar15 & 0xffff807f;
    *puVar15 = *puVar15 | (uVar11 & 0xff) << 7;
    uVar7 = uVar13;
  }
  abStack_130[0] = (byte)unaff_r7;
  abStack_130[0x80] = (byte)unaff_r8;
  if (uStack_794 < uVar19) {
    abStack_130[0] = (byte)unaff_r11;
    abStack_130[0x80] = (byte)uStack_798;
    auStack_790[0x118] = uVar7;
    unaff_r8 = uStack_798;
    unaff_r7 = unaff_r11;
  }
  uVar12 = 0;
  *puVar15 = *puVar15 & 0xffff807f;
  *puVar15 = *puVar15 | (uVar11 & 0xff) << 7;
  puVar15[3] = puVar15[3] & 0xfffffffb;
  uVar7 = 0;
  puVar15[0x14] = 0;
  do {
    unaff_r7 = unaff_r7 + 1;
    puVar15[0x14] = puVar15[0x14] + 1;
    puVar15[0x13] = 0;
    *puVar15 = *puVar15 & 0xffff807f;
    *puVar15 = *puVar15 | (unaff_r7 & 0xff) << 7;
    puVar15[1] = puVar15[1] | 0x1000;
    puVar15[6] = puVar15[6] | 0x4000;
    uVar12 = (uVar12 & 0xff) + 1;
    uVar11 = 0;
    bVar2 = false;
    bVar16 = 0;
    while( true ) {
      bVar10 = bVar16;
      puVar1 = _DAT_600123b0;
      bVar21 = 2 < bVar10;
      if (bVar10 < 4) {
        puVar15 = (uint *)(uVar11 & 0xff);
        bVar21 = (uint *)0x1 < puVar15;
      }
      if (bVar21) break;
      uVar11 = (unaff_r8 & 0xff) << 0xf;
      _DAT_600123b0[0x13] = _DAT_600123b0[0x13] + 1;
      *puVar1 = *puVar1 & 0xffc07fff;
      *puVar1 = *puVar1 | uVar11;
      FUN_60134a32(4);
      if (-1 < (int)(puVar1[1] << 0x1e)) goto LAB_600123be;
      uVar19 = puVar1[1] & 1;
      if (uVar19 == 0) {
        if ((unaff_r8 & 0xff) == 0) {
          uVar11 = (int)puVar15 + 1;
          unaff_r8 = 0;
        }
        else {
          unaff_r8 = unaff_r8 - 1;
          uVar11 = 0;
        }
      }
      else if ((unaff_r8 & 0xff) < 0x3f) {
        unaff_r8 = unaff_r8 + 1;
        uVar11 = 0;
      }
      else {
        uVar11 = (int)puVar15 + 1;
        unaff_r8 = 0x3f;
      }
      bVar16 = 0;
      if (uVar7 != uVar19) {
        bVar16 = bVar10 + 1;
      }
      bVar21 = !bVar2;
      uVar7 = uVar19;
      bVar2 = true;
      if (bVar21) {
        bVar16 = bVar10;
      }
    }
    uVar11 = (unaff_r8 & 0xff) << 0xf;
LAB_600123be:
    puVar15 = _DAT_600126e4;
    _DAT_600126e4[1] = _DAT_600126e4[1] & 0xffffefff;
    *puVar15 = *puVar15 & 0xffc07fff;
    *puVar15 = *puVar15 | uVar11;
    FUN_60134a32(4);
    puVar15[3] = puVar15[3] | 4;
    puVar15[3] = puVar15[3] & 0xfffffffd;
    puVar15[3] = puVar15[3] | 2;
    FUN_60134a32(200);
    do {
    } while ((puVar15[3] & 1) == 0);
    uVar11 = puVar15[4];
    if ((uVar11 & 0xffff) < 0x7611) {
      puVar15[1] = puVar15[1] & 0xff7fffff;
      puVar15[0x14] = 10;
      uVar7 = (uint)abStack_130[0];
      uVar11 = (uint)abStack_130[0x80];
      for (iVar9 = 0; iVar14 = _DAT_600126e8, iVar9 != 0x28; iVar9 = iVar9 + 1) {
        uVar17 = 0;
        uVar19 = 0;
        puVar15[0x14] = puVar15[0x14] + 1;
        puVar15[0x13] = 100;
        uVar13 = 0;
        for (bVar16 = 0; uVar8 = (uint)bVar16, uVar8 < (uVar12 & 0xff); bVar16 = bVar16 + 1) {
          uVar20 = *(uint *)(_DAT_60012d80 + iVar9 * 4);
          _DAT_600126e4[0x13] = _DAT_600126e4[0x13] + 1;
          uVar18 = auStack_790[uVar8 + 0x118];
          if (bVar16 == 0) {
            if (uVar18 < uVar20) {
              uVar13 = uVar20 - uVar18;
              uVar17 = *(int *)(_DAT_60012d84 + iVar9 * 4) - uVar18;
              uVar19 = uVar18;
              uVar18 = *(uint *)(_DAT_60012d88 + iVar9 * 4);
            }
            else {
              uVar19 = *(uint *)(_DAT_60012d88 + iVar9 * 4);
              uVar13 = uVar18 - uVar20;
              uVar17 = uVar18 - *(int *)(_DAT_60012d84 + iVar9 * 4);
            }
            uVar19 = uVar18 - uVar19;
            auStack_790[iVar9 + 0xa0] = uVar11;
            auStack_790[iVar9 + 0xf0] = uVar11;
            auStack_790[iVar9 + 200] = uVar11;
            auStack_790[iVar9 + 0x78] = uVar7;
            auStack_790[iVar9 + 0x28] = uVar7;
            auStack_790[iVar9 + 0x50] = uVar7;
          }
          else {
            if (uVar18 < uVar20) {
              uVar20 = uVar20 - uVar18;
            }
            else {
              uVar20 = uVar18 - uVar20;
            }
            if (uVar20 < uVar13) {
              auStack_790[iVar9 + 0xf0] = (uint)abStack_130[uVar8 + 0x80];
              auStack_790[iVar9 + 0x78] = (uint)abStack_130[uVar8];
              uVar13 = uVar20;
            }
            uVar20 = *(int *)(_DAT_60012d84 + iVar9 * 4) - uVar18;
            if (uVar20 < uVar17) {
              auStack_790[iVar9 + 0xa0] = (uint)abStack_130[uVar8 + 0x80];
              auStack_790[iVar9 + 0x28] = (uint)abStack_130[uVar8];
              uVar17 = uVar20;
            }
            uVar18 = *(int *)(_DAT_60012d88 + iVar9 * 4) - uVar18;
            if (uVar18 < uVar19) {
              auStack_790[iVar9 + 200] = (uint)abStack_130[uVar8 + 0x80];
              auStack_790[iVar9 + 0x50] = (uint)abStack_130[uVar8];
              uVar19 = uVar18;
            }
          }
        }
        puVar15 = _DAT_600126e4;
      }
      puVar15[0x14] = 100;
      puVar15[1] = puVar15[1] | 0x800000;
      puVar15[4] = puVar15[4] & 0xffff;
      puVar15[4] = puVar15[4] | 0x43800000;
      *(uint *)(iVar14 + 0x9c) = *(uint *)(iVar14 + 0x9c) & 0xfffff801;
      *(uint *)(iVar14 + 0x9c) = *(uint *)(iVar14 + 0x9c) | 0x10;
      *(uint *)(iVar14 + 0x9c) = *(uint *)(iVar14 + 0x9c) & 0xfffffffe;
      *puVar15 = *puVar15 & 0xffff807f;
      *puVar15 = *puVar15 | auStack_790[0x81] << 7;
      *puVar15 = *puVar15 & 0xffc07fff;
      *puVar15 = *puVar15 | auStack_790[0xf9] << 0xf;
      *(uint *)(iVar14 + 0x98) = *(uint *)(iVar14 + 0x98) & 0xf03fffff;
      *(undefined4 *)(iVar14 + 0x98) = *(undefined4 *)(iVar14 + 0x98);
      *(uint *)(iVar14 + 0x98) = *(uint *)(iVar14 + 0x98) & 0xffdfffff;
      FUN_60134a32(0x14);
      puVar15[3] = puVar15[3] & 0xfffffffb;
      puVar15[3] = puVar15[3] | 4;
      iVar9 = _DAT_600126e8;
      do {
      } while ((puVar15[3] & 1) == 0);
      uVar7 = puVar15[4];
      puVar15[3] = puVar15[3] & 0xfffffffb;
      *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) & 0xf03fffff;
      *(uint *)(iVar9 + 0x98) = *(uint *)(iVar9 + 0x98) | 0xfc00000;
      FUN_60134a32(0x14);
      puVar15[3] = puVar15[3] | 4;
      do {
      } while ((puVar15[3] & 1) == 0);
      puVar15[3] = puVar15[3] & 0xfffffffb;
      puVar15[1] = puVar15[1] & 0xff7fffff;
      uVar25 = FUN_6016759c(0x6c000 / ((puVar15[4] & 0xffff) - (uVar7 & 0xffff)));
      fVar4 = _UNK_600126fc;
      iVar9 = _DAT_600126f8;
      uVar3 = (ulonglong)_UNK_600126f0 >> 0x20;
      uVar22 = (undefined4)_UNK_600126f0;
      for (iVar14 = 0; iVar5 = _DAT_600128a0, puVar15 = _DAT_6001289c, iVar14 != 0x14;
          iVar14 = iVar14 + 1) {
        _DAT_600126e4[0x14] = _DAT_600126e4[0x14] + 1;
        fVar23 = (float)VectorSignedToFloat(*(int *)(_DAT_60012d80 + iVar14 * 4) * 3 + iVar9 +
                                            0x12c0,(byte)(in_fpscr >> 0x16) & 3);
        uVar26 = FUN_60166bb4(fVar23 * fVar4);
        uVar26 = FUN_601682c8((int)uVar26,(int)((ulonglong)uVar26 >> 0x20),uVar22,(int)uVar3);
        FUN_601678fc((int)uVar26,(int)((ulonglong)uVar26 >> 0x20),(int)uVar25,
                     (int)((ulonglong)uVar25 >> 0x20));
        uVar7 = func_0x6015e530();
        auStack_790[iVar14] = uVar7;
      }
      _DAT_6001289c[0x14] = 1000;
      puVar15[1] = puVar15[1] | 0x800000;
      puVar15[4] = puVar15[4] & 0xffff;
      puVar15[4] = puVar15[4] | 0x43800000;
      *(uint *)(iVar5 + 0x9c) = *(uint *)(iVar5 + 0x9c) & 0xfffff801;
      *(uint *)(iVar5 + 0x9c) = *(uint *)(iVar5 + 0x9c) | 0x10;
      *(uint *)(iVar5 + 0x9c) = *(uint *)(iVar5 + 0x9c) & 0xfffffffe;
      *puVar15 = *puVar15 & 0xffff807f;
      *puVar15 = *puVar15 | auStack_790[0x95] << 7;
      *puVar15 = *puVar15 & 0xffc07fff;
      *puVar15 = *puVar15 | auStack_790[0x10d] << 0xf;
      *(uint *)(iVar5 + 0x98) = *(uint *)(iVar5 + 0x98) & 0xf03fffff;
      *(undefined4 *)(iVar5 + 0x98) = *(undefined4 *)(iVar5 + 0x98);
      *(uint *)(iVar5 + 0x98) = *(uint *)(iVar5 + 0x98) & 0xffdfffff;
      FUN_60134a32(0x14);
      puVar15[3] = puVar15[3] | 4;
      iVar14 = _DAT_600128a0;
      do {
      } while ((puVar15[3] & 1) == 0);
      uVar7 = puVar15[4];
      puVar15[3] = puVar15[3] & 0xfffffffb;
      *(uint *)(iVar14 + 0x98) = *(uint *)(iVar14 + 0x98) & 0xf03fffff;
      *(uint *)(iVar14 + 0x98) = *(uint *)(iVar14 + 0x98) | 0xfc00000;
      FUN_60134a32(0x14);
      puVar15[3] = puVar15[3] | 4;
      fVar4 = _UNK_600128a4;
      do {
      } while ((puVar15[3] & 1) == 0);
      puVar15[3] = puVar15[3] & 0xfffffffb;
      iVar14 = 0;
      fVar23 = (float)VectorSignedToFloat(0x6c000 / ((puVar15[4] & 0xffff) - (uVar7 & 0xffff)),
                                          (byte)(in_fpscr >> 0x16) & 3);
      for (; puVar15 = _DAT_6001289c, iVar14 != 0x14; iVar14 = iVar14 + 1) {
        _DAT_6001289c[0x14] = _DAT_6001289c[0x14] + 1;
        fVar24 = (float)VectorSignedToFloat(*(int *)(_DAT_60012d80 + iVar14 * 4 + 0x50) * 3 + iVar9,
                                            (byte)(in_fpscr >> 0x16) & 3);
        uVar7 = VectorFloatToUnsigned((fVar24 * fVar4 + 1.0) * fVar23,3);
        auStack_790[iVar14 + 0x14] = uVar7;
      }
      _DAT_6001289c[5] = _DAT_6001289c[5] & 0xfff7ffff;
      for (iVar9 = 0; pcVar6 = _DAT_60012d8c, iVar9 != 0xa0; iVar9 = iVar9 + 4) {
        *(int *)((int)puVar15 + iVar9 + 0x54) =
             *(int *)((int)auStack_790 + iVar9 + 0x3c0) * 0x100 +
             *(int *)((int)auStack_790 + iVar9) * 0x10000 +
             *(int *)((int)auStack_790 + iVar9 + 0x1e0);
        *(int *)((int)puVar15 + iVar9 + 0x2a0) =
             *(int *)((int)auStack_790 + iVar9 + 800) * 0x1000000 +
             *(int *)((int)auStack_790 + iVar9 + 0x140) * 0x10000 +
             *(int *)((int)auStack_790 + iVar9 + 0xa0) +
             *(int *)((int)auStack_790 + iVar9 + 0x280) * 0x100;
      }
      puVar15[9] = puVar15[9] & 0xffe1ffff;
      puVar15[9] = puVar15[9] | 0x1c0000;
      puVar15[2] = puVar15[2] | 0x10;
      puVar15[10] = puVar15[10] | 0xf800;
      puVar15[9] = puVar15[9] | 0x410000;
      puVar15[9] = puVar15[9] | 0x8000;
      puVar15[10] = puVar15[10] | 0x30000;
      puVar15[0x41] = puVar15[0x41] | 0x300;
      (*pcVar6)(0x14);
      puVar15[9] = puVar15[9] & 0xfffffdff;
      (*pcVar6)(2);
      puVar15[9] = puVar15[9] | 0x200;
      (*pcVar6)(0x14);
      puVar15[0x41] = puVar15[0x41] & 0xfffffffe;
      puVar15[0x41] = puVar15[0x41] | 1;
      do {
      } while (-1 < (int)(puVar15[0x41] << 0x1e));
      puVar15[9] = puVar15[9] & 0xffffc3ff;
      puVar15[9] = puVar15[9] & 0xffffbfff;
      puVar15[9] = puVar15[9] | (puVar15[0x41] & 0x78) << 7;
      puVar1 = _DAT_60012d7c;
      puVar15[9] = puVar15[9] | (puVar15[0x41] & 4) << 0xc;
      puVar15[0x41] = puVar15[0x41] & 0xfffffffe;
      puVar15[9] = puVar15[9] & 0xffff7fff;
      puVar15[9] = puVar15[9] & 0xffbfffff;
      puVar15[0x41] = puVar15[0x41] & 0xfffffdff;
      puVar15[2] = puVar15[2] & 0xffffffef;
      puVar15[2] = puVar15[2] & 0xfffeffff;
      puVar15[0x3d] = puVar15[0x3d] | 1;
      puVar15[0x3d] = puVar15[0x3d] | 2;
      puVar15[6] = puVar15[6] & 0xffffbfff;
      puVar15[1] = puVar15[1] & 0xff7fffff;
      puVar1[0x27] = puVar1[0x27] | 1;
      puVar1[0x26] = puVar1[0x26] | 0x200000;
      *puVar15 = *puVar15 & 0xfffffffe;
      puVar15[2] = puVar15[2] & 0xfffff7ff;
      puVar15[2] = puVar15[2] & 0xfffffbff;
      puVar15[9] = puVar15[9] | 1;
      puVar15[10] = puVar15[10] | 0x400;
      puVar15[3] = puVar15[3] | 2;
      puVar15[0x11] = puVar15[0x11] | 0x400;
      *puVar15 = *puVar15 & 0xf7ffffff;
      puVar15[3] = puVar15[3] & 0xfffff7ff;
      puVar15[0xc] = puVar15[0xc] | 0x2000;
      puVar15[0x10] = puVar15[0x10] | 8;
      puVar15[0x10] = puVar15[0x10] | 0x2000;
      puVar15[0x10] = puVar15[0x10] & 0xffffefff;
      puVar15[0x40] = puVar15[0x40] & 0xfc3fffff;
      puVar15[0x10] = puVar15[0x10] | 0x4000;
      puVar15[0x10] = puVar15[0x10] & 0xffffffbf;
      puVar15[0x10] = puVar15[0x10] | 0x40;
      puVar15[0x40] = puVar15[0x40] | 0x200000;
      puVar1 = _DAT_60012d7c;
      do {
      } while (-1 < (int)(puVar15[0x40] << 0xb));
      puVar15[0x10] = puVar15[0x10] & 0xfffff07f;
      puVar15[0x10] = puVar15[0x40] >> 0x13 & 0xf80 | puVar15[0x10];
      puVar15[0x10] = puVar15[0x10] | 0x1000;
      puVar15[0x40] = puVar15[0x40] & 0xffdfffff;
      puVar15[0x10] = puVar15[0x10] & 0xfffffff7;
      puVar15[0xc] = puVar15[0xc] & 0xffffdfff;
      puVar15[0xd] = puVar15[0xd] & 0xffff9fff;
      puVar15[0xd] = puVar15[0xd] | 0x6000;
      puVar15[2] = puVar15[2] & 0xfffffeff;
      puVar15[2] = puVar15[2] & 0xfffffdff;
      puVar1[0x26] = puVar1[0x26] & 0x8fffffff;
      puVar1[0x26] = puVar1[0x26] | 0x10000000;
      FUN_6001c044();
      FUN_60156f2c();
      puVar1[0x24] = puVar1[0x24] & 0xfffffe00;
      puVar1[0x24] = puVar1[0x24] | 0xff;
      puVar15[0x11] = puVar15[0x11] | 0x400;
      puVar15[0xb] = puVar15[0xb] & 0xffc3ffff;
      puVar15[0xb] = puVar15[0xb] | 0x340000;
      puVar15[2] = puVar15[2] & 0xff7fffff;
      puVar15[2] = puVar15[2] | 0x800000;
      puVar15[0xe] = puVar15[0xe] & 0xffffffdf;
      puVar15[0xe] = puVar15[0xe];
      puVar15[2] = puVar15[2] & 0xfdffffff;
      uVar7 = _DAT_60012d90;
      puVar1[7] = puVar1[7] & 0xfffffc00;
      puVar1[7] = puVar1[7] & 0xfff003ff;
      puVar1[7] = puVar1[7] & 0x800fffff;
      puVar1[7] = puVar1[7] | 0x168;
      puVar1[7] = puVar1[7] | 0x8800;
      puVar1[7] = puVar1[7] | 0xb000000;
      puVar1[0x20] = puVar1[0x20] & 0xff81ffff;
      puVar1[0x20] = puVar1[0x20] | 0x1e0000;
      puVar1[5] = puVar1[5] & 0xfffffc00;
      puVar1[5] = puVar1[5] | 0xa6;
      puVar1[0x29] = puVar1[0x29] & 0xfffe0000;
      puVar1[0x2a] = puVar1[0x2a] & 0xfffe0000;
      uVar11 = _DAT_60012d94;
      puVar1[0x29] = puVar1[0x29] | uVar7;
      puVar1[0x2a] = puVar1[0x2a] | uVar11;
      puVar1[4] = puVar1[4] | 0x800000;
      puVar1[4] = puVar1[4] | 0x100000;
      puVar1[4] = puVar1[4] | 0x100;
      puVar1[0x10] = puVar1[0x10] | 0x8000000;
      puVar1[0x10] = puVar1[0x10] | 0x8000;
      puVar1[0x10] = puVar1[0x10] | 0x30;
      puVar1[0x11] = puVar1[0x11] | 0x9000000;
      puVar1[0x11] = puVar1[0x11] | 0x8000;
      puVar1[0x11] = puVar1[0x11];
      puVar1[2] = _DAT_60012d98;
      puVar1[3] = puVar1[3] | 0xaa00;
      *puVar1 = *puVar1 & 0xf0003fff;
      *puVar1 = *puVar1 | 0xc000000;
      puVar1[0x24] = puVar1[0x24] & 0xfffc01ff;
      puVar1[0x24] = puVar1[0x24] | 0x1fe00;
      puVar1[0x28] = puVar1[0x28] & 0xfffff8ff;
      puVar1[0x28] = puVar1[0x28] | 0x600;
      puVar1[5] = puVar1[5] & 0xfff003ff;
      puVar1[5] = puVar1[5] | 0x2a800;
      puVar1[3] = puVar1[3] & 0xffffff00;
      puVar1[3] = puVar1[3] | 8;
      puVar15[0xc] = puVar15[0xc] & 0xfffffffc;
      puVar15[0xc] = puVar15[0xc] | 3;
      return;
    }
    uVar19 = uVar12 & 0xff;
    abStack_130[uVar19] = (byte)unaff_r7;
    abStack_130[uVar19 + 0x80] = (byte)unaff_r8;
    auStack_790[uVar19 + 0x118] = uVar11 & 0xffff;
  } while( true );
}

