
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * FUN_60004b60(int param_1,int param_2)

{
  short sVar1;
  code *pcVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  undefined4 uVar6;
  int *piVar7;
  undefined4 extraout_r1;
  int *extraout_r2;
  int extraout_r3;
  int unaff_r4;
  int iVar8;
  int unaff_r5;
  int iVar9;
  undefined4 *puVar10;
  int unaff_r6;
  int *unaff_r7;
  undefined4 in_stack_0000039c;
  
  if (param_1 != 0) {
    if (param_2 != 0) {
      *(int *)(param_1 + 4) = param_2;
    }
    return (int *)(param_1 + 4);
  }
  piVar4 = (int *)FUN_6016804c(uRam60004b74,0x60004b78,0xa5);
  *unaff_r7 = unaff_r6;
  *(char *)(unaff_r4 + 9) = (char)unaff_r5;
  *(int **)(unaff_r6 + 0x34) = piVar4;
  *(int **)(extraout_r3 + 0x34) = unaff_r7;
  iVar9 = *(int *)(*(int *)(unaff_r5 + 0x14) + 100);
  sVar1 = *(short *)(unaff_r6 + iVar9);
  *(undefined4 *)(sVar1 + 0x44) = in_stack_0000039c;
  iVar8 = (int)*(short *)(sVar1 + iVar9);
  *(char *)(unaff_r6 + 9) = (char)piVar4;
  puVar10 = (undefined4 *)(int)*(short *)(iVar8 + iVar9);
  *(int *)(iVar8 + 0x24) = extraout_r3;
  *(int **)(extraout_r3 + 0x14) = unaff_r7;
  *(char *)(iVar8 + 0x11) = (char)extraout_r3;
  pcVar2 = pcRam60004c04;
  iVar9 = puVar10[0x1d];
  if (piVar4 == (int *)0x0) {
    FUN_6016804c(&UNK_60004c34,_DAT_60004c30,0x2b);
  }
  else if (iVar9 != 0) {
    piVar5 = (int *)(*pcRam60004c04)(4);
    *piVar5 = iRam60004c08 + 8;
    uVar6 = (*pcVar2)(4);
    FUN_600f5a7c();
    piVar7 = (int *)(*pcVar2)(0x20);
    ZeroBytes(piVar7 + 1,0x14);
    piVar7[6] = 0;
    piVar7[7] = 0;
    *piVar7 = iRam60004c0c + 8;
    (**(code **)(*piVar4 + 0x14))(piVar4,uVar6);
    piVar3 = _DAT_60004c10;
    piVar7[3] = iVar9;
    piVar7[4] = (int)piVar5;
    piVar7[5] = (int)piVar4;
    *piVar3 = (int)piVar7;
    return piVar7;
  }
  FUN_6016804c(&UNK_60004c14,_DAT_60004c30,0x2c);
  *extraout_r2 = iVar8;
  *puVar10 = extraout_r1;
  *puVar10 = extraout_r1;
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

