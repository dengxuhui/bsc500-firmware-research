
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a788(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,uint param_6,undefined4 param_7,int param_8,undefined4 param_9)

{
  bool bVar1;
  undefined4 *puVar2;
  int iVar3;
  
  puVar2 = _DAT_6000a7f0;
  bVar1 = (int)_DAT_6000a7f0[7] < param_8;
  if (param_6 != _DAT_6000a7f0[5]) {
    bVar1 = ~_DAT_6000a7f0[5] + param_6 == 0;
  }
  if ((bVar1) && (iVar3 = FUN_60149b4c(), iVar3 == 0)) {
    func_0x60168578(&UNK_6000a7f4);
    FUN_6003de0c();
    puVar2[8] = param_9;
    *puVar2 = param_1;
    puVar2[1] = param_2;
    puVar2[2] = param_3;
    puVar2[3] = param_4;
    puVar2[4] = param_5;
    puVar2[5] = param_6;
    puVar2[6] = param_7;
    puVar2[7] = param_8;
    return;
  }
  return;
}

