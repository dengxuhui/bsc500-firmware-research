
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600035f4(void)

{
  return *(undefined4 *)(_DAT_600035fc + 8);
}

