
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60001c24(int param_1)

{
  int iVar1;
  int *unaff_r4;
  int unaff_r5;
  
  if (param_1 == 0) {
    func_0x60167f3c(3,_DAT_60001cf0,1,&UNK_60001d48);
    func_0x60167f3c(0,_DAT_60001d1c,1,_DAT_60001d20);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  iVar1 = FUN_60003600();
  unaff_r4[2] = iVar1;
  if (iVar1 != 0) {
    unaff_r4[3] = *(int *)(unaff_r5 + 0x10);
    iVar1 = FUN_601566b4(_DAT_60001cf8);
    *unaff_r4 = iVar1;
    FUN_60156808();
    if (*unaff_r4 != 0) {
      return 1;
    }
    func_0x60167f3c(3,_DAT_60001cf0,1,&UNK_60001cfc);
    func_0x60167f3c(0,_DAT_60001d1c,1,_DAT_60001d20);
    FUN_6013dd48();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  func_0x60167f3c(3,_DAT_60001cf0,1,&UNK_60001d24);
  func_0x60167f3c(0,_DAT_60001d1c,1,_DAT_60001d20);
  FUN_6013dd48();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}

