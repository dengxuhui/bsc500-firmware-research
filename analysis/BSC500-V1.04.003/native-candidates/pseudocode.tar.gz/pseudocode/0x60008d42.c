
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60008d42(void)

{
  int *piVar1;
  int *piVar2;
  char cVar3;
  undefined4 uStack_28;
  int *piStack_24;
  undefined4 uStack_1c;
  
  FUN_60019e1c(1,0);
  piVar1 = _DAT_601224ec;
  piVar2 = (int *)*_DAT_601224ec;
  if ((code *)piVar2[1] != (code *)0x0) {
    (*(code *)piVar2[1])();
    piVar2 = (int *)*piVar1;
  }
  (**(code **)(*piVar2 + 8))(&uStack_28,piVar2,0);
  if (piStack_24 == (int *)0x0) {
    cVar3 = '\r';
  }
  else {
    (**(code **)(*piStack_24 + 0x10))(piStack_24,0,1,2,uStack_28);
    (**(code **)(*piStack_24 + 0x20))(piStack_24,1);
    (**(code **)(*piStack_24 + 0x20))(piStack_24,0);
    (**(code **)(*(int *)*piVar1 + 0xc))((int *)*piVar1,&uStack_28);
    (**(code **)(*piStack_24 + 0x70))(piStack_24,&uStack_1c);
    cVar3 = (char)piStack_24[5];
  }
  (**(code **)(*(int *)*piVar1 + 0x10))((int *)*piVar1,&uStack_28);
  FUN_601675ca(*piVar1,cVar3,2);
  if (*(code **)(*piVar1 + 8) != (code *)0x0) {
    (**(code **)(*piVar1 + 8))();
  }
  if (cVar3 != '\0') {
    uStack_1c = 0xffffffff;
  }
  return uStack_1c;
}

