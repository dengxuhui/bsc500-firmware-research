
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006e58(int param_1)

{
  *(undefined4 *)(param_1 + 400) = 0;
  *(undefined1 *)(param_1 + 0x18b) = 0;
  if (*(int *)(_DAT_60006e6c + 4) != 0) {
    *(undefined4 *)(*(int *)(_DAT_60006e6c + 4) + 0x3c) = 0;
  }
  return;
}

