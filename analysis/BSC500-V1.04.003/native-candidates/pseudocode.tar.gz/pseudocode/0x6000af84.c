
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_6000af84(void)

{
  return *(undefined1 *)(_DAT_6000af8c + 2);
}

