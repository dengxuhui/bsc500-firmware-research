
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600167f8(int param_1)

{
  if ((param_1 != 0) && (*_DAT_60016814 != 0)) {
    FUN_6013a8de(_DAT_60016814[1],&stack0xfffffff4,0,0);
  }
  return;
}

