
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600052cc(void)

{
  undefined1 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  int *piVar5;
  undefined4 uVar6;
  int *piVar7;
  
  iVar2 = FUN_60164eb0(3);
  uVar4 = _DAT_60005338;
  piVar7 = (int *)(iVar2 + 4);
  uVar3 = FUN_6015de24(_DAT_60005338,piVar7);
  func_0x60168578(&UNK_6000533c,uVar3,uVar4);
  FUN_6015de60(uVar3);
  func_0x60168578(&UNK_60005360);
  piVar5 = piVar7;
  while (piVar5 = (int *)*piVar5, piVar5 != piVar7) {
    uVar6 = piVar5[5];
    uVar1 = *(undefined1 *)((int)piVar5 + 0x13);
    uVar4 = FUN_6015dd58(piVar5 + 2);
    func_0x60168578(&UNK_60005380,uVar3,0x10,piVar5 + -5,0x10,uVar6,uVar1,uVar4);
  }
  return 0;
}

