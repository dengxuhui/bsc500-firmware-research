
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600028d0(void)

{
  FUN_60156c34(_DAT_600028e4);
  FUN_60156bb4(FUN_600028e6,1);
  return 1;
}

