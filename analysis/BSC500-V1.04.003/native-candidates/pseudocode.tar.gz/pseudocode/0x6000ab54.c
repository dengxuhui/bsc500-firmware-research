
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_6000ab54(undefined4 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  int iVar1;
  byte *pbVar2;
  byte bVar3;
  undefined4 uStack_14;
  undefined4 uStack_10;
  uint uStack_c;
  
  uStack_14 = param_2;
  if ((*(char *)*_DAT_6000abbc == '\0') ||
     (uStack_10 = param_3, uStack_c = param_4, iVar1 = FUN_60019c8c(), iVar1 == 0)) {
    *_DAT_6000abc0 = 0x1d;
    bVar3 = 0;
    pbVar2 = _DAT_6000abc4;
  }
  else {
    uStack_c = uStack_c & 0xffff0000;
    uStack_14 = 0;
    uStack_10 = 0;
    iVar1 = FUN_60019c04(&uStack_14);
    if (iVar1 == 0) {
      *_DAT_6000abc0 = 0x1d;
      *_DAT_6000abc4 = 0;
      return CONCAT44(uStack_14,param_1);
    }
    bVar3 = *_DAT_6000abc4;
    if ((bVar3 < 5) && (*_DAT_6000abc4 = bVar3 + 1, bVar3 != 4)) goto LAB_6000abaa;
    if (0x1c < *_DAT_6000abc0) {
      *_DAT_6000abc0 = 0;
      FUN_60163e70(_DAT_6000abc8,&uStack_14,0);
      return CONCAT44(uStack_14,param_1);
    }
    bVar3 = *_DAT_6000abc0 + 1;
    pbVar2 = _DAT_6000abc0;
  }
  *pbVar2 = bVar3;
LAB_6000abaa:
  return CONCAT44(uStack_14,param_1);
}

