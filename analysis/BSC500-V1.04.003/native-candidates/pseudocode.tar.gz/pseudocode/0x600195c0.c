
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600195c0(void)

{
  undefined4 *puVar1;
  undefined1 *puVar2;
  
  puVar2 = _DAT_60019640;
  if (_DAT_60019640[2] == '\x01') {
    puVar1 = (undefined4 *)(_DAT_60019640 + 0xc);
    *_DAT_60019640 = 0;
    FUN_60159154(*puVar1);
    FUN_6013b0d8(*(undefined4 *)(puVar2 + 0xc));
    *(undefined2 *)(puVar2 + 4) = 0;
    *(undefined4 *)(puVar2 + 8) = 0;
    *(undefined4 *)(puVar2 + 0xc) = 0;
    *(undefined2 *)(puVar2 + 1) = 1;
  }
  return;
}

