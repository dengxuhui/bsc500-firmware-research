
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009e44(void)

{
  int *piVar1;
  int iVar2;
  
  iVar2 = 0x10;
  do {
    if (iVar2 + 0x28 == 0xb0) {
      return;
    }
    piVar1 = (int *)(_DAT_60009e64 + iVar2);
    iVar2 = iVar2 + 0x28;
  } while (*piVar1 == 0);
  return;
}

