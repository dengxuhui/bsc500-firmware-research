
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018794(undefined4 param_1)

{
  *_DAT_6001879c = param_1;
  return;
}

