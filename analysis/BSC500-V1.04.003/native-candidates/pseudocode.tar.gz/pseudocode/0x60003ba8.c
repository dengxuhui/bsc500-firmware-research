
uint FUN_60003ba8(void)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  int iStack_80;
  int aiStack_7c [2];
  int iStack_74;
  int iStack_4c;
  byte bStack_46;
  undefined4 uStack_30;
  char cStack_21;
  undefined *puStack_1c;
  
  FUN_60004de2();
  FUN_60004dd4();
  puStack_1c = &UNK_60003bbc;
  uVar1 = FUN_60159428(&puStack_1c,&iStack_80,2);
  if (uVar1 != 0) goto LAB_6015c5d8;
  iStack_4c = iStack_80;
  iVar2 = thunk_FUN_60162e34(0x200);
  if (iVar2 == 0) {
    uVar1 = 0x11;
    goto LAB_6015c5d8;
  }
  *(int *)(iStack_80 + 0xc) = iVar2;
  uVar1 = FUN_601339b8(&iStack_4c,puStack_1c);
  if (uVar1 == 0) {
    uVar1 = -(bStack_46 & 1) & 7;
    if (cStack_21 < '\0') {
      uVar1 = 6;
    }
    if (uVar1 == 0) {
      iVar3 = FUN_6012cb20(iStack_80,uStack_30);
      if ((int)((uint)bStack_46 << 0x1b) < 0) {
        aiStack_7c[0] = iStack_80;
        iStack_74 = iVar3;
        uVar1 = func_0x6012cf64(aiStack_7c,0);
        if (uVar1 == 0) {
          uVar1 = FUN_6012959c(aiStack_7c,0);
          if (uVar1 == 0) {
            uVar1 = 7;
          }
          if (uVar1 == 4) goto LAB_6015c5fa;
        }
      }
      else {
LAB_6015c5fa:
        uVar1 = FUN_60129544(&iStack_4c);
        if ((iVar3 != 0) && (uVar1 == 0)) {
          uVar1 = FUN_601377a8(&iStack_4c,iVar3,0);
        }
        if (uVar1 == 0) {
          uVar1 = FUN_60133930(iStack_80);
        }
      }
    }
  }
  FUN_60159408(iVar2);
LAB_6015c5d8:
  FUN_6015940c(iStack_80,uVar1);
  return uVar1;
}

