
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_600069b8(void)

{
  FUN_6015baa0(_DAT_600069dc,&stack0xfffffff4,4);
  return 0x1001f000;
}

