
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60011d78(int param_1)

{
  ushort uVar1;
  undefined2 uVar2;
  char *pcVar3;
  undefined4 uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint uVar8;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined1 *puVar9;
  
  pcVar3 = _DAT_60011da8;
  if (*_DAT_60011da8 == '\x01') {
    iVar5 = FUN_6015eff4();
    if (3000 < (uint)(**(int **)(iVar5 + 4) - *(int *)(pcVar3 + 4))) {
      *(undefined1 *)(param_1 + 2) = 0;
      iVar5 = _DAT_60168628;
      if (*(int *)(_DAT_60168628 + 8) == 0) {
        puVar9 = &stack0xfffffff4;
        if (*(int *)(_DAT_60168628 + 4) == 0) {
          uVar8 = FUN_6012ef90(_DAT_6016862c,0xff,&UNK_60011dac,puVar9,puVar9,unaff_r4,unaff_r5);
          iVar6 = *(int *)(iVar5 + 4);
          if (iVar6 == 0) {
            FUN_60154ab4(_DAT_6016862c);
          }
          else {
            uVar1 = *(ushort *)(iVar6 + 0x20);
            *(ushort *)(iVar6 + 0x20) = uVar1 | 0x40;
            uVar7 = 0xff;
            if (uVar8 < 0xff) {
              uVar7 = uVar8;
            }
            FUN_6015ef88(iVar6,0,_DAT_6016862c,uVar7);
            *(ushort *)(*(int *)(iVar5 + 4) + 0x20) = uVar1;
          }
        }
        else {
          uVar2 = *(undefined2 *)(*(int *)(_DAT_60168628 + 4) + 0x20);
          iVar6 = FUN_6001a8b4();
          if ((iVar6 == 0) || (iVar6 = FUN_6015b3f4(), iVar6 != 0)) {
            uVar4 = _DAT_6016862c;
            uVar7 = FUN_6012ef90(_DAT_6016862c,0xff,&UNK_60011dac,puVar9,puVar9,unaff_r4,unaff_r5);
            iVar6 = *(int *)(iVar5 + 4);
            *(ushort *)(iVar6 + 0x20) = (*(ushort *)(iVar6 + 0x20) & 0xf7bf) + 0x40;
            uVar8 = 0xff;
            if (uVar7 < 0xff) {
              uVar8 = uVar7;
            }
            FUN_6015ef88(iVar6,0,uVar4,uVar8);
            *(undefined2 *)(*(int *)(iVar5 + 4) + 0x20) = uVar2;
          }
          else {
            FUN_6001a8bc(&UNK_60011dac,puVar9);
          }
        }
      }
      return;
    }
  }
  return;
}

