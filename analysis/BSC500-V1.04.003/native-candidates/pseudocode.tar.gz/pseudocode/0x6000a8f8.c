
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000a8f8(uint param_1,undefined4 param_2,code *param_3,uint ****param_4,int param_5)

{
  undefined2 uVar1;
  short sVar2;
  byte bVar3;
  int iVar4;
  undefined4 uVar5;
  int iVar6;
  byte *pbVar7;
  undefined1 extraout_r1;
  byte bVar8;
  int iVar9;
  uint **extraout_r2;
  undefined4 *unaff_r4;
  uint ****ppppuVar10;
  uint ***unaff_r6;
  uint uVar11;
  uint uStack_6c;
  undefined4 uStack_68;
  uint uStack_64;
  byte *pbStack_60;
  undefined4 uStack_5c;
  uint ***pppuStack_58;
  uint uStack_54;
  undefined4 *puStack_50;
  uint uStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined4 uStack_3c;
  undefined4 uStack_38;
  undefined4 *puStack_34;
  uint ***apppuStack_30 [3];
  
  iVar4 = FUN_60168220(param_2);
  if ((9 < param_1) && (unaff_r6 = (uint ***)(param_1 - 10 & 0xff), unaff_r6 < (uint ***)0x10)) {
    FUN_60164a88();
    unaff_r4 = (undefined4 *)FUN_60164a70(unaff_r6);
    if (*(char *)(unaff_r4 + 2) == '\x01') {
      uVar11 = iVar4 + 1U & 0xffff;
      *(undefined1 *)(unaff_r4 + 2) = 2;
      unaff_r4[3] = 0;
      unaff_r4[4] = param_5;
      *unaff_r4 = param_3;
      unaff_r4[1] = param_4;
      FUN_60163b68(unaff_r4 + 5,param_2,8);
      *(undefined1 *)(unaff_r4 + 7) = 0;
      FUN_60164ac8();
      param_4 = (uint ****)
                CONCAT13(uRam6000aae7,CONCAT12(uRam6000aae6,CONCAT11(uRam6000aae5,uRam6000aae4)));
      unaff_r4 = &uStack_3c;
      pppuStack_58 = (uint ***)uVar11;
      uVar5 = FUN_60159df0(unaff_r4,0,(uint)unaff_r6 | ((uint)param_4[1] & 1) << 0xf,
                           ((uint)param_4[1] & 1) << 0xf | 0x7fff);
      iVar4 = FUN_60163b68(uVar5,param_2,uVar11);
      *(undefined1 *)(iVar4 + uVar11 + -1) = 0;
      if (uStack_38._2_2_ < 0xd) {
        ppppuVar10 = apppuStack_30;
      }
      else {
        ppppuVar10 = (uint ****)apppuStack_30[0];
        if ((uint ****)apppuStack_30[0] == (uint ****)0x0) goto LAB_6000aab8;
      }
      iVar4 = FUN_6015d5cc(ppppuVar10);
      pppuStack_58 = (uint ***)ppppuVar10;
      uStack_54 = iVar4;
      func_0x60167f3c(7,uRam6000aac4,1,0x6000ab0c);
      if (iVar4 == 0) {
        if (param_4[1] != (uint ***)(uint)((ushort)uStack_3c >> 0xf)) {
          FUN_600e9818(&uStack_3c,0xffffffff);
          uVar5 = FUN_60159dd4(&uStack_3c);
          return uVar5;
        }
        uStack_3c = (code *)(CONCAT22((ushort)uStack_3c,(ushort)uStack_3c) | 0x7fff0000);
      }
      else {
        iVar6 = FUN_600f92bc(iVar4);
        if (iVar6 != 0xff) {
          uStack_3c = (code *)CONCAT22((ushort)iVar6 | (ushort)((int)param_4[1] << 0xf) |
                                       (*(byte *)(iVar4 + 1) & 0x7f) << 8,(ushort)uStack_3c);
          func_0x60167f3c(7,uRam6000aac4,1,0x6000ab38);
          FUN_60120690(iVar4,&uStack_3c);
          uVar5 = 0;
          goto LAB_6000aa8e;
        }
      }
      uVar5 = 0xffffffff;
LAB_6000aa8e:
      uVar5 = FUN_600e9818(&uStack_3c,uVar5);
      return uVar5;
    }
  }
  FUN_60164ac8();
  uStack_44 = CONCAT31(uStack_44._1_3_,(char)param_1);
  uStack_48 = 0xffffffff;
  uVar5 = 0x88000;
  uStack_38 = 0x88000;
  apppuStack_30[0] = (uint ***)param_4;
  if (param_5 != 0) {
    uStack_3c = param_3;
    puStack_34 = (undefined4 *)FUN_60162e34(8);
    if (puStack_34 == (undefined4 *)0x0) {
      FUN_6016804c(0x6000aad4,uRam6000aad0,0x559);
LAB_6000aab8:
      iVar4 = FUN_6016804c(0x6000aae8,0x6000aaf8,0x2c1);
      *param_4 = unaff_r6;
      *param_4 = unaff_r6;
      *(undefined4 *)(iVar4 + 4) = 0x6000ae84;
      *param_4 = unaff_r6;
      *(undefined1 *)((int)unaff_r4 + 9) = extraout_r1;
      uVar1 = *(undefined2 *)(unaff_r4 + 0x18002ab8);
      pppuRam6000aaf0 = unaff_r6;
      unaff_r6[0x1d] = extraout_r2;
      *(undefined1 *)((int)unaff_r4 + 0x11) = extraout_r1;
      iVar9 = (int)unaff_r4 * 2;
      pppuRam6000ab20 = unaff_r6;
      *(char *)((int)extraout_r2 + iVar9) = (char)extraout_r2;
      iVar6 = _DAT_6000ac68;
      iVar4 = iRam6000ac44;
      *(undefined1 *)(iRam6000ac44 + 8) = 0x4c;
      *(undefined1 *)(iVar4 + 5) = 0xbf;
      *(int *)(iVar4 + 0x14) = iVar4;
      *(int *)(iVar6 + 0x14) = iVar4;
      uStack_64 = (uint)*(short *)(iVar4 + 0x6000aabf);
      bVar8 = (byte)*(short *)(iVar4 + 0x6000aabf);
      *(byte *)(iVar6 + 0x15) = bVar8;
      *(char *)(iVar4 + 0xd) = (char)extraout_r2;
      *(byte *)(iVar4 + 9) = bVar8;
      uRam6000aae3 = (undefined1)iVar9;
      uRam6000aae4 = (undefined1)((uint)iVar9 >> 8);
      uRam6000aae5 = (undefined1)((uint)iVar9 >> 0x10);
      uRam6000aae6 = (undefined1)((uint)iVar9 >> 0x18);
      sVar2 = *(short *)(iVar4 + 0x6000aabf);
      pbStack_60 = (byte *)(iVar6 * 2);
      *(byte **)(pbStack_60 + 0x14) = pbStack_60;
      *(byte **)(iVar6 + 0x14) = pbStack_60;
      pbStack_60[0xc] = 0x4c;
      bVar3 = (byte)sVar2;
      pbStack_60[9] = bVar3;
      iVar4 = *(int *)(iVar6 + 0x14);
      *(uint *)(pbStack_60 + 0x54) = uStack_64;
      pbStack_60[0xc] = 0x4c;
      *(int *)(iVar4 + 0x24) = (int)sVar2;
      *(uint *)(iVar4 + 0x34) = uStack_64;
      uStack_68 = *(undefined4 *)(iVar4 + 0x14);
      *(undefined4 *)(pbStack_60 + 0x54) = uStack_68;
      pbStack_60[0xc] = bVar3;
      pbStack_60[0xc] = 0x4c;
      pbStack_60[9] = bVar3;
      iVar4 = *(int *)(iVar4 + 0x14);
      *(uint *)(pbStack_60 + 0x54) = uStack_64;
      uStack_6c = (uint)*pbStack_60;
      *(byte **)(pbStack_60 + 0x14) = pbStack_60;
      *(byte **)(iVar4 + 0x14) = pbStack_60;
      *(byte *)(iVar4 + 0x15) = bVar8;
      pbStack_60[0xd] = (byte)uStack_68;
      pbStack_60[9] = bVar8;
      *(uint *)(uStack_6c + 0x24) = uStack_6c;
      *(byte **)(pbStack_60 + 0x54) = pbStack_60;
      *(char *)(uStack_6c + 1) = (char)uVar1;
      uStack_5c = 0x6000aac5;
      if ((*(char *)*_DAT_6000abbc == '\0') || (iVar4 = FUN_60019c8c(), iVar4 == 0)) {
        *_DAT_6000abc0 = 0x1d;
        bVar8 = 0;
        pbVar7 = _DAT_6000abc4;
      }
      else {
        uStack_64 = uStack_64 & 0xffff0000;
        uStack_6c = 0;
        uStack_68 = 0;
        iVar4 = FUN_60019c04(&uStack_6c);
        if (iVar4 == 0) {
          *_DAT_6000abc0 = 0x1d;
          *_DAT_6000abc4 = 0;
          return 0x76;
        }
        bVar8 = *_DAT_6000abc4;
        if ((bVar8 < 5) && (*_DAT_6000abc4 = bVar8 + 1, bVar8 != 4)) {
          return 0x76;
        }
        if (0x1c < *_DAT_6000abc0) {
          *_DAT_6000abc0 = 0;
          FUN_60163e70(_DAT_6000abc8,&uStack_6c,0);
          return 0x76;
        }
        bVar8 = *_DAT_6000abc0 + 1;
        pbVar7 = _DAT_6000abc0;
      }
      *pbVar7 = bVar8;
      return 0x76;
    }
    *puStack_34 = uStack_48;
    puStack_34[1] = uStack_44;
    iVar4 = FUN_601622a0(param_5,&uStack_3c,0x10);
    if (iVar4 == 0) {
      return 0;
    }
    uStack_54 = uStack_38 & 0xffff;
    uStack_4c = uStack_38 >> 0x10;
    pppuStack_58 = (uint ***)0x0;
    puStack_50 = puStack_34;
    func_0x60167f3c(7,uRam6000aac4,1,uRam6000aac8);
    uVar5 = FUN_6016804c(uRam6000aacc,uRam6000aad0,0x55f);
  }
  if (param_3 != (code *)0x0) {
    puStack_34 = &uStack_48;
    uVar5 = (*param_3)(&uStack_38);
  }
  return uVar5;
}

