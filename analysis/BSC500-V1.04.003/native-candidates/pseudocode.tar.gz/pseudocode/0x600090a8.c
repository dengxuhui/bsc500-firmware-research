
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_600090a8(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined4 unaff_r6;
  undefined1 uStack_18;
  undefined1 uStack_17;
  undefined2 uStack_16;
  undefined2 uStack_14;
  undefined2 uStack_12;
  undefined2 uStack_10;
  undefined2 uStack_e;
  undefined2 uStack_c;
  undefined2 uStack_a;
  
  uStack_a = (undefined2)((uint)unaff_r6 >> 0x10);
  uStack_17 = (undefined1)((uint)param_4 >> 8);
  uStack_10 = (undefined2)param_4;
  uStack_e = (undefined2)_DAT_600090d0;
  uStack_c = (undefined2)((uint)_DAT_600090d0 >> 0x10);
  uStack_12 = 0;
  uStack_18 = param_1;
  uStack_16 = param_3;
  uStack_14 = param_2;
  FUN_60011710(&uStack_18);
  return CONCAT26(uStack_12,CONCAT24(uStack_14,CONCAT22(uStack_16,CONCAT11(uStack_17,uStack_18))));
}

