
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60010c68(undefined4 param_1,undefined4 param_2)

{
  undefined4 *puVar1;
  
  puVar1 = _DAT_60010c74;
  *_DAT_60010c74 = param_1;
  puVar1[1] = param_2;
  return 0;
}

