
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void thunk_FUN_60016c78(void)

{
  int iVar1;
  
  iVar1 = _DAT_60016c94;
  *(undefined1 *)(_DAT_60016c94 + 1) = 1;
  FUN_600234a8(3);
  *(undefined4 *)(iVar1 + 0x18) = 0;
  *(undefined4 *)(iVar1 + 0x1c) = 0;
  *(undefined4 *)(iVar1 + 0x20) = 0;
  return;
}

