
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_600182f0(void)

{
  return *_DAT_600182f8;
}

