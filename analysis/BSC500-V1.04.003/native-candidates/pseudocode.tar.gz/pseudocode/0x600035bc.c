
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600035bc(void)

{
  int iVar1;
  
  iVar1 = FUN_60004d18(_DAT_600035d4);
  if (iVar1 != 0) {
    func_0x60168578(&UNK_600035d8);
    *_DAT_600035f0 = 1;
  }
  return;
}

