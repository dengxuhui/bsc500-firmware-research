
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001025c(int param_1)

{
  if (param_1 != 0) {
    *(int *)(_DAT_6001026c + 4) = param_1;
    return 1;
  }
  return 0;
}

