
/* WARNING: Removing unreachable block (ram,0x601671ba) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60008c30(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  char *pcVar1;
  char cVar2;
  int *piVar3;
  undefined1 *puVar4;
  byte bVar5;
  int iVar6;
  uint uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  int iVar10;
  undefined1 uVar11;
  int iVar12;
  undefined4 unaff_r4;
  bool bVar13;
  undefined4 uStack_28;
  int iStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  
  piVar3 = _DAT_60008d2c;
  bVar5 = *(byte *)(*_DAT_60008d2c + 2);
  cVar2 = *(char *)(*_DAT_60008d2c + 3);
  uStack_20 = param_2;
  uStack_1c = param_3;
  uStack_18 = param_4;
  iVar6 = thunk_FUN_60149780();
  puVar4 = _DAT_60008d30;
  pcVar1 = _DAT_60008d30 + 3;
  *_DAT_60008d30 = (char)iVar6;
  if ((*pcVar1 == '\0') && (iVar6 != 0)) {
    if (cVar2 == '\x01') {
      if (bVar5 < 3) {
        uVar11 = 0xf;
      }
      else {
        if (bVar5 < 6) goto LAB_60008c66;
        if (10 < bVar5) {
          bVar13 = 0xf < bVar5;
          goto LAB_60008c76;
        }
LAB_60008c6e:
        uVar11 = 3;
      }
    }
    else if (bVar5 < 3) {
LAB_60008c66:
      uVar11 = 7;
    }
    else {
      if (bVar5 < 6) goto LAB_60008c6e;
      bVar13 = 10 < bVar5;
LAB_60008c76:
      uVar11 = 0;
      if (!bVar13) {
        uVar11 = 1;
      }
    }
    puVar4[2] = uVar11;
    puVar4[3] = 1;
  }
  if (0xf < bVar5) {
    bVar5 = 0;
    goto LAB_60008c86;
  }
  if (iVar6 == 0) {
    puVar4[2] = 0;
    if (bVar5 != 0) {
      return;
    }
    if (cVar2 == '\x01') {
      return;
    }
    uStack_18 = unaff_r4;
    iVar10 = FUN_6015982e();
    FUN_60159828(iVar10,0,0,0);
    iVar6 = *(int *)(_DAT_60040178 + 4);
    uStack_1c = uStack_18;
    iVar12 = FUN_60041a68(iVar6,*(undefined4 *)(_DAT_601671d0 + 0x58),0,iVar10);
    if ((iVar6 != 0) && (iVar12 == 0)) {
      uVar8 = FUN_60052acc(iVar6);
      uVar9 = FUN_6012376e(iVar6);
      func_0x60167f3c(3,_DAT_60046030,1,&UNK_60046034,uVar8,uVar9);
      iVar12 = FUN_6012376e(iVar6);
      if (iVar12 == 0) {
        FUN_60133088();
        uVar8 = _DAT_60046030;
        while( true ) {
          uStack_20 = 0;
          uStack_28 = 0;
          iStack_24 = 0;
          iVar12 = FUN_6013388a(iVar6,&uStack_28,0,0);
          if (iVar12 != 0) break;
          func_0x60167f3c(3,uVar8,1,&UNK_60046058,uStack_28);
          if (iStack_24 != 0) {
            func_0x60139eac();
          }
        }
        FUN_601330ec();
      }
    }
    if (iVar10 != 0) {
      func_0x60139eac(iVar10);
    }
    return;
  }
  if (cVar2 == '\x01') {
    if (bVar5 < 0xb) {
      if (bVar5 < 6) {
        if (bVar5 < 3) {
          bVar5 = 0xf;
        }
        else {
          bVar5 = 7;
        }
      }
      else {
        bVar5 = 3;
      }
    }
    else {
      bVar5 = 1;
    }
    goto LAB_60008c86;
  }
  if (bVar5 < 3) {
    uVar7 = 3;
  }
  else if (bVar5 < 6) {
    uVar7 = 2;
  }
  else {
    uVar7 = 0;
    if (bVar5 < 0xb) {
      uVar7 = 1;
    }
  }
  if (((uint)(byte)puVar4[2] & 1 << uVar7) >> uVar7 != 0) {
    return;
  }
  if ((uVar7 | 2) == 2) {
    if (*(char *)(*piVar3 + 0x93) == '\0') {
      iVar12 = 0;
      iVar6 = _DAT_60008d34 + 1;
      uVar8 = _DAT_60008d38;
      goto LAB_60008d20;
    }
  }
  else {
    uVar8 = FUN_6015240c();
    iVar12 = (int)&uStack_20 + 2;
    func_0x601681f4(iVar12,&UNK_60008d3c,uVar8);
    uVar8 = 0;
    iVar6 = _DAT_60008d34;
LAB_60008d20:
    FUN_60163e70(iVar6,iVar12,uVar8);
  }
  bVar5 = puVar4[2] | (byte)(1 << uVar7);
LAB_60008c86:
  puVar4[2] = bVar5;
  return;
}

