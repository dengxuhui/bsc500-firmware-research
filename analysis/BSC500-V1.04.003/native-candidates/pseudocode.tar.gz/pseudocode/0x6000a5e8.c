
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000a5e8(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar1 = FUN_6015982e();
  FUN_60159828(uVar1,6,0,0);
  uVar2 = FUN_6015bd44();
  func_0x60159838(uVar2,_DAT_6000a63c,uVar1);
  if (*(char *)(_DAT_6000a614 + 1) != '\0') {
    *(undefined1 *)(_DAT_6000a614 + 1) = 0;
  }
  return;
}

