
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60011d4c(void)

{
  bool bVar1;
  int *piVar2;
  undefined4 uVar3;
  int iVar4;
  undefined4 uVar5;
  uint uVar6;
  int extraout_r3;
  short *unaff_r4;
  int iVar7;
  int unaff_r6;
  undefined4 uVar8;
  undefined4 unaff_r7;
  uint uVar9;
  int iVar10;
  undefined4 in_cr14;
  undefined8 uVar11;
  undefined1 auStack_108 [124];
  undefined4 uStack_8c;
  undefined1 auStack_88 [92];
  int iStack_2c;
  int iStack_28;
  
  iVar7 = _DAT_60011d68;
  if (*(int *)(_DAT_60011d68 + 4) == 0) {
    return 0;
  }
  func_0x60168578(&UNK_60011d6c);
  piVar2 = (int *)(iVar7 + 4);
  iVar7 = *piVar2;
  if (iVar7 == 0) {
    if ((*puRam6001cd48 & 1) != 0) {
      software_bkpt(0);
    }
    bVar1 = (bool)isCurrentModePrivileged();
    if (bVar1) {
      isIRQinterruptsEnabled();
    }
    disableIRQinterrupts();
    uVar11 = FUN_6016804c(uRam6001cd4c,0x6001cd50,0x15c);
    uVar3 = (undefined4)uVar11;
    coprocessor_loadlong(0,in_cr14,uVar3);
    *(short *)((int)((ulonglong)uVar11 >> 0x20) + 0x32) = (short)((ulonglong)uVar11 >> 0x20);
    *(undefined4 *)unaff_r7 = unaff_r7;
    *(int *)(unaff_r4 + 0x22) = unaff_r6;
    *(undefined4 *)(extraout_r3 + 0x34) = unaff_r7;
    psRam00000054 = unaff_r4;
    *(undefined4 *)(extraout_r3 + 0x14) = unaff_r7;
    *(char *)(unaff_r6 + 0x11) = (char)*(undefined4 *)(unaff_r4 + 0x3a);
    *(undefined4 *)(extraout_r3 + 100) = unaff_r7;
    uVar8 = uRam00000044;
    iStack_28 = (int)*unaff_r4;
    uVar6 = (uint)*(byte *)((int)unaff_r4 + 5);
    *(undefined4 *)(extraout_r3 + 100) = unaff_r7;
    iStack_2c = (int)unaff_r4 << 1;
    func_0x60168578(&UNK_6001ce84,uVar3);
    iVar7 = thunk_FUN_60162e34(0x170);
    if (iVar7 != 0) {
      FUN_60167214(iVar7,0x170);
      iVar4 = thunk_FUN_60162e34(0x260);
      *(int *)(iVar7 + 0x168) = iVar4;
      piVar2 = _DAT_6001ceb0;
      if (iVar4 != 0) {
        *(uint *)(iVar7 + 0x160) = uVar6;
        *(uint *)(iVar7 + 0x15c) = uVar6;
        *(uint *)(iVar7 + 0xf8) = uVar6;
        *piVar2 = iVar7;
        func_0x60168578(&UNK_6001ceb4,uVar6,uVar6);
        iVar10 = *(int *)(iVar7 + 0x168);
        iVar4 = FUN_6015838c(iVar10,uVar3,3);
        if (iVar4 == 0) {
          uVar9 = *(uint *)(iVar10 + 0xc);
          func_0x60168578(_DAT_6001ceec,uVar9,uVar6);
          if (uVar9 == uVar6) {
            FUN_60158174(iVar10,uVar6);
            uVar5 = FUN_60168220(uVar3);
            CopyBytes(iVar7 + 4,uVar3,uVar5);
            uVar5 = FUN_60168220(uVar8);
            CopyBytes(iVar7 + 0x84,uVar8,uVar5);
            ZeroBytes(auStack_108,0xdc);
            iVar4 = FUN_6002aed0(auStack_108);
            if (iVar4 == 0) {
              func_0x60168578(_DAT_6001cef4,uStack_8c);
              CopyBytes(iVar7 + 0x100,auStack_88,0x58);
              iVar4 = thunk_FUN_60162e34(0xdc);
              *(int *)(iVar7 + 0x164) = iVar4;
              if (iVar4 != 0) {
                func_0x6007db44(iVar4,auStack_108,0xdc);
              }
              func_0x60168578(_DAT_6001cef8,uVar6);
              return iVar7;
            }
          }
          FUN_60159154(iVar10);
          FUN_6015c57c(uVar3);
          FUN_6015c57c(_DAT_6001cef0);
        }
        FUN_6013b0d8(*(undefined4 *)(iVar7 + 0x168));
        *(undefined4 *)(iVar7 + 0x168) = 0;
      }
      FUN_6015e9c0(iVar7);
    }
    return 0;
  }
  uVar8 = *(undefined4 *)(iVar7 + 0x168);
  if (*(int *)(iVar7 + 0x164) == 0) {
    FUN_6015c57c(iVar7 + 4);
  }
  else {
    FUN_60156428(uVar8);
    FUN_60107b98(*piVar2);
    FUN_60107c50(*piVar2);
    if (*(int *)(iVar7 + 0x164) != 0) {
      FUN_6015e9c0();
    }
    if (*(int *)(iVar7 + 0x16c) != 0) {
      FUN_6012c99c(*(int *)(iVar7 + 0x16c) + 0x24);
      FUN_6015e9c0(*(undefined4 *)(iVar7 + 0x16c));
    }
  }
  FUN_6013b0d8(uVar8);
  FUN_6015e9c0(iVar7);
  *piVar2 = 0;
  return 0;
}

