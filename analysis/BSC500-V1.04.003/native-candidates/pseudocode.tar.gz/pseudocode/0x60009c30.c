
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 FUN_60009c30(void)

{
  int iVar1;
  undefined4 in_r3;
  undefined4 unaff_r4;
  undefined4 unaff_r5;
  undefined4 unaff_r6;
  undefined1 uStack_18;
  char cStack_17;
  undefined2 uStack_16;
  undefined2 uStack_14;
  undefined2 uStack_12;
  undefined1 uStack_10;
  undefined1 uStack_f;
  char cStack_e;
  undefined1 uStack_d;
  undefined1 uStack_c;
  undefined2 uStack_b;
  undefined1 uStack_9;
  
  uStack_c = (undefined1)unaff_r6;
  uStack_b = (undefined2)((uint)unaff_r6 >> 8);
  uStack_9 = (undefined1)((uint)unaff_r6 >> 0x18);
  uStack_10 = (undefined1)unaff_r5;
  uStack_f = (undefined1)((uint)unaff_r5 >> 8);
  cStack_e = (char)((uint)unaff_r5 >> 0x10);
  uStack_d = (undefined1)((uint)unaff_r5 >> 0x18);
  uStack_14 = (undefined2)unaff_r4;
  uStack_12 = (undefined2)((uint)unaff_r4 >> 0x10);
  uStack_18 = (undefined1)in_r3;
  cStack_17 = (char)((uint)in_r3 >> 8);
  uStack_16 = (undefined2)((uint)in_r3 >> 0x10);
  iVar1 = FUN_6013dad0(&uStack_10);
  if (iVar1 != 0) {
    func_0x6016713c(iVar1,0x57,_DAT_60009c98);
  }
  uStack_14 = 0;
  uStack_18 = 0;
  cStack_17 = '\0';
  uStack_16 = 0;
  FUN_60132294(&uStack_18,6);
  if (CONCAT22(uStack_b,CONCAT11(uStack_c,uStack_d)) != CONCAT22(uStack_14,uStack_16)) {
    uStack_14 = uStack_b;
    uStack_16 = CONCAT11(uStack_c,uStack_d);
    uStack_18 = uStack_f;
    cStack_17 = cStack_e;
    FUN_60016818(&uStack_18,6);
    return CONCAT26(uStack_12,CONCAT24(uStack_14,CONCAT22(uStack_16,CONCAT11(cStack_17,uStack_18))))
    ;
  }
  if (cStack_e != cStack_17) {
    cStack_e = cStack_17;
    iVar1 = FUN_60019658(&uStack_10);
    if (iVar1 != 0) {
      func_0x6016713c(iVar1,0x66,_DAT_60009c98);
    }
  }
  return CONCAT26(uStack_12,CONCAT24(uStack_14,CONCAT22(uStack_16,CONCAT11(cStack_17,uStack_18))));
}

