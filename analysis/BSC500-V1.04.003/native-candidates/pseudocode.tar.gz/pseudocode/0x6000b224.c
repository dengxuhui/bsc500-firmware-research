
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000b224(void)

{
  char *pcVar1;
  code *pcVar2;
  
  pcVar2 = _DAT_6000b264;
  pcVar1 = _DAT_6000b260;
  if (*_DAT_6000b260 == '\x01') {
    (*_DAT_6000b264)(0x86,0);
    (*pcVar2)(0x83,0);
    FUN_601649b8(0);
    func_0x60134ab4(2);
    (*pcVar2)(0x74,0);
    func_0x60134ab4(3);
    func_0x601559cc();
    *pcVar1 = '\0';
  }
  return;
}

