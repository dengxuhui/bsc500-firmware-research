
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60018138(int param_1,int param_2,uint *param_3)

{
  bool bVar1;
  int *piVar2;
  int *piVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  uint uVar8;
  uint uVar9;
  undefined4 in_cr0;
  undefined4 in_cr1;
  undefined4 in_cr8;
  undefined8 in_d3;
  float unaff_s16;
  float fVar10;
  undefined1 auStack_70 [16];
  undefined8 uStack_60;
  
  iVar5 = _DAT_6001817c;
  piVar2 = (int *)(_DAT_6001817c + 0x10);
  if (piVar2 == (int *)0x0) {
    return 0xffffffff;
  }
  if (param_2 == 0) {
    return 0xffffffff;
  }
  if (param_3 == (uint *)0x0) {
    return 0xffffffff;
  }
  piVar3 = *(int **)(_DAT_6001817c + 0x14);
  iVar7 = 0;
  uVar8 = 0;
  uVar6 = piVar3[1];
  fVar10 = *(float *)(*piVar3 + uVar6 * 0x10 + -0xc);
  coprocessor_function2(10,0,0,in_cr8,in_cr1,in_cr0);
  uStack_60 = in_d3;
  while( true ) {
    if (uVar6 <= uVar8) {
      return 1;
    }
    iVar4 = FUN_6010e156(*piVar3 + iVar7);
    if (iVar4 == 1) break;
    piVar3 = *(int **)(iVar5 + 0x14);
    iVar7 = iVar7 + 0x10;
    uVar8 = uVar8 + 1;
    uVar6 = piVar3[1];
  }
  ZeroBytes(auStack_70,0x38);
  iVar7 = **(int **)(iVar5 + 0x14) + iVar7;
  uVar8 = *(uint *)(iVar7 + 8);
  uVar6 = *(uint *)(iVar7 + 0xc);
  if (param_1 != 1) {
    while( true ) {
      if (uVar6 <= uVar8) {
        return 1;
      }
      iVar5 = FUN_600f7576(*piVar2,uVar8,auStack_70);
      if ((iVar5 == 0) && (unaff_s16 <= uStack_60._4_4_)) break;
      uVar8 = uVar8 + 1;
    }
    FUN_600fb404(param_2,auStack_70);
    *param_3 = uVar8;
    return 0;
  }
  bVar1 = false;
  uVar9 = 0;
  do {
    if (uVar6 <= uVar8) {
LAB_6001fba0:
      if (bVar1) {
LAB_6001fba6:
        iVar5 = FUN_600f7576(*piVar2,uVar9,auStack_70);
        if (iVar5 == 0) {
          FUN_600fb404(param_2,auStack_70);
          *(float *)(param_2 + 0x14) = fVar10 - *(float *)(param_2 + 0x14);
          *param_3 = ~uVar9 + *(int *)(*piVar2 + 0x14);
          return 0;
        }
      }
      return 1;
    }
    iVar5 = FUN_600f7576(*piVar2,uVar8,auStack_70);
    if ((iVar5 == 0) && (unaff_s16 < uStack_60._4_4_)) {
      if (uVar8 != 0) {
        uVar9 = uVar8 - 1;
        goto LAB_6001fba6;
      }
      goto LAB_6001fba0;
    }
    if (uVar6 - 1 == uVar8) {
      bVar1 = true;
      uVar9 = uVar6 - 1;
    }
    uVar8 = uVar8 + 1;
  } while( true );
}

