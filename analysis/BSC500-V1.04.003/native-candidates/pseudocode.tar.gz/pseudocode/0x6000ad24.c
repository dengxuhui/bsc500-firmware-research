
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6000ad24(int *param_1)

{
  undefined4 uVar1;
  int iVar2;
  int extraout_r3;
  int unaff_r4;
  int iVar3;
  int unaff_r5;
  int unaff_r6;
  int iVar4;
  int *unaff_r7;
  undefined1 auStack_4c [48];
  
  if (param_1 != (int *)0x0) {
                    /* WARNING: Could not recover jumptable at 0x6000ad30. Too many branches */
                    /* WARNING: Treating indirect jump as call */
    uVar1 = (**(code **)(*param_1 + 8))();
    return uVar1;
  }
  uVar1 = FUN_6016804c(uRam6000ad3c,0x6000ad40,0x9b);
  *unaff_r7 = unaff_r6;
  *(char *)(unaff_r4 + 9) = (char)unaff_r5;
  *(undefined4 *)(unaff_r6 + 0x34) = uVar1;
  *(char *)(extraout_r3 + 0xd) = (char)unaff_r7;
  *(char *)(unaff_r4 + 9) = (char)unaff_r5;
  *(int *)(unaff_r6 + 0x54) = unaff_r6;
  *(char *)(unaff_r6 + 0x15) = (char)*(undefined2 *)(unaff_r6 + unaff_r5);
  iVar4 = 0xd;
  iVar3 = _DAT_6000adbc;
  do {
    iVar2 = _DAT_6000adc0;
    if (iVar4 == 0) {
      iVar3 = 0;
      do {
        if (iVar3 == 0x1a4) {
          return 1;
        }
        iVar4 = FUN_6015c8a2(auStack_4c,iVar2 + iVar3);
        if (iVar4 == 0) {
          FUN_6015bd24(auStack_4c);
        }
        else if ((iVar4 == 0xd) || (iVar4 = FUN_6015ad48(iVar2 + iVar3), iVar4 != 0)) {
          return 0;
        }
        iVar3 = iVar3 + 0x23;
      } while( true );
    }
    iVar2 = FUN_6015c8a2(auStack_4c,iVar3);
    if (iVar2 == 0) {
      FUN_6015bd24(auStack_4c);
    }
    else {
      if (iVar2 == 0xd) {
        return 0;
      }
      iVar2 = FUN_6015ad48(iVar3);
      if (iVar2 != 0) {
        return 0;
      }
    }
    iVar3 = iVar3 + 0x23;
    iVar4 = iVar4 + -1;
  } while( true );
}

