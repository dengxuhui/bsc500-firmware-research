
undefined * FUN_6000a0c0(void)

{
  return &UNK_6000a0c4;
}

