
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000e35c(void)

{
  FUN_6001a04c();
  if (*_DAT_6000e378 != '\0') {
    FUN_60018918();
  }
  *_DAT_6000e37c = *_DAT_6000e37c + 1;
  return;
}

