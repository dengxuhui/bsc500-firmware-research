
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600075e4(undefined4 param_1,uint param_2,int param_3)

{
  int *piVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  undefined4 uStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  int iStack_28;
  
  iStack_28 = 0;
  if (((int)(param_2 << 2) < 0) &&
     (iVar2 = FUN_601169e8(param_1,&iStack_28), piVar1 = _DAT_60007684, iVar2 != 0)) {
    param_2 = param_2 & 0xdfffffff;
    iVar2 = *_DAT_60007684;
    if (iVar2 == 0) {
      uStack_30 = 0;
      uStack_2c = 0;
      uStack_34 = 1;
      uStack_38 = _DAT_60007688;
      iVar2 = FUN_60168494(&uStack_38);
      *piVar1 = iVar2;
    }
    FUN_6016825e(iVar2,0xffffffff);
    uVar4 = 0;
    for (; param_2 != 0; param_2 = param_2 >> 1) {
      if ((param_2 & 1) != 0) {
        uVar3 = 1 << (uVar4 & 0xff);
        uVar5 = uVar3 | 0x20000000;
        iVar2 = FUN_60019d88(uVar5,param_1,param_3);
        if (iVar2 != 0) {
          if (param_3 == 0) {
            *(uint *)(iStack_28 + 0x18) = *(uint *)(iStack_28 + 0x18) & ~uVar3 | 0x20000000;
          }
          else {
            *(uint *)(iStack_28 + 0x18) = *(uint *)(iStack_28 + 0x18) | uVar5;
            FUN_60019ce4(uVar5);
          }
        }
      }
      uVar4 = uVar4 + 1;
    }
    if (*piVar1 != 0) {
      func_0x601682ae();
    }
  }
  return;
}

