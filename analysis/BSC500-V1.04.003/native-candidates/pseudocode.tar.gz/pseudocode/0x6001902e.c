
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001902e(undefined4 param_1)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  char cVar4;
  undefined4 unaff_r7;
  undefined4 unaff_r9;
  int unaff_r10;
  code *unaff_r11;
  uint in_fpscr;
  float unaff_s16;
  undefined8 uVar5;
  undefined8 uVar6;
  undefined4 in_stack_0000000c;
  undefined8 in_stack_00000030;
  undefined8 in_stack_00000038;
  float in_stack_00000040;
  undefined4 in_stack_0000004c;
  undefined4 in_stack_00000050;
  undefined4 in_stack_00000054;
  undefined4 in_stack_00000058;
  undefined4 in_stack_0000005c;
  undefined4 in_stack_00000064;
  
  while( true ) {
    uVar5 = FUN_6016759c(param_1);
    uVar6 = FUN_6016759c(unaff_r9);
    in_stack_00000030 =
         FUN_601675d8((int)uVar5,(int)((ulonglong)uVar5 >> 0x20),(int)uVar6,
                      (int)((ulonglong)uVar6 >> 0x20));
    uVar2 = in_stack_0000005c;
    uVar5 = FUN_6016759c(in_stack_00000058);
    uVar6 = FUN_6016759c(uVar2);
    in_stack_00000038 =
         FUN_601675d8((int)uVar5,(int)((ulonglong)uVar5 >> 0x20),(int)uVar6,
                      (int)((ulonglong)uVar6 >> 0x20));
    iVar1 = FUN_60132c70(in_stack_0000000c,&stack0x00000030,&stack0x00000010);
    if (iVar1 == 0) break;
LAB_60018fe8:
    do {
      iVar1 = FUN_6015d9d4(in_stack_00000064);
      if (iVar1 != 0) {
        FUN_601667bc(in_stack_00000064);
        iVar1 = FUN_60132d28(in_stack_0000000c,&stack0x00000010);
        if (iVar1 == 0) {
          iVar1 = FUN_60021df4(&stack0x00000010);
          if (iVar1 != 0) goto code_r0x600190ce;
          iVar1 = FUN_60021fec(&stack0x00000010);
          if (iVar1 == 0) {
            iVar1 = FUN_6002183c(&stack0x00000010);
            if (iVar1 != 0) {
              FUN_60021ee4();
              FUN_60022138();
              goto LAB_600190d6;
            }
            cVar4 = '\0';
            *(undefined4 *)(unaff_r10 + 100) = 0;
            *(undefined2 *)(unaff_r10 + 0x40) = 0x103;
            iVar1 = FUN_6015e0d0();
            if (iVar1 != 0) {
              *(undefined4 *)(unaff_r10 + 0x50) = *(undefined4 *)(iVar1 + 0x20);
            }
            iVar1 = _UNK_600191cc;
            *(undefined1 *)(_UNK_600191cc + 0x21) = 4;
            uVar2 = _UNK_600191d0;
            *(undefined1 *)(iVar1 + 0x74) = 0;
            *(undefined1 *)(iVar1 + 0x51) = 0;
            *(undefined4 *)(iVar1 + 0x70) = uVar2;
            uVar2 = *(undefined4 *)(unaff_r10 + 0x50);
            *(undefined4 *)(iVar1 + 0xa4) = 0;
            *(undefined4 *)(iVar1 + 0xa8) = uVar2;
            if (*(byte *)(unaff_r10 + 0x42) < 3) {
              cVar4 = *(byte *)(unaff_r10 + 0x42) + 1;
            }
            *(char *)(iVar1 + 0x20) = cVar4;
            iVar3 = FUN_601623fc();
            if (iVar3 != 0) {
              *(undefined4 *)(iVar1 + 0x54) = 0xffffffff;
              *(undefined4 *)(iVar1 + 0x58) = 0xffffffff;
              *(undefined4 *)(iVar1 + 0x5c) = 0xffffffff;
              uVar2 = *(undefined4 *)(iVar3 + 4);
              *(undefined4 *)(iVar1 + 0x68) = *(undefined4 *)(iVar3 + 8);
              *(undefined4 *)(iVar1 + 0x6c) = uVar2;
            }
            if (*(code **)(unaff_r10 + 0x44) != (code *)0x0) {
              (**(code **)(unaff_r10 + 0x44))(*(undefined1 *)(unaff_r10 + 0x42));
            }
            uVar2 = 0;
            goto LAB_600190e2;
          }
          FUN_60021ee4();
        }
        else {
          FUN_6011c750();
code_r0x600190ce:
          FUN_6011c6ec();
        }
        FUN_6011c710();
        goto LAB_600190d6;
      }
      iVar1 = (*unaff_r11)(in_stack_00000064,&stack0x00000058,unaff_r7,&stack0x00000048);
    } while (((iVar1 == -1) || (iVar1 = func_0x60166dd0(&stack0x00000058), iVar1 == 1)) ||
            (iVar1 = func_0x60166dd0(unaff_r7), iVar1 == 1));
    in_stack_00000040 = (float)VectorSignedToFloat(in_stack_0000004c,(byte)(in_fpscr >> 0x16) & 3);
    in_stack_00000040 = in_stack_00000040 / unaff_s16;
    param_1 = in_stack_00000050;
    unaff_r9 = in_stack_00000054;
  }
  iVar1 = FUN_60030b8c(&stack0x00000010);
  if (iVar1 == 0) {
    iVar1 = FUN_60030c34(&stack0x00000010);
    if (iVar1 == 0) {
      iVar1 = FUN_60030a78(&stack0x00000010);
      if (iVar1 != 0) {
        FUN_6011c750();
        FUN_6011c6ec();
        goto LAB_6001911a;
      }
      goto LAB_60018fe8;
    }
    FUN_6011c750();
  }
  else {
    FUN_6011c6ec();
  }
  FUN_6011c710();
LAB_6001911a:
  FUN_601667bc(in_stack_00000064);
LAB_600190d6:
  *(undefined2 *)(unaff_r10 + 0x40) = 0x201;
  uVar2 = 0xffffffff;
LAB_600190e2:
  *(undefined1 *)(unaff_r10 + 0x68) = 0;
  return uVar2;
}

