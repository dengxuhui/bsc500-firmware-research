
/* WARNING: Removing unreachable block (ram,0x6011e4c0) */
/* WARNING: Removing unreachable block (ram,0x6011e4dc) */
/* WARNING: Removing unreachable block (ram,0x6011e4c4) */
/* WARNING: Removing unreachable block (ram,0x6011e4e6) */
/* WARNING: Removing unreachable block (ram,0x6011e4f2) */
/* WARNING: Removing unreachable block (ram,0x6011e4fa) */
/* WARNING: Removing unreachable block (ram,0x6011e522) */
/* WARNING: Removing unreachable block (ram,0x6011e526) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 * FUN_600102ac(int param_1)

{
  undefined4 uVar1;
  undefined4 *puVar2;
  int iVar3;
  undefined1 auStack_2c [16];
  
  uVar1 = _DAT_6011e584;
  if (param_1 != 0) {
    *_DAT_6011e580 = *_DAT_6011e580 + 1;
    FUN_60162c3a(auStack_2c,0x10,uVar1);
    puVar2 = (undefined4 *)FUN_60162e34(0x44);
    if (puVar2 != (undefined4 *)0x0) {
      func_0x60134ac8(puVar2,0,0x44);
      *puVar2 = 0xc;
      *(byte *)(puVar2 + 1) = *(byte *)(puVar2 + 1) | 0x10;
      iVar3 = FUN_60162e34(param_1 * 0x48);
      if (iVar3 != 0) {
        func_0x60134ac8(iVar3,0,4);
        *(byte *)(puVar2 + 1) = *(byte *)(puVar2 + 1) | 2;
        FUN_60123a64(puVar2 + 2,auStack_2c,iVar3,0xc,param_1 * 0x48,0);
        return puVar2;
      }
      if ((int)((uint)*(byte *)(puVar2 + 1) << 0x1b) < 0) {
        func_0x60166c0c(puVar2);
      }
    }
  }
  return (undefined4 *)0x0;
}

