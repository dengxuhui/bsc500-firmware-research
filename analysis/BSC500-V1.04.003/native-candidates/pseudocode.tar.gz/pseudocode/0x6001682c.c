
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_6001682c(void)

{
  if (*_DAT_6001683c == '\x01') {
    return *(char *)(_DAT_6011f78c + 0xcc) != '\0';
  }
  return false;
}

