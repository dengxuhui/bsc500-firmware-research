
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60019720(int param_1)

{
  undefined4 uVar1;
  undefined4 uVar2;
  
  uVar2 = _DAT_6001973c;
  uVar1 = _DAT_60019738;
  if (param_1 != 0) {
    *(undefined4 *)(param_1 + 0x2efc) = _DAT_60019740;
    *(undefined4 *)(param_1 + 0x2f00) = uVar2;
    *(undefined4 *)(param_1 + 0x2f04) = uVar1;
  }
  return;
}

