
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60002b18(void)

{
  FUN_60004514();
  FUN_60167f4a(&UNK_60002b3c,_DAT_60002b44,0,0x800,6,10);
  FUN_60167f8c();
  return 0;
}

