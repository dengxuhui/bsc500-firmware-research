
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600187a0(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  ushort uVar3;
  short sVar4;
  int *piVar5;
  undefined1 auStack_ac [96];
  undefined1 auStack_4c [32];
  undefined1 auStack_2c [8];
  int aiStack_24 [2];
  
  uVar3 = FUN_60147734(_DAT_600188cc,_DAT_600188d0,0,0,0,0);
  if (uVar3 < 2) {
    if (uVar3 == 0) {
      ZeroBytes(auStack_4c,0x20);
      ZeroBytes(auStack_ac,0x60);
      FUN_60161fb8(auStack_2c);
      sVar4 = FUN_6015ee0c(auStack_2c,_DAT_600188cc,_DAT_600188d4,0,0,0,0);
      uVar2 = _DAT_60019558;
      uVar1 = _DAT_600188cc;
      if (sVar4 != 0) {
        piVar5 = aiStack_24;
        while (piVar5 = (int *)*piVar5, aiStack_24 != piVar5) {
          ZeroBytes(auStack_4c,0x20);
          ZeroBytes(auStack_ac,0x60);
          CopyBytes(auStack_4c,piVar5[-2],piVar5[-1]);
          func_0x60164dec(auStack_ac,0x60,uVar2,uVar1,auStack_4c);
          FUN_60163bbe(auStack_ac);
        }
      }
      FUN_601607f4(auStack_2c);
      FUN_601629c8();
    }
  }
  else {
    ZeroBytes(auStack_4c,0x20);
    ZeroBytes(auStack_ac,0x60);
    FUN_60130ce4();
    FUN_60161fb8(auStack_2c);
    sVar4 = FUN_6015ee0c(auStack_2c,_DAT_600188d8,_DAT_600188dc,0,0,0,0);
    uVar2 = _DAT_60019558;
    uVar1 = _DAT_600188d8;
    if (sVar4 != 0) {
      piVar5 = aiStack_24;
      while (piVar5 = (int *)*piVar5, aiStack_24 != piVar5) {
        ZeroBytes(auStack_4c,0x20);
        ZeroBytes(auStack_ac,0x60);
        CopyBytes(auStack_4c,piVar5[-2],piVar5[-1]);
        func_0x60164dec(auStack_ac,0x60,uVar2,uVar1,auStack_4c);
        FUN_60163bbe(auStack_ac);
      }
    }
    FUN_601607f4(auStack_2c);
  }
  return;
}

