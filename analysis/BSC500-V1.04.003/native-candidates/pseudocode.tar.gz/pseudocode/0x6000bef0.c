
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_6000bef0(void)

{
  return *_DAT_6000bef8;
}

