
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60017e44(float param_1,int param_2,uint *param_3)

{
  uint uVar1;
  int *piVar2;
  int iVar3;
  int *piVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  float *pfVar8;
  uint uVar9;
  uint uVar10;
  float *pfVar11;
  undefined4 in_cr0;
  undefined4 in_cr8;
  float fVar12;
  float fVar13;
  float fVar14;
  float fVar15;
  float fVar16;
  uint in_s14;
  float fVar17;
  undefined8 uStack_38;
  
  uVar1 = _DAT_601131ec;
  iVar6 = _DAT_60017e50;
  piVar2 = (int *)(_DAT_60017e50 + 0x18);
  if (piVar2 == (int *)0x0) {
    return 0xffffffff;
  }
  if (param_3 == (uint *)0x0) {
    return 0xffffffff;
  }
  param_3[7] = _DAT_601131ec;
  *param_3 = 0xffffffff;
  param_3[1] = 0xffffffff;
  iVar3 = 0;
  piVar4 = *(int **)(iVar6 + 0x20);
  param_3[2] = 0;
  iVar7 = piVar4[1];
  fVar17 = *(float *)(*piVar4 + iVar7 * 0x10 + -0xc);
  fVar12 = fVar17 - param_1;
  coprocessor_function2(10,0,0,in_cr0,in_cr0,in_cr8);
  for (; iVar7 != 0; iVar7 = iVar7 + -1) {
    pfVar8 = (float *)(*piVar4 + iVar3);
    if ((*pfVar8 <= fVar12) && (fVar12 <= pfVar8[1])) {
      uStack_38 = (ulonglong)in_s14;
      uVar9 = *(uint *)(iVar3 + *piVar4 + 8);
      uVar10 = *(uint *)(iVar3 + *piVar4 + 0xc);
      goto LAB_6011307a;
    }
    iVar3 = iVar3 + 0x10;
  }
  uVar9 = 0xffffffff;
LAB_6011305e:
  param_3[2] = uVar9;
  return 1;
LAB_6011307a:
  if (uVar10 <= uVar9) {
    return 1;
  }
  if (param_2 == 1) {
    iVar3 = FUN_600f5660();
  }
  else {
    iVar3 = FUN_60116860(fVar17,*(undefined4 *)(iVar6 + 0x1c),uVar9,(int)&uStack_38 + 4);
  }
  if (iVar3 != 0) {
    param_3[7] = uVar1;
    param_3[1] = 0xffffffff;
    param_3[2] = 0xffffffff;
    return 0xffffffff;
  }
  fVar12 = (float)uStack_38._4_4_[2];
  if (param_1 < fVar12) {
    param_3[7] = (uint)(fVar12 - param_1);
    if (param_2 != 1) {
      piVar2 = (int *)*piVar2;
      param_3[1] = uVar9;
      uVar9 = *piVar2 - uVar9;
      goto LAB_6011305e;
    }
    piVar4 = (int *)*piVar2;
    uVar5 = ~uVar9;
    uVar9 = uVar9 + 1;
    param_3[2] = uVar9;
    param_3[1] = uVar5 + *piVar4;
    goto LAB_6011307a;
  }
  fVar13 = (float)uStack_38._4_4_[3];
  if (param_1 <= fVar13) {
    pfVar11 = (float *)*uStack_38._4_4_;
    iVar3 = 0;
    pfVar8 = pfVar11;
    goto LAB_601130f6;
  }
  if (param_2 == 1) {
    return 1;
  }
  uVar9 = uVar9 + 1;
  goto LAB_6011307a;
LAB_601130f6:
  if (uStack_38._4_4_[1] + -1 == iVar3) {
    fVar17 = *pfVar11;
    fVar15 = pfVar11[3];
    iVar3 = 0;
LAB_60113130:
    fVar17 = pfVar11[iVar3 * 3 + 2] +
             ((param_1 - fVar17) * (pfVar11[iVar3 * 3 + 5] - pfVar11[iVar3 * 3 + 2])) /
             (fVar15 - fVar17);
    if (param_2 == 1) {
      fVar14 = (float)uStack_38._4_4_[0xb] + (float)uStack_38._4_4_[8];
      uVar9 = *(int *)(*(int *)(iVar6 + 0x1c) + 0x14) + ~uVar9;
      fVar12 = (fVar13 + (float)uStack_38._4_4_[0xc]) - param_1;
      *param_3 = uVar9;
      fVar15 = fVar17;
    }
    else {
      iVar6 = *piVar2;
      fVar16 = (float)uStack_38._4_4_[0xc];
      fVar15 = (float)uStack_38._4_4_[0xb];
      *param_3 = uVar9;
      fVar15 = fVar17 + fVar15;
      fVar14 = *(float *)(iVar6 + 4);
      fVar12 = *(float *)(iVar6 + 8) + ((fVar12 - param_1) - fVar16);
    }
    param_3[5] = (uint)fVar12;
    param_3[6] = (uint)(fVar14 - fVar15);
    param_3[3] = (uint)(fVar13 - param_1);
    uVar10 = *(uint *)*piVar2;
    param_3[4] = (uint)((float)uStack_38._4_4_[8] - fVar17);
    if (uVar9 + 1 < uVar10) {
      param_3[1] = uVar9 + 1;
      uVar10 = uVar10 - uVar9;
    }
    else {
      param_3[1] = 0xffffffff;
      uVar10 = 1;
    }
    param_3[2] = uVar10;
    param_3[7] = uVar1;
    return 0;
  }
  fVar17 = *pfVar8;
  if ((fVar17 <= param_1) && (fVar15 = pfVar8[3], param_1 <= fVar15)) goto LAB_60113130;
  iVar3 = iVar3 + 1;
  pfVar8 = pfVar8 + 3;
  goto LAB_601130f6;
}

