
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60009abc(uint param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  undefined4 uStack_24;
  
  iVar1 = _DAT_60009c2c;
  uStack_24 = 0;
  for (iVar3 = 0; iVar3 != 8; iVar3 = iVar3 + 1) {
    iVar4 = *(int *)(iVar1 + iVar3 * 4 + 4);
    if ((iVar4 != 0) && (*(byte *)(iVar4 + 0x1a) == param_1)) {
      while (iVar2 = FUN_60011ea0(iVar3,&uStack_24), iVar2 != 0) {
        FUN_60011edc(uStack_24);
      }
      if (*(char *)(iVar4 + 0x18) != -1) {
        if (*(code **)(iVar4 + 0x10) != (code *)0x0) {
          (**(code **)(iVar4 + 0x10))(*(undefined1 *)(iVar4 + 0x19),*(undefined1 *)(iVar4 + 0x1b));
        }
        *(undefined1 *)(iVar4 + 0x1b) = 0xff;
        *(undefined2 *)(iVar4 + 0x18) = 0xffff;
      }
      FUN_600fcf04(iVar4);
    }
  }
  return;
}

