
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60016ad8(void)

{
  undefined4 uVar1;
  undefined4 uStack_7c;
  undefined *puStack_78;
  undefined4 uStack_74;
  undefined4 uStack_70;
  undefined4 *puStack_6c;
  undefined4 uStack_68;
  int iStack_64;
  undefined4 uStack_60;
  undefined *puStack_5c;
  undefined1 uStack_58;
  undefined4 uStack_54;
  undefined4 uStack_50;
  int iStack_4c;
  undefined4 uStack_48;
  undefined4 uStack_44;
  undefined1 uStack_40;
  undefined4 *puStack_3c;
  undefined4 uStack_38;
  int iStack_34;
  undefined4 uStack_30;
  undefined *puStack_2c;
  undefined1 uStack_28;
  undefined4 *puStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  undefined1 uStack_10;
  undefined4 *puStack_c;
  
  puStack_c = &uStack_38;
  puStack_14 = &UNK_60016b6c;
  uStack_10 = 0;
  uStack_18 = 0x1000;
  uStack_20 = 0;
  uStack_1c = 0x8000000;
  puStack_24 = &uStack_50;
  uStack_54 = 0;
  uStack_58 = 0;
  uStack_38 = 0;
  uStack_50 = 0;
  uStack_40 = 0;
  uStack_28 = 1;
  puStack_2c = &UNK_60016b7c;
  uStack_30 = 0x5000;
  puStack_3c = &uStack_68;
  uStack_44 = _DAT_60016b88;
  uStack_48 = *(undefined4 *)(_DAT_60016b8c + 4);
  iStack_4c = _DAT_60016b90 + 0x10000;
  iStack_34 = _DAT_60016b90;
  uStack_60 = 0x1000;
  puStack_5c = &UNK_60016b94;
  iStack_64 = _DAT_60016b90 + 0x3fc000;
  uStack_68 = 0;
  puStack_6c = &uStack_20;
  uStack_70 = _DAT_60016ba0;
  uStack_74 = _DAT_60016ba4;
  puStack_78 = &UNK_60016ba8;
  uStack_7c = _DAT_60016bc0;
  uVar1 = FUN_6001e0d8(&uStack_7c);
  func_0x60168578(&UNK_60016bc4,uVar1);
  return uVar1;
}

