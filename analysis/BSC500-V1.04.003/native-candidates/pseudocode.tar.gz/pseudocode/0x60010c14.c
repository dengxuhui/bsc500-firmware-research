
void FUN_60010c14(int param_1)

{
  FUN_6001b81c();
                    /* WARNING: Could not recover jumptable at 0x60010c26. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (**(code **)(**(int **)(param_1 + 4) + 8))();
  return;
}

