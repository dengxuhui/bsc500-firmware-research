
/* WARNING: Possible PIC construction at 0x60165446: Changing call to branch */
/* WARNING: Possible PIC construction at 0x6016545a: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60165488: Changing call to branch */
/* WARNING: Possible PIC construction at 0x601654e2: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60165260: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60165276: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60165304: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60165338: Changing call to branch */
/* WARNING: Possible PIC construction at 0x60165352: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x60165308) */
/* WARNING: Removing unreachable block (ram,0x60165314) */
/* WARNING: Removing unreachable block (ram,0x60165316) */
/* WARNING: Removing unreachable block (ram,0x6016527a) */
/* WARNING: Removing unreachable block (ram,0x60165286) */
/* WARNING: Removing unreachable block (ram,0x60165292) */
/* WARNING: Removing unreachable block (ram,0x6016529c) */
/* WARNING: Removing unreachable block (ram,0x601652aa) */
/* WARNING: Removing unreachable block (ram,0x601652ae) */
/* WARNING: Removing unreachable block (ram,0x601652b8) */
/* WARNING: Removing unreachable block (ram,0x601652c6) */
/* WARNING: Removing unreachable block (ram,0x6016531e) */
/* WARNING: Removing unreachable block (ram,0x6016532c) */
/* WARNING: Removing unreachable block (ram,0x60165336) */
/* WARNING: Removing unreachable block (ram,0x601652ca) */
/* WARNING: Removing unreachable block (ram,0x6016534a) */
/* WARNING: Removing unreachable block (ram,0x601652ce) */
/* WARNING: Removing unreachable block (ram,0x601652da) */
/* WARNING: Removing unreachable block (ram,0x601652e2) */
/* WARNING: Removing unreachable block (ram,0x601652f2) */
/* WARNING: Removing unreachable block (ram,0x60165302) */
/* WARNING: Removing unreachable block (ram,0x60165264) */
/* WARNING: Removing unreachable block (ram,0x6016537c) */
/* WARNING: Removing unreachable block (ram,0x60165274) */
/* WARNING: Removing unreachable block (ram,0x601654e6) */
/* WARNING: Removing unreachable block (ram,0x6016548c) */
/* WARNING: Removing unreachable block (ram,0x6016545e) */
/* WARNING: Removing unreachable block (ram,0x60165476) */
/* WARNING: Removing unreachable block (ram,0x6016547a) */
/* WARNING: Removing unreachable block (ram,0x6016548e) */
/* WARNING: Removing unreachable block (ram,0x601654a4) */
/* WARNING: Removing unreachable block (ram,0x601654b2) */
/* WARNING: Removing unreachable block (ram,0x601654ba) */
/* WARNING: Removing unreachable block (ram,0x601654f0) */
/* WARNING: Removing unreachable block (ram,0x601654c4) */
/* WARNING: Removing unreachable block (ram,0x6016549c) */
/* WARNING: Removing unreachable block (ram,0x601654ea) */
/* WARNING: Removing unreachable block (ram,0x601654ec) */
/* WARNING: Removing unreachable block (ram,0x60165480) */
/* WARNING: Removing unreachable block (ram,0x60165486) */
/* WARNING: Removing unreachable block (ram,0x6016544a) */
/* WARNING: Removing unreachable block (ram,0x60165522) */
/* WARNING: Removing unreachable block (ram,0x60165458) */
/* WARNING: Removing unreachable block (ram,0x6016533c) */
/* WARNING: Removing unreachable block (ram,0x60165342) */
/* WARNING: Removing unreachable block (ram,0x60165346) */
/* WARNING: Removing unreachable block (ram,0x60165356) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 *
FUN_60006ae4(uint param_1,int param_2,undefined4 param_3,int param_4,undefined4 param_5,
            undefined4 *param_6)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  uint *puVar4;
  int iVar5;
  uint *puVar6;
  int extraout_r1;
  undefined4 extraout_r2;
  undefined4 extraout_r2_00;
  uint uVar7;
  int *piVar8;
  int iVar9;
  undefined4 extraout_r3;
  undefined4 unaff_r4;
  uint uVar10;
  undefined4 *puVar11;
  uint *unaff_r5;
  uint *unaff_r6;
  uint uVar12;
  int *unaff_r7;
  undefined4 unaff_lr;
  char cVar13;
  char cVar14;
  undefined4 in_cr4;
  undefined4 uStack_b4;
  undefined1 auStack_b0 [100];
  undefined4 uStack_4c;
  undefined4 uStack_48;
  int iStack_44;
  uint *puStack_40;
  uint *puStack_3c;
  
  cVar14 = SBORROW4(param_1,8);
  cVar13 = (int)(param_1 - 8) < 0;
  uVar2 = uRam60006b5c;
  if (7 < param_1) goto LAB_60006b38;
  if (param_2 == 0) goto LAB_60006b42;
  if (param_4 == 0) {
    while( true ) {
      FUN_6016804c(uRam60006b68,uRam60006b60,0x20c);
      **(uint **)(extraout_r1 + 0xc) = (uint)unaff_r6;
      uVar2 = *(undefined4 *)(extraout_r1 + 0x10);
      piVar8 = *(int **)(extraout_r1 + 0x14);
      uStack_48 = *(undefined4 *)(extraout_r1 + 0x18);
      iStack_44 = *(int *)(extraout_r1 + 0x1c);
      unaff_r6 = *(uint **)(extraout_r1 + 0x20);
      puStack_3c = *(uint **)(extraout_r1 + 0x24);
      *puStack_3c = (uint)unaff_r6;
      if (cVar13 == cVar14) break;
LAB_60006b38:
      FUN_6016804c(uVar2,uRam60006b60,0x206);
LAB_60006b42:
      FUN_6016804c(uRam60006b6c,uRam60006b60,0x20b);
    }
    puVar11 = (undefined4 *)*piVar8;
    iVar5 = piVar8[1];
    iVar9 = piVar8[2];
    puVar11[1] = iVar5;
    iStack_44 = iStack_44 + 0x73;
    puVar11[1] = iVar5;
    puStack_40 = unaff_r6;
    ZeroBytes(auStack_b0,100);
    uStack_b4 = 1;
    FUN_6015ad48(_DAT_60006bec);
    uVar2 = _DAT_60006bf0;
    FUN_6015ad48(_DAT_60006bf0);
    func_0x601681f4(auStack_b0,_DAT_60006bf4,uVar2,iVar5,puVar11[5],puVar11[4],puVar11[3],puVar11[2]
                    ,puVar11[1],*puVar11);
    iVar5 = FUN_60166758(&uStack_4c,auStack_b0,0x12);
    if (((iVar5 == 0) && (iVar5 = FUN_60164ed8(uStack_4c,extraout_r2,iVar9,&uStack_b4), iVar5 == 0))
       && (iVar5 = FUN_601667bc(uStack_4c), iVar5 == 0)) {
      puVar11 = (undefined4 *)0x0;
    }
    else {
      puVar11 = (undefined4 *)0xffffffff;
    }
    return puVar11;
  }
  if (*piRam60006b64 == 0) {
    return (undefined4 *)0x0;
  }
  uVar2 = FUN_60166a64();
  FUN_6016750c();
  uVar3 = FUN_6000fffc(uVar2,param_1,param_2,param_3);
  uVar2 = FUN_60166a7c(param_1,param_2,0,uVar2);
  iVar5 = FUN_60163aac(uVar2,uVar3,param_5,param_4);
  if (iVar5 != 0) {
    puVar6 = *(uint **)(_DAT_60167598 + 0xbc);
    goto SUB_60167d14;
  }
  if (_DAT_60167598 == -8) {
    FUN_6016804c(_DAT_60165554,uRam6016553c,0x329);
LAB_6016550e:
    FUN_6016804c(uRam60165538,uRam6016553c,0x32a);
    uVar2 = _DAT_60165550;
    puVar4 = unaff_r5;
    puVar6 = unaff_r6;
  }
  else {
    iVar5 = FUN_601631fc();
    if (iVar5 != 3) goto LAB_6016550e;
    puVar4 = (uint *)FUN_60167d0c();
    iVar5 = FUN_60163ab8();
    uVar2 = _DAT_60165550;
    puVar6 = unaff_r6;
    if (iVar5 != 0) {
      puVar6 = (uint *)FUN_60167d0c();
      iVar5 = FUN_6015b3f4();
      uVar2 = uRam60165540;
      if (iVar5 == 0) goto SUB_60167d14;
    }
  }
  uVar3 = uRam6016553c;
  func_0x60168578(uVar2,uRam6016553c);
  FUN_6016804c(uRam60165544,uVar3,0x32f);
  iVar5 = *unaff_r7;
  *(uint **)unaff_r7[2] = puVar6;
  uVar7 = *puVar4;
  puVar11 = (undefined4 *)puVar4[2];
  uVar12 = puVar4[3];
  *(uint *)puVar4[4] = uVar12;
  uVar2 = *puVar11;
  uVar3 = puVar11[1];
  *(uint *)puVar11[2] = uVar12;
  uVar7 = (uint)(puVar4 + 5) | uVar7;
  *(undefined4 *)(iVar5 + 4) = uVar3;
  *unaff_r6 = (uint)unaff_r5;
  coprocessor_storelong(6,in_cr4,uVar7 - 0x14);
  iVar5 = FUN_60163ab8(iVar5,uVar2,extraout_r3,unaff_r4);
  uVar2 = _DAT_60165550;
  puVar6 = unaff_r5;
  if (iVar5 != 0) {
    puVar6 = (uint *)FUN_60167d0c();
    iVar5 = FUN_6015b3f4();
    uVar2 = uRam601653f0;
    if (iVar5 == 0) {
SUB_60167d14:
      bVar1 = (bool)isCurrentModePrivileged();
      if (bVar1) {
        enableIRQinterrupts(((uint)puVar6 & 1) == 1);
      }
      return puVar6;
    }
  }
  uVar3 = uRam601653e8;
  func_0x60168578(uVar2,uRam601653e8);
  FUN_6016804c(uRam601653ec,uVar3,0x29f);
  FUN_6016804c(_DAT_60165554,uRam601653e8,0x2a2);
  FUN_6016804c(uRam601653f8,uRam601653e8,0x2a3);
  iVar5 = FUN_6016804c(&UNK_60165404,uRam601653e8,0x2a7);
  *(char *)(iVar5 + 0x15) = (char)puVar6;
  *(uint **)(uVar7 + 0x20) = puVar6;
  iVar5 = iRam00000094;
  uVar10 = puVar6[5];
  puVar11 = *(undefined4 **)(uVar7 + 0x50);
  uVar7 = puVar6[1];
  *(undefined4 *)(uVar10 + 0x54) = extraout_r2_00;
  *(undefined1 *)(uVar10 + 0x14) = 0x74;
  *(uint *)(iVar5 + 0x54) = uVar7;
  uVar12 = *(uint *)(iVar5 + 0x14);
  *(uint *)(*(int *)(iVar5 + 0x14) + 0x14) = uVar7;
  uVar3 = uRam00000030;
  uVar7 = uRam0000002c;
  iVar5 = iRam00000028;
  uVar2 = uRam00000024;
  *puVar11 = uRam00000030;
  uVar7 = uVar7 | uVar12;
  *(undefined4 *)((uVar10 | 100) + 4) = uVar2;
  **(undefined4 **)(iVar5 + 8) = uVar3;
  *param_6 = param_5;
  uVar2 = *param_6;
  uVar3 = param_6[1];
  *(undefined4 *)param_6[2] = param_5;
  puVar11 = (undefined4 *)FUN_60122a50(uVar2,uVar3,unaff_r7,unaff_lr);
  if (puVar11 != (undefined4 *)0x0) {
    if (uVar7 == 3) {
      puVar11[2] = uVar2;
      return puVar11;
    }
    if (uVar7 == 2) {
      puVar11[1] = uVar2;
      return puVar11;
    }
    if (uVar7 == 1) {
      *puVar11 = uVar2;
      return puVar11;
    }
  }
  return puVar11;
}

