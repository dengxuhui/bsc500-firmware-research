
void FUN_6000e4b0(int param_1)

{
  undefined4 uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined1 auStack_f4 [20];
  undefined1 auStack_e0 [200];
  
  if (param_1 == 0) {
    return;
  }
  if (*(byte *)(param_1 + 0x24) - 1 < 4) {
    uVar1 = 4;
  }
  else {
    if (3 < *(byte *)(param_1 + 0x24) - 0xfc) {
      return;
    }
    uVar1 = 3;
  }
  ZeroBytes(auStack_f4,0xdc);
  iVar2 = FUN_6015f468();
  for (uVar4 = 0; (int)uVar4 < iVar2; uVar4 = uVar4 + 1) {
    ZeroBytes(auStack_f4,0xdc);
    iVar3 = FUN_6015f42c(uVar4 & 0xff,auStack_f4);
    if ((iVar3 != 0) && (iVar3 = FUN_6015f38c(auStack_e0), iVar3 == 0)) {
      FUN_6002709e(auStack_e0,uVar1);
      func_0x60027068(auStack_e0,uVar1);
    }
  }
  return;
}

