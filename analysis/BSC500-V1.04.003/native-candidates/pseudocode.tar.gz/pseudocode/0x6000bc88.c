
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000bc88(void)

{
  char *pcVar1;
  
  pcVar1 = _DAT_6000bcc0;
  if (*_DAT_6000bcc0 == '\0') {
    FUN_6002eb90();
    FUN_60010c78();
    FUN_6015d958(_DAT_6000bcc4,8);
    FUN_60010ccc();
    FUN_60010c84();
    FUN_600170f0(0x10);
    FUN_60010c68(_DAT_6000bcc8,_DAT_6000bccc);
    thunk_FUN_6001e644();
    *pcVar1 = '\x01';
  }
  return;
}

