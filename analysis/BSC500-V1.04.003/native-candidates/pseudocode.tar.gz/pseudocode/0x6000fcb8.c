
/* WARNING: Removing unreachable block (ram,0x6000fdca) */
/* WARNING: Removing unreachable block (ram,0x6000fe0e) */
/* WARNING: Removing unreachable block (ram,0x6000fe12) */
/* WARNING: Removing unreachable block (ram,0x6000fe14) */
/* WARNING: Removing unreachable block (ram,0x6000fe16) */
/* WARNING: Removing unreachable block (ram,0x6000fe38) */
/* WARNING: Removing unreachable block (ram,0x6000fe42) */
/* WARNING: Removing unreachable block (ram,0x6000fe44) */
/* WARNING: Removing unreachable block (ram,0x6000fe48) */

undefined4 * FUN_6000fcb8(void)

{
  byte bVar1;
  undefined4 uVar2;
  undefined4 *puVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  int extraout_r2;
  int extraout_r3;
  uint unaff_r4;
  int unaff_r6;
  int iVar7;
  int *unaff_r7;
  undefined8 uVar8;
  int in_stack_00000028;
  undefined1 uStack_27;
  undefined2 uStack_26;
  undefined1 uStack_24;
  undefined1 uStack_23;
  undefined2 uStack_20;
  undefined2 uStack_1e;
  
  uStack_26 = 5;
  uStack_27 = 0x32;
  iVar4 = func_0x60166f2c(uRam6000fd88);
  if (iVar4 == 0) {
    uVar8 = FUN_6016804c(0x6000fdd8,0x6000fdf0,0x10a);
    iVar4 = (int)((ulonglong)uVar8 >> 0x20);
    piVar6 = (int *)uVar8;
    if (extraout_r2 != 0) {
      *unaff_r7 = unaff_r6;
      *piVar6 = iVar4;
      *(uint *)(iVar4 + 0x34) = unaff_r4;
      piVar6 = (int *)0x64;
      unaff_r6 = *(int *)(unaff_r4 + 0x74);
    }
    *(char *)(unaff_r4 + 0x1c) = (char)piVar6;
    iVar5 = 0x3a;
    iVar4 = extraout_r3;
    do {
      *(int *)(unaff_r4 + 0x40) = iVar5;
      *(char *)(unaff_r6 + 0xd) = (char)unaff_r4;
      *(char *)(iVar4 + 1) = (char)unaff_r7;
      *(char *)(unaff_r4 + 9) = (char)iVar5;
      *(char *)(iVar4 + 1) = (char)unaff_r7;
      bVar1 = *(byte *)(iVar5 + 1);
      unaff_r4 = unaff_r4 >> 0x15;
      *(char *)(unaff_r4 + 0xd) = (char)unaff_r4;
      iVar5 = *(int *)(unaff_r4 + 0x54);
      *(uint *)(iVar5 + 0xc) = (uint)bVar1;
      iVar4 = in_stack_00000028;
    } while( true );
  }
  FUN_60164d4c(iVar4,uRam6000fd8c);
  iVar5 = func_0x60166e68(iVar4,3);
  if (iVar5 == 0) {
    FUN_60165124(iVar4,0x17,&uStack_24);
    func_0x60168578(0x6000fd90,uStack_20,uStack_1e,uStack_23);
  }
  FUN_60165124(iVar4,0x1b,&uStack_26);
  FUN_60165124(iVar4,0x1a,&uStack_27);
  iVar5 = iRam6000fdb8;
  func_0x60167ef4(iRam6000fdb8 + 0x28,0x6000fdbc,1,0);
  uVar2 = uRam6000fdc4;
  func_0x60134ac8(uRam6000fdc4,0,0x4b000);
  iVar7 = iVar5 + 0xc;
  FUN_60016e64(iVar7,uVar2,0,0x25800);
  puVar3 = puRam6000fdc8;
  FUN_60016e80(puRam6000fdc8);
  uVar2 = uRam6000fdcc;
  puVar3[3] = iVar7;
  puVar3[0x13] = iVar4;
  puVar3[10] = uVar2;
  puVar3[5] = uRam6000fdd0;
  *puVar3 = uRam6000fdd4;
  puVar3[4] = puVar3[4] | 2;
  FUN_600170bc(puVar3);
  FUN_60016ec4(puVar3);
  *(undefined4 **)(iVar5 + 4) = puVar3;
  return puVar3;
}

