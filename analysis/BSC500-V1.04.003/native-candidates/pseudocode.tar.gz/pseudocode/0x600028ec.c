
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_600028ec(void)

{
  int *piVar1;
  int iVar2;
  undefined *puStack_34;
  undefined1 auStack_30 [16];
  undefined4 uStack_20;
  undefined4 uStack_1c;
  
  ZeroBytes(auStack_30,0x20);
  uStack_1c = 0x2f;
  puStack_34 = &UNK_60002934;
  uStack_20 = 0x600;
  iVar2 = FUN_6011e4a8(0x20,4,0);
  piVar1 = _DAT_60002940;
  _DAT_60002940[1] = iVar2;
  iVar2 = FUN_601566b4(_DAT_60002944,0,&puStack_34);
  *piVar1 = iVar2;
  FUN_60156808();
  return *piVar1 != 0;
}

