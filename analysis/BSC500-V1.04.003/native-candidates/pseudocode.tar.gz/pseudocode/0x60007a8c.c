
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60007a8c(void)

{
  bool bVar1;
  
  do {
    ExclusiveAccess(_DAT_60007a94);
    bVar1 = (bool)hasExclusiveAccess(_DAT_60007a94);
  } while (!bVar1);
  *_DAT_60007a94 = 0;
  return 0;
}

