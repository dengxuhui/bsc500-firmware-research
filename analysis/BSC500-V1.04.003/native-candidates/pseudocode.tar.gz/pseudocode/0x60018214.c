
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_60018214(float param_1)

{
  char cVar1;
  
  if (0.0 <= param_1) {
    if (_UNK_600182b4 <= param_1) {
      cVar1 = '\x04';
      goto LAB_600182b0;
    }
    if (_UNK_600182b8 <= param_1) {
      cVar1 = '\x03';
      goto LAB_600182b0;
    }
    if (_UNK_600182bc <= param_1) {
      cVar1 = '\x02';
      goto LAB_600182b0;
    }
    if (30.0 <= param_1) {
      cVar1 = '\x01';
      goto LAB_600182b0;
    }
  }
  else {
    if (param_1 <= _UNK_600182c0) {
      cVar1 = -4;
      goto LAB_600182b0;
    }
    if (param_1 <= _UNK_600182c4) {
      cVar1 = -3;
      goto LAB_600182b0;
    }
    if (param_1 <= _UNK_600182c8) {
      cVar1 = -2;
      goto LAB_600182b0;
    }
    if (param_1 <= -30.0) {
      cVar1 = -1;
      goto LAB_600182b0;
    }
  }
  cVar1 = '\0';
LAB_600182b0:
  return (int)cVar1;
}

