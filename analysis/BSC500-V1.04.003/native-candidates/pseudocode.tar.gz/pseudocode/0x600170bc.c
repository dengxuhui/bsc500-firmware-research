
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600170bc(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = _DAT_600170cc;
  *(undefined4 *)(param_1 + 0x40) = _DAT_600170d0;
  *(undefined4 *)(param_1 + 0x44) = uVar1;
  *(undefined4 *)(param_1 + 0x48) = 0xac;
  return;
}

