
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

bool FUN_6000fa80(void)

{
  return *_DAT_6000fa90 == '\x01';
}

