
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

char * FUN_60010b64(void)

{
  char cVar1;
  char cVar2;
  int iVar3;
  char *pcVar4;
  int iVar5;
  undefined4 uVar6;
  char *extraout_r1;
  char *pcVar7;
  int unaff_r5;
  undefined4 unaff_r6;
  char *pcVar8;
  
  iVar3 = *(int *)(_DAT_60010b6c + 8);
  if (iVar3 == 0) {
    FUN_6016804c(_DAT_60166b60,uRam60166b58,0x1b5);
  }
  else {
    iVar5 = FUN_601631fc();
    if (iVar5 == 2) {
      if ((code *)*puRam60166b5c != (code *)0x0) {
        (*(code *)*puRam60166b5c)(iVar3);
      }
      uVar6 = FUN_60167d0c();
      if (*(int **)(iVar3 + 0x1c) == (int *)(iVar3 + 0x1c)) {
        *(short *)(iVar3 + 0x24) = *(short *)(iVar3 + 0x24) + 1;
        func_0x60167d14(uVar6);
      }
      else {
        FUN_6013a15a();
        func_0x60167d14(uVar6);
        func_0x60163a08();
      }
      return (char *)0x0;
    }
  }
  FUN_6016804c(uRam60166b54,uRam60166b58,0x1b6);
  **(undefined4 **)(unaff_r5 + 4) = unaff_r6;
  pcVar8 = (char *)(unaff_r5 + 0x1c);
  **(undefined4 **)(unaff_r5 + 0x18) = *(undefined4 *)(unaff_r5 + 0x14);
  do {
    pcVar8 = pcVar8 + 1;
    pcVar4 = pcVar8;
    pcVar7 = extraout_r1;
    do {
      cVar1 = *pcVar7;
      cVar2 = *pcVar4;
      if (cVar2 == '\0') break;
      pcVar4 = pcVar4 + 1;
      pcVar7 = pcVar7 + 1;
    } while (cVar2 == cVar1);
    pcVar4 = pcVar8;
    if ((cVar1 == '\0') || (pcVar4 = (char *)0x0, cVar2 == '\0')) {
      return pcVar4;
    }
  } while( true );
}

