
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60000ff4(int param_1,undefined4 *param_2,int param_3,undefined4 param_4)

{
  byte bVar1;
  undefined4 uVar2;
  undefined1 *puVar3;
  uint uVar4;
  int ***pppiVar5;
  undefined4 uVar6;
  int extraout_r1;
  undefined4 uVar7;
  undefined4 extraout_r1_00;
  uint uVar8;
  int iVar9;
  int extraout_r2;
  char extraout_r3;
  char *pcVar10;
  int ****ppppiVar11;
  char *pcVar12;
  int ****ppppiVar13;
  undefined4 *puVar14;
  ulonglong uVar15;
  int ***pppiStack_4c;
  int ***pppiStack_48;
  int iStack_44;
  int iStack_40;
  char *pcStack_3c;
  int iStack_38;
  undefined4 uStack_34;
  undefined4 uStack_30;
  undefined4 uStack_2c;
  
  uVar2 = uRam60001064;
  uVar6 = uRam60001060;
  param_3 = param_3 + 1;
  pcVar12 = (char *)(param_1 + 0x11c);
  do {
    pcVar10 = pcVar12;
    param_3 = param_3 + -1;
    if (param_3 == 0) {
      return ZEXT48(param_2) << 0x20;
    }
    iVar9 = 0x703;
    puVar14 = param_2 + 5;
    pcVar12 = pcVar10 + 0x18c;
    *(undefined4 *)(pcVar10 + 0x5c) = uVar2;
    *(undefined4 *)(pcVar10 + 0x60) = param_4;
    *(undefined4 *)(pcVar10 + 100) = uVar6;
    *(undefined4 **)(pcVar10 + -0xa4) = param_2;
    bVar1 = pcVar10[1];
    if (*pcVar10 == '\0') {
      iVar9 = 0x503;
    }
    if (bVar1 != 0) {
      iVar9 = iVar9 + 0x800;
    }
    iVar9 = FUN_6000194c(pcVar10 + 4,*param_2,iVar9,pcVar10 + -0x11c);
    param_2 = puVar14;
  } while (iVar9 == 0);
  FUN_6016804c(0x60001068,0x6000107c,0x363);
  iVar9 = iRam60001298;
  *puVar14 = pcVar12;
  *(int *)(pcVar10 + 0x1e0) = extraout_r2;
  pcVar10[0x1a1] = extraout_r3;
  *(byte *)(iVar9 + 0x11) = bVar1;
  iStack_40 = iVar9 + -0x20;
  *(char *)(extraout_r2 + extraout_r1) = (char)extraout_r2;
  pcVar10[0x19d] = (char)extraout_r2;
  iStack_38 = (int)*(short *)(pcVar12 + iStack_40);
  pcVar10[0x199] = (char)iStack_40;
  *(char *)(bVar1 + 9) = (char)extraout_r1;
  iStack_44 = (int)*(short *)(pcVar12 + iStack_40);
  uVar7 = *(undefined4 *)(iVar9 + 0x44);
  *(char *)(iVar9 + -0xf) = (char)uVar7;
  uStack_2c = uVar6;
  uStack_34 = uVar2;
  pppiStack_4c = (int ***)&pppiStack_4c;
  pppiStack_48 = (int ***)&pppiStack_4c;
  pcStack_3c = pcVar12;
  uStack_30 = param_4;
  uVar15 = FUN_60167d0c(0x3d);
  uVar4 = _DAT_60001154;
  puVar3 = _DAT_60001150;
  while ((ppppiVar13 = *(int *****)(puVar3 + 0x18), uVar8 = (uint)(uVar15 >> 0x20),
         ppppiVar13 != (int ****)(puVar3 + 0x18) &&
         (iVar9 = func_0x6016717c(), uVar8 = uVar4, (uint)(iVar9 - (int)ppppiVar13[6]) <= uVar4))) {
    ppppiVar11 = ppppiVar13 + -7;
    if (*(code **)(puVar3 + 4) != (code *)0x0) {
      (**(code **)(puVar3 + 4))(ppppiVar11);
    }
    FUN_6016374c(ppppiVar11);
    if (-1 < (int)((uint)*(byte *)((int)ppppiVar13 + -0xb) << 0x1e)) {
      *(byte *)((int)ppppiVar13 + -0xb) = *(byte *)((int)ppppiVar13 + -0xb) & 0xfe;
    }
    pppiStack_4c[1] = (int **)ppppiVar13;
    *ppppiVar13 = pppiStack_4c;
    ppppiVar13[1] = (int ***)&pppiStack_4c;
    *puVar3 = 1;
    pppiStack_4c = (int ***)ppppiVar13;
    func_0x60167d14((int)uVar15);
    (*(code *)ppppiVar13[2])(ppppiVar13[3]);
    if (*(code **)(puVar3 + 8) != (code *)0x0) {
      (**(code **)(puVar3 + 8))(ppppiVar11);
    }
    uVar15 = FUN_60167d0c();
    uVar6 = (undefined4)uVar15;
    *puVar3 = 0;
    if ((int ****)pppiStack_4c != &pppiStack_4c) {
      pppiVar5 = *ppppiVar13;
      pppiVar5[1] = (int **)ppppiVar13[1];
      *ppppiVar13[1] = (int **)pppiVar5;
      *ppppiVar13 = (int ***)ppppiVar13;
      ppppiVar13[1] = (int ***)ppppiVar13;
      bVar1 = *(byte *)((int)ppppiVar13 + -0xb);
      uVar15 = (ulonglong)CONCAT14(bVar1,uVar6) & 0x3ffffffff;
      if ((bVar1 & 3) == 3) {
        *(byte *)((int)ppppiVar13 + -0xb) = bVar1 & 0xfe;
        func_0x60167bd4(ppppiVar11);
        uVar15 = CONCAT44(extraout_r1_00,uVar6);
      }
    }
  }
  uVar6 = func_0x60167d14((int)uVar15,uVar8);
  return CONCAT44(uVar7,uVar6);
}

