
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60002a1c(void)

{
  int iVar1;
  
  InitializeBacklight();
  FUN_6016572c(_DAT_60002a50,1,_DAT_60002a54);
  FUN_6016572c(_DAT_60002a58,1,_DAT_60002a5c);
  FUN_6011694c(_DAT_60002a60,_DAT_60002a64);
  iVar1 = _DAT_60002a68;
  FUN_600040a4(_DAT_60002a68 + 0x54);
  *(undefined1 *)(iVar1 + 1) = 1;
  return;
}

