
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_6000e4f8(void)

{
  return *(undefined1 *)(_DAT_6000e500 + 2);
}

