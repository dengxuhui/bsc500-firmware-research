
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60010c84(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  
  FUN_6015d958(_DAT_60010cb0,0x14);
  puVar4 = (undefined4 *)FUN_601179cc();
  uVar3 = _DAT_60010cbc;
  uVar2 = _DAT_60010cb8;
  uVar1 = _DAT_60010cb4;
  if (puVar4 != (undefined4 *)0x0) {
    *puVar4 = _DAT_60010cc0;
    puVar4[1] = uVar3;
    puVar4[2] = uVar2;
    puVar4[3] = uVar1;
    return;
  }
  FUN_60163730(_DAT_60010cc4,_DAT_60010cc8,0x40);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

