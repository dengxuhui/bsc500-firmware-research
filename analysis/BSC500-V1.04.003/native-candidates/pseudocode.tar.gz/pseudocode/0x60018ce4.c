
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60018ce4(uint *param_1,uint param_2)

{
  bool bVar1;
  int iVar2;
  uint *puVar3;
  uint *puVar4;
  uint *puVar5;
  byte *pbVar6;
  uint uVar7;
  byte bVar8;
  byte bVar9;
  undefined2 uVar10;
  uint uVar11;
  uint uVar12;
  uint uVar13;
  uint uVar14;
  uint uVar15;
  bool bVar16;
  
  iVar2 = _DAT_60018cf4;
  if (param_1 == (uint *)0x0) {
    return (ulonglong)param_2 << 0x20;
  }
  uVar7 = 0x30;
  puVar3 = (uint *)(_DAT_60018cf4 + 0x30);
  uVar11 = (uint)puVar3 & 3;
  uVar12 = uVar11;
  if (uVar11 != 0) {
    bVar8 = (byte)*param_1;
    puVar5 = (uint *)((int)param_1 + 1);
    if (uVar11 < 3) {
      puVar5 = (uint *)((int)param_1 + 2);
      uVar12 = (uint)*(byte *)((int)param_1 + 1);
    }
    puVar4 = (uint *)(_DAT_60018cf4 + 0x31);
    *(byte *)puVar3 = bVar8;
    param_1 = puVar5;
    if (uVar11 < 2) {
      param_1 = (uint *)((int)puVar5 + 1);
      bVar8 = (byte)*puVar5;
    }
    uVar7 = uVar11 + 0x2c;
    puVar5 = puVar4;
    if (uVar11 < 3) {
      puVar5 = (uint *)(iVar2 + 0x32);
      *(byte *)puVar4 = (byte)uVar12;
    }
    puVar3 = puVar5;
    if (uVar11 < 2) {
      puVar3 = (uint *)((int)puVar5 + 1);
      *(byte *)puVar5 = bVar8;
    }
  }
  uVar11 = (uint)param_1 & 3;
  if (uVar11 != 0) {
    while( true ) {
      bVar8 = (byte)uVar12;
      if (uVar7 < 8) break;
      puVar5 = param_1 + 1;
      uVar11 = *param_1;
      param_1 = param_1 + 2;
      uVar12 = *puVar5;
      *puVar3 = uVar11;
      puVar3[1] = uVar12;
      puVar3 = puVar3 + 2;
      uVar7 = uVar7 - 8;
    }
    puVar5 = puVar3;
    puVar4 = param_1;
    if (-1 < (int)(uVar7 - 4)) {
      puVar4 = param_1 + 1;
      uVar11 = *param_1;
      puVar5 = puVar3 + 1;
      *puVar3 = uVar11;
    }
    bVar9 = (byte)uVar11;
    bVar1 = (uVar7 - 4 & 2) != 0;
    uVar7 = uVar7 << 0x1f;
    bVar16 = (int)uVar7 < 0;
    if (bVar1) {
      pbVar6 = (byte *)((int)puVar4 + 1);
      bVar9 = (byte)*puVar4;
      puVar4 = (uint *)((int)puVar4 + 2);
      bVar8 = *pbVar6;
    }
    puVar3 = puVar4;
    if (bVar16) {
      puVar3 = (uint *)((int)puVar4 + 1);
      uVar7 = (uint)(byte)*puVar4;
    }
    if (bVar1) {
      pbVar6 = (byte *)((int)puVar5 + 1);
      *(byte *)puVar5 = bVar9;
      puVar5 = (uint *)((int)puVar5 + 2);
      *pbVar6 = bVar8;
    }
    puVar4 = puVar5;
    if (bVar16) {
      puVar4 = (uint *)((int)puVar5 + 1);
      *(byte *)puVar5 = (byte)uVar7;
    }
    return CONCAT44(puVar3,puVar4);
  }
  uVar12 = 0;
  while (uVar11 = uVar7 - 0x20, 0x1f < uVar7) {
    uVar12 = param_1[1];
    uVar7 = param_1[2];
    uVar13 = param_1[3];
    *puVar3 = *param_1;
    puVar3[1] = uVar12;
    puVar3[2] = uVar7;
    puVar3[3] = uVar13;
    uVar12 = param_1[4];
    uVar7 = param_1[5];
    uVar13 = param_1[6];
    uVar14 = param_1[7];
    param_1 = param_1 + 8;
    puVar3[4] = uVar12;
    puVar3[5] = uVar7;
    puVar3[6] = uVar13;
    puVar3[7] = uVar14;
    puVar3 = puVar3 + 8;
    uVar7 = uVar11;
  }
  if ((uVar11 & 0x10) != 0) {
    uVar12 = *param_1;
    uVar13 = param_1[1];
    uVar14 = param_1[2];
    uVar15 = param_1[3];
    param_1 = param_1 + 4;
    *puVar3 = uVar12;
    puVar3[1] = uVar13;
    puVar3[2] = uVar14;
    puVar3[3] = uVar15;
    puVar3 = puVar3 + 4;
  }
  if ((int)(uVar7 << 0x1c) < 0) {
    uVar12 = *param_1;
    uVar13 = param_1[1];
    param_1 = param_1 + 2;
    *puVar3 = uVar12;
    puVar3[1] = uVar13;
    puVar3 = puVar3 + 2;
  }
  puVar4 = puVar3;
  puVar5 = param_1;
  if ((uVar11 & 4) != 0) {
    puVar5 = param_1 + 1;
    uVar12 = *param_1;
    puVar4 = puVar3 + 1;
    *puVar3 = uVar12;
  }
  uVar10 = (undefined2)uVar12;
  if ((uVar11 & 3) != 0) {
    bVar1 = (uVar11 & 2) != 0;
    uVar7 = uVar7 << 0x1f;
    bVar16 = (int)uVar7 < 0;
    puVar3 = puVar5;
    if (bVar1) {
      puVar3 = (uint *)((int)puVar5 + 2);
      uVar10 = (undefined2)*puVar5;
    }
    puVar5 = puVar3;
    if (bVar16) {
      puVar5 = (uint *)((int)puVar3 + 1);
      uVar7 = (uint)(byte)*puVar3;
    }
    puVar3 = puVar4;
    if (bVar1) {
      puVar3 = (uint *)((int)puVar4 + 2);
      *(undefined2 *)puVar4 = uVar10;
    }
    puVar4 = puVar3;
    if (bVar16) {
      puVar4 = (uint *)((int)puVar3 + 1);
      *(byte *)puVar3 = (byte)uVar7;
    }
    return CONCAT44(puVar5,puVar4);
  }
  return CONCAT44(puVar5,puVar4);
}

