
/* WARNING: Possible PIC construction at 0x60008582: Changing call to branch */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60008538(void)

{
  ushort uVar1;
  undefined2 uVar2;
  int iVar3;
  int iVar4;
  undefined *puVar5;
  uint uVar6;
  undefined4 extraout_r2;
  undefined4 extraout_r2_00;
  undefined4 uVar7;
  int extraout_r3;
  int extraout_r3_00;
  uint unaff_r4;
  uint uVar8;
  undefined1 *unaff_r5;
  int unaff_r6;
  undefined4 unaff_r7;
  undefined4 unaff_r8;
  undefined4 unaff_lr;
  int *piVar9;
  undefined1 auStack_50 [64];
  
  iVar3 = _DAT_600085b0;
  if (-1 < (int)((uint)*(byte *)(_DAT_600085b0 + 0x14) << 0x1b)) {
    return;
  }
  uVar8 = *(uint *)(_DAT_600085b4 + 4);
  iVar4 = FUN_6011f77c();
  if (iVar4 == 0) {
    if (*(char *)(iVar3 + 4) != '\0') {
      return;
    }
    *(uint *)(iVar3 + 0x1c) = uVar8;
    *(undefined1 *)(iVar3 + 4) = 1;
    puVar5 = &UNK_600085b8;
    uVar7 = extraout_r2;
    iVar4 = extraout_r3;
  }
  else {
    if (*(char *)(iVar3 + 4) != '\x01' || *(int *)(iVar3 + 0x1c) == 0) {
      *(undefined4 *)(iVar3 + 0x1c) = 0;
      *(undefined1 *)(iVar3 + 4) = 0;
      FUN_601488a0(2);
      return;
    }
    uVar8 = (uVar8 - *(int *)(iVar3 + 0x1c)) / 1000;
    func_0x60164dec(auStack_50,0x40,&UNK_600085e0,uVar8);
    FUN_60118b7c(auStack_50);
    unaff_lr = 0x60008587;
    puVar5 = &UNK_600085f4;
    uVar7 = extraout_r2_00;
    iVar4 = extraout_r3_00;
    unaff_r4 = uVar8;
    unaff_r5 = auStack_50;
    unaff_r6 = iVar3;
    register0x00000054 = (BADSPACEBASE *)auStack_50;
  }
  iVar3 = _DAT_60168628;
  *(undefined4 *)((int)register0x00000054 + -0x10) = unaff_lr;
  *(undefined4 *)((int)register0x00000054 + -0x14) = unaff_r8;
  *(undefined4 *)((int)register0x00000054 + -0x18) = unaff_r7;
  *(int *)((int)register0x00000054 + -0x1c) = unaff_r6;
  *(undefined1 **)((int)register0x00000054 + -0x20) = unaff_r5;
  *(uint *)((int)register0x00000054 + -0x24) = unaff_r4;
  piVar9 = (int *)((int)register0x00000054 + -0x28);
  *piVar9 = iVar4;
  *(uint *)((int)register0x00000054 + -0xc) = uVar8;
  *(undefined4 *)((int)register0x00000054 + -8) = uVar7;
  *(int *)((int)register0x00000054 + -4) = iVar4;
  if (*(int *)(_DAT_60168628 + 8) == 0) {
    *piVar9 = (int)((int)register0x00000054 + -0xc);
    if (*(int *)(_DAT_60168628 + 4) == 0) {
      uVar8 = FUN_6012ef90(_DAT_6016862c,0xff,puVar5,*piVar9);
      iVar4 = *(int *)(iVar3 + 4);
      if (iVar4 == 0) {
        FUN_60154ab4(_DAT_6016862c);
      }
      else {
        uVar1 = *(ushort *)(iVar4 + 0x20);
        *(ushort *)(iVar4 + 0x20) = uVar1 | 0x40;
        uVar6 = 0xff;
        if (uVar8 < 0xff) {
          uVar6 = uVar8;
        }
        FUN_6015ef88(iVar4,0,_DAT_6016862c,uVar6);
        *(ushort *)(*(int *)(iVar3 + 4) + 0x20) = uVar1;
      }
    }
    else {
      uVar2 = *(undefined2 *)(*(int *)(_DAT_60168628 + 4) + 0x20);
      iVar4 = FUN_6001a8b4();
      if ((iVar4 == 0) || (iVar4 = FUN_6015b3f4(), iVar4 != 0)) {
        uVar7 = _DAT_6016862c;
        uVar6 = FUN_6012ef90(_DAT_6016862c,0xff,puVar5,*piVar9);
        iVar4 = *(int *)(iVar3 + 4);
        *(ushort *)(iVar4 + 0x20) = (*(ushort *)(iVar4 + 0x20) & 0xf7bf) + 0x40;
        uVar8 = 0xff;
        if (uVar6 < 0xff) {
          uVar8 = uVar6;
        }
        FUN_6015ef88(iVar4,0,uVar7,uVar8);
        *(undefined2 *)(*(int *)(iVar3 + 4) + 0x20) = uVar2;
      }
      else {
        FUN_6001a8bc(puVar5,*piVar9);
      }
    }
  }
  return;
}

