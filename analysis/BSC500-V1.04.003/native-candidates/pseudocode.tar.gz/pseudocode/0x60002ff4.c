
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

longlong FUN_60002ff4(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int *piVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  undefined4 uVar5;
  int *piVar6;
  uint uVar7;
  
  if (param_1 != 0) {
    FUN_6015dfa8();
  }
  piVar1 = _DAT_600030d0;
  FUN_600f056e(_DAT_600030d0);
  iVar3 = _DAT_600030d8;
  iVar2 = _DAT_600030d4;
  piVar6 = (int *)0x0;
  if ((char)piVar1[0x1c] != '\0') {
    piVar6 = piVar1;
  }
  (**(code **)(*piVar6 + 0x24))
            (piVar6,2,_DAT_600030d8,_DAT_600030d8 + 0x2d400,0x200,_DAT_600030d4,param_4);
  piVar6 = (int *)0x0;
  if ((char)piVar1[0x1c] != '\0') {
    piVar6 = piVar1;
  }
  uVar5 = FUN_60004c44();
  uVar5 = FUN_60004b98(piVar6,uVar5);
  pcVar4 = _DAT_600030dc;
  *(undefined4 *)(_DAT_600030dc + 4) = uVar5;
  uVar5 = FUN_6015da70(&UNK_600030e0,1);
  *(undefined4 *)(pcVar4 + 8) = uVar5;
  FUN_60004b60(*(undefined4 *)(pcVar4 + 4),_DAT_600030e4);
  FUN_60004b28(*(undefined4 *)(pcVar4 + 4),_DAT_600030e8);
  piVar1 = _DAT_600030ec;
  FUN_600f056e(_DAT_600030ec);
  piVar6 = (int *)0x0;
  if ((char)piVar1[0x1c] != '\0') {
    piVar6 = piVar1;
  }
  (**(code **)(*piVar6 + 0x24))(piVar6,3,iVar3 + 0x200,_DAT_600030f0,0x200,iVar2 + 0x200);
  piVar6 = (int *)0x0;
  if ((char)piVar1[0x1c] != '\0') {
    piVar6 = piVar1;
  }
  uVar5 = FUN_60004c5c();
  uVar5 = FUN_60004c74(piVar6,uVar5);
  *(undefined4 *)(pcVar4 + 0xc) = uVar5;
  uVar7 = 0x18;
  uVar5 = FUN_60167f4a(&UNK_600030f4,_DAT_600030fc,0,0x800,0x18,10);
  *(undefined4 *)(pcVar4 + 0x10) = uVar5;
  FUN_60167f8c();
  while (*pcVar4 == '\0') {
    FUN_60167188(5);
  }
  return (ulonglong)uVar7 << 0x20;
}

