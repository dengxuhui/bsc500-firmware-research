
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000b590(void)

{
  *_DAT_6000b598 = 0;
  return;
}

