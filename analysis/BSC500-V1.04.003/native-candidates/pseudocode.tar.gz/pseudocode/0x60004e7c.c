
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60004e7c(void)

{
  undefined1 *puVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 auStack_54 [64];
  undefined4 uStack_14;
  
  uVar3 = 0;
  uStack_14 = 0;
  func_0x601681f4(auStack_54,&UNK_60004ef4,_DAT_60004f00);
  iVar2 = FUN_60166758(&uStack_14,auStack_54,1);
  puVar1 = _DAT_60004f08;
  if (iVar2 == 0) {
    *_DAT_60004f08 = 0;
    FUN_601667bc(uStack_14);
    func_0x601681f4(auStack_54,_DAT_60004f0c,_DAT_60004f00,_DAT_60004f10);
    iVar2 = FUN_60166758(&uStack_14,auStack_54,1);
    if (iVar2 == 0) {
      uVar3 = FUN_6016506c(uStack_14);
      *(undefined4 *)(puVar1 + 4) = uVar3;
      FUN_601667bc(uStack_14);
      uVar3 = 0;
      if (0x100000 < *(uint *)(puVar1 + 4)) {
        *(undefined2 *)(puVar1 + 1) = 0x101;
        uVar3 = 1;
      }
    }
  }
  else {
    *_DAT_60004f04 = 0;
    *_DAT_60004f08 = 1;
  }
  return uVar3;
}

