
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_600170f0(int param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  uint uVar3;
  uint uVar4;
  
  piVar1 = _DAT_60017130;
  if (*_DAT_60017130 != 0) {
    FUN_6015cc94(0);
    func_0x60160aa4(*piVar1);
  }
  uVar4 = param_1 * 0x2c;
  puVar2 = (undefined4 *)FUN_6015f71c(uVar4);
  *piVar1 = (int)puVar2;
  if (puVar2 == (undefined4 *)0x0) {
    FUN_60163730(&UNK_60017138,_DAT_60017158,0xa3);
                    /* WARNING: Bad instruction - Truncating control flow here */
    halt_baddata();
  }
  *_DAT_60017134 = (short)param_1;
  if (((uint)puVar2 & 3) != 0) {
    uVar3 = (uint)puVar2 & 3 | 0xfffffffc;
    for (; (uVar4 != 0 && (uVar3 != 0)); uVar3 = uVar3 + 1) {
      *(undefined1 *)puVar2 = 0;
      uVar4 = uVar4 - 1;
      puVar2 = (undefined4 *)((int)puVar2 + 1);
    }
  }
  for (; 0x20 < uVar4; uVar4 = uVar4 - 0x20) {
    ZeroBytes(puVar2,0x20);
    puVar2 = puVar2 + 8;
  }
  for (; 4 < uVar4; uVar4 = uVar4 - 4) {
    *puVar2 = 0;
    puVar2 = puVar2 + 1;
  }
  for (uVar3 = 0; uVar4 != uVar3; uVar3 = uVar3 + 1) {
    *(undefined1 *)((int)puVar2 + uVar3) = 0;
  }
  return;
}

