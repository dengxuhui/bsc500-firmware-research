
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60016c40(void)

{
  undefined1 *puVar1;
  int iVar2;
  
  iVar2 = FUN_60164940();
  puVar1 = _DAT_60016c64;
  *(undefined4 *)(_DAT_60016c64 + 0x10) = *(undefined4 *)(iVar2 + 0x10);
  FUN_6001e1be();
  FUN_6004c70c();
  func_0x6004c688();
  *puVar1 = 1;
  FUN_6014bc0c();
  puVar1[2] = 1;
  return;
}

