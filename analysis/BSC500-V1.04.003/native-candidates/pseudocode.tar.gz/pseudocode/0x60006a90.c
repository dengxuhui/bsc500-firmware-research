
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60006a90(void)

{
  code *pcVar1;
  code *pcVar2;
  
  FUN_6000a810();
  FUN_6000fe04();
  FUN_6000fbe8();
  FUN_6000a640();
  pcVar1 = _DAT_6000fadc;
  (*_DAT_6000fadc)(3,0,0);
  (*pcVar1)(1,0,0);
  pcVar2 = _DAT_6000fae0;
  (*_DAT_6000fae0)(1,0,0);
  (*pcVar2)(0,0,0);
  (*pcVar2)(3,0,0);
  (*pcVar2)(2,0,0);
  (*pcVar1)(2,0,0);
  (*(code *)0x20440)(5);
  return;
}

