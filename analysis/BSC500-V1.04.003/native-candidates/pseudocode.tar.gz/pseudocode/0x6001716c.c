
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_6001716c(void)

{
  int iVar1;
  
  iVar1 = _DAT_60017184;
  *(undefined1 *)(_DAT_60017184 + 0x36) = 0;
  *(undefined2 *)(iVar1 + 0x34) = 0x50;
  FUN_60160d64(4);
  return 0;
}

