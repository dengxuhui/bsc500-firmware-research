
int * FUN_60006e70(void)

{
  int *piVar1;
  undefined4 uVar2;
  
  piVar1 = (int *)FUN_60010c28();
  FUN_60010c14();
  uVar2 = FUN_60154888();
  (**(code **)(*piVar1 + 0x14))(piVar1,uVar2);
  return piVar1;
}

