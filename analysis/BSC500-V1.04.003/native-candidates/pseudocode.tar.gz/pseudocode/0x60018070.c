
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60018070(void)

{
  int iVar1;
  
  iVar1 = _DAT_60018094;
  if (*(int *)(_DAT_60018094 + 4) != 0) {
    FUN_601667bc();
    *(undefined4 *)(iVar1 + 4) = 0;
  }
  return;
}

