
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_60000cc8(void)

{
  undefined4 uVar1;
  undefined4 uVar2;
  int iVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  int iVar7;
  undefined4 in_r3;
  
  iVar3 = _DAT_60000fe4;
  uVar2 = _DAT_60000cd8;
  uVar1 = _DAT_60000cd4;
  *(undefined1 *)(_DAT_60000fe4 + 0x1c) = 0x12;
  ZeroBytes(iVar3 + 0x24,0x14,0x50000000,in_r3,in_r3);
  uVar6 = _DAT_60000ff0;
  uVar5 = _DAT_60000fec;
  uVar4 = _DAT_60000fe8;
  *(undefined4 *)(iVar3 + 0xd8) = uVar2;
  *(undefined4 *)(iVar3 + 0x38) = uVar6;
  *(undefined4 *)(iVar3 + 0x3c) = uVar5;
  *(undefined4 *)(iVar3 + 0x40) = uVar4;
  *(undefined4 *)(iVar3 + 0x54) = 0x50000000;
  for (iVar7 = 0; iVar7 != 0x20; iVar7 = iVar7 + 1) {
    *(undefined2 *)(iVar3 + iVar7 * 4 + 0x58) = 0xffff;
  }
  func_0x601637f8(_DAT_60000fe4,uVar1,3);
  return 0;
}

