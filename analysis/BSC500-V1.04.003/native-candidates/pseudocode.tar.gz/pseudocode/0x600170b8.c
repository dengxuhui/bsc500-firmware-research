
/* WARNING: Control flow encountered bad instruction data */
/* WARNING: Possible PIC construction at 0x6001e684: Changing call to branch */
/* WARNING: Removing unreachable block (ram,0x6001e688) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void thunk_FUN_6001e644(void)

{
  undefined1 *puVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  undefined4 uVar9;
  undefined4 uVar10;
  undefined4 *puVar11;
  
  puVar1 = _DAT_6001e6c0;
  FUN_6002eb20(_DAT_6001e6c0);
  uVar10 = _DAT_6001e6e4;
  uVar9 = _DAT_6001e6e0;
  uVar8 = _DAT_6001e6dc;
  uVar7 = _DAT_6001e6d8;
  uVar6 = _DAT_6001e6d4;
  uVar5 = _DAT_6001e6d0;
  uVar4 = _DAT_6001e6cc;
  uVar3 = _DAT_6001e6c8;
  uVar2 = _DAT_6001e6c4;
  *puVar1 = 0x30;
  *(undefined4 *)(puVar1 + 0x28) = uVar2;
  *(undefined4 *)(puVar1 + 8) = uVar8;
  *(undefined4 *)(puVar1 + 0xc) = uVar7;
  *(undefined4 *)(puVar1 + 0x10) = uVar6;
  *(undefined4 *)(puVar1 + 0x14) = uVar5;
  *(undefined4 *)(puVar1 + 0x18) = uVar4;
  *(undefined4 *)(puVar1 + 0x1c) = uVar3;
  *(undefined4 *)(puVar1 + 0x20) = uVar10;
  *(undefined4 *)(puVar1 + 0x24) = uVar9;
  puVar11 = (undefined4 *)FUN_601597fc(_DAT_6002eb44);
  if (puVar11 != (undefined4 *)0x0) {
    *puVar11 = puVar1;
    return;
  }
  FUN_60163730(&UNK_6002eb48,_DAT_6002eb5c,0x193);
                    /* WARNING: Bad instruction - Truncating control flow here */
  halt_baddata();
}

