
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_60003a74(void)

{
  *_DAT_60003a7c = 1;
  return;
}

