
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_6000e2cc(void)

{
  undefined4 uVar1;
  
  uVar1 = FUN_6011c240(&UNK_6000e2e0,_DAT_6000e2f0,3);
  *(undefined4 *)(_DAT_6000e2f4 + 0xc) = uVar1;
  return;
}

